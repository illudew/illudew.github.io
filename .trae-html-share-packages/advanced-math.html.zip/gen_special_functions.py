# -*- coding: utf-8 -*-
"""Generate special-functions.html with 8 chapters: 朗博W函数/伽马函数/高斯积分/菲涅尔积分/超几何函数/厄米多项式/椭圆积分/马丢函数."""
import json

FIG = {
"lambertw": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="14" y1="92" x2="232" y2="92" stroke="#475569" stroke-width="1.2"/>
<line x1="62" y1="12" x2="62" y2="150" stroke="#475569" stroke-width="1.2"/>
<path d="M46,132 C54,120 60,106 70,92 C84,72 108,60 144,52 C178,45 206,40 228,37" fill="none" stroke="#2563eb" stroke-width="2.2"/>
<circle cx="46" cy="132" r="2.6" fill="#2563eb"/>
<circle cx="62" cy="92" r="2.4" fill="#0f172a"/>
<line x1="46" y1="92" x2="46" y2="132" stroke="#cbd5e1" stroke-width="0.8" stroke-dasharray="3 3"/>
<text x="28" y="145" font-size="9" fill="#2563eb">-1/e</text>
<text x="50" y="86" font-size="9" fill="#0f172a">O</text>
<text x="222" y="106" font-size="10" fill="#64748b">x</text>
<text x="68" y="24" font-size="10" fill="#64748b">W</text>
<text x="118" y="122" font-size="10" fill="#2563eb">W0 主支</text>
<text x="24" y="28" font-size="9" fill="#64748b">W e^W = x</text>
<text x="92" y="150" font-size="9" fill="#64748b">单调递增，过原点</text>
</svg>''',
"lambert_branches": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="14" y1="80" x2="232" y2="80" stroke="#475569" stroke-width="1.2"/>
<line x1="122" y1="12" x2="122" y2="150" stroke="#475569" stroke-width="1.2"/>
<line x1="78" y1="16" x2="78" y2="150" stroke="#94a3b8" stroke-width="1" stroke-dasharray="4 3"/>
<path d="M78,128 C92,112 106,92 122,80 C152,62 184,54 214,50" fill="none" stroke="#2563eb" stroke-width="2.2"/>
<path d="M78,128 C88,140 104,148 120,150" fill="none" stroke="#7c3aed" stroke-width="2.2"/>
<circle cx="78" cy="128" r="2.8" fill="#0f172a"/>
<text x="52" y="146" font-size="9" fill="#0f172a">(-1/e,-1)</text>
<text x="184" y="44" font-size="10" fill="#2563eb">W0</text>
<text x="140" y="120" font-size="10" fill="#7c3aed">W-1</text>
<text x="38" y="24" font-size="9" fill="#94a3b8">x=-1/e</text>
<text x="20" y="70" font-size="9" fill="#64748b">分支点在 (-1/e,-1)</text>
</svg>''',
"lambert_series": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="12" y1="80" x2="232" y2="80" stroke="#475569" stroke-width="1"/>
<line x1="60" y1="14" x2="60" y2="150" stroke="#475569" stroke-width="1"/>
<circle cx="60" cy="80" r="58" fill="none" stroke="#2563eb" stroke-width="1.4" stroke-dasharray="5 3"/>
<circle cx="60" cy="80" r="2.4" fill="#0f172a"/>
<text x="64" y="74" font-size="9" fill="#0f172a">0</text>
<text x="110" y="34" font-size="9" fill="#2563eb">|x|=1/e</text>
<text x="18" y="140" font-size="9" fill="#64748b">收敛半径由奇点 x=-1/e 决定</text>
<text x="94" y="120" font-size="10" fill="#2563eb">W(x)=Σ (-n)^(n-1) x^n/n!</text>
<text x="96" y="136" font-size="9" fill="#64748b">n 从 1 到无穷</text>
</svg>''',
"lambert_app": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="20" y1="130" x2="230" y2="130" stroke="#475569" stroke-width="1.2"/>
<line x1="70" y1="12" x2="70" y2="145" stroke="#475569" stroke-width="1.2"/>
<path d="M78,126 C104,118 130,98 152,64 C164,46 172,34 178,22" fill="none" stroke="#2563eb" stroke-width="2.2"/>
<line x1="70" y1="60" x2="180" y2="60" stroke="#ef4444" stroke-width="1.6" stroke-dasharray="5 3"/>
<circle cx="150" cy="60" r="3" fill="#ef4444"/>
<line x1="150" y1="60" x2="150" y2="130" stroke="#94a3b8" stroke-width="0.8" stroke-dasharray="3 3"/>
<text x="184" y="52" font-size="9" fill="#ef4444">y=a</text>
<text x="132" y="144" font-size="9" fill="#64748b">x=W(a)</text>
<text x="176" y="34" font-size="10" fill="#2563eb">y=x e^x</text>
<text x="74" y="24" font-size="9" fill="#64748b">超越方程 x e^x=a</text>
</svg>''',
"gamma_plot": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="16" y1="104" x2="232" y2="104" stroke="#475569" stroke-width="1.2"/>
<line x1="152" y1="10" x2="152" y2="152" stroke="#475569" stroke-width="1.2"/>
<line x1="128" y1="10" x2="128" y2="150" stroke="#cbd5e1" stroke-width="1" stroke-dasharray="4 3"/>
<line x1="104" y1="10" x2="104" y2="150" stroke="#cbd5e1" stroke-width="1" stroke-dasharray="4 3"/>
<path d="M156,14 C164,60 172,84 186,88 C196,90 202,88 214,80 C224,73 228,68 232,64" fill="none" stroke="#7c3aed" stroke-width="2.2"/>
<path d="M128,20 C138,52 146,80 151,116 C153,132 154,142 154,150" fill="none" stroke="#7c3aed" stroke-width="2.2"/>
<path d="M104,22 C114,54 122,82 127,118 C129,134 130,144 130,150" fill="none" stroke="#7c3aed" stroke-width="2.2"/>
<circle cx="186" cy="90" r="2.4" fill="#0f172a"/>
<text x="176" y="100" font-size="8" fill="#0f172a">最小值0.885</text>
<text x="36" y="150" font-size="9" fill="#64748b">极点 0,-1,-2,…</text>
<text x="196" y="30" font-size="10" fill="#7c3aed">Γ(x)</text>
<text x="224" y="118" font-size="9" fill="#64748b">x</text>
</svg>''',
"beta_region": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="40" y1="130" x2="210" y2="130" stroke="#475569" stroke-width="1.2"/>
<line x1="40" y1="16" x2="40" y2="140" stroke="#475569" stroke-width="1.2"/>
<path d="M40,130 L190,130 L190,22 Z" fill="#ede9fe" stroke="#7c3aed" stroke-width="1.2"/>
<text x="112" y="120" font-size="9" fill="#7c3aed">t+u=1</text>
<text x="194" y="144" font-size="9" fill="#64748b">t</text>
<text x="28" y="24" font-size="9" fill="#64748b">u</text>
<text x="58" y="52" font-size="10" fill="#7c3aed">B(a,b)=∫t^(a-1)(1-t)^(b-1)dt</text>
<text x="30" y="152" font-size="9" fill="#64748b">化二重积分用极坐标求 Γ 乘积</text>
</svg>''',
"stirling": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="20" y1="132" x2="232" y2="132" stroke="#475569" stroke-width="1.2"/>
<line x1="44" y1="12" x2="44" y2="146" stroke="#475569" stroke-width="1.2"/>
<path d="M52,126 C90,110 130,84 176,50 C196,36 210,28 226,20" fill="none" stroke="#7c3aed" stroke-width="2.2"/>
<path d="M52,128 C90,112 130,86 176,52 C196,38 210,30 226,22" fill="none" stroke="#0ea5e9" stroke-width="1.8" stroke-dasharray="5 3"/>
<text x="150" y="40" font-size="9" fill="#7c3aed">ln n!</text>
<text x="150" y="56" font-size="9" fill="#0ea5e9">斯特林近似</text>
<text x="56" y="146" font-size="9" fill="#64748b">两条曲线在大 n 处几乎重合</text>
<text x="196" y="146" font-size="9" fill="#64748b">n</text>
</svg>''',
"gamma_reflection": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="16" y1="80" x2="232" y2="80" stroke="#475569" stroke-width="1.2"/>
<line x1="120" y1="10" x2="120" y2="152" stroke="#475569" stroke-width="1.2"/>
<line x1="60" y1="10" x2="60" y2="150" stroke="#cbd5e1" stroke-width="0.8" stroke-dasharray="3 3"/>
<line x1="180" y1="10" x2="180" y2="150" stroke="#cbd5e1" stroke-width="0.8" stroke-dasharray="3 3"/>
<path d="M64,80 C74,60 84,44 100,20" fill="none" stroke="#7c3aed" stroke-width="2"/>
<path d="M64,80 C74,100 84,116 100,140" fill="none" stroke="#7c3aed" stroke-width="2"/>
<path d="M140,20 C156,44 166,60 176,80" fill="none" stroke="#7c3aed" stroke-width="2"/>
<path d="M140,140 C156,116 166,100 176,80" fill="none" stroke="#7c3aed" stroke-width="2"/>
<text x="116" y="16" font-size="9" fill="#94a3b8">x=1</text>
<text x="52" y="150" font-size="9" fill="#94a3b8">x=0</text>
<text x="176" y="150" font-size="9" fill="#94a3b8">x=2</text>
<text x="122" y="98" font-size="10" fill="#7c3aed">Γ(x)Γ(1-x)=π/sinπx</text>
<text x="18" y="26" font-size="9" fill="#64748b">反射公式在整数处发散</text>
</svg>''',
"gaussian_bell": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="16" y1="126" x2="232" y2="126" stroke="#475569" stroke-width="1.2"/>
<line x1="120" y1="12" x2="120" y2="140" stroke="#475569" stroke-width="1.2"/>
<path d="M104,126 C104,88 112,40 120,20 C128,40 136,88 136,126 Z" fill="#0d9488" fill-opacity="0.14" stroke="none"/>
<path d="M40,126 C74,124 92,112 104,88 C112,72 116,40 120,20 C124,40 128,72 136,88 C148,112 166,124 200,126" fill="none" stroke="#0d9488" stroke-width="2.2"/>
<line x1="104" y1="126" x2="104" y2="88" stroke="#94a3b8" stroke-width="0.8" stroke-dasharray="3 3"/>
<line x1="136" y1="126" x2="136" y2="88" stroke="#94a3b8" stroke-width="0.8" stroke-dasharray="3 3"/>
<text x="96" y="140" font-size="9" fill="#64748b">-σ</text>
<text x="146" y="140" font-size="9" fill="#64748b">σ</text>
<text x="148" y="40" font-size="10" fill="#0d9488">e^(-x^2/2σ^2)</text>
<text x="34" y="152" font-size="9" fill="#64748b">68.3% 面积落在 ±σ 内</text>
</svg>''',
"gaussian_moment": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="16" y1="118" x2="232" y2="118" stroke="#475569" stroke-width="1.2"/>
<line x1="120" y1="12" x2="120" y2="140" stroke="#475569" stroke-width="1.2"/>
<path d="M44,30 C80,40 104,62 120,86 C136,62 160,40 196,30" fill="none" stroke="#0d9488" stroke-width="2.2"/>
<circle cx="120" cy="86" r="2.6" fill="#0f172a"/>
<text x="124" y="100" font-size="9" fill="#0f172a">M(0)=1</text>
<text x="150" y="46" font-size="10" fill="#0d9488">M(t)=e^(t^2/2)</text>
<text x="26" y="150" font-size="9" fill="#64748b">对 t 求导 n 次即得 n 阶矩</text>
<text x="196" y="132" font-size="9" fill="#64748b">t</text>
</svg>''',
"erf": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="16" y1="80" x2="232" y2="80" stroke="#475569" stroke-width="1.2"/>
<line x1="120" y1="12" x2="120" y2="148" stroke="#475569" stroke-width="1.2"/>
<line x1="16" y1="136" x2="232" y2="136" stroke="#94a3b8" stroke-width="0.8" stroke-dasharray="4 3"/>
<line x1="16" y1="24" x2="232" y2="24" stroke="#94a3b8" stroke-width="0.8" stroke-dasharray="4 3"/>
<path d="M28,140 C60,136 92,118 108,96 C114,86 118,80 120,80 C122,80 126,74 132,64 C148,42 180,26 212,22" fill="none" stroke="#0d9488" stroke-width="2.2"/>
<text x="170" y="38" font-size="9" fill="#94a3b8">erf(∞)=1</text>
<text x="170" y="150" font-size="9" fill="#94a3b8">-1</text>
<text x="126" y="70" font-size="10" fill="#0d9488">erf(x)</text>
<text x="20" y="152" font-size="9" fill="#64748b">奇函数，过原点斜率为 2/√π</text>
</svg>''',
"gaussian_2d": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="20" y1="80" x2="228" y2="80" stroke="#475569" stroke-width="1"/>
<line x1="120" y1="12" x2="120" y2="148" stroke="#475569" stroke-width="1"/>
<ellipse cx="120" cy="80" rx="88" ry="58" fill="none" stroke="#0d9488" stroke-width="1.2" stroke-dasharray="4 3"/>
<ellipse cx="120" cy="80" rx="62" ry="40" fill="none" stroke="#0d9488" stroke-width="1.4"/>
<ellipse cx="120" cy="80" rx="34" ry="22" fill="#0d9488" fill-opacity="0.14" stroke="#0d9488" stroke-width="1.6"/>
<circle cx="120" cy="80" r="2.4" fill="#0f172a"/>
<text x="146" y="46" font-size="9" fill="#0d9488">等几率椭圆</text>
<text x="24" y="24" font-size="10" fill="#0d9488">e^(-½ xᵀA x)</text>
<text x="20" y="152" font-size="9" fill="#64748b">A 的特征值决定椭圆长短轴</text>
</svg>''',
"fresnel_spiral": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="16" y1="80" x2="232" y2="80" stroke="#94a3b8" stroke-width="0.8" stroke-dasharray="4 3"/>
<line x1="120" y1="12" x2="120" y2="150" stroke="#94a3b8" stroke-width="0.8" stroke-dasharray="4 3"/>
<path d="M80,120 C108,104 132,92 132,80 C132,70 112,66 100,72 C88,78 96,94 118,100 C140,106 156,84 160,40" fill="none" stroke="#c2410c" stroke-width="2.2"/>
<circle cx="80" cy="120" r="2.6" fill="#c2410c"/>
<circle cx="160" cy="40" r="2.6" fill="#c2410c"/>
<text x="60" y="136" font-size="9" fill="#c2410c">(-½,-½)</text>
<text x="164" y="34" font-size="9" fill="#c2410c">(½,½)</text>
<text x="26" y="24" font-size="10" fill="#c2410c">科纽螺线</text>
<text x="62" y="152" font-size="9" fill="#64748b">弧长参数对应衍射屏坐标</text>
</svg>''',
"fresnel_curves": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="16" y1="100" x2="232" y2="100" stroke="#475569" stroke-width="1.2"/>
<line x1="32" y1="12" x2="32" y2="150" stroke="#475569" stroke-width="1.2"/>
<line x1="16" y1="64" x2="232" y2="64" stroke="#94a3b8" stroke-width="0.8" stroke-dasharray="4 3"/>
<path d="M32,100 C48,74 58,44 76,42 C96,40 104,66 116,78 C130,90 142,64 158,52 C176,40 190,62 206,68 C218,72 224,66 230,64" fill="none" stroke="#c2410c" stroke-width="2"/>
<path d="M32,100 C48,116 58,138 76,140 C96,142 104,120 116,110 C130,100 142,120 158,130 C176,140 194,126 210,118" fill="none" stroke="#ea580c" stroke-width="2" stroke-dasharray="5 3"/>
<text x="34" y="60" font-size="9" fill="#94a3b8">1/2</text>
<text x="148" y="44" font-size="9" fill="#c2410c">C(x)</text>
<text x="148" y="140" font-size="9" fill="#ea580c">S(x)</text>
<text x="196" y="152" font-size="9" fill="#64748b">x</text>
<text x="18" y="152" font-size="9" fill="#64748b">振荡趋于 1/2</text>
</svg>''',
"fresnel_diffraction": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="16" y1="80" x2="232" y2="80" stroke="#94a3b8" stroke-width="0.8" stroke-dasharray="4 3"/>
<rect x="96" y="16" width="6" height="46" fill="#475569"/>
<rect x="96" y="98" width="6" height="46" fill="#475569"/>
<line x1="24" y1="80" x2="96" y2="80" stroke="#c2410c" stroke-width="1.6"/>
<path d="M102,62 L200,40" stroke="#c2410c" stroke-width="1.2"/>
<path d="M102,98 L200,120" stroke="#c2410c" stroke-width="1.2"/>
<text x="34" y="72" font-size="9" fill="#c2410c">平面波</text>
<text x="146" y="30" font-size="9" fill="#64748b">边缘衍射</text>
<text x="100" y="152" font-size="9" fill="#64748b">菲涅耳区光强由 C,S 组合给出</text>
</svg>''',
"hypergeometric": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="30" y1="110" x2="228" y2="110" stroke="#475569" stroke-width="1.2"/>
<line x1="30" y1="12" x2="30" y2="150" stroke="#475569" stroke-width="1.2"/>
<path d="M30,110 C60,106 90,96 120,78 C150,58 180,32 196,18" fill="none" stroke="#be185d" stroke-width="2.2"/>
<line x1="190" y1="12" x2="190" y2="146" stroke="#94a3b8" stroke-width="1" stroke-dasharray="4 3"/>
<text x="176" y="152" font-size="9" fill="#94a3b8">z=1</text>
<text x="92" y="40" font-size="10" fill="#be185d">2F1(1,1;1;z)=1/(1-z)</text>
<text x="36" y="152" font-size="9" fill="#64748b">|z|&lt;1 收敛，z=1 处发散</text>
<text x="214" y="124" font-size="9" fill="#64748b">z</text>
</svg>''',
"kummer": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="30" y1="110" x2="228" y2="110" stroke="#475569" stroke-width="1.2"/>
<line x1="70" y1="12" x2="70" y2="150" stroke="#475569" stroke-width="1.2"/>
<path d="M30,104 C60,100 100,86 130,64 C158,44 180,28 206,18" fill="none" stroke="#be185d" stroke-width="2.2"/>
<path d="M30,106 C60,102 100,88 130,66 C158,46 180,30 206,20" fill="none" stroke="#f472b6" stroke-width="1.6" stroke-dasharray="5 3"/>
<text x="120" y="46" font-size="10" fill="#be185d">1F1(1;1;x)=e^x</text>
<text x="130" y="150" font-size="9" fill="#64748b">合流超几何的基本特例</text>
<text x="214" y="124" font-size="9" fill="#64748b">x</text>
</svg>''',
"hermite": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="16" y1="80" x2="232" y2="80" stroke="#475569" stroke-width="1.2"/>
<line x1="120" y1="12" x2="120" y2="150" stroke="#475569" stroke-width="1.2"/>
<line x1="30" y1="80" x2="210" y2="80" stroke="#0891b2" stroke-width="1.8"/>
<line x1="40" y1="118" x2="200" y2="42" stroke="#0ea5e9" stroke-width="1.8"/>
<path d="M50,30 C80,120 160,120 190,30" fill="none" stroke="#22d3ee" stroke-width="1.8"/>
<path d="M46,124 C70,26 96,26 120,80 C144,134 170,134 194,36" fill="none" stroke="#0891b2" stroke-width="1.6" stroke-dasharray="5 3"/>
<text x="196" y="72" font-size="9" fill="#0891b2">H0</text>
<text x="196" y="34" font-size="9" fill="#0ea5e9">H1</text>
<text x="92" y="24" font-size="9" fill="#22d3ee">H2</text>
<text x="176" y="146" font-size="9" fill="#64748b">H3</text>
<text x="20" y="152" font-size="9" fill="#64748b">n 次多项式，奇偶性与 n 一致</text>
</svg>''',
"hermite_rec": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<rect x="14" y="14" width="212" height="132" rx="8" fill="#f0fdfa" stroke="#a5f3fc"/>
<text x="28" y="42" font-size="11" fill="#0891b2">H0 = 1</text>
<text x="28" y="66" font-size="11" fill="#0891b2">H1 = 2x</text>
<text x="28" y="90" font-size="11" fill="#0891b2">H2 = 4x²-2</text>
<text x="28" y="114" font-size="11" fill="#0891b2">H3 = 8x³-12x</text>
<text x="132" y="42" font-size="9" fill="#64748b">H(n+1)=2xHn-2nH(n-1)</text>
<text x="132" y="62" font-size="9" fill="#64748b">Hn'=2nH(n-1)</text>
<text x="132" y="82" font-size="9" fill="#64748b">∫HmHn e^(-x^2)dx</text>
<text x="132" y="102" font-size="9" fill="#64748b">=√π 2^n n! δ(mn)</text>
<text x="24" y="140" font-size="9" fill="#94a3b8">递推关系给出多项式序列</text>
</svg>''',
"hermite_qho": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="16" y1="112" x2="232" y2="112" stroke="#475569" stroke-width="1.2"/>
<line x1="120" y1="12" x2="120" y2="150" stroke="#475569" stroke-width="1.2"/>
<path d="M30,24 C70,60 100,88 120,92 C140,88 170,60 210,24" fill="none" stroke="#94a3b8" stroke-width="1.4" stroke-dasharray="4 3"/>
<path d="M62,108 C84,58 104,44 120,44 C136,44 156,58 178,108" fill="none" stroke="#0891b2" stroke-width="1.8"/>
<path d="M56,110 C84,80 106,68 120,80 C134,92 158,70 184,110" fill="none" stroke="#0ea5e9" stroke-width="1.6"/>
<path d="M74,108 C94,84 108,64 120,64 C132,64 146,84 166,108" fill="none" stroke="#22d3ee" stroke-width="1.4"/>
<text x="150" y="36" font-size="9" fill="#94a3b8">势阱 ½x²</text>
<text x="128" y="56" font-size="9" fill="#0891b2">ψ0</text>
<text x="160" y="86" font-size="9" fill="#0ea5e9">ψ1</text>
<text x="98" y="60" font-size="9" fill="#22d3ee">ψ2</text>
<text x="22" y="152" font-size="9" fill="#64748b">节点数 = n，能级间隔 ℏω</text>
</svg>''',
"elliptic": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="30" y1="126" x2="228" y2="126" stroke="#475569" stroke-width="1.2"/>
<line x1="30" y1="12" x2="30" y2="146" stroke="#475569" stroke-width="1.2"/>
<path d="M30,96 C60,94 100,86 140,68 C170,50 195,30 214,18" fill="none" stroke="#4f46e5" stroke-width="2.2"/>
<path d="M30,96 C80,100 130,106 170,108 C190,109 205,110 214,110" fill="none" stroke="#818cf8" stroke-width="2" stroke-dasharray="5 3"/>
<line x1="214" y1="12" x2="214" y2="140" stroke="#94a3b8" stroke-width="0.8" stroke-dasharray="4 3"/>
<text x="202" y="150" font-size="9" fill="#94a3b8">k=1</text>
<text x="150" y="42" font-size="9" fill="#4f46e5">K(k)</text>
<text x="150" y="120" font-size="9" fill="#818cf8">E(k)</text>
<text x="24" y="140" font-size="9" fill="#64748b">k</text>
<text x="34" y="24" font-size="9" fill="#64748b">K 在 k→1 对数发散</text>
</svg>''',
"pendulum_elliptic": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="120" y1="16" x2="120" y2="60" stroke="#475569" stroke-width="1.2"/>
<line x1="120" y1="60" x2="172" y2="118" stroke="#4f46e5" stroke-width="2"/>
<circle cx="172" cy="118" r="8" fill="#4f46e5"/>
<path d="M120,120 A 46 46 0 0 1 186,72" fill="none" stroke="#94a3b8" stroke-width="1" stroke-dasharray="4 3"/>
<text x="176" y="66" font-size="9" fill="#94a3b8">θ0</text>
<text x="20" y="42" font-size="10" fill="#4f46e5">T=4√(L/g) K(sin(θ0/2))</text>
<text x="20" y="152" font-size="9" fill="#64748b">大摆角周期由第一类完全椭圆积分给出</text>
</svg>''',
"jacobi_sn": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="16" y1="80" x2="232" y2="80" stroke="#475569" stroke-width="1.2"/>
<line x1="30" y1="12" x2="30" y2="148" stroke="#475569" stroke-width="1.2"/>
<line x1="16" y1="30" x2="232" y2="30" stroke="#94a3b8" stroke-width="0.8" stroke-dasharray="4 3"/>
<line x1="16" y1="130" x2="232" y2="130" stroke="#94a3b8" stroke-width="0.8" stroke-dasharray="4 3"/>
<path d="M30,80 C44,20 60,20 74,80 C88,140 104,140 118,80 C132,20 148,20 162,80 C176,140 192,140 206,80 C216,38 224,34 230,44" fill="none" stroke="#4f46e5" stroke-width="2.2"/>
<text x="198" y="26" font-size="9" fill="#94a3b8">+1</text>
<text x="198" y="144" font-size="9" fill="#94a3b8">-1</text>
<text x="146" y="60" font-size="10" fill="#4f46e5">sn(u,k)</text>
<text x="84" y="154" font-size="9" fill="#64748b">周期 4K，双周期函数</text>
</svg>''',
"mathieu_stability": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<rect x="30" y="14" width="196" height="130" fill="#f0fdf4" stroke="#a7f3d0"/>
<line x1="30" y1="144" x2="226" y2="144" stroke="#475569" stroke-width="1.2"/>
<line x1="30" y1="14" x2="30" y2="144" stroke="#475569" stroke-width="1.2"/>
<path d="M30,144 L30,140 C70,136 130,128 196,118 L196,144 Z" fill="#059669" fill-opacity="0.16" stroke="#059669" stroke-width="1.2"/>
<path d="M30,130 L196,96 L196,74 L30,116 Z" fill="#059669" fill-opacity="0.16" stroke="#059669" stroke-width="1.2"/>
<path d="M30,86 C90,84 150,74 196,52 L196,44 C150,66 90,78 30,80 Z" fill="#059669" fill-opacity="0.14" stroke="#059669" stroke-width="1"/>
<text x="34" y="140" font-size="8" fill="#64748b">0</text>
<text x="34" y="126" font-size="8" fill="#64748b">1</text>
<text x="34" y="82" font-size="8" fill="#64748b">4</text>
<text x="218" y="140" font-size="9" fill="#64748b">q</text>
<text x="18" y="24" font-size="9" fill="#64748b">a</text>
<text x="136" y="136" font-size="9" fill="#059669">不稳定舌区</text>
<text x="58" y="30" font-size="9" fill="#64748b">Ince-Strutt 稳定图</text>
</svg>''',
"mathieu_ce": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="30" y1="120" x2="228" y2="120" stroke="#475569" stroke-width="1.2"/>
<line x1="30" y1="12" x2="30" y2="146" stroke="#475569" stroke-width="1.2"/>
<path d="M30,116 C70,112 130,104 200,92" fill="none" stroke="#059669" stroke-width="2"/>
<path d="M30,88 C70,88 130,92 200,104" fill="none" stroke="#10b981" stroke-width="2"/>
<path d="M30,52 C80,54 140,62 210,76" fill="none" stroke="#34d399" stroke-width="1.8" stroke-dasharray="5 3"/>
<text x="190" y="86" font-size="9" fill="#059669">b0</text>
<text x="190" y="118" font-size="9" fill="#10b981">a0</text>
<text x="186" y="56" font-size="9" fill="#34d399">a1</text>
<text x="34" y="26" font-size="9" fill="#64748b">a0≈-q²/2，b0≈q²/2</text>
<text x="112" y="154" font-size="9" fill="#64748b">特征值随 q 分离</text>
</svg>''',
"mathieu_mode": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="16" y1="80" x2="232" y2="80" stroke="#475569" stroke-width="1.2"/>
<line x1="30" y1="12" x2="30" y2="148" stroke="#475569" stroke-width="1.2"/>
<line x1="30" y1="30" x2="230" y2="30" stroke="#94a3b8" stroke-width="0.8" stroke-dasharray="4 3"/>
<line x1="30" y1="130" x2="230" y2="130" stroke="#94a3b8" stroke-width="0.8" stroke-dasharray="4 3"/>
<path d="M30,80 C50,26 70,26 90,80 C110,134 130,134 150,80 C170,26 190,26 210,80 C220,104 226,104 230,92" fill="none" stroke="#059669" stroke-width="2.2"/>
<text x="34" y="26" font-size="9" fill="#94a3b8">稳定</text>
<text x="34" y="146" font-size="9" fill="#94a3b8">不稳定</text>
<text x="146" y="60" font-size="10" fill="#059669">ce1(z,q)</text>
<text x="64" y="154" font-size="9" fill="#64748b">振荡解与指数增长解交替</text>
</svg>''',
}

TAG_LABEL = {"def":"定 义","thm":"定 理","der":"推 导","exa":"例 子","app":"应 用","his":"注 记","note":"备 注"}

CORE_FORMULAS = [
    ("朗博W函数定义", "W(x)\\,e^{W(x)} = x", "朗博W函数是 f(w)=w e^w 的反函数，满足定义式"),
    ("W 的隐函数导数", "\\frac{dW}{dx} = \\frac{W(x)}{x\\,(1+W(x))}", "对定义式两边求导消去 e^W 得到"),
    ("W 的等价恒等式", "e^{W(x)} = \\frac{x}{W(x)}", "由定义式直接变形，用于化简含 e^W 的表达式"),
    ("原点值", "W(0) = 0", "W 函数图像经过原点"),
    ("分支点值", "W\\!\\left(-\\tfrac1e\\right) = -1", "两实分支的分支点，也是 f 的极小值点"),
    ("欧米伽常数", "\\Omega = W(1) = 0.5671432904\\ldots", "方程 \\Omega e^{\\Omega}=1 的解，称欧米伽常数"),
    ("拉格朗日反转级数", "W(x) = \\sum_{n=1}^{\\infty} \\frac{(-n)^{n-1}}{n!}\\,x^{n}", "由拉格朗日反转公式得到的泰勒级数"),
    ("级数收敛半径", "R = \\frac1e", "由最靠近原点的支点 x=-1/e 决定"),
    ("大 x 渐近展开", "W(x) \\sim L_1 - L_2 + \\frac{L_2}{L_1},\\quad L_1=\\ln x,\\ L_2=\\ln\\ln x", "x→+∞ 时主支的双对数渐近"),
    ("W-1 渐近展开", "W_{-1}(x) \\sim \\ln(-x) - \\ln(-\\ln(-x))", "x→0⁻ 时次分支的对数渐近"),
    ("W 复合恒等式", "W\\!\\left(x\\,e^{x}\\right) = x\\quad (x\\ge -1)", "表明 e^x 的复合给出原变量"),
    ("x^x=a 的求解", "x = \\frac{\\ln a}{W(\\ln a)}", "取对数后用 W 解幂指方程"),
    ("树函数", "T(x) = -W(-x) = \\sum_{n\\ge1}\\frac{n^{n-1}}{n!}x^{n}", "有标号树的计数生成函数"),
    ("伽马函数积分定义", "\\Gamma(z) = \\int_0^{\\infty} t^{\\,z-1}e^{-t}\\,dt\\quad(\\Re z>0)", "欧拉第二类积分，是阶乘的解析延拓"),
    ("伽马递推关系", "\\Gamma(z+1) = z\\,\\Gamma(z)", "分部积分得到的核心函数方程"),
    ("阶乘特例", "\\Gamma(n+1) = n!\\quad(n=0,1,2,\\dots)", "伽马函数是阶乘的连续推广"),
    ("半整数特殊值", "\\Gamma\\!\\left(\\tfrac12\\right) = \\sqrt{\\pi}", "由高斯积分 t=u² 换元得到"),
    ("反射公式", "\\Gamma(z)\\,\\Gamma(1-z) = \\frac{\\pi}{\\sin\\pi z}", "欧拉反射公式，联系 z 与 1-z"),
    ("勒让德倍角公式", "\\Gamma(z)\\,\\Gamma\\!\\left(z+\\tfrac12\\right) = 2^{\\,1-2z}\\sqrt{\\pi}\\,\\Gamma(2z)", "倍增（duplication）公式"),
    ("维尔斯特拉斯乘积", "\\frac{1}{\\Gamma(z)} = z\\,e^{\\gamma z}\\prod_{n=1}^{\\infty}\\!\\left(1+\\frac{z}{n}\\right)e^{-z/n}", "将 1/Γ 表示为整函数的无穷乘积"),
    ("欧拉常数", "\\gamma = -\\Gamma'(1) = 0.5772156649\\ldots", "与伽马函数在 1 处导数相连"),
    ("贝塔函数定义", "B(a,b) = \\int_0^1 t^{\\,a-1}(1-t)^{\\,b-1}\\,dt", "欧拉第一类积分，要求 Re a,Re b>0"),
    ("贝塔与伽马关系", "B(a,b) = \\frac{\\Gamma(a)\\,\\Gamma(b)}{\\Gamma(a+b)}", "两类欧拉积分的桥梁"),
    ("贝塔函数对称性", "B(a,b) = B(b,a)", "换元 t→1-t 立即得到"),
    ("三角幂积分", "\\int_0^{\\pi/2}\\!\\sin^{2a-1}\\theta\\cos^{2b-1}\\theta\\,d\\theta = \\tfrac12 B(a,b)", "三角函数的幂积分化为贝塔函数"),
    ("斯特林公式", "n! \\sim \\sqrt{2\\pi n}\\,\\left(\\frac{n}{e}\\right)^{n}", "大 n 阶乘的主项近似"),
    ("斯特林级数", "\\ln n! = n\\ln n - n + \\tfrac12\\ln(2\\pi n) + \\frac{1}{12n} - \\frac{1}{360n^{3}} + \\cdots", "由欧拉-麦克劳林求和得到的渐近级数"),
    ("中心二项式系数", "\\binom{2n}{n} \\sim \\frac{4^{n}}{\\sqrt{\\pi n}}", "斯特林公式的经典推论"),
    ("高斯积分", "\\int_{-\\infty}^{\\infty} e^{-a x^{2}}\\,dx = \\sqrt{\\frac{\\pi}{a}}\\quad(a>0)", "全实轴高斯积分，极坐标法的标准结果"),
    ("半轴高斯积分", "\\int_0^{\\infty} e^{-a x^{2}}\\,dx = \\frac12\\sqrt{\\frac{\\pi}{a}}", "偶函数积分的直接推论"),
    ("带线性项高斯积分", "\\int_{-\\infty}^{\\infty} e^{-a x^{2}+b x}\\,dx = \\sqrt{\\frac{\\pi}{a}}\\,e^{\\,b^{2}/4a}", "配方后化为标准高斯积分"),
    ("高斯偶数阶矩", "\\langle x^{2n}\\rangle = \\frac{(2n-1)!!}{(2a)^{n}}", "奇阶矩为零，偶阶矩由求导递推"),
    ("高斯的傅里叶变换", "\\mathcal{F}\\!\\left[e^{-x^{2}/2}\\right](k) = \\sqrt{2\\pi}\\,e^{-k^{2}/2}", "高斯函数是傅里叶变换的不动点"),
    ("误差函数定义", "\\operatorname{erf}(x) = \\frac{2}{\\sqrt{\\pi}}\\int_0^{x} e^{-t^{2}}\\,dt", "高斯核的累积分布"),
    ("余误差函数", "\\operatorname{erfc}(x) = 1-\\operatorname{erf}(x)", "描述高斯分布的尾概率"),
    ("误差函数级数", "\\operatorname{erf}(x) = \\frac{2}{\\sqrt{\\pi}}\\sum_{n=0}^{\\infty}\\frac{(-1)^{n}x^{2n+1}}{n!\\,(2n+1)}", "逐项积分 e^{-t²} 的泰勒展开"),
    ("余误差函数渐近", "\\operatorname{erfc}(x) \\sim \\frac{e^{-x^{2}}}{x\\sqrt{\\pi}}\\quad(x\\to\\infty)", "大 x 时误差函数的尾部渐近"),
    ("多维高斯积分", "\\int_{\\mathbb{R}^n} e^{-\\frac12 \\mathbf{x}^{T}A\\mathbf{x}}\\,d^{n}x = \\frac{(2\\pi)^{n/2}}{\\sqrt{\\det A}}", "正定矩阵 A 上的高斯积分"),
    ("n 维球体积", "V_n(R) = \\frac{\\pi^{n/2}\\,R^{n}}{\\Gamma\\!\\left(\\frac n2+1\\right)}", "由高斯积分与球坐标积分联立得到"),
    ("n 维球表面积", "S_{n-1} = \\frac{2\\pi^{n/2}}{\\Gamma\\!\\left(\\frac n2\\right)}", "单位球面面积，n=2 时得 2π"),
    ("菲涅尔余弦积分", "C(x) = \\int_0^{x}\\cos\\!\\left(\\frac{\\pi t^{2}}{2}\\right)dt", "菲涅尔积分之一"),
    ("菲涅尔正弦积分", "S(x) = \\int_0^{x}\\sin\\!\\left(\\frac{\\pi t^{2}}{2}\\right)dt", "菲涅尔积分之二"),
    ("菲涅尔积分的复表示", "C(x)+iS(x) = \\frac{1+i}{2}\\,\\operatorname{erf}\\!\\left(\\frac{(1+i)\\sqrt{\\pi}\\,x}{2}\\right)", "用复误差函数统一表示两个菲涅尔积分"),
    ("菲涅尔积分极限值", "C(\\infty) = S(\\infty) = \\frac12", "科纽螺线两端趋向 (1/2,1/2)"),
    ("正弦平方积分", "\\int_0^{\\infty}\\sin(t^{2})\\,dt = \\sqrt{\\frac{\\pi}{8}}", "菲涅尔积分的直接推论"),
    ("菲涅尔余弦渐近", "C(x) \\sim \\frac12 - \\frac{\\sin(\\pi x^{2}/2)}{\\pi x}\\quad(x\\to\\infty)", "分部积分得到的大 x 渐近"),
    ("科纽螺线曲率", "\\kappa(t) = \\pi t", "弧长参数曲线 (C(t),S(t)) 的曲率"),
    ("超几何级数定义", "{}_{2}F_{1}(a,b;c;z) = \\sum_{n=0}^{\\infty}\\frac{(a)_n(b)_n}{(c)_n}\\,\\frac{z^{n}}{n!}", "高斯超几何级数，(|z|<1) 收敛"),
    ("高斯求和公式", "{}_{2}F_{1}(a,b;c;1) = \\frac{\\Gamma(c)\\Gamma(c-a-b)}{\\Gamma(c-a)\\Gamma(c-b)}", "在 z=1 处求值，条件 Re(c-a-b)>0"),
    ("超几何微分方程", "z(1-z)y''+\\left[c-(a+b+1)z\\right]y'-ab\\,y = 0", "以 z=0,1,∞ 为正则奇点"),
    ("指数指标方程", "\\rho(\\rho-1+c) = 0 \\Rightarrow \\rho = 0,\\ 1-c", "在 z=0 处的两个 Frobenius 指数"),
    ("欧拉变换", "{}_{2}F_{1}(a,b;c;z) = (1-z)^{c-a-b}{}_{2}F_{1}(c-a,c-b;c;z)", "连接 z 与 z 的欧拉变换"),
    ("普法夫变换", "{}_{2}F_{1}(a,b;c;z) = (1-z)^{-a}{}_{2}F_{1}\\!\\left(a,c-b;c;\\frac{z}{z-1}\\right)", "Pfaff 变换，实现变量有理替换"),
    ("对数初等情形", "{}_{2}F_{1}(1,1;2;z) = -\\frac{\\ln(1-z)}{z}", "超几何级数可退化为初等函数"),
    ("几何级数情形", "{}_{2}F_{1}(1,1;1;z) = \\frac{1}{1-z}", "最简单的超几何特例"),
    ("勒让德多项式表示", "P_n(x) = {}_{2}F_{1}\\!\\left(-n,n+1;1;\\frac{1-x}{2}\\right)", "勒让德多项式是超几何函数的特例"),
    ("切比雪夫多项式表示", "T_n(x) = {}_{2}F_{1}\\!\\left(-n,n;\\tfrac12;\\frac{1-x}{2}\\right)", "第一类切比雪夫多项式与超几何函数"),
    ("库默尔方程", "z\\,y''+(b-z)y'-a\\,y = 0", "合流超几何方程，z=0 为正则奇点"),
    ("合流超几何级数", "{}_{1}F_{1}(a;b;z) = \\sum_{n=0}^{\\infty}\\frac{(a)_n}{(b)_n}\\,\\frac{z^{n}}{n!}", "Kummer 级数，全平面收敛"),
    ("指数函数特例", "{}_{1}F_{1}(1;1;z) = e^{z}", "最基本的合流超几何特例"),
    ("拉盖尔多项式表示", "L_n^{(\\alpha)}(x) = \\binom{n+\\alpha}{n}{}_{1}F_{1}(-n;\\alpha+1;x)", "缔合拉盖尔多项式与 ₁F₁"),
    ("厄米多项式罗德里格斯公式", "H_n(x) = (-1)^{n}e^{x^{2}}\\frac{d^{n}}{dx^{n}}e^{-x^{2}}", "厄米多项式的紧凑定义"),
    ("厄米生成函数", "e^{\\,2xt-t^{2}} = \\sum_{n=0}^{\\infty} H_n(x)\\,\\frac{t^{n}}{n!}", "由生成函数可推出所有性质"),
    ("厄米三项递推", "H_{n+1}(x) = 2x\\,H_n(x) - 2n\\,H_{n-1}(x)", "相邻三个厄米多项式的关系"),
    ("厄米导数关系", "H_n'(x) = 2n\\,H_{n-1}(x)", "求导降低阶数"),
    ("厄米微分方程", "y'' - 2x\\,y' + 2n\\,y = 0", "厄米多项式满足的二阶方程"),
    ("厄米正交关系", "\\int_{-\\infty}^{\\infty} H_m(x)H_n(x)e^{-x^{2}}\\,dx = \\sqrt{\\pi}\\,2^{n}n!\\,\\delta_{mn}", "以高斯权重正交"),
    ("厄米显式展开", "H_n(x) = n!\\sum_{m=0}^{\\lfloor n/2\\rfloor}\\frac{(-1)^{m}(2x)^{n-2m}}{m!\\,(n-2m)!}", "由生成函数展开得到的显式表达"),
    ("谐振子能级", "E_n = \\left(n+\\tfrac12\\right)\\hbar\\omega", "量子谐振子的等间距能级"),
    ("谐振子波函数", "\\psi_n(x) = N_n\\,H_n(\\alpha x)\\,e^{-\\alpha^{2}x^{2}/2}", "定态波函数由厄米多项式构成"),
    ("升降算符对易关系", "[a,a^{\\dagger}] = 1", "玻色子代数，决定能级结构"),
    ("位置矩阵元", "\\langle m|x|n\\rangle = \\sqrt{\\frac{\\hbar}{2m\\omega}}\\left(\\sqrt{n}\\,\\delta_{m,n-1}+\\sqrt{n+1}\\,\\delta_{m,n+1}\\right)", "偶极跃迁选择定则 Δn=±1"),
    ("第一类完全椭圆积分", "K(k) = \\int_0^{\\pi/2}\\frac{d\\theta}{\\sqrt{1-k^{2}\\sin^{2}\\theta}}", "勒让德第一类完全椭圆积分"),
    ("第二类完全椭圆积分", "E(k) = \\int_0^{\\pi/2}\\sqrt{1-k^{2}\\sin^{2}\\theta}\\,d\\theta", "勒让德第二类完全椭圆积分"),
    ("第三类完全椭圆积分", "\\Pi(n,k) = \\int_0^{\\pi/2}\\frac{d\\theta}{(1-n\\sin^{2}\\theta)\\sqrt{1-k^{2}\\sin^{2}\\theta}}", "勒让德第三类完全椭圆积分"),
    ("椭圆积分特殊值", "K(0)=E(0)=\\frac{\\pi}{2},\\quad E(1)=1,\\quad K(1)=\\infty", "边界处的取值，K 在 k→1 对数发散"),
    ("不完全椭圆积分", "F(\\varphi,k) = \\int_0^{\\varphi}\\frac{d\\theta}{\\sqrt{1-k^{2}\\sin^{2}\\theta}}", "第一类不完全椭圆积分，K=F(π/2,k)"),
    ("算术几何平均公式", "K(k) = \\frac{\\pi}{2\\,\\mathrm{AGM}\\!\\left(1,\\sqrt{1-k^{2}}\\right)}", "用 AGM 快速计算完全椭圆积分"),
    ("模数余量关系", "k^{2}+k'^{2}=1,\\quad K(k)=\\frac{1}{k'}K\\!\\left(\\frac{k}{k'}\\right)", "余模数与模数变换（Landen）"),
    ("雅可比椭圆函数 sn", "u = \\int_0^{\\varphi}\\frac{d\\theta}{\\sqrt{1-k^{2}\\sin^{2}\\theta}},\\quad \\mathrm{sn}\\,u = \\sin\\varphi", "第一类椭圆积分的反函数"),
    ("雅可比恒等式", "\\mathrm{sn}^{2}u+\\mathrm{cn}^{2}u=1,\\quad k^{2}\\mathrm{sn}^{2}u+\\mathrm{dn}^{2}u=1", "sn,cn,dn 之间的基本恒等式"),
    ("sn 的周期", "\\mathrm{sn}(u+4K) = \\mathrm{sn}\\,u", "雅可比椭圆函数以 4K 为实周期"),
    ("单摆大角度周期", "T = 4\\sqrt{\\frac{L}{g}}\\,K\\!\\left(\\sin\\frac{\\theta_0}{2}\\right)", "振幅 θ0 的单摆精确周期"),
    ("椭圆弧长", "L = 4a\\,E(e),\\quad e=\\sqrt{1-\\frac{b^{2}}{a^{2}}}", "半轴 a,b 椭圆的周长由第二类椭圆积分给出"),
    ("马丢方程", "y'' + (a-2q\\cos 2z)\\,y = 0", "含周期系数的二阶线性方程"),
    ("马丢特征值", "a_n(q),\\ b_n(q)", "使方程存在 π 或 2π 周期解的参数对"),
    ("小 q 特征值展开", "a_n(q) = n^{2}+\\frac{q^{2}}{2(n^{2}-1)}+O(q^{4})\\quad(n\\ne1)", "微扰展开，相邻特征值间距随 q 增大"),
    ("马丢周期解", "\\mathrm{ce}_n(z,q),\\quad \\mathrm{se}_n(z,q)", "偶/奇 π 或 2π 周期解"),
    ("Floquet 解", "y(z) = e^{\\mu z}P(z),\\quad P(z+\\pi)=P(z)", "周期系数方程的解结构"),
    ("稳定性判据", "|\\operatorname{tr}M| \\le 2", "单值矩阵迹决定解有界（稳定）"),
    ("马丢函数正交性", "\\int_0^{2\\pi}\\mathrm{ce}_m(z,q)\\,\\mathrm{ce}_n(z,q)\\,dz = \\pi\\,\\delta_{mn}", "周期马丢函数构成正交系"),
    ("大 q 特征值渐近", "a_n(q) \\sim -2q + (2n+1)\\sqrt{q}+\\cdots", "q→+∞ 时的渐近展开"),
]

def js_escape(s):
    return s.replace("\\","\\\\").replace("`","\\`").replace("${","\\${")
def fix_lt_math(s):
    import re
    return re.sub(r"\$\$[\s\S]*?\$\$|\$[^$\n]*?\$", lambda m: m.group(0).replace("<", "&lt;"), s)
def defn(t, body): return f'<section class="la-kp-sec la-kp-def"><h5>定 义</h5><p><strong>{t}</strong></p>{body}</section>'
def thm(t, body): return f'<section class="la-kp-sec la-kp-thm"><h5>定 理 · {t}</h5>{body}</section>'
def der(body): return f'<section class="la-kp-sec la-kp-der"><h5>推 导</h5>{body}</section>'
def exa(body): return f'<section class="la-kp-sec la-kp-exa"><h5>例 子</h5>{body}</section>'
def app(body): return f'<section class="la-kp-sec la-kp-app"><h5>应 用</h5>{body}</section>'
def note(body): return f'<section class="la-kp-sec la-kp-note"><h5>备 注</h5>{body}</section>'
def fml(latex, caption=""):
    cap = f'<span class="note">{caption}</span>' if caption else ""
    return f'<div class="la-fml">$${latex}$$ {cap}</div>'
def p(txt): return f'<p>{txt}</p>'
def wrap(body): return f'<div class="la-kp">{body}</div>'

ch1_sections = [
{
"name": "1.1 朗博W函数的定义",
"color": "#2563eb",
"desc": "由 w e^w 的反函数引入 W 函数及其定义式",
"items": [
{"id":"sf1s1-1","name":"朗博W函数的定义","tags":["def","der"],"brief":"W 是 f(w)=w e^w 的反函数，满足 W e^W = x。",
 "fig":"lambertw","figCap":"朗博W函数主支 W0 的图像：过原点、单调递增，支点在 (-1/e,-1)",
 "body": wrap(
   defn("朗博W函数", p("函数 $f(w)=w\\,e^{w}$ 在区间 $[-1,+\\infty)$ 上严格单调，其反函数称为<strong>朗博W函数</strong>，记作 $W(x)$，定义为：")+
   fml("W(x)\\,e^{W(x)} = x","朗博W函数的定义式")+
   p("通常记严格凹区间上取 $W\\ge -1$ 的那一支为主支 $W_0$。"))+
   der(p("<strong>可逆性：</strong>先求 $f$ 的导数与单调性。对 $f(w)=w e^{w}$ 求导：")+
   fml("f'(w) = e^{w} + w\\,e^{w} = e^{w}(1+w)")+
   p("因 $e^{w}>0$，故 $f'(w)$ 的符号完全由 $1+w$ 决定。当 $w>-1$ 时 $f'(w)>0$，$f$ 严格递增；当 $w<-1$ 时 $f'(w)<0$，$f$ 严格递减。")+
   p("$f$ 在 $w=-1$ 取得全局极小值：")+
   fml("f(-1) = (-1)e^{-1} = -\\frac1e")+
   p("因此在 $w\\in[-1,\\infty)$ 上 $f$ 从 $-1/e$ 递增到 $+\\infty$，是一一映射，反函数 $W_0:[-1/e,\\infty)\\to[-1,\\infty)$ 存在。对 $w\\in(-\\infty,-1]$ 上的递减分支，反函数给出次支 $W_{-1}$。"))+
   note(p("「朗博」即 J. H. Lambert，他在研究三体问题与兰伯特四边形的年代已触及这一函数的雏形；现代符号 $W$ 由 Corless 等人于 1993 年系统确立。"))
 )},
{"id":"sf1s1-2","name":"隐函数求导与基本导数","tags":["thm","der"],"brief":"由定义式隐式求导得 dW/dx = W/(x(1+W))。",
 "body": wrap(
   thm("W 的导数", p("对定义式 $W e^{W}=x$ 两边关于 $x$ 求导，可解出：")+
   fml("\\frac{dW}{dx} = \\frac{W(x)}{x\\,(1+W(x))} = \\frac{e^{-W}}{1+W}"))+
   der(p("<strong>推导：</strong>把 $W=W(x)$ 看作 $x$ 的函数，对恒等式 $W e^{W}=x$ 两边求导。左边用乘积法则：")+
   fml("\\frac{d}{dx}\\left[W e^{W}\\right] = W' e^{W} + W\\,e^{W}W' = e^{W}(1+W)\\,W'")+
   p("右边为 $1$，于是：")+
   fml("e^{W}(1+W)\\,W' = 1 \\;\\Longrightarrow\\; W' = \\frac{1}{e^{W}(1+W)}")+
   p("再由定义式 $e^{W}=x/W$，代入消去 $e^{W}$：")+
   fml("W' = \\frac{1}{\\dfrac{x}{W}(1+W)} = \\frac{W}{x(1+W)}")+
   p("该式在 $x\\ne 0$ 且 $W\\ne -1$（即 $x\\ne -1/e$）处成立。"))+
   exa(p("<strong>例：</strong>求 $W$ 在原点的导数。因 $W(0)=0$，不能用 $W/x$ 直接代入，改用 $W'=e^{-W}/(1+W)$：")+
   fml("W'(0) = \\frac{e^{0}}{1+0} = 1")+
   p("与级数展开 $W(x)=x-x^{2}+\\cdots$ 的线性项一致。"))+
   note(p("注意 $W'$ 在 $x=-1/e$ 处发散，正对应图像竖直切线的支点。"))
 )},
{"id":"sf1s1-3","name":"数值求解与牛顿迭代","tags":["der","exa"],"brief":"用牛顿法逐步逼近 W 的数值，并算得欧米伽常数。",
 "body": wrap(
   exa(p("<strong>例（欧米伽常数）：</strong>解方程 $w e^{w}=1$ 即求 $\\Omega=W(1)$。取初值 $w_0=0.5$，按下面迭代公式得：")+
   fml("w_0=0.5,\\ w_1=0.5663,\\ w_2=0.567143,\\ \\Omega=0.5671432904\\ldots","欧米伽常数")+
   p("它是无量纲的数学常数，满足 $\\Omega = e^{-\\Omega}$。"))+
   der(p("<strong>牛顿迭代公式：</strong>设要求解 $g(w)=w e^{w}-x=0$。由牛顿法 $w_{n+1}=w_n-\\dfrac{g(w_n)}{g'(w_n)}$，而 $g'(w)=e^{w}(1+w)$，故：")+
   fml("w_{n+1} = w_n - \\frac{w_n e^{w_n}-x}{e^{w_n}(1+w_n)}")+
   p("化简分子分母，把 $w_n e^{w_n}$ 记为 $r_n$：")+
   fml("w_{n+1} = w_n - \\frac{r_n-x}{e^{w_n}+r_n}")+
   p("若把 $e^{w_n}$ 也按 $r_n=x$ 近似处理，则退化为 $w_{n+1}\\approx w_n-\\frac{w_n e^{w_n}-x}{e^{w_n}(1+w_n)}$，即常见的固定点形式。对主支取初值 $w_0=\\ln x$ 即可二次收敛。"))+
   note(p("牛顿法每步误差平方收敛，但对接近支点 $x\\to-1/e$ 的初值敏感，实际计算常改用 Halley 迭代或级数展开作初值。"))
 )},
]},
{
"name": "1.2 朗博W函数的性质与分支",
"color": "#1d4ed8",
"desc": "双实分支的结构、函数方程与特殊值",
"items": [
{"id":"sf1s2-1","name":"实分支 W0 与 W-1","tags":["def","der"],"brief":"实数域上 W 有两支，仅在 x≥-1/e 有定义。",
 "fig":"lambert_branches","figCap":"朗博W函数的两条实分支 W0（上）与 W-1（下），在 (-1/e,-1) 相遇",
 "body": wrap(
   defn("实分支", p("当 $x\\ge -1/e$ 时，方程 $w e^{w}=x$ 有两个实根（除支点外）：一个 $w\\ge -1$ 记作 $W_0(x)$（主支），另一个 $w\\le -1$ 记作 $W_{-1}(x)$（次支）。当 $-1/e<x<0$ 时两支都取实值。"))+
   der(p("<strong>两支的由来：</strong>由 1.1 节，$f(w)=w e^{w}$ 在 $w=-1$ 处取极小值 $-1/e$，且两侧分别严格单调。对给定水平线 $y=x$：")+
   fml("x > -\\frac1e \\Rightarrow \\text{与 } f \\text{ 交两点}","一支在 w>-1，一支在 w<-1")+
   p("于是同一 $x$ 对应两个 $w$，正是两个反函数分支。在支点处两根合并：")+
   fml("W_0\\!\\left(-\\tfrac1e\\right) = W_{-1}\\!\\left(-\\tfrac1e\\right) = -1")+
   p("当 $x<-1/e$ 时 $f(w)=x$ 无实根，$W$ 无实值。"))+
   note(p("作为复函数，$W$ 有无穷多个分支 $W_k$（$k\\in\\mathbb{Z}$），实轴上只有 $k=0$ 与 $k=-1$ 两支可见。"))
 )},
{"id":"sf1s2-2","name":"函数方程与复合恒等式","tags":["thm","der"],"brief":"W(x e^x)=x，e^W=x/W，幂的化简。",
 "body": wrap(
   thm("基本函数方程", p("对任意实数 $y\\ge -1$ 有 $W(y e^{y})=y$；对任意 $x>-1/e$ 有 $e^{W(x)}=x/W(x)$。更一般地：")+
   fml("W\\!\\left(x^{n}e^{nx}\\right) = x\\quad(n\\in\\mathbb{R},\\ x\\ge -1)"))+
   der(p("<strong>推导：</strong>把 $y e^{y}$ 作为 $W$ 的自变量代入定义式。由 $W(u)e^{W(u)}=u$，取 $u=y e^{y}$，则需找 $W(u)$ 使 $W e^{W}=y e^{y}$。显然 $W=y$ 是一解，且由主支唯一性即得：")+
   fml("W\\!\\left(y e^{y}\\right) = y")+
   p("对 $x^{n}e^{nx}=(x^{n})e^{x^{n}\\cdot n/x^{n}}$ 不易直接看出，改用 $\\left(x e^{nx}\\right)$ 的形式或用 $W$ 的乘法恒等式：由定义 $e^{W(x)}=x/W(x)$，故")+
   fml("W(x)\\,e^{W(x)}=x \\Rightarrow e^{W(x)}=\\frac{x}{W(x)}")+
   p("把它代入 $W\\!\\left(x^{n}e^{nx}\\right)$：若设 $W=x$，则左边为 $x e^{x}\\ne x^n e^{nx}$，所以对一般 $n$ 需直接验证 $n x\\,e^{nx}$ 中提出 $n$ 后仍成立，具体地令 $u=nx$ 得 $W(nx\\,e^{nx})=nx$，即 $W\\!\\left(x e^{nx}\\right)=x$ 乘以 $n$ 的缩放版本。"))+
   note(p("这些恒等式是解超越方程与化简迭代指数的关键工具。"))
 )},
{"id":"sf1s2-3","name":"特殊值与渐近行为","tags":["der","exa"],"brief":"W(1)=Ω，W(-1/e)=-1，大 x 双对数渐近。",
 "body": wrap(
   exa(p("<strong>例：</strong>几个常用特殊值：")+
   fml("W(0)=0,\\quad W(1)=\\Omega\\approx0.5671,\\quad W\\!\\left(-\\tfrac1e\\right)=-1,\\quad W(e)=1")+
   p("其中 $W(e)=1$ 由 $1\\cdot e^{1}=e$ 直接验证。"))+
   der(p("<strong>大 x 渐近：</strong>当 $x\\to+\\infty$ 时 $W\\to\\infty$。由定义式取对数：")+
   fml("\\ln W + W = \\ln x")+
   p("主项上 $W$ 增长慢于 $\\ln x$ 但快于常数，先取零级近似 $W\\approx\\ln x$。令 $L_1=\\ln x$，$L_2=\\ln\\ln x$，把 $W=L_1-\\eta$ 代入：")+
   fml("\\ln(L_1-\\eta)+(L_1-\\eta)=L_1")+
   p("即 $\\ln(L_1-\\eta)=\\eta$，故 $\\eta\\approx\\ln L_1=L_2$。于是：")+
   fml("W(x) = L_1 - L_2 + \\frac{L_2}{L_1} + O\\!\\left(\\frac{L_2^{2}}{L_1^{2}}\\right)","双对数渐近展开")+
   p("继续迭代可得到更精确的项。"))+
   note(p("对次支 $W_{-1}$，当 $x\\to 0^{-}$ 时 $W\\to-\\infty$，有 $W_{-1}(x)\\sim\\ln(-x)-\\ln(-\\ln(-x))$。"))
 )},
]},
{
"name": "1.3 朗博W函数的级数与渐近展开",
"color": "#3b82f6",
"desc": "拉格朗日反演给出泰勒级数，及大自变量的渐近级数",
"items": [
{"id":"sf1s3-1","name":"拉格朗日反演的泰勒级数","tags":["der"],"brief":"W(x)=Σ(-n)^(n-1)x^n/n!，收敛半径 1/e。",
 "fig":"lambert_series","figCap":"泰勒级数的收敛圆：半径 1/e 由支点 x=-1/e 决定",
 "body": wrap(
   der(p("<strong>拉格朗日反演定理：</strong>设 $w=f(z)$ 满足 $w=z\\,\\phi(w)$ 且 $\\phi(0)\\ne0$，则 $w$ 的泰勒系数为：")+
   fml("w = \\sum_{n=1}^{\\infty}\\frac{z^{n}}{n}\\left[\\frac{d^{\\,n-1}}{dw^{\\,n-1}}\\phi(w)^{n}\\right]_{w=0}")+
   p("现在把定义式改写为 $w=z\\,e^{-w}$ 的形式。由 $w e^{w}=x$ 得 $w=x\\,e^{-w}$，即 $z=x$，$\\phi(w)=e^{-w}$。于是：")+
   fml("\\phi(w)^{n} = e^{-nw}")+
   p("求其 $n-1$ 阶导数在 $w=0$ 的值：")+
   fml("\\frac{d^{\\,n-1}}{dw^{\\,n-1}}e^{-nw}\\Big|_{w=0} = (-n)^{n-1}")+
   p("代回反演公式：")+
   fml("W(x) = \\sum_{n=1}^{\\infty}\\frac{(-n)^{n-1}}{n!}\\,x^{n} = x - x^{2} + \\frac{3}{2}x^{3} - \\frac{8}{3}x^{4}+\\cdots")+
   p("前几项为 $x,-x^2,\\tfrac32x^3,-\\tfrac83x^4,\\tfrac{125}{24}x^5,\\dots$"))+
   note(p("收敛半径由最近的奇点 $x=-1/e$ 决定，即 $R=1/e$；在边界 $|x|=1/e$ 上级数条件收敛。"))
 )},
{"id":"sf1s3-2","name":"渐近展开的逐阶推导","tags":["der","thm"],"brief":"用对数迭代法得到 W 的双对数渐近级数。",
 "body": wrap(
   der(p("<strong>逐阶迭代：</strong>由 $\\ln W+W=\\ln x$ 出发，令 $L_1=\\ln x$、$L_2=\\ln\\ln x$。已知主项 $W\\sim L_1$，设 $W=L_1(1-\\delta)$，代入：")+
   fml("\\ln\\!\\left[L_1(1-\\delta)\\right] + L_1(1-\\delta) = L_1")+
   p("整理得 $\\ln L_1 + \\ln(1-\\delta)=L_1\\delta$。因 $\\delta\\ll1$，$\\ln(1-\\delta)\\approx-\\delta$：")+
   fml("\\ln L_1 - \\delta \\approx L_1\\delta \\;\\Longrightarrow\\; \\delta\\approx\\frac{\\ln L_1}{L_1} = \\frac{L_2}{L_1}")+
   p("于是得到第二阶：")+
   fml("W(x) = L_1 - L_2 + o(L_2)")+
   p("为得到 $L_2/L_1$ 项，再作修正 $W=L_1-L_2+\\eta$，重复同样的线性化步骤得到 $\\eta\\approx L_2/L_1$：")+
   fml("W(x) = L_1 - L_2 + \\frac{L_2}{L_1} + O\\!\\left(\\frac{L_2^{2}}{L_1^{2}}\\right)"))+
   thm("渐近性质", p("该展开是 $x\\to\\infty$ 的<strong>渐近级数</strong>而非收敛级数：对固定项数，误差随 $x\\to\\infty$ 趋于零，但固定 $x$ 时增加项数不收敛。"))+
   note(p("此展开在求解 $x=x_0\\ln x$ 型方程、分析迭代对数与计算二极管电压时非常实用。"))
 )},
{"id":"sf1s3-3","name":"收敛性与数值检验","tags":["exa","der"],"brief":"在 x=0.5 处级数与精确值对比，检验收敛速度。",
 "body": wrap(
   exa(p("<strong>例：</strong>用级数计算 $W(0.5)$。取前三项：")+
   fml("W(0.5)\\approx 0.5-0.25+\\frac{3}{2}(0.125) = 0.4375")+
   p("取前六项：$0.5-0.25+0.1875-0.1667+0.1563-0.15=0.2771$；精确值 $W(0.5)=0.3517$。可见当 $x$ 接近 $1/e\\approx0.368$ 时收敛很慢。"))+
   der(p("<strong>收敛速度：</strong>由比值判别法，通项 $a_n=\\frac{(-n)^{n-1}}{n!}x^{n}$，相邻项之比：")+
   fml("\\left|\\frac{a_{n+1}}{a_n}\\right| = \\frac{(n+1)^{n}}{(n+1)!}\\cdot\\frac{n!}{n^{n-1}}\\cdot|x| = \\left(1+\\frac1n\\right)^{n}\\frac{|x|}{n}\\cdot\\frac{n^{n}}{n^{n-1}}")+
   p("化简 $(1+1/n)^{n}\\to e$，并注意因子 $|x|\\cdot\\frac{(n+1)^{n}}{n!}\\cdot\\frac{n!}{n^{n-1}}=|x|\\,(n+1)(1+1/n)^{n-1}$，取极限得：")+
   fml("\\lim_{n\\to\\infty}\\left|\\frac{a_{n+1}}{a_n}\\right| = e\\,|x|")+
   p("故 $|x|<1/e$ 时级数绝对收敛，$|x|=1/e$ 时处于收敛边界。"))+
   note(p("因此在级数与渐近展开之间存在一条「分界线」：$|x|\\lesssim 1$ 用级数，$x\\gg1$ 用渐近展开，二者在 $x\\sim1$ 附近都需配合牛顿法。"))
 )},
]},
{
"name": "1.4 朗博W函数的应用",
"color": "#60a5fa",
"desc": "求解超越方程、指数迭代与物理规律",
"items": [
{"id":"sf1s4-1","name":"求解超越方程","tags":["der","app"],"brief":"x e^x=a、x^x=a、x+a^x=b 的闭式解。",
 "fig":"lambert_app","figCap":"用 W 求 x e^x=a 的解：曲线与水平线的交点横坐标为 W(a)",
 "body": wrap(
   der(p("<strong>型一 $x e^{x}=a$：</strong>这正是 W 的定义式，直接得：")+
   fml("x = W(a)","要求 a\\ge-1/e，否则无实解")+
   p("<strong>型二 $x^{x}=a$：</strong>取对数得 $x\\ln x=\\ln a$。作代换 $x=e^{u}$，则 $u e^{u}=\\ln a$：")+
   fml("u = W(\\ln a) \\;\\Longrightarrow\\; x = e^{W(\\ln a)} = \\frac{\\ln a}{W(\\ln a)}","利用了 e^W=\\ln a/W")+
   p("<strong>型三 $x+a^{x}=b$：</strong>设 $a^{x}=e^{x\\ln a}$，令 $t=x\\ln a$，则 $x=t/\\ln a$，方程化为 $t/\\ln a+e^{t}=b$，再令 $y=-(t-b\\ln a)/\\ln a$ 的类型可归入 $y e^{y}$ 形式，最终：")+
   fml("x = b - \\frac{1}{\\ln a}W\\!\\left(a^{b}\\ln a\\right)"))+
   app(p("这类方程广泛出现在：太阳电池与理想二极管的 <strong>Lambert W 解</strong>、人口增长的逻辑斯蒂修正、以及化学反应平衡浓度计算中。"))+
   note(p("使用 W 时须说明取哪一支：$W_0$ 给出物理上通常较小的正根，$W_{-1}$ 给出另一支（可能出现的不稳定根）。"))
 )},
{"id":"sf1s4-2","name":"迭代指数与树函数","tags":["der","app"],"brief":"无穷指数塔 E=x^{x^{x^{...}}} 的收敛值与有标号树计数。",
 "body": wrap(
   der(p("<strong>无穷指数塔：</strong>设 $E=x^{x^{x^{\\cdot^{\\cdot}}}}$，由自相似性 $E=x^{E}$。取对数：")+
   fml("\\ln E = E\\ln x \\;\\Longrightarrow\\; E\\,e^{-E\\ln x}=1")+
   p("令 $y=-E\\ln x$，则 $-y e^{-y}/\\ln x=1$，即 $y e^{y}=-\\ln x$，故：")+
   fml("E = -\\frac{W(-\\ln x)}{\\ln x}")+
   p("实值收敛要求 $-\\ln x\\ge -1/e$，即 $x\\le e^{1/e}\\approx1.4447$，这正是指数塔的<strong>收敛阈值</strong>。")+
   p("<strong>树函数：</strong>定义 $T(x)=-W(-x)$，由 W 的级数得：")+
   fml("T(x) = \\sum_{n\\ge1}\\frac{n^{n-1}}{n!}\\,x^{n}","有标号根树计数生成函数")+
   p("其中 $n^{n-1}$ 由 Cayley 公式给出 $n$ 个顶点的有标号树数目，而 $T$ 满足 $T=x e^{T}$。"))+
   app(p("迭代指数用于分析递推 $a_{n+1}=x^{a_n}$ 的收敛与动力系统；树函数用于随机图、分支过程与 WKB 展开的组合计数。"))+
   note(p("当 $x=e^{1/e}$ 时指数塔以极慢速度收敛，$E=e$；当 $x>e^{1/e}$ 时发散。"))
 )},
{"id":"sf1s4-3","name":"物理中的应用：维恩位移律","tags":["app","der"],"brief":"由 Planck 谱极值导出维恩位移律，常数含 W。",
 "body": wrap(
   app(p("朗博W函数在物理学中最漂亮的应用之一，是求解普朗克黑体辐射谱的极值，从而给出<strong>维恩位移律</strong>的精确形式。"))+
   der(p("<strong>谱极值条件：</strong>普朗克公式中谱辐射度正比于 $u^{3}/(e^{u}-1)$（$u=hc/\\lambda kT$）。对 $\\lambda$ 求极值等价于对 $u$ 求 $\\frac{d}{du}\\frac{u^{5}}{e^{u}-1}=0$，即：")+
   fml("\\frac{d}{du}\\left[\\frac{u^{5}}{e^{u}-1}\\right]=0 \\;\\Longrightarrow\\; 5(e^{u}-1)-u e^{u}=0")+
   p("整理得：")+
   fml("(5-u)\\,e^{u} = 5")+
   p("两边乘以 $-e^{-5}$ 并变形，使左边成为 $y e^{y}$ 的形式。令 $y=5-u$，则 $u=5-y$：")+
   fml("y\\,e^{5-y}=5 \\;\\Longrightarrow\\; y e^{-y} = 5e^{-5}")+
   p("再令 $\\zeta=-y$，得 $\\zeta e^{\\zeta}=-5e^{-5}$，因此 $\\zeta=W(-5e^{-5})$，从而：")+
   fml("u = 5 + W\\!\\left(-5e^{-5}\\right) \\approx 4.965114")+
   p("由于 $u=hc/\\lambda kT$，极值波长满足 $\\lambda_{\\max}T = hc/(u k)$，即维恩位移律，比例常数由上式精确给出。"))+
   note(p("此处应取主支 $W_0(-5e^{-5})$，因为 $-5e^{-5}\\in(-1/e,0)$ 且需要 $u$ 落在物理区间 $(0,5)$ 内，对应 $W_0$ 的值 $-0.0349$。"))
 )},
]},
]

ch2_sections = [
{
"name": "2.1 伽马函数的定义与积分表示",
"color": "#7c3aed",
"desc": "欧拉第二类积分、递推关系与解析延拓",
"items": [
{"id":"sf2s1-1","name":"伽马函数的积分定义","tags":["def","der"],"brief":"Γ(z)=∫t^(z-1)e^(-t)dt，是阶乘的解析延拓。",
 "fig":"gamma_plot","figCap":"Γ(x) 的实函数图像：在 0,-1,-2,… 处有单极点，x>0 时最小值约 0.885",
 "body": wrap(
   defn("伽马函数", p("对复变量 $z$（$\\Re z>0$），定义<strong>欧拉第二类积分</strong>：")+
   fml("\\Gamma(z) = \\int_0^{\\infty} t^{\\,z-1}e^{-t}\\,dt","伽马函数的积分定义")+
   p("它在右半平面解析，并可解析延拓为除 $z=0,-1,-2,\\dots$ 外处处亚纯的函数。"))+
   der(p("<strong>收敛性：</strong>把积分拆成 $\\int_0^1+\\int_1^{\\infty}$。在 $t\\to0^+$ 附近，$e^{-t}\\to1$，被积函数 $\\sim t^{\\,z-1}$，而：")+
   fml("\\int_0^1 t^{\\,\\Re z-1}\\,dt = \\frac{1}{\\Re z}\\ \\text{收敛} \\iff \\Re z>0")+
   p("在 $t\\to\\infty$ 处，指数衰减 $e^{-t}$ 远快于任意多项式增长 $t^{\\Re z-1}$，故：")+
   fml("\\int_1^{\\infty} t^{\\,\\Re z-1}e^{-t}\\,dt < \\int_1^{\\infty}t^{N}e^{-t}\\,dt < \\infty")+
   p("因此定义在 $\\Re z>0$ 上绝对收敛且解析。"))+
   note(p("用围道积分（Hankel 表示）可把定义延拓到全平面：$\\frac{1}{\\Gamma(z)}=\\frac{1}{2\\pi i}\\oint_C (-t)^{-z}e^{-t}dt$。"))
 )},
{"id":"sf2s1-2","name":"递推关系的推导","tags":["thm","der"],"brief":"分部积分得 Γ(z+1)=zΓ(z)。",
 "body": wrap(
   thm("函数方程", p("伽马函数满足：")+
   fml("\\Gamma(z+1) = z\\,\\Gamma(z)")+
   p("结合 $\\Gamma(1)=1$ 立刻得到 $\\Gamma(n+1)=n!$，故 $\\Gamma$ 是阶乘的连续插值。"))+
   der(p("<strong>分部积分：</strong>对 $\\Gamma(z+1)=\\int_0^{\\infty}t^{z}e^{-t}dt$ 取 $u=t^{z}$，$dv=e^{-t}dt$，则 $du=z t^{z-1}dt$，$v=-e^{-t}$：")+
   fml("\\Gamma(z+1) = \\Big[-t^{z}e^{-t}\\Big]_0^{\\infty} + z\\int_0^{\\infty}t^{\\,z-1}e^{-t}\\,dt")+
   p("边界项在 $\\Re z>0$ 时为零（$t\\to\\infty$ 由指数抑制，$t\\to0$ 由 $t^{z}\\to0$）：")+
   fml("\\Big[-t^{z}e^{-t}\\Big]_0^{\\infty} = 0")+
   p("于是：")+
   fml("\\Gamma(z+1) = z\\int_0^{\\infty}t^{\\,z-1}e^{-t}\\,dt = z\\,\\Gamma(z)"))+
   exa(p("<strong>例：</strong>反复使用递推：$\\Gamma(4)=3\\Gamma(3)=3\\cdot2\\Gamma(2)=6\\Gamma(1)=6=3!$，验证了阶乘关系。"))+
   note(p("递推关系还可反向使用 $\\Gamma(z)=\\Gamma(z+1)/z$ 把函数延拓到左半平面，并暴露出 $z=0,-1,\\dots$ 处的极点。"))
 )},
{"id":"sf2s1-3","name":"维尔斯特拉斯乘积与解析延拓","tags":["def","der"],"brief":"1/Γ 的无穷乘积表示及其推论。",
 "body": wrap(
   defn("维尔斯特拉斯乘积", p("把 $\\Gamma$ 的倒数表示为整函数的无穷乘积：")+
   fml("\\frac{1}{\\Gamma(z)} = z\\,e^{\\gamma z}\\prod_{n=1}^{\\infty}\\left(1+\\frac{z}{n}\\right)e^{-z/n}","γ 为欧拉常数")+
   p("等式右端是全平面解析的整函数，其零点恰为 $z=0,-1,-2,\\dots$。"))+
   der(p("<strong>推导思路：</strong>从欧拉极限出发。由 $\\Gamma(z)=\\lim_{n\\to\\infty}\\frac{n!\\,n^{z}}{z(z+1)\\cdots(z+n)}$，取倒数：")+
   fml("\\frac{1}{\\Gamma(z)} = \\lim_{n\\to\\infty}\\frac{z(z+1)\\cdots(z+n)}{n!\\,n^{z}}")+
   p("把乘积改写成连乘形式并提取指数：")+
   fml("\\frac{z(z+1)\\cdots(z+n)}{n!\\,n^{z}} = z\\prod_{k=1}^{n}\\left(1+\\frac{z}{k}\\right)n^{-z}")+
   p("利用 $n^{-z}=e^{-z\\ln n}$ 与 $\\ln n=\\sum_{k=1}^{n}\\frac1k-\\gamma+O(1/n)$，把 $e^{-z\\ln n}$ 分摊到各因子 $e^{-z/k}$ 上，取极限即得维尔斯特拉斯乘积。"))+
   exa(p("<strong>推论：</strong>在 $z=1$ 处：$\\frac{1}{\\Gamma(1)}=1\\cdot e^{\\gamma}\\prod(1+1/n)e^{-1/n}$，结合 $\\Gamma(1)=1$ 可反解出欧拉常数 $\\gamma$。"))+
   note(p("该乘积同时证明了 $\\Gamma$ 在正实轴上无零点，且 $1/\\Gamma$ 是整函数，这一性质在复分析中极为重要。"))
 )},
]},
{
"name": "2.2 递推关系与特殊值",
"color": "#6d28d9",
"desc": "半整数取值、欧拉反射公式与倍角公式",
"items": [
{"id":"sf2s2-1","name":"半整数与特殊值","tags":["der","exa"],"brief":"Γ(1/2)=√π，及由递推得到的半整数族。",
 "body": wrap(
   exa(p("<strong>例：</strong>$\\Gamma(2)=1!=1$，$\\Gamma(3)=2!=2$，$\\Gamma(1/2)=\\sqrt\\pi\\approx1.7725$，$\\Gamma(3/2)=\\tfrac12\\sqrt\\pi\\approx0.8862$。"))+
   der(p("<strong>推导 $\\Gamma(1/2)=\\sqrt\\pi$：</strong>在定义式中取 $z=1/2$ 并作换元 $t=u^{2}$，$dt=2u\\,du$：")+
   fml("\\Gamma\\!\\left(\\tfrac12\\right) = \\int_0^{\\infty} t^{-1/2}e^{-t}\\,dt = \\int_0^{\\infty}\\frac{e^{-u^{2}}}{u}\\cdot2u\\,du = 2\\int_0^{\\infty}e^{-u^{2}}du")+
   p("这正是高斯积分的一半，由 $\\int_{-\\infty}^{\\infty}e^{-u^2}du=\\sqrt\\pi$ 及偶性：")+
   fml("2\\int_0^{\\infty}e^{-u^{2}}du = \\int_{-\\infty}^{\\infty}e^{-u^{2}}du = \\sqrt{\\pi}")+
   p("于是 $\\Gamma(1/2)=\\sqrt\\pi$。再用递推得半整数族：")+
   fml("\\Gamma\\!\\left(n+\\tfrac12\\right) = \\frac{(2n-1)!!}{2^{n}}\\sqrt{\\pi}"))+
   note(p("$\\Gamma(1/2)$ 与高斯积分同源，是把 $\\pi$ 引入阶乘体系的关键一环。"))
 )},
{"id":"sf2s2-2","name":"欧拉反射公式","tags":["thm","der"],"brief":"Γ(z)Γ(1-z)=π/sin πz 的证明。",
 "fig":"gamma_reflection","figCap":"反射公式的右端 π/sin πx 在两整数处发散，与 Γ 的极点呼应",
 "body": wrap(
   thm("欧拉反射公式", p("对非整数 $z$ 有：")+
   fml("\\Gamma(z)\\,\\Gamma(1-z) = \\frac{\\pi}{\\sin\\pi z}")+
   p("尤其取 $z=1/2$ 得 $\\Gamma(1/2)^{2}=\\pi$，与前面的结果自洽。"))+
   der(p("<strong>推导：</strong>利用贝塔函数 $B(z,1-z)=\\Gamma(z)\\Gamma(1-z)/\\Gamma(1)$，先算 $B(z,1-z)$。按定义：")+
   fml("B(z,1-z) = \\int_0^{1} t^{\\,z-1}(1-t)^{\\,-z}\\,dt")+
   p("作换元 $t=\\frac{u}{1+u}$，则 $1-t=\\frac{1}{1+u}$，$dt=\\frac{du}{(1+u)^{2}}$，积分限由 $t\\in(0,1)$ 变为 $u\\in(0,\\infty)$：")+
   fml("B(z,1-z) = \\int_0^{\\infty}\\left(\\frac{u}{1+u}\\right)^{z-1}\\left(\\frac{1}{1+u}\\right)^{-z}\\frac{du}{(1+u)^{2}}")+
   p("化简各幂次：$u^{z-1}(1+u)^{-(z-1)}(1+u)^{z}(1+u)^{-2}=u^{z-1}(1+u)^{-1}$，故：")+
   fml("B(z,1-z) = \\int_0^{\\infty}\\frac{u^{\\,z-1}}{1+u}\\,du = \\frac{\\pi}{\\sin\\pi z}")+
   p("最后一步是标准定积分（可用留数定理或围道积分证明）。代回贝塔关系即得反射公式。"))+
   note(p("当 $z$ 为整数时 $\\sin\\pi z=0$，右端发散，对应 $\\Gamma$ 在整数处的极点。"))
 )},
{"id":"sf2s2-3","name":"勒让德倍角公式","tags":["thm","der"],"brief":"Γ(z)Γ(z+1/2)=2^(1-2z)√π Γ(2z)。",
 "body": wrap(
   thm("勒让德倍角公式", p("也称为倍增（duplication）公式：")+
   fml("\\Gamma(z)\\,\\Gamma\\!\\left(z+\\tfrac12\\right) = 2^{\\,1-2z}\\sqrt{\\pi}\\,\\Gamma(2z)")+
   p("它把 $2z$ 处的值用 $z$ 与 $z+1/2$ 的值表示。"))+
   der(p("<strong>推导（贝塔函数法）：</strong>考虑 $B(z,z)=\\Gamma(z)^{2}/\\Gamma(2z)$。由换元 $t=\\frac{1+u}{2}$ 把 $B(z,z)$ 写成对称形式：")+
   fml("B(z,z) = \\int_0^{1}t^{z-1}(1-t)^{z-1}dt = \\int_0^{1}\\left[t(1-t)\\right]^{z-1}dt")+
   p("用 $t=\\frac{1+s}{2}$ 消去线性项：$t(1-t)=\\frac{1-s^{2}}{4}$，$dt=\\frac{ds}{2}$：")+
   fml("B(z,z) = 2^{\\,1-2z}\\int_{-1}^{1}(1-s^{2})^{z-1}\\,ds = 2^{\\,2-2z}\\int_{0}^{1}(1-s^{2})^{z-1}ds")+
   p("再令 $s^{2}=w$，$ds=\\frac{w^{-1/2}}{2}dw$：")+
   fml("\\int_0^1(1-s^2)^{z-1}ds = \\frac12\\int_0^1 w^{-1/2}(1-w)^{z-1}dw = \\frac12 B\\!\\left(\\tfrac12,z\\right)")+
   p("于是 $B(z,z)=2^{1-2z}B(1/2,z)$。用贝塔-伽马关系把两边都化为伽马函数：")+
   fml("\\frac{\\Gamma(z)^{2}}{\\Gamma(2z)} = 2^{\\,1-2z}\\frac{\\Gamma(1/2)\\Gamma(z)}{\\Gamma(z+1/2)}")+
   p("约去一个 $\\Gamma(z)$ 并代入 $\\Gamma(1/2)=\\sqrt\\pi$，整理即得倍角公式。"))+
   note(p("倍角公式在计算 $\\Gamma(n+1/2)$、处理统计分布的归一化常数以及量子场论中的维数正规化时经常用到。"))
 )},
]},
{
"name": "2.3 贝塔函数及其与伽马函数的关系",
"color": "#8b5cf6",
"desc": "欧拉第一类积分、关系证明与三角积分应用",
"items": [
{"id":"sf2s3-1","name":"贝塔函数的定义","tags":["def","der"],"brief":"B(a,b)=∫₀¹ t^(a-1)(1-t)^(b-1)dt。",
 "fig":"beta_region","figCap":"贝塔函数对应的积分区域与变量替换",
 "body": wrap(
   defn("贝塔函数", p("对 $\\Re a>0,\\Re b>0$ 定义<strong>欧拉第一类积分</strong>：")+
   fml("B(a,b) = \\int_0^{1} t^{\\,a-1}(1-t)^{\\,b-1}\\,dt")+
   p("换元 $t\\to1-t$ 立即给出对称性 $B(a,b)=B(b,a)$。"))+
   der(p("<strong>另一种常用形式：</strong>令 $t=\\frac{u}{1+u}$，则 $1-t=\\frac{1}{1+u}$，$dt=\\frac{du}{(1+u)^{2}}$，积分限 $u:0\\to\\infty$：")+
   fml("B(a,b) = \\int_0^{\\infty}\\frac{u^{\\,a-1}}{(1+u)^{\\,a+b}}\\,du")+
   p("这一形式在解析延拓与围道积分中更方便。也能看出当 $a\\to0$ 或 $b\\to0$ 时积分发散，故要求正实部。"))+
   exa(p("<strong>例：</strong>$B(1,1)=\\int_0^1dt=1$；$B(2,1)=\\int_0^1 t\\,dt=\\tfrac12$；$B(2,2)=\\int_0^1t(1-t)dt=\\tfrac16$。"))+
   note(p("贝塔函数与组合学关系密切：$B(a,b)$ 的倒数常出现在二项式系数的连续插值中。"))
 )},
{"id":"sf2s3-2","name":"贝塔与伽马函数的关系","tags":["thm","der"],"brief":"证明 B(a,b)=Γ(a)Γ(b)/Γ(a+b)。",
 "body": wrap(
   thm("基本关系", p("对 $\\Re a,\\Re b>0$：")+
   fml("B(a,b) = \\frac{\\Gamma(a)\\,\\Gamma(b)}{\\Gamma(a+b)}"))+
   der(p("<strong>推导（极坐标法）：</strong>计算 $\\Gamma(a)\\Gamma(b)$ 的二重积分：")+
   fml("\\Gamma(a)\\Gamma(b) = \\int_0^{\\infty}\\!\\!\\int_0^{\\infty} s^{\\,a-1}t^{\\,b-1}e^{-(s+t)}\\,ds\\,dt")+
   p("作变量替换 $s=uv$，$t=u(1-v)$，其雅可比行列式为：")+
   fml("\\left|\\frac{\\partial(s,t)}{\\partial(u,v)}\\right| = \\begin{vmatrix} v & u \\\\ 1-v & -u\\end{vmatrix} = -uv-u(1-v) = -u")+
   p("绝对值 $|J|=u$，且 $s+t=u$，$s,t>0$ 对应 $u\\in(0,\\infty)$，$v\\in(0,1)$。代入：")+
   fml("\\Gamma(a)\\Gamma(b) = \\int_0^{\\infty}\\!\\!\\int_0^{1}(uv)^{a-1}\\left[u(1-v)\\right]^{b-1}e^{-u}\\,u\\,dv\\,du")+
   p("把 $u$ 与 $v$ 的因子分离：")+
   fml("= \\int_0^{\\infty} u^{\\,a+b-1}e^{-u}\\,du \\cdot \\int_0^{1} v^{\\,a-1}(1-v)^{\\,b-1}\\,dv = \\Gamma(a+b)\\,B(a,b)")+
   p("两边除以 $\\Gamma(a+b)$ 即得所证。"))+
   note(p("该关系是两类欧拉积分的桥梁：涉及贝塔函数的积分都可以翻译成伽马函数的乘积与商，从而便于计算与延拓。"))
 )},
{"id":"sf2s3-3","name":"三角幂积分与几何应用","tags":["app","der"],"brief":"用贝塔函数求 ∫sin^m cos^n，及球面/单纯形体积。",
 "body": wrap(
   app(p("贝塔函数最直接的应用是计算三角函数的高次幂积分，以及在几何中求高维区域的体积。"))+
   der(p("<strong>三角幂积分：</strong>令 $t=\\sin^{2}\\theta$，则 $dt=2\\sin\\theta\\cos\\theta\\,d\\theta$，$\\theta:0\\to\\pi/2$ 对应 $t:0\\to1$。于是：")+
   fml("\\int_0^{\\pi/2}\\sin^{2a-1}\\theta\\cos^{2b-1}\\theta\\,d\\theta = \\tfrac12\\int_0^1 t^{\\,a-1}(1-t)^{\\,b-1}dt = \\tfrac12 B(a,b)")+
   p("化为伽马函数即：")+
   fml("\\int_0^{\\pi/2}\\sin^{m}\\theta\\cos^{n}\\theta\\,d\\theta = \\frac{\\Gamma\\!\\left(\\frac{m+1}{2}\\right)\\Gamma\\!\\left(\\frac{n+1}{2}\\right)}{2\\,\\Gamma\\!\\left(\\frac{m+n+2}{2}\\right)}")+
   p("<strong>几何应用：</strong>用同一替换计算单位单纯形余体积，可导出 $\\int_0^1\\!\\cdots\\!\\int_0^1$ 型积分的伽马表达，进而得到 $n$ 维球体积 $V_n=\\pi^{n/2}/\\Gamma(n/2+1)$。"))+
   exa(p("<strong>例：</strong>$\\int_0^{\\pi/2}\\sin^{2}\\theta\\,d\\theta=\\frac{\\Gamma(3/2)\\Gamma(1/2)}{2\\Gamma(2)}=\\frac{(\\sqrt\\pi/2)\\sqrt\\pi}{2}=\\frac{\\pi}{4}$，与直接积分一致。"))+
   note(p("贝塔函数还用于 $\\beta$ 分布、$t$ 分布、Dirichlet 分布的归一化，以及弦论中的 Veneziano 振幅 $B(-\\alpha(s),-\\alpha(t))$。"))
 )},
]},
{
"name": "2.4 斯特林公式与渐近展开",
"color": "#a855f7",
"desc": "阶乘的对数渐近、误差项与推导",
"items": [
{"id":"sf2s4-1","name":"斯特林公式","tags":["thm","der"],"brief":"n! ~ √(2πn)(n/e)^n 的鞍点推导。",
 "fig":"stirling","figCap":"ln n! 与斯特林近似曲线在大 n 处几乎重合",
 "body": wrap(
   thm("斯特林公式", p("当 $n\\to\\infty$：")+
   fml("n! \\sim \\sqrt{2\\pi n}\\,\\left(\\frac{n}{e}\\right)^{n}")+
   p("等价的误差估计为 $n! = \\sqrt{2\\pi n}(n/e)^{n}\\left[1+\\frac{1}{12n}+O(n^{-2})\\right]$。"))+
   der(p("<strong>鞍点法推导：</strong>由 $n!=\\Gamma(n+1)=\\int_0^{\\infty}t^{n}e^{-t}dt$。把被积函数写成指数形式：")+
   fml("t^{n}e^{-t} = e^{\\,n\\ln t - t} = e^{\\,n(\\ln t - t/n)}")+
   p("被积函数的峰值由 $\\frac{d}{dt}(\\ln t-t/n)=\\frac1t-\\frac1n=0$ 给出，即 $t=n$。令 $t=n+s$，对指数在 $s=0$ 附近展开：")+
   fml("\\ln(n+s)-\\frac{n+s}{n} = \\ln n - \\frac{s^{2}}{2n^{2}}\\cdot n + \\cdots = \\ln n -1 - \\frac{s^{2}}{2n}+\\cdots")+
   p("于是被积函数 $\\approx e^{n\\ln n-n}\\,e^{-s^{2}/(2n)}=n^{n}e^{-n}e^{-s^{2}/(2n)}$。把它对 $s\\in(-\\infty,\\infty)$ 积分（高斯积分）：")+
   fml("\\int_{-\\infty}^{\\infty}e^{-s^{2}/(2n)}\\,ds = \\sqrt{2\\pi n}")+
   p("合并得：")+
   fml("n! \\sim n^{n}e^{-n}\\sqrt{2\\pi n}"))+
   note(p("鞍点法（也称最陡下降法）把阶乘估计转化为局部高斯积分，是渐近分析的核心技巧，也可推广到复平面上的围道积分。"))
 )},
{"id":"sf2s4-2","name":"斯特林级数与误差项","tags":["der"],"brief":"用欧拉-麦克劳林公式给出 1/(12n) 等修正项。",
 "body": wrap(
   der(p("<strong>欧拉-麦克劳林求和：</strong>把 $\\ln n!=\\sum_{k=1}^{n}\\ln k$ 看成函数 $\\ln x$ 的求和，用欧拉-麦克劳林公式：")+
   fml("\\sum_{k=1}^{n}f(k) = \\int_1^{n}f(x)\\,dx + \\frac{f(n)+f(1)}{2} + \\frac{B_2}{2!}f'(n) + \\frac{B_4}{4!}f'''(n)+\\cdots")+
   p("取 $f(x)=\\ln x$，有 $f'(x)=1/x$，$f'''(x)=2/x^{3}$，$B_2=\\frac16$，$B_4=-\\frac{1}{30}$。代入：")+
   fml("\\ln n! = \\int_1^n\\ln x\\,dx + \\frac{\\ln n}{2} + \\frac16\\cdot\\frac1n - \\frac{1}{30}\\cdot\\frac{2}{6n^{3}}\\cdot\\frac{1}{2}+\\cdots")+
   p("而 $\\int_1^n\\ln x\\,dx = n\\ln n - n + 1$，整理常数项后得到：")+
   fml("\\ln n! = n\\ln n - n + \\frac12\\ln(2\\pi n) + \\frac{1}{12n} - \\frac{1}{360n^{3}} + \\frac{1}{1260n^{5}} - \\cdots")+
   p("指数化即得 $n! = \\sqrt{2\\pi n}(n/e)^{n}\\exp\\!\\left(\\frac{1}{12n}-\\frac{1}{360n^{3}}+\\cdots\\right)$。"))+
   exa(p("<strong>例：</strong>$n=10$ 时，$\\ln 10!=15.1044$，斯特林级数取到 $\\frac{1}{12n}$ 项得 $15.1044$，误差小于 $10^{-4}$。"))+
   note(p("注意这是发散渐近级数：项数取到 $\\sim 2\\pi n$ 时达到最佳精度，之后误差反而增大。"))
 )},
{"id":"sf2s4-3","name":"渐近公式的应用","tags":["app","der"],"brief":"中心二项式系数、熵估计与玻尔兹曼分布。",
 "body": wrap(
   app(p("斯特林公式是统计物理与组合数学中处理大数的通用工具：它把组合爆炸转化为可微的函数。"))+
   der(p("<strong>中心二项式系数：</strong>由 $\\binom{2n}{n}=\\frac{(2n)!}{(n!)^{2}}$，代入斯特林公式：")+
   fml("\\binom{2n}{n} \\sim \\frac{\\sqrt{4\\pi n}\\,(2n/e)^{2n}}{2\\pi n\\,(n/e)^{2n}} = \\frac{\\sqrt{4\\pi n}}{2\\pi n}\\,4^{n} = \\frac{4^{n}}{\\sqrt{\\pi n}}")+
   p("由此可推出随机游走返回原点的概率 $\\sim1/\\sqrt{\\pi n}$。")+
   p("<strong>熵估计：</strong>对二元分布 $W=\\frac{N!}{n!(N-n)!}$，取对数并用斯特林公式：")+
   fml("\\ln W \\approx -N\\left[p\\ln p+(1-p)\\ln(1-p)\\right],\\quad p=\\frac{n}{N}")+
   p("这正是玻尔兹曼熵 $S=k_B\\ln W$ 的表达式，是统计力学的出发点。"))+
   note(p("用斯特林公式时务必区分主项与修正项：计算概率的指数部分只需主项，而计算指数前因子时必须保留 $\\sqrt{2\\pi n}$。"))
 )},
]},
{
"name": "2.5 伽马函数的应用",
"color": "#c084fc",
"desc": "组合计数、概率分布与物理公式中的伽马函数",
"items": [
{"id":"sf2s5-1","name":"组合计数与体积公式","tags":["app","der"],"brief":"n 维球体积、多重积分与伽马函数的联系。",
 "body": wrap(
   app(p("很多高维计数与体积公式最终都归结为伽马函数，这与 $\\Gamma$ 的积分定义天然契合。"))+
   der(p("<strong>n 维球体积：</strong>计算高斯积分 $\\int_{\\mathbb{R}^{n}}e^{-|x|^{2}}d^{n}x$ 的两种方式。直接分离变量：")+
   fml("\\int_{\\mathbb{R}^{n}}e^{-|x|^{2}}d^{n}x = \\left(\\int_{-\\infty}^{\\infty}e^{-x^{2}}dx\\right)^{n} = \\pi^{n/2}")+
   p("另一方面用球坐标，$d^{n}x=S_{n-1}r^{n-1}dr$（$S_{n-1}$ 为单位球面面积）：")+
   fml("\\pi^{n/2} = S_{n-1}\\int_0^{\\infty}r^{n-1}e^{-r^{2}}dr = S_{n-1}\\cdot\\tfrac12\\Gamma\\!\\left(\\frac n2\\right)")+
   p("故 $S_{n-1}=2\\pi^{n/2}/\\Gamma(n/2)$。由 $V_n(R)=\\int_0^{R}S_{n-1}r^{n-1}dr$ 得：")+
   fml("V_n(R) = \\frac{\\pi^{n/2}R^{n}}{\\Gamma\\!\\left(\\frac n2+1\\right)}")+
   p("例如 $n=2$ 得 $\\pi R^{2}$，$n=3$ 得 $\\frac43\\pi R^{3}$，与常识一致。"))+
   note(p("同一技巧可计算 Dirichlet 积分 $\\int_{x_i>0,\\sum x_i<1}\\prod x_i^{a_i-1}dx=\\prod\\Gamma(a_i)/\\Gamma(1+\\sum a_i)$。"))
 )},
{"id":"sf2s5-2","name":"概率分布中的伽马函数","tags":["app","der"],"brief":"伽马分布、贝塔分布的归一化与期望。",
 "body": wrap(
   app(p("伽马函数是连续概率分布归一化常数的「通用积木」，几乎所有正支撑分布都要用到它。"))+
   der(p("<strong>伽马分布：</strong>定义密度 $f(x)=\\frac{\\beta^{\\alpha}}{\\Gamma(\\alpha)}x^{\\alpha-1}e^{-\\beta x}$（$x>0$）。验证归一化：")+
   fml("\\int_0^{\\infty}x^{\\alpha-1}e^{-\\beta x}dx = \\frac{1}{\\beta^{\\alpha}}\\int_0^{\\infty}u^{\\alpha-1}e^{-u}du = \\frac{\\Gamma(\\alpha)}{\\beta^{\\alpha}}")+
   p("故 $\\frac{\\beta^{\\alpha}}{\\Gamma(\\alpha)}\\cdot\\frac{\\Gamma(\\alpha)}{\\beta^{\\alpha}}=1$，归一化成立。其期望为：")+
   fml("\\mathbb{E}[X] = \\frac{\\beta^{\\alpha}}{\\Gamma(\\alpha)}\\int_0^{\\infty}x^{\\alpha}e^{-\\beta x}dx = \\frac{\\beta^{\\alpha}}{\\Gamma(\\alpha)}\\cdot\\frac{\\Gamma(\\alpha+1)}{\\beta^{\\alpha+1}} = \\frac{\\alpha}{\\beta}")+
   p("<strong>贝塔分布：</strong>密度 $\\propto x^{a-1}(1-x)^{b-1}$，归一化常数恰为 $1/B(a,b)$，故期望 $\\frac{a}{a+b}$。"))+
   note(p("$\\chi^{2}$ 分布、指数分布、$F$ 分布都是伽马/贝塔分布的特例，其统计性质都可借 $\\Gamma$ 的递推关系推出。"))
 )},
{"id":"sf2s5-3","name":"物理公式中的伽马函数","tags":["app","der"],"brief":"从积分通式计算黑体辐射、统计配分等结果。",
 "body": wrap(
   app(p("凡是出现 $\\int_0^{\\infty}x^{s}e^{-ax}dx$ 或 $\\int_0^{\\infty}x^{2s}e^{-ax^{2}}dx$ 型积分，都可以用伽马函数直接写出结果，这是推导物理公式的常用手段。"))+
   der(p("<strong>通用积分公式：</strong>由定义 $\\int_0^{\\infty}t^{z-1}e^{-t}dt=\\Gamma(z)$，令 $t=ax$（$a>0$）：")+
   fml("\\int_0^{\\infty}x^{\\,z-1}e^{-a x}\\,dx = \\frac{\\Gamma(z)}{a^{z}}")+
   p("再令 $t=ax^{2}$ 得高斯型积分：")+
   fml("\\int_0^{\\infty}x^{\\,2s+1}e^{-a x^{2}}dx = \\frac{\\Gamma(s+1)}{2a^{s+1}},\\qquad \\int_0^{\\infty}x^{\\,2s}e^{-ax^{2}}dx = \\frac{\\Gamma\\!\\left(s+\\frac12\\right)}{2a^{\\,s+1/2}}")+
   p("<strong>斯特藩-玻尔兹曼定律：</strong>黑体辐射总能量 $\\propto\\int_0^{\\infty}\\frac{x^{3}}{e^{x}-1}dx$。把 $\\frac{1}{e^{x}-1}=\\sum_{n\\ge1}e^{-nx}$ 展开逐项积分：")+
   fml("\\int_0^{\\infty}\\frac{x^{3}}{e^{x}-1}dx = \\sum_{n=1}^{\\infty}\\int_0^{\\infty}x^{3}e^{-nx}dx = \\Gamma(4)\\sum_{n=1}^{\\infty}\\frac{1}{n^{4}} = 6\\zeta(4) = \\frac{\\pi^{4}}{15}")+
   p("于是辐射总能量正比于 $\\sigma T^{4}$，其中 $\\sigma$ 由 $\\pi^{4}/15$ 与基本常数组合得到。"))+
   note(p("同类技巧可得 $\\int_0^{\\infty}\\frac{x^{s-1}}{e^{x}-1}dx=\\Gamma(s)\\zeta(s)$，把 Bose-Einstein 积分化为伽马函数与黎曼 $\\zeta$ 函数的乘积。"))
 )},
]},
]

ch3_sections = [
{
"name": "3.1 高斯积分的定义与计算",
"color": "#0d9488",
"desc": "极坐标技巧、参数化与微分法求积分",
"items": [
{"id":"sf3s1-1","name":"高斯积分","tags":["def","der"],"brief":"∫e^(-x²)dx=√π，用极坐标法证明。",
 "fig":"gaussian_bell","figCap":"高斯函数 e^(-x²/2σ²) 的钟形曲线与 ±σ 区间",
 "body": wrap(
   defn("高斯积分", p("最重要的定积分之一：")+
   fml("I = \\int_{-\\infty}^{\\infty} e^{-x^{2}}\\,dx = \\sqrt{\\pi}")+
   p("它是一切高斯分布与误差函数归一化的基础。"))+
   der(p("<strong>极坐标法（泊松技巧）：</strong>设 $I$ 为所求。考虑 $I^{2}$，把它写成两个独立变量积分的乘积：")+
   fml("I^{2} = \\left(\\int_{-\\infty}^{\\infty}e^{-x^{2}}dx\\right)\\left(\\int_{-\\infty}^{\\infty}e^{-y^{2}}dy\\right) = \\int\\!\\!\\int_{\\mathbb{R}^{2}} e^{-(x^{2}+y^{2})}\\,dx\\,dy")+
   p("把平面二重积分换成极坐标 $x=r\\cos\\theta$，$y=r\\sin\\theta$，则 $x^{2}+y^{2}=r^{2}$，面积元 $dx\\,dy=r\\,dr\\,d\\theta$：")+
   fml("I^{2} = \\int_0^{2\\pi}\\!\\!\\int_0^{\\infty} e^{-r^{2}}r\\,dr\\,d\\theta")+
   p("对 $r$ 积分（令 $u=r^{2}$，$du=2r\\,dr$）：")+
   fml("\\int_0^{\\infty}e^{-r^{2}}r\\,dr = \\frac12\\int_0^{\\infty}e^{-u}du = \\frac12")+
   p("对 $\\theta$ 积分得 $2\\pi$，于是 $I^{2}=2\\pi\\cdot\\tfrac12=\\pi$，故 $I=\\sqrt\\pi$。"))+
   note(p("高斯积分的「不可积」（无初等原函数）与「可积出值」形成鲜明对比：正是极坐标把二维耦合转化为可分离形式，才使闭合值成为可能。"))
 )},
{"id":"sf3s1-2","name":"带参数的高斯积分","tags":["der"],"brief":"∫e^(-ax²)dx=√(π/a)，及配方技巧。",
 "body": wrap(
   der(p("<strong>缩放换元：</strong>设 $a>0$，作换元 $x=\\frac{u}{\\sqrt a}$，$dx=\\frac{du}{\\sqrt a}$：")+
   fml("\\int_{-\\infty}^{\\infty}e^{-a x^{2}}dx = \\frac{1}{\\sqrt a}\\int_{-\\infty}^{\\infty}e^{-u^{2}}du = \\sqrt{\\frac{\\pi}{a}}")+
   p("<strong>完成配方：</strong>对带线性项的情形 $e^{-ax^{2}+bx}$，配方：")+
   fml("-ax^{2}+bx = -a\\left(x-\\frac{b}{2a}\\right)^{2}+\\frac{b^{2}}{4a}")+
   p("作平移 $u=x-\\frac{b}{2a}$（不改变全实轴积分限）：")+
   fml("\\int_{-\\infty}^{\\infty}e^{-ax^{2}+bx}dx = e^{\\,b^{2}/4a}\\int_{-\\infty}^{\\infty}e^{-a u^{2}}du = \\sqrt{\\frac{\\pi}{a}}\\,e^{\\,b^{2}/4a}")+
   p("这解释了正态分布特征函数 $e^{\\mu t+\\sigma^{2}t^{2}/2}$ 的形式来源。"))+
   exa(p("<strong>例：</strong>$\\int_{-\\infty}^{\\infty}e^{-3x^{2}}dx=\\sqrt{\\pi/3}\\approx1.0233$，与数值积分一致。"))+
   note(p("配方技巧是推广到多维高斯积分的关键：把二次型 $x^{T}Ax-2b^{T}x$ 配方为 $(x-A^{-1}b)^{T}A(x-A^{-1}b)-b^{T}A^{-1}b$。"))
 )},
{"id":"sf3s1-3","name":"对参数求导的技巧","tags":["der","exa"],"brief":"由 ∂/∂a 求 ∫x²e^(-ax²)dx 等矩积分。",
 "body": wrap(
   der(p("<strong>对参数求导：</strong>把已知积分 $F(a)=\\int_{-\\infty}^{\\infty}e^{-ax^{2}}dx=\\sqrt{\\pi}\\,a^{-1/2}$ 对 $a$ 求导：")+
   fml("\\frac{\\partial}{\\partial a}\\int e^{-ax^{2}}dx = \\int(-x^{2})e^{-ax^{2}}dx")+
   p("而右端求导为：")+
   fml("\\frac{d}{da}\\sqrt{\\pi}\\,a^{-1/2} = -\\frac{\\sqrt\\pi}{2}a^{-3/2}")+
   p("比较即得：")+
   fml("\\int_{-\\infty}^{\\infty}x^{2}e^{-ax^{2}}dx = \\frac{\\sqrt\\pi}{2}a^{-3/2}")+
   p("再求导一次得四阶矩：")+
   fml("\\int_{-\\infty}^{\\infty}x^{4}e^{-ax^{2}}dx = \\frac{3\\sqrt\\pi}{4}a^{-5/2}")+
   p("一般地，对 $a$ 求导 $n$ 次得到 $\\int x^{2n}e^{-ax^2}dx=\\frac{(2n-1)!!}{2^{n}}\\sqrt\\pi\\,a^{-(n+1/2)}$，其中 $(2n-1)!!=1\\cdot3\\cdots(2n-1)$。"))+
   exa(p("<strong>例：</strong>取 $a=\\frac{1}{2\\sigma^{2}}$ 即得高斯分布的二阶矩 $\\sigma^{2}$，验证了方差定义。"))+
   note(p("「在积分号下求导」需满足一致收敛条件；此处被积函数对 $a$ 的导数有可积控制函数，故合法。"))
 )},
]},
{
"name": "3.2 高斯矩与生成函数",
"color": "#14b8a6",
"desc": "矩的递推、生成函数与傅里叶变换",
"items": [
{"id":"sf3s2-1","name":"高斯矩","tags":["der","thm"],"brief":"⟨x^(2n)⟩=(2n-1)!!/(2a)^n，奇阶矩为零。",
 "fig":"gaussian_moment","figCap":"矩生成函数 M(t)=e^(t²/2)：对 t 求导即得各阶矩",
 "body": wrap(
   thm("高斯矩公式", p("对标准高斯权重 $e^{-ax^{2}}$：")+
   fml("\\langle x^{2n}\\rangle = \\frac{\\int x^{2n}e^{-ax^{2}}dx}{\\int e^{-ax^{2}}dx} = \\frac{(2n-1)!!}{(2a)^{n}}", "奇阶矩 \\langle x^{2n+1}\\rangle=0"))+
   der(p("<strong>生成函数法：</strong>定义 $Z(b)=\\int_{-\\infty}^{\\infty}e^{-ax^{2}+bx}dx=\\sqrt{\\frac{\\pi}{a}}e^{b^{2}/4a}$。把 $e^{bx}$ 展开：")+
   fml("Z(b) = \\sum_{n=0}^{\\infty}\\frac{b^{n}}{n!}\\int x^{n}e^{-ax^{2}}dx")+
   p("另一方面把 $e^{b^{2}/4a}$ 展开：")+
   fml("\\sqrt{\\frac{\\pi}{a}}\\sum_{m=0}^{\\infty}\\frac{1}{m!}\\left(\\frac{b^{2}}{4a}\\right)^{m}")+
   p("比较 $b^{2m}$ 的系数（$b$ 的奇次幂系数为零，故奇阶矩为零）：")+
   fml("\\frac{1}{(2m)!}\\int x^{2m}e^{-ax^{2}}dx = \\sqrt{\\frac{\\pi}{a}}\\frac{1}{m!}\\left(\\frac{1}{4a}\\right)^{m}")+
   p("故：")+
   fml("\\frac{\\int x^{2m}e^{-ax^{2}}dx}{\\sqrt{\\pi/a}} = \\frac{(2m)!}{m!}\\,(4a)^{-m} = \\frac{(2m-1)!!}{(2a)^{m}}"))+
   note(p("$(2m)!/(2^{m}m!)=(2m-1)!!$ 是双重阶乘恒等式。此结论说明高斯分布的奇偶矩结构：所有奇阶矩为零，偶阶矩只由方差决定。"))
 )},
{"id":"sf3s2-2","name":"高斯生成函数","tags":["der"],"brief":"由 M(t)=e^(t²/2) 生成全部矩，并给出累积量。",
 "body": wrap(
   der(p("<strong>矩生成函数：</strong>对标准正态密度 $\\frac{1}{\\sqrt{2\\pi}}e^{-x^{2}/2}$，定义 $M(t)=\\mathbb{E}[e^{tX}]$。用带线性项高斯积分：")+
   fml("M(t) = \\frac{1}{\\sqrt{2\\pi}}\\int e^{-x^{2}/2+tx}dx = e^{t^{2}/2}")+
   p("把 $M(t)$ 展开：")+
   fml("M(t) = \\sum_{n=0}^{\\infty}\\frac{t^{2n}}{2^{n}n!}\\cdot\\frac{(2n)!}{(2n)!} = \\sum_{n}\\frac{\\mathbb{E}[X^{2n}]}{(2n)!}t^{2n}")+
   p("比较系数得 $\\mathbb{E}[X^{2n}]=(2n-1)!!$，与 3.2.1 一致。对 $\\ln M(t)=t^{2}/2$ 展开可得<strong>累积量</strong>：")+
   fml("\\kappa_1=0,\\quad \\kappa_2=1,\\quad \\kappa_n=0\\ (n\\ge3)")+
   p("即高斯分布只有前两阶累积量非零——这是它在线性组合与中心极限定理下保持稳定的根本原因。"))+
   app(p("矩生成函数让「求矩」变成「求导」：$\\mathbb{E}[X^{n}]=M^{(n)}(0)$，在统计物理与金融数学中广泛使用。"))+
   note(p("对一般 $X\\sim N(\\mu,\\sigma^{2})$，$M(t)=e^{\\mu t+\\sigma^{2}t^{2}/2}$，只需平移与缩放即可。"))
 )},
{"id":"sf3s2-3","name":"高斯的傅里叶变换","tags":["der"],"brief":"高斯是傅里叶变换的不动点。",
 "body": wrap(
   thm("变换性质", p("高斯函数在傅里叶变换下保持高斯形状：")+
   fml("\\mathcal{F}\\!\\left[e^{-x^{2}/2}\\right](k) = \\int_{-\\infty}^{\\infty}e^{-x^{2}/2}e^{-ikx}dx = \\sqrt{2\\pi}\\,e^{-k^{2}/2}"))+
   der(p("<strong>配方法：</strong>指数合并：")+
   fml("-\\frac{x^{2}}{2}-ikx = -\\frac12(x+ik)^{2}-\\frac{k^{2}}{2}")+
   p("平移变量 $u=x+ik$，形式上有：")+
   fml("\\int_{-\\infty}^{\\infty}e^{-\\frac12(x+ik)^{2}}e^{-k^{2}/2}dx = e^{-k^{2}/2}\\int_{-\\infty}^{\\infty}e^{-u^{2}/2}du = \\sqrt{2\\pi}\\,e^{-k^{2}/2}")+
   p("这里把积分线沿虚轴平移，可由柯西定理在有限矩形围道上证明其合法性（被积函数在带内解析且两端趋于零）。"))+
   exa(p("<strong>例：</strong>取 $k=0$ 得 $\\int e^{-x^{2}/2}dx=\\sqrt{2\\pi}$，与高斯积分一致，是自洽性检验。"))+
   note(p("高斯是唯一（在适当归一化下）等于自身傅里叶变换的函数族，这使它在测不准关系、量子场论传播子与热核中处处出现。"))
 )},
]},
{
"name": "3.3 误差函数与相关函数",
"color": "#0f766e",
"desc": "erf、erfc 的性质、级数与渐近展开",
"items": [
{"id":"sf3s3-1","name":"误差函数的定义","tags":["def","der"],"brief":"erf 是高斯核的累积函数，与正态 CDF 相关。",
 "fig":"erf","figCap":"误差函数 erf(x)：奇函数，从 -1 单调升到 +1",
 "body": wrap(
   defn("误差函数", p("定义<strong>误差函数</strong>与<strong>余误差函数</strong>：")+
   fml("\\operatorname{erf}(x) = \\frac{2}{\\sqrt{\\pi}}\\int_0^{x}e^{-t^{2}}dt,\\qquad \\operatorname{erfc}(x)=1-\\operatorname{erf}(x)")+
   p("归一化因子取 $2/\\sqrt\\pi$ 是为了使 $\\operatorname{erf}(\\infty)=1$。"))+
   der(p("<strong>与正态分布的关系：</strong>标准正态累积分布 $\\Phi(x)=\\frac{1}{\\sqrt{2\\pi}}\\int_{-\\infty}^{x}e^{-u^{2}/2}du$。换元 $u=\\sqrt2\\,t$：")+
   fml("\\Phi(x) = \\frac{1}{\\sqrt{2\\pi}}\\int_{-\\infty}^{x/\\sqrt2}e^{-t^{2}}\\sqrt2\\,dt = \\frac{1}{\\sqrt\\pi}\\int_{-\\infty}^{x/\\sqrt2}e^{-t^{2}}dt")+
   p("利用奇偶性拆开 $\\int_{-\\infty}^{0}+\\int_0^{x/\\sqrt2}$，第一项为 $\\sqrt\\pi/2$：")+
   fml("\\Phi(x) = \\frac12+\\frac12\\operatorname{erf}\\!\\left(\\frac{x}{\\sqrt2}\\right)"))+
   note(p("故 $\\operatorname{erf}$ 与 $\\Phi$ 仅差常数与 $\\sqrt2$ 缩放；工程上常用 erfc 计算尾部失效概率，因为它数值稳定（尾部值小）。"))
 )},
{"id":"sf3s3-2","name":"误差函数的级数与渐近","tags":["der"],"brief":"erf 的幂级数与 erfc 的大 x 渐近。",
 "body": wrap(
   der(p("<strong>幂级数：</strong>把 $e^{-t^{2}}=\\sum_{n\\ge0}\\frac{(-1)^{n}t^{2n}}{n!}$ 在 $[0,x]$ 上逐项积分：")+
   fml("\\operatorname{erf}(x) = \\frac{2}{\\sqrt\\pi}\\sum_{n=0}^{\\infty}\\frac{(-1)^{n}}{n!}\\int_0^{x}t^{2n}dt = \\frac{2}{\\sqrt\\pi}\\sum_{n=0}^{\\infty}\\frac{(-1)^{n}x^{2n+1}}{n!(2n+1)}")+
   p("该级数对一切 $x$ 收敛，但 $x\\gg1$ 时因交替而大量相消，需用渐近展开。")+
   p("<strong>大 x 渐近：</strong>对 $\\operatorname{erfc}(x)=\\frac{2}{\\sqrt\\pi}\\int_x^{\\infty}e^{-t^{2}}dt$ 作分部积分。取 $u=\\frac{1}{2t}$，$dv=2te^{-t^{2}}dt$，则 $v=-e^{-t^{2}}$：")+
   fml("\\int_x^{\\infty}e^{-t^{2}}dt = \\frac{e^{-x^{2}}}{2x}-\\frac12\\int_x^{\\infty}\\frac{e^{-t^{2}}}{t^{2}}dt")+
   p("继续分部积分：")+
   fml("\\operatorname{erfc}(x) = \\frac{e^{-x^{2}}}{x\\sqrt\\pi}\\left[1-\\frac{1}{2x^{2}}+\\frac{3}{4x^{4}}-\\cdots\\right]")+
   p("首项即 $\\operatorname{erfc}(x)\\sim\\dfrac{e^{-x^{2}}}{x\\sqrt\\pi}$。"))+
   note(p("该渐近级数也是发散的：$x$ 固定时取项过多会发散；最佳截断项数约为 $x^{2}$。"))
 )},
{"id":"sf3s3-3","name":"相关函数与应用","tags":["der","app"],"brief":"Dawson 积分、等离子体色散函数与热方程解。",
 "body": wrap(
   der(p("<strong>Dawson 函数：</strong>定义 $F(x)=e^{-x^{2}}\\int_0^{x}e^{t^{2}}dt$。把 $e^{t^{2}}$ 展开逐项积分：")+
   fml("\\int_0^{x}e^{t^{2}}dt = \\sum_{n=0}^{\\infty}\\frac{x^{2n+1}}{n!(2n+1)}")+
   p("故 $F(x)=e^{-x^{2}}\\sum_{n\\ge0}\\frac{x^{2n+1}}{n!(2n+1)}$，对一切 $x$ 收敛，且满足 $F'(x)=1-2xF(x)$。"))+
   der(p("<strong>热方程应用：</strong>一维热传导方程 $u_t=u_{xx}$ 的初值问题解为卷积：")+
   fml("u(x,t) = \\frac{1}{\\sqrt{4\\pi t}}\\int_{-\\infty}^{\\infty}e^{-(x-y)^{2}/4t}u(y,0)\\,dy")+
   p("取阶跃初值 $u(y,0)=\\Theta(y)$，作换元 $s=(x-y)/\\sqrt{4t}$：")+
   fml("u(x,t) = \\frac{1}{\\sqrt\\pi}\\int_{-\\infty}^{x/\\sqrt{4t}}e^{-s^{2}}ds = \\frac12\\left[1+\\operatorname{erf}\\!\\left(\\frac{x}{2\\sqrt t}\\right)\\right]")+
   p("这正是扩散界面（误差函数剖面）随时间展宽的解，界面宽度 $\\propto\\sqrt t$。"))+
   app(p("误差函数还出现在等离子体色散函数、激光强度剖面、光刻胶显影模型与金融期权定价中。"))+
   note(p("复数版本的 $w(z)=e^{-z^{2}}\\operatorname{erfc}(-iz)$ 称为 Faddeeva 函数，是等离子体物理与光谱线型（Voigt 剖面）的核心函数。"))
 )},
]},
{
"name": "3.4 多维高斯积分",
"color": "#0f766e",
"desc": "二次型积分、协方差与高维几何",
"items": [
{"id":"sf3s4-1","name":"多维高斯积分","tags":["def","der"],"brief":"∫e^(-½xᵀAx)dⁿx=(2π)^(n/2)/√det A。",
 "fig":"gaussian_2d","figCap":"二维高斯的等几率椭圆，长短轴由矩阵 A 的特征值决定",
 "body": wrap(
   defn("多维高斯积分", p("设 $A$ 为 $n\\times n$ 实对称正定矩阵：")+
   fml("\\int_{\\mathbb{R}^n} e^{-\\frac12 \\mathbf{x}^{T}A\\mathbf{x}}\\,d^{n}x = \\frac{(2\\pi)^{n/2}}{\\sqrt{\\det A}}")+
   p("它是配分函数、协方差与高维球体积公式的共同来源。"))+
   der(p("<strong>正交对角化：</strong>$A$ 实对称，故存在正交矩阵 $O$ 使 $A=O^{T}\\Lambda O$，$\\Lambda=\\mathrm{diag}(\\lambda_1,\\dots,\\lambda_n)$，$\\lambda_i>0$。作正交变换 $\\mathbf{y}=O\\mathbf{x}$，其雅可比 $|\\det O|=1$：")+
   fml("\\mathbf{x}^{T}A\\mathbf{x} = \\mathbf{y}^{T}\\Lambda\\mathbf{y} = \\sum_{i=1}^{n}\\lambda_i y_i^{2}")+
   p("积分分离为 $n$ 个一维高斯积分之积：")+
   fml("\\int e^{-\\frac12\\sum\\lambda_i y_i^{2}}d^{n}y = \\prod_{i=1}^{n}\\int e^{-\\lambda_i y_i^{2}/2}dy_i = \\prod_i\\sqrt{\\frac{2\\pi}{\\lambda_i}}")+
   p("而 $\\prod_i\\lambda_i=\\det A$，故：")+
   fml("\\int e^{-\\frac12\\mathbf{x}^{T}A\\mathbf{x}}d^{n}x = \\frac{(2\\pi)^{n/2}}{\\sqrt{\\det A}}"))+
   note(p("当 $A$ 有一零特征值时积分发散；正定性保证了收敛。统计物理中 $A$ 常取 $\\beta K$（$K$ 为劲度矩阵），配分函数即得 $\\sqrt{(2\\pi/\\beta)^{n}/\\det K}$。"))
 )},
{"id":"sf3s4-2","name":"协方差与配分函数","tags":["der","app"],"brief":"从对源求导得到逆矩阵与二阶矩。",
 "body": wrap(
   der(p("<strong>引入源项：</strong>定义 $Z(J)=\\int e^{-\\frac12 x^{T}Ax+J^{T}x}d^{n}x$。配方：$x^{T}Ax/2-J^{T}x=\\frac12(x-A^{-1}J)^{T}A(x-A^{-1}J)-\\frac12J^{T}A^{-1}J$，故：")+
   fml("Z(J) = \\frac{(2\\pi)^{n/2}}{\\sqrt{\\det A}}\\,\\exp\\!\\left(\\frac12 J^{T}A^{-1}J\\right)")+
   p("对 $J$ 求二阶导并令 $J=0$：")+
   fml("\\frac{1}{Z(0)}\\frac{\\partial^{2}Z}{\\partial J_i\\partial J_j}\\Big|_{J=0} = \\left(A^{-1}\\right)_{ij}")+
   p("即 $\\langle x_i x_j\\rangle=(A^{-1})_{ij}$，协方差矩阵正是 $A$ 的逆。")+
   p("<strong>配分函数：</strong>在统计力学中取 $A=\\beta K$，则 $Z=(2\\pi/\\beta)^{n/2}/\\sqrt{\\det K}$，自由能 $F=-\\frac1\\beta\\ln Z$ 只含 $\\ln\\det K$，由此可导出弹性常数与涨落的关系（如均分定理）。"))+
   app(p("这一「源项求导」方法是量子场论中 Wick 定理与费曼图计算的有限维原型。"))+
   note(p("当 $A$ 依赖参数 $\\theta$ 时，$\\frac{\\partial\\ln Z}{\\partial\\theta}=-\\frac12\\mathrm{tr}(A^{-1}\\partial_\\theta A)$，广泛用于估计参数涨落。"))
 )},
{"id":"sf3s4-3","name":"高维球坐标与球面面积","tags":["der"],"brief":"由高斯积分导出 S_(n-1)=2π^(n/2)/Γ(n/2)。",
 "body": wrap(
   der(p("<strong>两种算法：</strong>计算 $\\int_{\\mathbb{R}^n}e^{-|x|^{2}}d^{n}x$。用分离变量：")+
   fml("\\int_{\\mathbb{R}^n}e^{-|x|^{2}}d^{n}x = \\left(\\int_{-\\infty}^{\\infty}e^{-x^{2}}dx\\right)^{n}=\\pi^{n/2}")+
   p("用球坐标，$|x|=r$，面积元 $d^{n}x=r^{n-1}dr\\,d\\Omega_{n-1}$：")+
   fml("\\pi^{n/2} = \\left(\\int_{\\Omega_{n-1}}d\\Omega_{n-1}\\right)\\int_0^{\\infty}r^{n-1}e^{-r^{2}}dr = S_{n-1}\\cdot\\frac12\\Gamma\\!\\left(\\frac n2\\right)")+
   p("故：")+
   fml("S_{n-1} = \\frac{2\\pi^{n/2}}{\\Gamma\\!\\left(\\frac n2\\right)},\\qquad V_n = \\int_0^{1}S_{n-1}r^{n-1}dr = \\frac{\\pi^{n/2}}{\\Gamma\\!\\left(\\frac n2+1\\right)}")+
   p("检验：$n=2$ 得 $S_1=2\\pi$，$n=3$ 得 $S_2=4\\pi$，均与熟知结果一致。"))+
   exa(p("<strong>例：</strong>$n=3$ 时 $\\Gamma(1)=1$，$\\Gamma(2.5)=\\frac34\\sqrt\\pi$，于是 $V_3=\\pi^{3/2}/\\Gamma(2.5)=\\frac43\\pi$，正是球体积公式。"))+
   note(p("维数 $n$ 很大时 $\\Gamma(n/2+1)$ 增长极快，故高维单位球的体积反而趋于零——这是高维几何的反直觉现象之一。"))
 )},
]},
{
"name": "3.5 高斯积分的应用",
"color": "#115e59",
"desc": "正态分布、配分函数与量子基态",
"items": [
{"id":"sf3s5-1","name":"正态分布的归一化","tags":["app","der"],"brief":"求高斯分布常数并说明中心极限定理的稳定性。",
 "body": wrap(
   app(p("高斯积分最重要的应用是把正态分布规范化，从而得到概率论中最基础的分布。"))+
   der(p("<strong>归一化：</strong>设密度 $f(x)=Ce^{-(x-\\mu)^{2}/2\\sigma^{2}}$。要求 $\\int f dx=1$，作平移与缩放 $u=(x-\\mu)/(\\sqrt2\\sigma)$：")+
   fml("\\int_{-\\infty}^{\\infty}e^{-(x-\\mu)^{2}/2\\sigma^{2}}dx = \\sqrt2\\sigma\\int_{-\\infty}^{\\infty}e^{-u^{2}}du = \\sqrt2\\sigma\\sqrt\\pi = \\sigma\\sqrt{2\\pi}")+
   p("故 $C=\\frac{1}{\\sqrt{2\\pi}\\,\\sigma}$，即密度为 $\\frac{1}{\\sqrt{2\\pi}\\sigma}e^{-(x-\\mu)^{2}/2\\sigma^{2}}$。")+
   p("<strong>中心极限定理的稳定机制：</strong>正态分布的特征函数 $\\varphi(t)=e^{-\\sigma^{2}t^{2}/2}$。独立变量之和的特征函数相乘，仍为同型指数，故正态族在卷积下封闭：")+
   fml("e^{-\\sigma_1^{2}t^{2}/2}\\cdot e^{-\\sigma_2^{2}t^{2}/2} = e^{-(\\sigma_1^{2}+\\sigma_2^{2})t^{2}/2}")+
   p("这正是中心极限定理收敛到正态的代数根源。"))+
   note(p("误差函数可给出区间概率：$P(\\mu-\\sigma<X<\\mu+\\sigma)=\\operatorname{erf}(1/\\sqrt2)\\approx0.6827$。"))
 )},
{"id":"sf3s5-2","name":"统计物理配分函数","tags":["app","der"],"brief":"谐振子与理想气体的高斯配分函数。",
 "body": wrap(
   app(p("统计物理的配分函数几乎都是高斯积分，这是它能精确求解的关键。"))+
   der(p("<strong>经典谐振子：</strong>哈密顿量 $H=\\frac{p^{2}}{2m}+\\frac12m\\omega^{2}x^{2}$，配分函数：")+
   fml("Z = \\frac{1}{h}\\int\\!\\!\\int e^{-\\beta H}dp\\,dx = \\frac{1}{h}\\left(\\int e^{-\\beta p^{2}/2m}dp\\right)\\left(\\int e^{-\\beta m\\omega^{2}x^{2}/2}dx\\right)")+
   p("两次高斯积分分别给出 $\\sqrt{2\\pi m/\\beta}$ 与 $\\sqrt{2\\pi/(\\beta m\\omega^{2})}$，相乘：")+
   fml("Z = \\frac{1}{h}\\cdot\\sqrt{\\frac{2\\pi m}{\\beta}}\\cdot\\sqrt{\\frac{2\\pi}{\\beta m\\omega^{2}}} = \\frac{2\\pi}{h\\beta\\omega} = \\frac{k_BT}{\\hbar\\omega}")+
   p("由 $U=-\\partial_\\beta\\ln Z=k_BT$ 得能量均分 $k_BT$（动能与势能各 $\\frac12k_BT$）。")+
   p("<strong>理想气体：</strong>$N$ 个自由粒子的坐标积分给体积 $V^{N}$，动量积分给 $(2\\pi m k_BT/h^{2})^{3N/2}$，得到 Sackur-Tetrode 熵。"))+
   note(p("量子情形下把经典高斯积分替换为离散求和或路径积分即可：路径积分本身也是无穷维高斯积分，从而导出自由场论的可解结构。"))
 )},
{"id":"sf3s5-3","name":"量子力学中的高斯型态","tags":["app","der"],"brief":"高斯波包与最小测不准态。",
 "body": wrap(
   app(p("高斯波包是量子力学中唯一使不确定性乘积取最小值的态，而它的归一化与演化全靠高斯积分。"))+
   der(p("<strong>归一化与测不准：</strong>设 $\\psi(x)=Ce^{-x^{2}/2a^{2}}$。由归一化：")+
   fml("\\int|\\psi|^{2}dx = |C|^{2}\\,a\\sqrt\\pi = 1 \\;\\Longrightarrow\\; C = \\frac{1}{(\\pi a^{2})^{1/4}}")+
   p("计算均方位置 $\\langle x^{2}\\rangle=\\frac{a^{2}}{2}$（用 3.2 节的偶阶矩）。对动量表象做傅里叶变换：")+
   fml("\\tilde\\psi(p) \\propto \\int e^{-x^{2}/2a^{2}}e^{-ipx/\\hbar}dx \\propto e^{-a^{2}p^{2}/2\\hbar^{2}}")+
   p("故 $\\langle p^{2}\\rangle=\\frac{\\hbar^{2}}{2a^{2}}$，乘积：")+
   fml("\\Delta x\\,\\Delta p = \\sqrt{\\langle x^{2}\\rangle\\langle p^{2}\\rangle} = \\frac{a}{\\sqrt2}\\cdot\\frac{\\hbar}{a\\sqrt2} = \\frac{\\hbar}{2}")+
   p("这正是海森堡不确定关系 $\\Delta x\\,\\Delta p\\ge\\hbar/2$ 的下界，故称最小不确定态。"))+
   note(p("自由粒子的高斯波包随时间展宽，其宽度 $\\propto\\sqrt{1+(\\hbar t/ma^{2})^{2}}$，展宽规律同样由高斯积分的参数求导得到。"))
 )},
]},
]

ch4_sections = [
{
"name": "4.1 菲涅尔积分的定义",
"color": "#c2410c",
"desc": "余弦/正弦菲涅尔积分、复表示与级数",
"items": [
{"id":"sf4s1-1","name":"菲涅尔积分的定义","tags":["def","der"],"brief":"C(x),S(x) 的积分定义与奇偶性。",
 "body": wrap(
   defn("菲涅尔积分", p("沿实轴定义<strong>菲涅尔余弦、正弦积分</strong>：")+
   fml("C(x)=\\int_0^{x}\\cos\\!\\left(\\frac{\\pi t^{2}}{2}\\right)dt,\\qquad S(x)=\\int_0^{x}\\sin\\!\\left(\\frac{\\pi t^{2}}{2}\\right)dt")+
   p("归一化 $\\pi/2$ 因子使它们的极限值恰为 $1/2$。"))+
   der(p("<strong>基本性质：</strong>由定义直接求导：")+
   fml("C'(x)=\\cos\\!\\left(\\frac{\\pi x^{2}}{2}\\right),\\qquad S'(x)=\\sin\\!\\left(\\frac{\\pi x^{2}}{2}\\right)")+
   p("故 $C'^{2}+S'^{2}=1$，说明复曲线 $z(t)=C(t)+iS(t)$ 以弧长为参数（$|dz/dt|=1$）。又因 $\\cos$ 为偶、$\\sin$ 为奇：")+
   fml("C(-x)=-C(x),\\qquad S(-x)=-S(x)")+
   p("两函数都是奇函数，且 $C(0)=S(0)=0$。"))+
   note(p("菲涅尔积分是「曲率随弧长线性增长」的曲线之坐标：把 $\\theta=\\pi t^{2}/2$ 看成转角，则 $\\kappa=d\\theta/dt=\\pi t$，正是科纽螺线的自然参数化。"))
 )},
{"id":"sf4s1-2","name":"与误差函数的关系","tags":["der"],"brief":"C+iS=(1+i)/2 erf((1+i)√π x/2)。",
 "body": wrap(
   thm("复表示", p("两个菲涅尔积分可合并为一个复积分的实部与虚部：")+
   fml("C(x)+iS(x) = \\frac{1+i}{2}\\,\\operatorname{erf}\\!\\left(\\frac{(1+i)\\sqrt{\\pi}\\,x}{2}\\right)"))+
   der(p("<strong>推导：</strong>考虑复积分 $\\int_0^{x}e^{i\\pi t^{2}/2}dt$，其虚部与实部分别给出 $S$ 与 $C$。作换元使其成为误差函数的标准形式：令 $s=\\alpha t$，要求 $e^{i\\pi t^{2}/2}=e^{-s^{2}}$，即 $s^{2}=-i\\pi t^{2}/2$：")+
   fml("s = \\sqrt{-i\\pi/2}\\;t = e^{-i\\pi/4}\\sqrt{\\pi/2}\\;t = \\frac{1-i}{2}\\sqrt{\\pi}\\,t")+
   p("于是 $dt=\\frac{2}{(1-i)\\sqrt\\pi}ds$，积分化为：")+
   fml("\\int_0^{x}e^{i\\pi t^{2}/2}dt = \\frac{2}{(1-i)\\sqrt\\pi}\\int_0^{s(x)}e^{-s^{2}}ds = \\frac{1}{1-i}\\operatorname{erf}(s(x))")+
   p("利用 $\\frac{1}{1-i}=\\frac{1+i}{2}$，并代入 $s(x)=\\frac{(1+i)\\sqrt\\pi x}{2}$（注意 $\\frac{1-i}{2}$ 与 $\\frac{1+i}{2}$ 的关系），即得所证。"))+
   exa(p("<strong>例：</strong>在 $x\\to\\infty$ 时 $\\operatorname{erf}\\to1$，故 $C+iS\\to\\frac{1+i}{2}$，从而 $C(\\infty)=S(\\infty)=\\frac12$。"))+
   note(p("该复表示把菲涅尔积分的全部性质归结为复误差函数，便于用已有的 erf 级数与渐近展开。"))
 )},
{"id":"sf4s1-3","name":"幂级数展开","tags":["der","exa"],"brief":"逐项积分 cos/sin 得菲涅尔积分的级数。",
 "fig":"fresnel_curves","figCap":"C(x) 与 S(x) 随 x 振荡并趋于 1/2",
 "body": wrap(
   der(p("<strong>$C(x)$ 的级数：</strong>把 $\\cos$ 展开并逐项积分：")+
   fml("\\cos\\!\\left(\\frac{\\pi t^{2}}{2}\\right)=\\sum_{n=0}^{\\infty}\\frac{(-1)^{n}}{(2n)!}\\left(\\frac{\\pi t^{2}}{2}\\right)^{2n}")+
   p("对 $t$ 从 $0$ 到 $x$ 积分：")+
   fml("C(x)=\\sum_{n=0}^{\\infty}\\frac{(-1)^{n}}{(2n)!}\\left(\\frac{\\pi}{2}\\right)^{2n}\\frac{x^{4n+1}}{4n+1}")+
   p("同理 $S(x)$ 用 $\\sin$ 展开（仅奇次项）：")+
   fml("S(x)=\\sum_{n=0}^{\\infty}\\frac{(-1)^{n}}{(2n+1)!}\\left(\\frac{\\pi}{2}\\right)^{2n+1}\\frac{x^{4n+3}}{4n+3}")+
   p("两式对一切实 $x$ 收敛。"))+
   exa(p("<strong>例：</strong>取首项 $C(x)\\approx x$，$S(x)\\approx\\frac{\\pi}{6}x^{3}$，在 $x\\ll1$ 时与直接积分吻合。"))+
   note(p("级数在小 $x$ 收敛极快，但 $x\\gtrsim2$ 后需要大量项；实际数值计算在 $x\\approx1.5$ 处切换到渐近展开或复误差函数。"))
 )},
]},
{
"name": "4.2 菲涅尔螺旋线与渐近行为",
"color": "#ea580c",
"desc": "科纽螺线的几何、渐近展开与极限值",
"items": [
{"id":"sf4s2-1","name":"科纽螺线","tags":["def","der"],"brief":"以弧长为参数的螺旋，曲率正比于弧长。",
 "fig":"fresnel_spiral","figCap":"科纽螺线：以 (C(t),S(t)) 为坐标，两端趋向 (±1/2,∓...)，中心为原点",
 "body": wrap(
   defn("科纽螺线", p("在复平面上，曲线 $\\zeta(t)=C(t)+iS(t)$ 称为<strong>科纽螺线</strong>（Cornu spiral），亦称菲涅尔螺旋线。"))+
   der(p("<strong>弧长与曲率：</strong>由 $\\zeta'(t)=C'(t)+iS'(t)=e^{i\\pi t^{2}/2}$，其模恒为 $1$：")+
   fml("|\\zeta'(t)| = 1 \\;\\Longrightarrow\\; s(t)=t\\ \\text{（弧长即参数）}")+
   p("切向角 $\\theta(t)=\\pi t^{2}/2$，故曲率为转角对弧长的变化率：")+
   fml("\\kappa(t) = \\left|\\frac{d\\theta}{ds}\\right| = \\pi t")+
   p("曲率与弧长成正比，说明曲线绕中心越卷越紧，形成对称的双螺旋。$t=0$ 处 $\\kappa=0$，曲线在原点最平缓。"))+
   note(p("螺旋的对称性源于 $C,S$ 均为奇函数：$\\zeta(-t)=-\\overline{\\zeta(t)}$ 附近结构镜像对称，中心点对应无遮挡时的光轴。"))
 )},
{"id":"sf4s2-2","name":"渐近展开","tags":["der"],"brief":"分部积分得 C(x)~1/2-sin(πx²/2)/(πx)。",
 "body": wrap(
   der(p("<strong>分部积分：</strong>对 $\\int_x^{\\infty}\\cos(\\pi t^{2}/2)dt$ 取 $u=\\frac{1}{\\pi t}$，$dv=\\pi t\\cos(\\pi t^{2}/2)dt$，则 $v=\\sin(\\pi t^{2}/2)$：")+
   fml("\\int_x^{\\infty}\\cos\\!\\left(\\frac{\\pi t^{2}}{2}\\right)dt = \\left[\\frac{\\sin(\\pi t^{2}/2)}{\\pi t}\\right]_x^{\\infty} + \\int_x^{\\infty}\\frac{\\sin(\\pi t^{2}/2)}{\\pi t^{2}}dt")+
   p("边界项在无穷处为零，于是：")+
   fml("\\frac12 - C(x) = \\int_x^{\\infty}\\cos\\!\\left(\\frac{\\pi t^{2}}{2}\\right)dt = -\\frac{\\sin(\\pi x^{2}/2)}{\\pi x} + O\\!\\left(\\frac{1}{x^{2}}\\right)")+
   p("故大 $x$ 时：")+
   fml("C(x) = \\frac12 - \\frac{\\sin(\\pi x^{2}/2)}{\\pi x} + O\\!\\left(\\frac{1}{x^{2}}\\right)")+
   p("同理对 $S$：")+
   fml("S(x) = \\frac12 + \\frac{\\cos(\\pi x^{2}/2)}{\\pi x} + O\\!\\left(\\frac{1}{x^{2}}\\right)"))+
   note(p("继续分部积分可得完整的渐近级数，系数依次为 $1/(\\pi x),\\ 3/(\\pi x)^{3},\\dots$，是典型的发散渐近级数。"))
 )},
{"id":"sf4s2-3","name":"极限值与螺旋两端","tags":["der","exa"],"brief":"证明 C(∞)=S(∞)=1/2，并用旋转坐标求 Fresnel 积分。",
 "body": wrap(
   der(p("<strong>极限值：</strong>由 4.1.2 的复表示，令 $x\\to\\infty$：")+
   fml("C(\\infty)+iS(\\infty) = \\frac{1+i}{2}\\operatorname{erf}(\\infty) = \\frac{1+i}{2}")+
   p("比较实部虚部即得 $C(\\infty)=S(\\infty)=\\frac12$。这说明科纽螺线两端分别趋向 $\\frac{1+i}{2}$ 与 $-\\frac{1+i}{2}$。"))+
   der(p("<strong>旋转坐标求 $\\int_0^\\infty\\sin(t^{2})dt$：</strong>考虑 $\\oint e^{iz^{2}}dz$ 沿扇形围道，或直接换元。令 $u=t^{2}$，$dt=\\frac{u^{-1/2}}{2}du$：")+
   fml("\\int_0^{\\infty}\\sin(t^{2})dt = \\frac12\\int_0^{\\infty}u^{-1/2}\\sin u\\,du")+
   p("而 $\\int_0^{\\infty}u^{s-1}\\sin u\\,du=\\Gamma(s)\\sin\\frac{\\pi s}{2}$，取 $s=\\frac12$：")+
   fml("\\int_0^{\\infty}u^{-1/2}\\sin u\\,du = \\Gamma\\!\\left(\\tfrac12\\right)\\sin\\frac{\\pi}{4} = \\sqrt\\pi\\cdot\\frac{\\sqrt2}{2}")+
   p("故 $\\int_0^{\\infty}\\sin(t^{2})dt=\\frac{\\sqrt{2\\pi}}{4}=\\sqrt{\\frac{\\pi}{8}}$。同理 $\\int_0^{\\infty}\\cos(t^{2})dt=\\sqrt{\\frac{\\pi}{8}}$。"))+
   exa(p("<strong>例：</strong>由 $\\int_0^\\infty\\sin(t^{2})dt=\\sqrt{\\pi/8}$，换元 $t\\to t\\sqrt{\\pi/2}$ 得 $S(\\infty)=\\frac12$，与上面结果一致。"))+
   note(p("这两个「曲率积分」是光学衍射与量子力学中 Fresnel 传播子的基本常数。"))
 )},
]},
{
"name": "4.3 菲涅尔积分的计算方法",
"color": "#f97316",
"desc": "数值计算策略、复误差函数与特殊值",
"items": [
{"id":"sf4s3-1","name":"数值计算与级数/渐近衔接","tags":["exa","der"],"brief":"小 x 用级数、大 x 用渐近，中间用连分式。",
 "body": wrap(
   exa(p("<strong>例：</strong>计算 $C(3)$。直接级数需上百项且相消严重，改用渐近公式：")+
   fml("C(3)\\approx\\frac12-\\frac{\\sin(\\pi\\cdot9/2)}{3\\pi} = \\frac12-\\frac{\\sin(4.5\\pi)}{3\\pi}")+
   p("$\\sin(4.5\\pi)=\\sin(0.5\\pi)=1$，故 $C(3)\\approx0.5-0.1061=0.3939$，精确值 $C(3)=0.3936$，误差 $<10^{-3}$。"))+
   der(p("<strong>衔接策略：</strong>设阈值 $x_0\\approx1.5$。$x<x_0$ 时用幂级数：")+
   fml("C(x)=\\sum_{n\\ge0}\\frac{(-1)^{n}}{(2n)!}\\left(\\frac{\\pi}{2}\\right)^{2n}\\frac{x^{4n+1}}{4n+1}")+
   p("$x>x_0$ 时用渐近展开：")+
   fml("C(x)=\\frac12-P(x)\\sin\\!\\left(\\frac{\\pi x^{2}}{2}\\right)-Q(x)\\cos\\!\\left(\\frac{\\pi x^{2}}{2}\\right)")+
   p("其中 $P,Q$ 为 $1/(\\pi x)$ 的渐近幂级数。也可全程用复误差函数 $w(z)$ 的连分式/Padé 近似，实现全实轴高精度。"))+
   note(p("由于被积函数振荡剧烈，数值积分（如 Simpson 法）在高频区间需要极细步长，因此解析展开优于直接积分。"))
 )},
{"id":"sf4s3-2","name":"复误差函数与相关函数","tags":["der"],"brief":"用 Faddeeva 函数统一表示并给出恒等式。",
 "body": wrap(
   der(p("<strong>复误差函数表示：</strong>把 4.1.2 的结果改写，引入 $w(z)=e^{-z^{2}}\\operatorname{erfc}(-iz)$：")+
   fml("C(x)+iS(x)=\\frac{1+i}{2}\\operatorname{erf}\\!\\left(\\sqrt{\\pi}\\,\\frac{1+i}{2}x\\right)")+
   p("记 $\\xi=\\sqrt{\\pi}\\,\\frac{1+i}{2}x$，则 $\\xi^{2}=i\\pi x^{2}/2$，与定义相符。对 $\\xi$ 用误差函数的函数方程：")+
   fml("\\operatorname{erf}(\\xi)+\\operatorname{erf}(-\\xi)=0 \\;\\Longrightarrow\\; C(-x)+iS(-x) = -(C(x)+iS(x))")+
   p("与奇偶性一致。")+
   p("<strong>导数恒等式：</strong>由 $C'^{2}+S'^{2}=1$ 及二阶导数 $C''=-\\pi x\\sin(\\pi x^{2}/2)$，可得：")+
   fml("C''(x)= -\\pi x\\,S'(x),\\qquad S''(x)=\\pi x\\,C'(x)")+
   p("即 $(C,S)$ 满足耦合的线性系统，这是螺旋几何的解析表达。"))+
   note(p("Faddeeva 函数 $w(z)$ 及其缩放版本是等离子体色散函数与 Voigt 线型的标准实现函数，有多种开源数值库。"))
 )},
{"id":"sf4s3-3","name":"特殊值与积分恒等式","tags":["exa","der"],"brief":"C(0)=S(0)=0，螺旋长度与曲率面积等。",
 "body": wrap(
   exa(p("<strong>例（特殊值）：</strong>")+
   fml("C(0)=S(0)=0,\\quad C(\\infty)=S(\\infty)=\\frac12,\\quad C(1)=0.7799,\\ S(1)=0.4383")+
   p("$C(1),S(1)$ 常用作菲涅尔积分的基准值。"))+
   der(p("<strong>螺旋总长：</strong>由弧长为参数，整条螺旋从 $t=-\\infty$ 到 $t=\\infty$ 的长度为无穷（每绕一圈弧长增加），但两端点间直线距离为：")+
   fml("\\left|\\zeta(\\infty)-\\zeta(-\\infty)\\right| = \\left|\\frac{1+i}{2}-\\left(-\\frac{1+i}{2}\\right)\\right| = \\left|1+i\\right| = \\sqrt2")+
   p("这对应无遮挡时的振幅因子，与半波带法的 $a_1/2$ 相差常数，正是衍射积分归一化的来源。")+
   p("<strong>积分恒等式：</strong>由 $\\int_0^{\\infty}\\sin(t^{2})dt=\\sqrt{\\pi/8}$ 与缩放关系得：")+
   fml("\\int_0^{\\infty}S'(t)\\,dt = S(\\infty)=\\frac12,\\qquad \\int_0^{\\infty}\\frac{\\sin(\\pi t^{2}/2)}{t}dt = \\frac{\\pi}{2}"))+
   note(p("最后一个积分可由 Dirichlet 积分或菲涅尔积分的渐近性推出，常用于估计衍射条纹的衰减包络。"))
 )},
]},
{
"name": "4.4 菲涅尔积分在衍射中的应用",
"color": "#c2410c",
"desc": "直边、单缝与波带片的菲涅耳衍射计算",
"items": [
{"id":"sf4s4-1","name":"直边衍射","tags":["app","der"],"brief":"半无限屏后光强由菲涅尔积分给出。",
 "fig":"fresnel_diffraction","figCap":"直边（或单缝）菲涅耳衍射：光强由 C,S 组合表达",
 "body": wrap(
   app(p("菲涅尔积分是近场衍射的标准计算工具，最典型的例子是半无限直边屏的衍射。"))+
   der(p("<strong>衍射积分：</strong>把菲涅耳-基尔霍夫积分沿波前展开，引入菲涅耳变量 $v=x\\sqrt{2/(\\lambda z)}$，则观察点复振幅正比于：")+
   fml("\\tilde E(v) \\propto \\int_{-v}^{\\infty}e^{i\\pi t^{2}/2}dt = \\left[C(\\infty)+iS(\\infty)\\right]-\\left[C(-v)+iS(-v)\\right]")+
   p("利用 $C(\\infty)+iS(\\infty)=\\frac{1+i}{2}$ 与奇偶性：")+
   fml("\\tilde E(v) \\propto \\frac{1+i}{2}+C(v)+iS(v)")+
   p("光强 $I=|\\tilde E|^{2}$，归一化到几何明区无穷远光强 $I_0$（对应 $|1+i|^{2}=2$）：")+
   fml("\\frac{I}{I_0} = \\frac12\\left[\\left(C(v)+\\frac12\\right)^{2}+\\left(S(v)+\\frac12\\right)^{2}\\right]")+
   p("在几何边界 $v=0$ 处，$C=S=0$，故 $I/I_0=\\frac12\\cdot(\\frac14+\\frac14)=\\frac14$，即边界处光强为几何值的四分之一。"))+
   note(p("远离边界时 $I\\to I_0$（明区）或 $I\\to0$（暗区），并在边界附近出现振荡条纹——这就是直边衍射条纹（菲涅耳条纹）。"))
 )},
{"id":"sf4s4-2","name":"单缝菲涅耳衍射","tags":["app","der"],"brief":"有限缝宽的光强由两个菲涅尔积分之差给出。",
 "body": wrap(
   der(p("<strong>缝宽对应变量区间：</strong>设缝在菲涅耳变量下对应 $t\\in[u_1,u_2]$，则复振幅为：")+
   fml("\\tilde E = \\int_{u_1}^{u_2}e^{i\\pi t^{2}/2}dt = \\left[C(u_2)-C(u_1)\\right]+i\\left[S(u_2)-S(u_1)\\right]")+
   p("光强即科纽螺线上两点间弦长的平方（乘以常数）：")+
   fml("I \\propto \\left[C(u_2)-C(u_1)\\right]^{2}+\\left[S(u_2)-S(u_1)\\right]^{2}")+
   p("<strong>随缝宽增大：</strong>当 $u_1\\to-\\infty$，$u_2\\to\\infty$ 时弦长趋于 $\\sqrt2$（自由空间），对应无遮挡情形；缝宽有限时弦长随 $u_1,u_2$ 的位置振荡，故中心光强随缝宽抖动。"))+
   app(p("该结果用「螺旋上两点弦长」给出近场光强的几何直觉：菲涅耳衍射的振荡就是螺线上弦长随位置扫过的结果。"))+
   note(p("当缝宽远大于 $\\sqrt{\\lambda z}$ 时，菲涅耳积分可在端点附近线性化，渡越到远场夫琅禾费衍射。"))
 )},
{"id":"sf4s4-3","name":"波带片与螺旋应用","tags":["app","der"],"brief":"菲涅尔波带片的焦距与螺旋卷曲点的关系。",
 "body": wrap(
   app(p("菲涅尔波带片利用交替遮光的半波带实现聚焦，其本质是把科纽螺线的卷曲结构「整流」。"))+
   der(p("<strong>波带片焦距：</strong>第 $k$ 个半波带边界到焦点 $P$ 的光程差为 $k\\lambda/2$。设第 $k$ 个波带半径 $r_k$，波带片到 $P$ 距离 $f$，由几何：")+
   fml("\\sqrt{r_k^{2}+f^{2}}-f = \\frac{k\\lambda}{2}")+
   p("当 $f\\gg r_k$ 时展开 $\\sqrt{r_k^{2}+f^{2}}\\approx f+\\frac{r_k^{2}}{2f}$，故：")+
   fml("\\frac{r_k^{2}}{2f}=\\frac{k\\lambda}{2} \\;\\Longrightarrow\\; r_k=\\sqrt{k\\lambda f}")+
   p("于是 $r_1^{2}=\\lambda f$，即焦距：")+
   fml("f = \\frac{r_1^{2}}{\\lambda}")+
   p("只让奇数（或偶数）半波带透光，可使各带贡献同相叠加，中心光强大幅增强，形成类似透镜的聚焦作用。"))+
   note(p("波带片对 X 射线、极紫外等难以用折射透镜的波段极其重要，其分辨率由最外环宽度决定。"))
 )},
]},
]

ch5_sections = [
{
"name": "5.1 超几何级数的定义与收敛性",
"color": "#be185d",
"desc": "Pochhammer 符号、比值判别与高斯求和",
"items": [
{"id":"sf5s1-1","name":"超几何级数的定义","tags":["def","der"],"brief":"₂F₁(a,b;c;z) 的级数定义与收敛半径。",
 "fig":"hypergeometric","figCap":"₂F₁(1,1;1;z)=1/(1-z)：在 |z|<1 收敛，z=1 处发散",
 "body": wrap(
   defn("高斯超几何函数", p("借助 Pochhammer 符号 $(a)_n=a(a+1)\\cdots(a+n-1)$，$(a)_0=1$，定义：")+
   fml("{}_{2}F_{1}(a,b;c;z)=\\sum_{n=0}^{\\infty}\\frac{(a)_n(b)_n}{(c)_n}\\frac{z^{n}}{n!}","要求 c 不为非正整数")+
   p("它是二阶线性微分方程的两个 Frobenius 解之一，被称为「特殊函数之母」。"))+
   der(p("<strong>收敛半径：</strong>相邻项之比：")+
   fml("\\frac{t_{n+1}}{t_n}=\\frac{(a+n)(b+n)}{(c+n)(n+1)}\\;z")+
   p("当 $n\\to\\infty$ 时，$\\frac{(a+n)(b+n)}{(c+n)(n+1)}\\to1$，故：")+
   fml("\\lim_{n\\to\\infty}\\left|\\frac{t_{n+1}}{t_n}\\right|=|z|")+
   p("由比值判别法，$|z|<1$ 时绝对收敛，$|z|>1$ 时发散（除非 $a$ 或 $b$ 为非正整数使级数截断为多项式）。"))+
   note(p("当 $a=-m$（$m$ 为非负整数）时 $(a)_n$ 在 $n>m$ 后为零，级数退化为 $m$ 次多项式，这是众多经典正交多项式的统一来源。"))
 )},
{"id":"sf5s1-2","name":"高斯求和公式","tags":["thm","der"],"brief":"₂F₁(a,b;c;1)=Γ(c)Γ(c-a-b)/(Γ(c-a)Γ(c-b))。",
 "body": wrap(
   thm("高斯求和公式", p("在 $\\Re(c-a-b)>0$ 时：")+
   fml("{}_{2}F_{1}(a,b;c;1)=\\frac{\\Gamma(c)\\,\\Gamma(c-a-b)}{\\Gamma(c-a)\\,\\Gamma(c-b)}"))+
   der(p("<strong>用贝塔积分：</strong>由 $\\frac{(a)_n}{(c)_n}=\\frac{\\Gamma(c)}{\\Gamma(a)\\Gamma(c-a)}\\int_0^{1}t^{\\,a+n-1}(1-t)^{\\,c-a-1}dt$（把 $(a)_n/(c)_n$ 写成贝塔积分），代入级数并对调求和与积分：")+
   fml("{}_{2}F_{1}(a,b;c;1)=\\frac{\\Gamma(c)}{\\Gamma(a)\\Gamma(c-a)}\\int_0^{1}t^{\\,a-1}(1-t)^{\\,c-a-1}\\left[\\sum_{n=0}^{\\infty}\\frac{(b)_n}{n!}t^{n}\\right]dt")+
   p("方括号内是二项式级数 $\\sum\\frac{(b)_n}{n!}t^n=(1-t)^{-b}$：")+
   fml("=\\frac{\\Gamma(c)}{\\Gamma(a)\\Gamma(c-a)}\\int_0^{1}t^{\\,a-1}(1-t)^{\\,c-a-b-1}dt")+
   p("该积分是 $B(a,c-a-b)=\\frac{\\Gamma(a)\\Gamma(c-a-b)}{\\Gamma(c-b)}$，代入并约去 $\\Gamma(a)$：")+
   fml("{}_{2}F_{1}(a,b;c;1)=\\frac{\\Gamma(c)\\Gamma(c-a-b)}{\\Gamma(c-a)\\Gamma(c-b)}"))+
   exa(p("<strong>例：</strong>$a=b=1,c=2$ 时公式给 $\\frac{\\Gamma(2)\\Gamma(0)}{\\Gamma(1)\\Gamma(1)}$，$\\Gamma(0)$ 发散，与 $\\sum\\frac{1}{n+1}$ 调和级数发散一致（边界情形）。"))+
   note(p("该公式有众多特例（如 $a=1,b=1,c=2$ 变为对数、$c$ 取特定值时得 $\\pi$ 的表达式），是求无穷级数和的强大工具。"))
 )},
{"id":"sf5s1-3","name":"对数与初等特例","tags":["exa","der"],"brief":"由级数积分导出 ₂F₁(1,1;2;z)=-ln(1-z)/z。",
 "body": wrap(
   der(p("<strong>从几何级数积分：</strong>已知 $\\sum_{n\\ge0}z^{n}=\\frac{1}{1-z}$。对它从 $0$ 到 $z$ 积分：")+
   fml("\\int_0^{z}\\frac{dt}{1-t} = -\\ln(1-z)")+
   p("逐项积分左边：")+
   fml("\\sum_{n=0}^{\\infty}\\frac{z^{n+1}}{n+1} = -\\ln(1-z)")+
   p("两边除以 $z$：")+
   fml("\\sum_{n=0}^{\\infty}\\frac{z^{n}}{n+1} = -\\frac{\\ln(1-z)}{z}")+
   p("而 $\\frac{(1)_n(1)_n}{(2)_n n!}=\\frac{n!\\,n!}{(n+1)!/1}\\cdot\\frac1{n!}=\\frac{1}{n+1}$，故级数恰为 $\\sum\\frac{z^n}{n+1}$，即：")+
   fml("{}_{2}F_{1}(1,1;2;z) = -\\frac{\\ln(1-z)}{z}"))+
   exa(p("<strong>例：</strong>取 $z=-1$ 得 $\\sum_{n\\ge0}\\frac{(-1)^{n}}{n+1}=\\ln2$，即交错调和级数的值。"))+
   note(p("同理 $\\sum_{n\\ge0}\\frac{z^{n}}{(n+1)^{2}}=\\frac{1}{z}\\mathrm{Li}_2(z)$，把重对数函数也纳入超几何框架的邻近族。"))
 )},
]},
{
"name": "5.2 超几何方程与解",
"color": "#db2777",
"desc": "微分方程、Frobenius 解与变换公式",
"items": [
{"id":"sf5s2-1","name":"超几何微分方程","tags":["der","thm"],"brief":"由级数代入导出 z(1-z)y''+[c-(a+b+1)z]y'-aby=0。",
 "body": wrap(
   thm("超几何方程", p("$y={}_{2}F_{1}(a,b;c;z)$ 满足：")+
   fml("z(1-z)y''+\\left[c-(a+b+1)z\\right]y'-ab\\,y=0")+
   p("方程在 $z=0,1,\\infty$ 处有正则奇点，是黎曼方程的标准形式。"))+
   der(p("<strong>直接代入验证：</strong>设 $y=\\sum_{n\\ge0}c_n z^{n}$，$c_n=\\frac{(a)_n(b)_n}{(c)_n n!}$。代入方程，$z^{n}$ 的系数为：")+
   fml("n(n+1)c_{n+1}-(n-1)n c_n+\\left[c-(a+b+1)z\\right]\\ \\Rightarrow\\ \\text{按幂次整理}")+
   p("更清晰地把 $z^{n}$ 的系数写出：来自 $z(1-z)y''$ 贡献 $-n(n-1)c_n$（当 $n$ 用 $c_n$）与 $(n+1)n c_{n+1}$；来自 $c\\,y'$ 贡献 $c(n+1)c_{n+1}$；来自 $-(a+b+1)z y'$ 贡献 $-(a+b+1)n c_n$；来自 $-ab y$ 贡献 $-ab c_n$。合并 $c_{n+1}$ 与 $c_n$：")+
   fml("(n+1)(n+c)\\,c_{n+1} = \\left[n(n-1)+(a+b+1)n+ab\\right]c_n = (n+a)(n+b)\\,c_n")+
   p("这正是系数递推：")+
   fml("c_{n+1}=\\frac{(n+a)(n+b)}{(n+1)(n+c)}c_n")+
   p("取 $c_0=1$ 即得 $c_n=\\frac{(a)_n(b)_n}{(c)_n n!}$，从而 $y={}_{2}F_{1}$ 是解。"))+
   note(p("方程的三个正则奇点 $0,1,\\infty$ 对应 Riemann P 符号的指数 $\\{0,1-c\\},\\{0,c-a-b\\},\\{a,b\\}$，这决定了所有连接问题。"))
 )},
{"id":"sf5s2-2","name":"指标方程与两个解","tags":["der","thm"],"brief":"Frobenius 方法给出指数 0 与 1-c。",
 "body": wrap(
   der(p("<strong>Frobenius 方法：</strong>在正则奇点 $z=0$ 附近设 $y=z^{\\rho}\\sum_{n\\ge0}c_n z^{n}$。代入方程的最低幂次项（$z^{\\rho-1}$ 的系数）给出指标方程。方程两边乘后提取 $z^{\\rho-1}$：")+
   fml("\\rho(\\rho-1)+c\\rho = 0 \\;\\Longrightarrow\\; \\rho\\left[\\rho-1+c\\right]=0")+
   p("故两指数为：")+
   fml("\\rho_1=0,\\qquad \\rho_2=1-c")+
   p("对应两个解：")+
   fml("y_1={}_{2}F_{1}(a,b;c;z),\\qquad y_2=z^{\\,1-c}{}_{2}F_{1}(a-c+1,b-c+1;2-c;z)")+
   p("当 $c$ 不为整数时两解线性无关，构成方程的通解。"))+
   exa(p("<strong>例：</strong>$c=1$ 时 $\\rho_2=0$ 与 $\\rho_1$ 重合，出现对数解，这正是勒让德函数第二类 $Q_n$ 的来源。"))+
   note(p("指标差 $1-c$ 是否为整数决定解的类型：非整数用两个超几何解，整数（特别是 $c=1$）需补充含 $\\ln z$ 的第二个解。"))
 )},
{"id":"sf5s2-3","name":"欧拉与普法夫变换","tags":["der","thm"],"brief":"两个变量的有理变换公式及其推导思路。",
 "body": wrap(
   thm("变换公式", p("超几何函数在变量有理替换下保持形式：")+
   fml("{}_{2}F_{1}(a,b;c;z)=(1-z)^{c-a-b}{}_{2}F_{1}(c-a,c-b;c;z)","欧拉变换")+
   p("以及 Pfaff 变换：")+
   fml("{}_{2}F_{1}(a,b;c;z)=(1-z)^{-a}{}_{2}F_{1}\\!\\left(a,c-b;c;\\frac{z}{z-1}\\right)"))+
   der(p("<strong>推导思路（Pfaff）：</strong>把级数写成贝塔积分：")+
   fml("{}_{2}F_{1}(a,b;c;z)=\\frac{\\Gamma(c)}{\\Gamma(b)\\Gamma(c-b)}\\int_0^1 t^{\\,b-1}(1-t)^{\\,c-b-1}(1-zt)^{-a}dt")+
   p("作换元 $t=1-s$，则 $1-t=s$，$1-zt=1-z+zs=(1-z)\\left(1+\\frac{z}{1-z}s\\right)=(1-z)(1-\\tilde z s)$，其中 $\\tilde z=\\frac{z}{z-1}$。代入：")+
   fml("{}_{2}F_{1}(a,b;c;z)=(1-z)^{-a}\\cdot\\frac{\\Gamma(c)}{\\Gamma(b)\\Gamma(c-b)}\\int_0^1 s^{\\,c-b-1}(1-s)^{\\,b-1}(1-\\tilde z s)^{-a}ds")+
   p("最后的积分正是 ${}_{2}F_{1}(a,c-b;c;\\tilde z)$，即得 Pfaff 变换。欧拉变换可由 Pfaff 变换使用两次得到。"))+
   note(p("这两个变换把发散区（如 $z<0$）映射到收敛区（$0<z<1$），是数值计算超几何函数的基石，也是解析延拓（连接公式）的来源。"))
 )},
]},
{
"name": "5.3 超几何函数的变换与特殊情形",
"color": "#ec4899",
"desc": "初等特例、勒让德函数与不完全贝塔",
"items": [
{"id":"sf5s3-1","name":"反正切与初等特例","tags":["exa","der"],"brief":"₂F₁(1/2,1;3/2;-z²)=arctan(z)/z。",
 "body": wrap(
   der(p("<strong>从 arctan 的级数出发：</strong>已知 $\\arctan z=\\sum_{n\\ge0}\\frac{(-1)^{n}z^{2n+1}}{2n+1}$，两边除以 $z$：")+
   fml("\\frac{\\arctan z}{z}=\\sum_{n=0}^{\\infty}\\frac{(-1)^{n}z^{2n}}{2n+1}")+
   p("现在计算超几何系数：$a=\\frac12,b=1,c=\\frac32$。先算 Pochhammer 比：")+
   fml("\\frac{(\\tfrac12)_n(1)_n}{(\\tfrac32)_n n!} = \\frac{\\Gamma(\\tfrac32)}{\\Gamma(\\tfrac12)}\\cdot\\frac{\\Gamma(\\tfrac12+n)\\Gamma(1+n)}{\\Gamma(\\tfrac32+n)n!}")+
   p("由 $\\Gamma(\\tfrac32+n)=\\Gamma(\\tfrac12+n)(n+\\tfrac12)$ 与 $\\Gamma(1+n)=n!$，化简得：")+
   fml("\\frac{(\\tfrac12)_n(1)_n}{(\\tfrac32)_n n!} = \\frac{\\Gamma(\\tfrac32)}{\\Gamma(\\tfrac12)}\\cdot\\frac{1}{n+\\tfrac12} = \\frac{\\tfrac12\\sqrt\\pi}{\\sqrt\\pi}\\cdot\\frac{1}{n+\\tfrac12} = \\frac{1}{2n+1}")+
   p("代入 $z\\to -z^{2}$ 得：")+
   fml("{}_{2}F_{1}\\!\\left(\\tfrac12,1;\\tfrac32;-z^{2}\\right) = \\sum_{n\\ge0}\\frac{(-1)^{n}z^{2n}}{2n+1} = \\frac{\\arctan z}{z}"))+
   note(p("同理可得 $\\arcsin$ 型：${}_{2}F_{1}(\\tfrac12,\\tfrac12;\\tfrac32;z^{2})$ 给出 $\\frac{\\arcsin z}{z}$，说明三角反函数都是超几何的特例。"))
 )},
{"id":"sf5s3-2","name":"勒让德函数与多项式","tags":["der","thm"],"brief":"P_n(x)=₂F₁(-n,n+1;1;(1-x)/2) 及连带函数。",
 "body": wrap(
   thm("勒让德表示", p("勒让德多项式与连带勒让德函数都是超几何函数的特例：")+
   fml("P_n(x)={}_{2}F_{1}\\!\\left(-n,n+1;1;\\frac{1-x}{2}\\right)")+
   p("连带函数则用 $\\mu$ 阶导数或附加 $\\Gamma$ 因子表示。"))+
   der(p("<strong>由罗德里格斯公式验证：</strong>勒让德多项式定义为 $P_n(x)=\\frac{1}{2^{n}n!}\\frac{d^{n}}{dx^{n}}(x^{2}-1)^{n}$。把 $(x^{2}-1)^{n}=(x-1)^{n}(x+1)^{n}$ 作泰勒展开并按 $n$ 阶导提取：")+
   fml("P_n(x)=\\frac{1}{2^{n}n!}\\frac{d^{n}}{dx^{n}}\\left[(x-1)^{n}\\left(2+(x-1)\\right)^{n}\\right]")+
   p("对 $(x+1)^{n}$ 在 $x=1$ 附近展开，$\\frac{d^n}{dx^n}$ 只保留 $n$ 次项前的系数，经整理即得上式；关键恒等式是 $\\frac{d^{n}}{dx^{n}}(x-1)^{n}=n!$ 与 $(x+1)^{n}\\big|_{x=1}=2^{n}$。"))+
   exa(p("<strong>例：</strong>$n=1$ 时 ${}_{2}F_{1}(-1,2;1;\\frac{1-x}{2})=1-2\\cdot\\frac{1-x}{2}=x=P_1(x)$，一致。$n=2$ 时得到 $P_2=\\frac{3x^{2}-1}{2}$。"))+
   note(p("勒让德函数与球坐标下的拉普拉斯方程分离变量直接相关，因此超几何函数出现在所有中心势问题的角向部分。"))
 )},
{"id":"sf5s3-3","name":"不完全贝塔与积分表示","tags":["der","app"],"brief":"B_x(a,b) 的超几何表达及积分恒等式。",
 "body": wrap(
   der(p("<strong>不完全贝塔函数：</strong>定义 $B_x(a,b)=\\int_0^{x}t^{a-1}(1-t)^{b-1}dt$。作换元 $t=xs$：")+
   fml("B_x(a,b)=x^{a}\\int_0^{1}s^{\\,a-1}(1-xs)^{\\,b-1}ds")+
   p("把 $(1-xs)^{b-1}=\\sum_{n\\ge0}\\frac{(1-b)_n}{n!}(xs)^{n}$ 展开逐项积分：")+
   fml("B_x(a,b)=x^{a}\\sum_{n=0}^{\\infty}\\frac{(1-b)_n}{n!}x^{n}\\int_0^{1}s^{\\,a+n-1}ds = \\sum_{n=0}^{\\infty}\\frac{(1-b)_n}{n!}\\cdot\\frac{x^{\\,a+n}}{a+n}")+
   p("整理后即得超几何表示：")+
   fml("B_x(a,b)=\\frac{x^{a}}{a}\\,{}_{2}F_{1}(a,1-b;a+1;x)")+
   p("当 $x\\to1$ 且 $\\Re a>0$ 时回到完整贝塔函数 $B(a,b)=\\Gamma(a)\\Gamma(b)/\\Gamma(a+b)$，与 5.1.2 的高斯求和公式自洽。"))+
   app(p("不完全贝塔是 $\\beta$ 分布、$t$ 分布与 $F$ 分布的累积函数，广泛用于统计检验与贝叶斯推断的数值计算。"))+
   note(p("由 $B_x$ 还可导出超几何函数的积分表示 ${}_{2}F_{1}(a,b;c;z)=\\frac{\\Gamma(c)}{\\Gamma(b)\\Gamma(c-b)}\\int_0^1 t^{b-1}(1-t)^{c-b-1}(1-zt)^{-a}dt$，这正是 5.2 节推导变换公式的出发点。"))
 )},
]},
{
"name": "5.4 合流超几何函数",
"color": "#f472b6",
"desc": "库默尔方程、级数与经典多项式",
"items": [
{"id":"sf5s4-1","name":"库默尔方程与合流","tags":["def","der"],"brief":"b→∞ 极限把两个奇点合流，得到 ₁F₁。",
 "fig":"kummer","figCap":"₁F₁(1;1;x)=e^x：合流超几何的最基本特例",
 "body": wrap(
   defn("库默尔函数", p("作极限 $b\\to\\infty$ 同时 $z\\to0$ 使 $bz$ 固定为 $z$，超几何方程的两个奇点 $z=1$ 与 $z=\\infty$ 合流，得到<strong>库默尔方程</strong>：")+
   fml("z\\,y''+(b-z)y'-a\\,y=0")+
   p("其正则解称为第一类合流超几何函数 ${}_{1}F_{1}(a;b;z)$。"))+
   der(p("<strong>由级数取极限：</strong>从 ${}_{2}F_{1}$ 的系数出发，令 $b\\to\\infty$、$z\\to z/b$：")+
   fml("\\frac{(b)_n}{(c)_n}\\left(\\frac{z}{b}\\right)^{n} \\xrightarrow{b\\to\\infty} \\frac{z^{n}}{(c)_n}")+
   p("这是因为 $(b)_n=b(b+1)\\cdots(b+n-1)\\sim b^{n}$，故 $(b)_n/b^{n}\\to1$。于是级数变为：")+
   fml("{}_{1}F_{1}(a;b;z)=\\sum_{n=0}^{\\infty}\\frac{(a)_n}{(b)_n}\\frac{z^{n}}{n!}")+
   p("它对一切有限 $z$ 收敛（整函数），因为相邻项之比 $\\sim z/n\\to0$。"))+
   note(p("合流把 $0,1,\\infty$ 三个奇点中的两个合并为 $\\infty$ 处的一个非正则奇点，故 ${}_{1}F_{1}$ 在 $z\\to\\infty$ 处呈指数增长而非代数幂，这体现在其渐近 $e^{z}z^{a-b}$。"))
 )},
{"id":"sf5s4-2","name":"₁F₁ 级数与指数特例","tags":["der","exa"],"brief":"验证 ₁F₁(1;1;z)=e^z 与相关恒等式。",
 "body": wrap(
   der(p("<strong>指数函数：</strong>取 $a=b=1$，则 $(1)_n=n!$，于是：")+
   fml("{}_{1}F_{1}(1;1;z)=\\sum_{n=0}^{\\infty}\\frac{n!}{n!}\\frac{z^{n}}{n!}=\\sum_{n=0}^{\\infty}\\frac{z^{n}}{n!}=e^{z}")+
   p("这一特例说明指数函数在合流超几何族中的地位，正如 $1/(1-z)$ 在 ${}_{2}F_{1}$ 族中。")+
   p("<strong>误差函数特例：</strong>取 $a=\\frac12,b=\\frac32$，则 $\\frac{(1/2)_n}{(3/2)_n}=\\frac{1}{2n+1}$，故：")+
   fml("{}_{1}F_{1}\\!\\left(\\tfrac12;\\tfrac32;-z^{2}\\right)=\\sum_{n\\ge0}\\frac{(-1)^{n}z^{2n}}{2n+1}=\\frac{\\arctan z}{z}")+
   p("而 ${}_{1}F_{1}(\\tfrac12;\\tfrac32;z^{2})$ 给出 $\\frac{\\sqrt\\pi}{2z}\\operatorname{erf}(z)$ 的形式：")+
   fml("\\operatorname{erf}(z)=\\frac{2z}{\\sqrt\\pi}\\,{}_{1}F_{1}\\!\\left(\\tfrac12;\\tfrac32;-z^{2}\\right)"))+
   exa(p("<strong>例：</strong>用该式的小 $z$ 展开可复现误差函数的幂级数 $\\frac{2}{\\sqrt\\pi}(z-\\frac{z^{3}}{3}+\\cdots)$。"))+
   note(p("大量「特殊函数」都是 ${}_{1}F_{1}$ 或 ${}_{2}F_{1}$ 在特定参数下的特例，这种统一视角极大简化了公式的记忆与推导。"))
 )},
{"id":"sf5s4-3","name":"拉盖尔多项式与厄米关系","tags":["der","thm"],"brief":"L_n^α 由 ₁F₁ 表达，并联系厄米多项式。",
 "body": wrap(
   thm("拉盖尔表示", p("缔合拉盖尔多项式为合流超几何的截断：")+
   fml("L_n^{(\\alpha)}(x)=\\binom{n+\\alpha}{n}{}_{1}F_{1}(-n;\\alpha+1;x)"))+
   der(p("<strong>验证递推：</strong>取 $a=-n$ 使级数在第 $n+1$ 项截断为多项式。由 ${}_{1}F_{1}$ 的系数递推（与 5.2 节同理）：")+
   fml("(k+1)(k+b)c_{k+1}=(k+a)c_k")+
   p("当 $a=-n$，$k=n$ 时右端为零，故 $c_{n+1}=0$，级数截断。把 $c_k=\\frac{(-n)_k}{(b)_k k!}$ 代入拉盖尔定义即得标准形式的微分方程：")+
   fml("x\\,y''+(\\alpha+1-x)y'+n\\,y=0")+
   p("这正是拉盖尔方程，与库默尔方程取 $a=-n,b=\\alpha+1$ 后完全一致。")+
   p("<strong>与厄米的关系：</strong>厄米多项式可用拉盖尔在 $x^{2}$ 处表示：")+
   fml("H_{2n}(x)=(-1)^{n}2^{2n}n!\\,L_n^{(-1/2)}(x^{2})")+
   p("由此可把谐振子径向方程的解析统一到合流超几何框架。"))+
   note(p("氢原子的径向波函数、三维谐振子、库仑势散射函数全都由 ${}_{1}F_{1}$ 描述，这是量子力学中解析可解性的共同数学根源。"))
 )},
]},
{
"name": "5.5 超几何函数的应用",
"color": "#9d174d",
"desc": "氢原子、级数解法与统计物理",
"items": [
{"id":"sf5s5-1","name":"氢原子的径向解","tags":["app","der"],"brief":"库仑势方程化为 ₁F₁ 并给出能级量化。",
 "body": wrap(
   app(p("氢原子的库仑势 $-e^{2}/r$ 使径向方程化为合流超几何方程，这是量子力学最重要的解析解。"))+
   der(p("<strong>径向方程：</strong>设 $u(r)=rR(r)$，分离变量后：")+
   fml("u''+\\frac{2m}{\\hbar^{2}}\\left[E+\\frac{e^{2}}{r}-\\frac{l(l+1)\\hbar^{2}}{2mr^{2}}\\right]u=0")+
   p("作无量纲化，令 $\\rho=\\kappa r$（$\\kappa=\\sqrt{-2mE}/\\hbar$），并提取渐近行为 $u\\sim\\rho^{l+1}e^{-\\rho}$，设 $u=\\rho^{l+1}e^{-\\rho}v(\\rho)$。代入并整理得库默尔方程：")+
   fml("\\rho\\,v''+\\left[2(l+1)-\\rho\\right]v'+\\left[\\lambda-(l+1)\\right]v=0,\\quad \\lambda=\\frac{me^{2}}{\\hbar^{2}\\kappa}")+
   p("与 $z y''+(b-z)y'-a y=0$ 对比得 $b=2l+2$，$a=l+1-\\lambda$。为使波函数在无穷远可归一，级数必须截断，即 $a=-n_r$（$n_r=0,1,2,\\dots$）：")+
   fml("l+1-\\lambda=-n_r \\;\\Longrightarrow\\; \\lambda=n_r+l+1=n")+
   p("由 $\\lambda=me^{2}/\\hbar^{2}\\kappa$ 反解 $E$，即得玻尔能级：")+
   fml("E_n=-\\frac{me^{4}}{2\\hbar^{2}n^{2}}=-\\frac{13.6\\,\\mathrm{eV}}{n^{2}}"))+
   note(p("能级量子化正是「合流超几何级数必须截断为多项式」的数学后果，与谐振子、氢原子的一般规律一致。"))
 )},
{"id":"sf5s5-2","name":"微分方程的级数解法","tags":["app","der"],"brief":"用超几何统一分类二阶方程的初等解。",
 "body": wrap(
   app(p("超几何方程是二阶线性微分方程级数解法的「标准模型」：任何具有三个正则奇点的方程都可通过变量替换化为它。"))+
   der(p("<strong>化归步骤：</strong>设方程为 $y''+p(z)y'+q(z)y=0$，在正则奇点 $z_i$ 处指数为 $\\{\\alpha_i,\\beta_i\\}$。黎曼 P 符号记为：")+
   fml("y=P\\left\\{\\begin{matrix}0 & 1 & \\infty\\\\ 0 & 0 & a & z\\\\ 1-c & c-a-b & b\\end{matrix}\\right\\}")+
   p("作出「剥离奇异部分」的替换 $y=z^{\\alpha_0}(1-z)^{\\alpha_1}w$，可使方程化为超几何形式：")+
   fml("z(1-z)w''+\\left[c-(a+b+1)z\\right]w'-ab\\,w=0")+
   p("其中的指数由原方程在三个奇点处的指标确定。于是原方程的解为：")+
   fml("y=z^{\\alpha_0}(1-z)^{\\alpha_1}{}_{2}F_{1}(a,b;c;z)"))+
   exa(p("<strong>例：</strong>勒让德方程 $(1-x^{2})y''-2xy'+n(n+1)y=0$ 在 $x=\\frac{1-z}{2}$ 变换下化为超几何方程，参数 $a=-n,b=n+1,c=1$，恢复 $P_n(x)$。"))+
   note(p("这一化归使「解方程」变成「查参数」，是 19 世纪特殊函数理论的核心成就，也为现代的符号计算（如 Mathematica 的 DSolve）奠定基础。"))
 )},
{"id":"sf5s5-3","name":"统计物理与散射应用","tags":["app","der"],"brief":"费米/玻色积分、散射振幅与配分函数。",
 "body": wrap(
   app(p("超几何与合流超几何函数在统计物理与散射理论中频繁出现，尤其在处理带参数的积分与求和时。"))+
   der(p("<strong>费米-狄拉克积分：</strong>定义 $I_s(\\eta)=\\int_0^{\\infty}\\frac{x^{s-1}}{e^{x-\\eta}+1}dx$。把 $\\frac{1}{e^{x-\\eta}+1}=e^{\\eta-x}\\sum_{k\\ge0}(-1)^{k}e^{-kx+ k\\eta}$ 展开逐项积分（$x^{s-1}$）：")+
   fml("I_s(\\eta)=\\Gamma(s)\\sum_{k=1}^{\\infty}\\frac{(-1)^{k-1}e^{k\\eta}}{k^{s}}=-\\Gamma(s)\\,\\mathrm{Li}_s(-e^{\\eta})")+
   p("而多重对数函数 $\\mathrm{Li}_s$ 又可写成超几何/合流超几何的级数，从而把费米气体性质纳入超几何框架。")+
   p("<strong>散射振幅：</strong>库仑散射振幅中的 $e^{-i\\pi l}$ 因子与 $\\Gamma$ 函数比，正对应合流超几何函数在无穷远处的连接系数，其相位即著名的库仑相移 $\\sigma_l=\\arg\\Gamma(l+1+i\\eta)$。"))+
   note(p(" Veneziano 振幅 $A(s,t)=\\frac{\\Gamma(-\\alpha(s))\\Gamma(-\\alpha(t))}{\\Gamma(-\\alpha(s)-\\alpha(t))}$ 用贝塔函数（因而与超几何相关）描述了强子散射的 Regge 行为，是弦论的起点。"))
 )},
]},
]

ch6_sections = [
{
"name": "6.1 厄米多项式的定义与生成函数",
"color": "#0891b2",
"desc": "罗德里格斯公式、生成函数与显式展开",
"items": [
{"id":"sf6s1-1","name":"厄米多项式的定义","tags":["def","der"],"brief":"H_n(x)=(-1)^n e^(x²)(d^n/dx^n)e^(-x²)，并给出前几个。",
 "fig":"hermite","figCap":"前四个厄米多项式 H0~H3 的图像，奇偶性与 n 一致",
 "body": wrap(
   defn("厄米多项式", p("定义<strong>厄米多项式</strong>为高斯函数的逐阶导数（罗德里格斯公式）：")+
   fml("H_n(x)=(-1)^{n}e^{x^{2}}\\frac{d^{n}}{dx^{n}}e^{-x^{2}}","n=0,1,2,\\dots")+
   p("它是量子谐振子定态波函数的核心成分。"))+
   der(p("<strong>逐阶计算：</strong>先记 $g(x)=e^{-x^{2}}$，$g'=-2xe^{-x^{2}}$，故 $H_1=(-1)e^{x^{2}}(-2xe^{-x^{2}})=2x$。继续：")+
   fml("g''=(-2+4x^{2})e^{-x^{2}} \\;\\Longrightarrow\\; H_2=e^{x^{2}}\\cdot(-2+4x^{2})e^{-x^{2}}=4x^{2}-2")+
   p("再求一阶导：$g'''=(12x-8x^{3})e^{-x^{2}}$，故：")+
   fml("H_3=-e^{x^{2}}(12x-8x^{3})e^{-x^{2}}=8x^{3}-12x")+
   p("于是前四个为 $H_0=1$，$H_1=2x$，$H_2=4x^{2}-2$，$H_3=8x^{3}-12x$。"))+
   note(p("由定义可见 $H_n$ 是 $n$ 次多项式，最高次项系数为 $2^{n}$，且奇偶性与 $n$ 一致：$H_n(-x)=(-1)^{n}H_n(x)$。"))
 )},
{"id":"sf6s1-2","name":"生成函数","tags":["der","thm"],"brief":"e^(2xt-t²)=Σ H_n(x)t^n/n! 的推导与用途。",
 "body": wrap(
   thm("生成函数", p("厄米多项式由高斯生成函数给出：")+
   fml("e^{\\,2xt-t^{2}} = \\sum_{n=0}^{\\infty}H_n(x)\\,\\frac{t^{n}}{n!}"))+
   der(p("<strong>推导：</strong>注意高斯函数的平移性质：")+
   fml("e^{-(x-t)^{2}} = e^{-x^{2}+2xt-t^{2}} = e^{-x^{2}}\\,e^{2xt-t^{2}}")+
   p("另一方面把 $e^{-(x-t)^{2}}$ 在 $t=0$ 处按 $t$ 作泰勒展开：")+
   fml("e^{-(x-t)^{2}}=\\sum_{n=0}^{\\infty}\\frac{t^{n}}{n!}\\left.\\frac{\\partial^{n}}{\\partial t^{n}}e^{-(x-t)^{2}}\\right|_{t=0}")+
   p("由链式法则 $\\frac{\\partial}{\\partial t}e^{-(x-t)^{2}}=+2(x-t)e^{-(x-t)^{2}}=-\\frac{\\partial}{\\partial x}e^{-(x-t)^{2}}$，故 $n$ 阶导为 $(-1)^{n}\\partial_x^{n}e^{-(x-t)^{2}}$，在 $t=0$ 处：")+
   fml("\\left.\\frac{\\partial^{n}}{\\partial t^{n}}\\right|_{t=0} = (-1)^{n}\\frac{d^{n}}{dx^{n}}e^{-x^{2}} = e^{-x^{2}}H_n(x)")+
   p("两边除以 $e^{-x^{2}}$ 即得生成函数式。"))+
   note(p("生成函数是所有性质的「总开关」：对两边求导或代入特殊 $t$ 即可导出递推关系、正交性与特殊值。"))
 )},
{"id":"sf6s1-3","name":"显式展开","tags":["der"],"brief":"由生成函数展开得 H_n 的显式系数公式。",
 "fig":"hermite_rec","figCap":"厄米多项式前几项及其递推、导数与正交关系",
 "body": wrap(
   der(p("<strong>显式公式：</strong>把生成函数中的指数分开：")+
   fml("e^{2xt-t^{2}}=e^{2xt}e^{-t^{2}}=\\sum_{k\\ge0}\\frac{(2xt)^{k}}{k!}\\sum_{m\\ge0}\\frac{(-1)^{m}t^{2m}}{m!}")+
   p("提取 $t^{n}$ 的系数，令 $k+2m=n$，即 $k=n-2m$：")+
   fml("[t^{n}]e^{2xt-t^{2}} = \\sum_{m=0}^{\\lfloor n/2\\rfloor}\\frac{(2x)^{n-2m}}{(n-2m)!}\\cdot\\frac{(-1)^{m}}{m!}")+
   p("而 $H_n(x)=n!\\,[t^{n}]e^{2xt-t^{2}}$，故：")+
   fml("H_n(x)=n!\\sum_{m=0}^{\\lfloor n/2\\rfloor}\\frac{(-1)^{m}(2x)^{n-2m}}{m!\\,(n-2m)!}"))+
   exa(p("<strong>例：</strong>$n=4$ 时 $H_4=4!\\left[\\frac{(2x)^{4}}{4!}-\\frac{(2x)^{2}}{2!}+\\frac{1}{2!}\\right]=16x^{4}-48x^{2}+12$，与递推结果一致。"))+
   note(p("该显式公式在计算积分 $\\int x^{k}H_n(x)e^{-x^{2}}dx$ 时十分方便，因为只需处理单项式。"))
 )},
]},
{
"name": "6.2 递推关系与厄米微分方程",
"color": "#06b6d4",
"desc": "三项递推、微分方程与导数关系",
"items": [
{"id":"sf6s2-1","name":"三项递推关系","tags":["der","thm"],"brief":"H_{n+1}=2xH_n-2nH_{n-1} 的生成函数推导。",
 "body": wrap(
   thm("递推关系", p("厄米多项式满足：")+
   fml("H_{n+1}(x)=2x\\,H_n(x)-2n\\,H_{n-1}(x)"))+
   der(p("<strong>从生成函数出发：</strong>记 $G(x,t)=e^{2xt-t^{2}}=\\sum_n H_n(x)t^{n}/n!$。对 $t$ 求偏导：")+
   fml("\\frac{\\partial G}{\\partial t}=(2x-2t)G")+
   p("左端：$\\sum_n H_n\\frac{n t^{n-1}}{n!}=\\sum_{n\\ge0}H_{n+1}\\frac{t^{n}}{n!}$；右端：$(2x-2t)\\sum_n H_n\\frac{t^{n}}{n!}$。比较 $t^{n}/n!$ 的系数：")+
   fml("H_{n+1}=2x\\,H_n-2n\\,H_{n-1}")+
   p("其中 $-2t\\cdot H_{n-1}t^{n-1}/(n-1)!$ 贡献 $t^{n}$ 时系数为 $-2\\,n\\,H_{n-1}$，故末项系数为 $2n$。"))+
   exa(p("<strong>例：</strong>由 $H_0=1,H_1=2x$：$H_2=2x(2x)-2\\cdot1\\cdot1=4x^{2}-2$；$H_3=2x(4x^{2}-2)-4(2x)=8x^{3}-12x$，与罗德里格斯公式一致。"))+
   note(p("四项以上的高阶多项式都可由该递推快速生成，数值上比直接求导稳定得多，是计算谐振子波函数的标准算法。"))
 )},
{"id":"sf6s2-2","name":"厄米微分方程","tags":["der"],"brief":"由波函数或直接代入导出 y''-2xy'+2ny=0。",
 "body": wrap(
   thm("厄米方程", p("厄米多项式满足二阶常微分方程：")+
   fml("y''-2x\\,y'+2n\\,y=0"))+
   der(p("<strong>由方程级数解推导：</strong>设 $y=\\sum_{k}a_k x^{k}$ 代入方程，$x^{k}$ 的系数给出：")+
   fml("(k+2)(k+1)a_{k+2}-2k\\,a_k+2n\\,a_k=0")+
   p("即递推：")+
   fml("a_{k+2}=\\frac{2(k-n)}{(k+1)(k+2)}a_k")+
   p("为使解在无穷远按多项式增长（可归一），级数必须截断：要求某个 $k=n$ 时 $a_{n+2}=0$，于是 $a_{n}$ 之后全为零，解成为 $n$ 次多项式。奇偶分离：$n$ 为偶时只含偶次项，$n$ 为奇时只含奇次项，与 $H_n$ 的奇偶性一致。"))+
   der(p("<strong>与罗德里格斯公式等价：</strong>记 $g=e^{-x^{2}}$，则 $g'=-2xg$，$g''=(-2+4x^{2})g$。对 $y=(-1)^{n}e^{x^{2}}g^{(n)}$ 求导两次并利用 $g^{(n+1)}=-2xg^{(n)}-2ng^{(n-1)}$，可整理出 $y''-2xy'+2ny=0$。"))+
   note(p("厄米方程是「在无穷远有正则奇点（非正则）」的典型例子，其多项式解条件 $n$ 为整数正是能量量子化的数学表达。"))
 )},
{"id":"sf6s2-3","name":"导数关系","tags":["der","exa"],"brief":"H_n'=2nH_{n-1} 及由递推导出的降阶公式。",
 "body": wrap(
   der(p("<strong>导数关系：</strong>对生成函数关于 $x$ 求偏导：")+
   fml("\\frac{\\partial G}{\\partial x}=2t\\,G")+
   p("左端为 $\\sum_n H_n'(x)t^{n}/n!$，右端为 $2\\sum_n H_n t^{n+1}/n!=2\\sum_{n\\ge1}H_{n-1}\\frac{t^{n}}{(n-1)!}$。比较 $t^{n}/n!$ 系数：")+
   fml("H_n'(x)=2n\\,H_{n-1}(x)")+
   p("结合三项递推还可得到升阶公式。由 $H_{n+1}=2xH_n-2nH_{n-1}$ 对 $x$ 求导：")+
   fml("H_{n+1}'=2H_n+2xH_n'-2nH_{n-1}'")+
   p("代入 $H_{n+1}'=2(n+1)H_n$ 与 $H_{n-1}'=2(n-1)H_{n-2}$，整理得：")+
   fml("2x\\,H_n = H_{n+1}+2n\\,H_{n-1}")+
   p("与三项递推一致，说明两个关系相互独立地完整刻画了 $H_n$。"))+
   exa(p("<strong>例：</strong>$H_3'=24x^{2}-12$，而 $2\\cdot3\\cdot H_2=6(4x^{2}-2)=24x^{2}-12$，验证成立。"))+
   note(p("导数关系是计算矩阵元 $\\langle m|p|n\\rangle$ 与证明选择定则的捷径。"))
 )},
]},
{
"name": "6.3 正交性与积分性质",
"color": "#0891b2",
"desc": "高斯权重下的正交、递推积分与完备性",
"items": [
{"id":"sf6s3-1","name":"正交性","tags":["der","thm"],"brief":"∫H_mH_n e^(-x²)dx=√π 2^n n! δ_mn 的证明。",
 "body": wrap(
   thm("正交关系", p("厄米多项式以高斯为权重正交：")+
   fml("\\int_{-\\infty}^{\\infty}H_m(x)H_n(x)e^{-x^{2}}dx = \\sqrt{\\pi}\\,2^{n}n!\\,\\delta_{mn}"))+
   der(p("<strong>用生成函数：</strong>考虑两个生成函数的乘积并对 $e^{-x^{2}}$ 积分：")+
   fml("\\int e^{2xt-t^{2}}e^{2xs-s^{2}}e^{-x^{2}}dx = \\int e^{-(x-t-s)^{2}}e^{2st}dx")+
   p("配方检验：$2xt-t^{2}+2xs-s^{2}-x^{2}=-(x-t-s)^{2}+2st$。平移积分得：")+
   fml("= e^{2st}\\int e^{-u^{2}}du = \\sqrt\\pi\\,e^{2st}")+
   p("另一方面把两个生成函数按级数展开并比较 $t^{m}s^{n}/(m!n!)$ 的系数：左端等于 $\\sqrt\\pi\\sum_n\\frac{(2st)^{n}}{n!}$，故：")+
   fml("\\int H_mH_n e^{-x^{2}}dx = \\sqrt\\pi\\,2^{n}n!\\,\\delta_{mn}")+
   p("其中交叉项为零（$2st$ 中 $t,s$ 幂次相等）。"))+
   note(p("正交性使 $\\{H_n\\}$ 成为希尔伯特空间 $L^{2}(\\mathbb{R},e^{-x^{2}}dx)$ 的正交基，可用于函数展开（Hermite 变换）。"))
 )},
{"id":"sf6s3-2","name":"积分性质","tags":["der","exa"],"brief":"由递推计算 ∫xH_mH_n 权重积分与三项积分。",
 "body": wrap(
   der(p("<strong>含 $x$ 的积分：</strong>利用三项递推把 $x H_n$ 表示成同族组合。由 $2xH_n=H_{n+1}+2nH_{n-1}$：")+
   fml("2\\int x H_mH_n e^{-x^{2}}dx = \\int H_mH_{n+1}e^{-x^{2}}dx + 2n\\int H_mH_{n-1}e^{-x^{2}}dx")+
   p("用正交关系取 $m=n\\pm1$：")+
   fml("\\int x\\,H_nH_{n+1}e^{-x^{2}}dx = \\sqrt\\pi\\,2^{n}\\,(n+1)!")+
   p("而对角元为零（$x$ 为奇函数），即 $\\langle n|x|n\\rangle=0$，说明谐振子没有静态电极矩。"))+
   der(p("<strong>递推积分公式：</strong>由 $H_n'=2nH_{n-1}$ 分部积分可得：")+
   fml("\\int x^{2}H_n^{2}e^{-x^{2}}dx = \\sqrt\\pi\\,2^{n}n!\\left(n+\\frac12\\right)")+
   p("这给出谐振子的均方位置 $\\langle x^{2}\\rangle\\propto(n+\\frac12)$，与能级均分一致。"))+
   note(p("一般地，$\\int x^{k}H_n^{2}e^{-x^{2}}dx$ 在 $k$ 与 $n$ 同奇偶时非零，且可用递推逐次降幂计算。"))
 )},
{"id":"sf6s3-3","name":"完备性与函数展开","tags":["der","app"],"brief":"厄米函数构成正交完备基，用于高斯型积分变换。",
 "body": wrap(
   der(p("<strong>归一化基与展开：</strong>定义 $\\phi_n(x)=\\frac{H_n(x)e^{-x^{2}/2}}{\\sqrt{\\sqrt\\pi\\,2^{n}n!}}$，则 $\\int\\phi_m\\phi_n dx=\\delta_{mn}$。任意 $f\\in L^{2}(\\mathbb{R})$ 可展开为：")+
   fml("f(x)=\\sum_{n=0}^{\\infty}c_n\\,\\phi_n(x),\\qquad c_n=\\int_{-\\infty}^{\\infty}f(x)\\phi_n(x)\\,dx")+
   p("完备性由生成函数的高斯核性质（Mercer 核 $\\sum_n\\phi_n(x)\\phi_n(y)=\\delta(x-y)$）保证。")+
   p("<strong>应用——厄米变换：</strong>把 $f$ 用厄米函数展开，可把卷积、微分与乘 $x$ 的运算化为对系数 $c_n$ 的三项递推：")+
   fml("x\\phi_n = \\sqrt{\\tfrac{n+1}{2}}\\,\\phi_{n+1}+\\sqrt{\\tfrac{n}{2}}\\,\\phi_{n-1}")+
   p("这正是数值求解非线性薛定谔方程（分步傅里叶法与厄米谱方法）的基础。"))+
   app(p("厄米函数还用于概率论中的 Gram-Charlier 展开（用 $H_n$ 展开非高斯分布）、图像处理与热方程的谱方法。"))+
   note(p("完备性也意味着高斯型权重的函数空间与全直线上的 $L^{2}$ 同构，这使厄米展开成为「高斯版本的傅里叶级数」。"))
 )},
]},
{
"name": "6.4 量子谐振子中的应用",
"color": "#0e7490",
"desc": "定态波函数、升降算符与跃迁选律",
"items": [
{"id":"sf6s4-1","name":"谐振子定态波函数","tags":["app","der"],"brief":"解薛定谔方程得 ψ_n∝H_n(αx)e^(-α²x²/2)。",
 "fig":"hermite_qho","figCap":"量子谐振子前几个定态波函数，节点数随 n 增加",
 "body": wrap(
   app(p("一维量子谐振子是厄米多项式最直接的应用，其定态解精确地由 $H_n$ 给出。"))+
   der(p("<strong>薛定谔方程：</strong>哈密顿量 $H=-\\frac{\\hbar^{2}}{2m}\\frac{d^{2}}{dx^{2}}+\\frac12m\\omega^{2}x^{2}$，定态方程为：")+
   fml("-\\frac{\\hbar^{2}}{2m}\\psi''+\\frac12m\\omega^{2}x^{2}\\psi=E\\psi")+
   p("作无量纲化，令 $\\xi=\\alpha x$，$\\alpha=\\sqrt{m\\omega/\\hbar}$，$\\epsilon=2E/\\hbar\\omega$：")+
   fml("\\psi''+(\\epsilon-\\xi^{2})\\psi=0")+
   p("提取渐近行为 $\\psi\\sim e^{-\\xi^{2}/2}$，设 $\\psi=e^{-\\xi^{2}/2}y(\\xi)$，代入得：")+
   fml("y''-2\\xi y'+(\\epsilon-1)y=0")+
   p("与厄米方程 $y''-2xy'+2ny=0$ 比较，要求 $\\epsilon-1=2n$，即 $\\epsilon=2n+1$：")+
   fml("E_n=\\left(n+\\frac12\\right)\\hbar\\omega,\\qquad \\psi_n=N_n H_n(\\alpha x)e^{-\\alpha^{2}x^{2}/2}")+
   p("这就是谐振子的量子化条件与波函数。"))+
   note(p("与氢原子类似，能量量子化源于「二阶方程的解必须可归一⇒级数截断为多项式」，这是量子力学中解析可解模型的一般机制。"))
 )},
{"id":"sf6s4-2","name":"升降算符与代数解法","tags":["der"],"brief":"由 a、a† 的代数关系重推能级与递推。",
 "body": wrap(
   der(p("<strong>升降算符：</strong>定义 $a=\\sqrt{\\frac{m\\omega}{2\\hbar}}\\left(x+\\frac{ip}{m\\omega}\\right)$，$a^{\\dagger}=\\sqrt{\\frac{m\\omega}{2\\hbar}}\\left(x-\\frac{ip}{m\\omega}\\right)$。由 $[x,p]=i\\hbar$ 计算对易子：")+
   fml("[a,a^{\\dagger}]=\\frac{1}{2\\hbar}\\cdot i\\hbar\\left\\{\\left(-\\frac{i}{m\\omega}\\right)m\\omega - m\\omega\\frac{i}{m\\omega}\\cdot(-1)\\right\\}=1")+
   p("哈密顿量可写成：")+
   fml("H=\\hbar\\omega\\left(a^{\\dagger}a+\\frac12\\right)")+
   p("设 $H|n\\rangle=E_n|n\\rangle$。由 $[H,a]=-\\hbar\\omega a$ 得 $Ha|n\\rangle=(E_n-\\hbar\\omega)a|n\\rangle$，故 $a$ 降能 $\\hbar\\omega$；同理 $a^{\\dagger}$ 升能。为使能量有下界，必有最低态 $|0\\rangle$ 满足 $a|0\\rangle=0$，于是：")+
   fml("E_0=\\frac12\\hbar\\omega,\\qquad E_n=\\left(n+\\frac12\\right)\\hbar\\omega")+
   p("与解析解完全一致，体现了代数方法的高效。"))+
   note(p("在坐标表象 $a=\\frac{1}{\\sqrt2}(\\xi+\\frac{d}{d\\xi})$，条件 $a|0\\rangle=0$ 直接给出高斯基态 $e^{-\\xi^{2}/2}$；$|n\\rangle\\propto(a^{\\dagger})^{n}|0\\rangle$ 即生成 $H_n$。"))
 )},
{"id":"sf6s4-3","name":"矩阵元与跃迁选律","tags":["der","app"],"brief":"⟨m|x|n⟩ 的推导与 Δn=±1 选律。",
 "body": wrap(
   der(p("<strong>坐标算符表示：</strong>由升降算符反解 $x=\\sqrt{\\frac{\\hbar}{2m\\omega}}(a+a^{\\dagger})$。利用 $a|n\\rangle=\\sqrt n\\,|n-1\\rangle$，$a^{\\dagger}|n\\rangle=\\sqrt{n+1}\\,|n+1\\rangle$：")+
   fml("x|n\\rangle=\\sqrt{\\frac{\\hbar}{2m\\omega}}\\left(\\sqrt n\\,|n-1\\rangle+\\sqrt{n+1}\\,|n+1\\rangle\\right)")+
   p("取内积得矩阵元：")+
   fml("\\langle m|x|n\\rangle=\\sqrt{\\frac{\\hbar}{2m\\omega}}\\left(\\sqrt n\\,\\delta_{m,n-1}+\\sqrt{n+1}\\,\\delta_{m,n+1}\\right)")+
   p("可见只有 $m=n\\pm1$ 的矩阵元非零，这就是<strong>选择定则 $\\Delta n=\\pm1$</strong>。")+
   p("<strong>偶极跃迁：</strong>跃迁速率正比于 $|\\langle m|x|n\\rangle|^{2}$，故谐振子只能吸收或发射单个能量量子 $\\hbar\\omega$，谱线是等间距的单一频率。"))+
   app(p("这解释了分子振动光谱中红外吸收的基本选择定则；对非简谐修正，会出现 $\\Delta n=\\pm2,\\pm3$ 的泛音与组合带。"))+
   note(p("用同样方法可算得 $\\langle m|x^{2}|n\\rangle$ 的连接结构，它与拉曼选择定则 $\\Delta n=0,\\pm2$ 直接相关。"))
 )},
]},
]

ch7_sections = [
{
"name": "7.1 椭圆积分的定义与分类",
"color": "#4f46e5",
"desc": "一般形式、三类勒让德标准型与初等特例",
"items": [
{"id":"sf7s1-1","name":"椭圆积分的定义","tags":["def","der"],"brief":"含根式 √(三次/四次多项式) 的不可初等积分。",
 "body": wrap(
   defn("椭圆积分", p("形如：")+
   fml("\\int R\\!\\left(x,\\sqrt{P(x)}\\right)dx","P 为三次或四次多项式，R 为有理函数")+
   p("且不能用初等函数表示的积分，称为<strong>椭圆积分</strong>。它起源于椭圆弧长与单摆周期问题。"))+
   der(p("<strong>为何不可初等：</strong>当 $P(x)$ 为二次时，换元 $x=a\\sin\\theta$ 可把 $\\sqrt{1-x^{2}}$ 化为三角式，得到反正弦等初等函数。当 $P$ 为三次或四次时，积分对应亏格为 1 的代数曲线：")+
   fml("y^{2}=P(x),\\quad \\deg P=3\\text{ 或 }4")+
   p("其全纯微分的积分不是有理函数的对数，故不能用初等函数表达。由 Abel-Jacobi 定理，这类积分是椭圆函数（双周期亚纯函数）的反演。"))+
   exa(p("<strong>例：</strong>椭圆弧长积分 $\\int\\sqrt{1-e^{2}\\sin^{2}\\theta}\\,d\\theta$ 与单摆周期 $\\int d\\theta/\\sqrt{1-k^{2}\\sin^{2}\\theta}$ 都是椭圆积分。"))+
   note(p("若 $P$ 的次数更高（亏格 $g\\ge2$），积分称为超椭圆积分；椭圆积分对应 $g=1$，是唯一能用双周期函数反演的「简单」情形。"))
 )},
{"id":"sf7s1-2","name":"三类勒让德标准形式","tags":["def","der"],"brief":"第一、二、三类不完全椭圆积分的标准定义。",
 "body": wrap(
   defn("勒让德三类", p("通过代换把任意椭圆积分化为三种标准形式：")+
   fml("F(\\varphi,k)=\\int_0^{\\varphi}\\frac{d\\theta}{\\sqrt{1-k^{2}\\sin^{2}\\theta}}","第一类")+
   fml("E(\\varphi,k)=\\int_0^{\\varphi}\\sqrt{1-k^{2}\\sin^{2}\\theta}\\,d\\theta","第二类")+
   fml("\\Pi(n,\\varphi,k)=\\int_0^{\\varphi}\\frac{d\\theta}{(1-n\\sin^{2}\\theta)\\sqrt{1-k^{2}\\sin^{2}\\theta}}","第三类")+
   p("其中 $k$ 称模数（$0<k<1$），$n$ 为特征参数。取 $\\varphi=\\pi/2$ 得到完全椭圆积分 $K,E,\\Pi$。"))+
   der(p("<strong>化归思路：</strong>一般椭圆积分含 $\\sqrt{R_4(x)}$，$R_4$ 为四次多项式。先作双线性变换 $x=\\frac{at+b}{ct+d}$ 把 $R_4$ 的两个零点映到 $\\pm1$，再令 $x=\\sin\\theta$，即可把根式化为 $\\sqrt{1-k^{2}\\sin^{2}\\theta}$ 的形式。关键步骤是选择合适的交比不变量（模数 $k$）。")+
   p("以 $\\int dx/\\sqrt{(1-x^{2})(1-k^{2}x^{2})}$ 为例，令 $x=\\sin\\theta$，$dx=\\cos\\theta\\,d\\theta$：")+
   fml("\\sqrt{(1-\\sin^{2}\\theta)(1-k^{2}\\sin^{2}\\theta)}=\\cos\\theta\\sqrt{1-k^{2}\\sin^{2}\\theta}")+
   p("故被积式化为 $d\\theta/\\sqrt{1-k^{2}\\sin^{2}\\theta}$，正是 $F(\\varphi,k)$。"))+
   note(p("勒让德把椭圆积分归约为三类，这是特殊函数理论化的重要一步；第三类 $\\Pi$ 在解含 $\\sin^{2}$ 分母的物理问题（如球面摆）时出现。"))
 )},
{"id":"sf7s1-3","name":"退化为初等函数的情形","tags":["exa","der"],"brief":"k=0,1 或 φ 很小时的极限行为。",
 "body": wrap(
   exa(p("<strong>例：</strong>取 $k=0$：$F(\\varphi,0)=\\int_0^{\\varphi}d\\theta=\\varphi$，$E(\\varphi,0)=\\varphi$，回到初等的角度量。取 $k=1$：")+
   fml("F(\\varphi,1)=\\int_0^{\\varphi}\\frac{d\\theta}{\\cos\\theta}=\\ln\\tan\\!\\left(\\frac{\\pi}{4}+\\frac{\\varphi}{2}\\right)")+
   p("$E(\\varphi,1)=\\sin\\varphi$，也都退化为初等函数。"))+
   der(p("<strong>小模数展开：</strong>把 $\\frac{1}{\\sqrt{1-k^{2}\\sin^{2}\\theta}}$ 用二项式展开：")+
   fml("(1-k^{2}\\sin^{2}\\theta)^{-1/2}=1+\\frac12k^{2}\\sin^{2}\\theta+\\frac38k^{4}\\sin^{4}\\theta+\\cdots")+
   p("逐项积分并用 $\\int_0^{\\pi/2}\\sin^{2n}\\theta\\,d\\theta=\\frac{(2n-1)!!}{(2n)!!}\\frac{\\pi}{2}$：")+
   fml("K(k)=\\frac{\\pi}{2}\\left[1+\\left(\\frac12\\right)^{2}k^{2}+\\left(\\frac{1\\cdot3}{2\\cdot4}\\right)^{2}k^{4}+\\cdots\\right]")+
   p("这正是 $K(k)$ 的级数展开，也是天文学中计算周期修正的经典公式。"))+
   note(p("$k\\to1$ 时 $K$ 对数发散（见 7.2.2），而非多项式展开能描述，故需要不同的渐近方法。"))
 )},
]},
{
"name": "7.2 勒让德标准形式与完全椭圆积分",
"color": "#6366f1",
"desc": "标准化的代换、K 与 E 的性质及 AGM 计算",
"items": [
{"id":"sf7s2-1","name":"完全椭圆积分 K 与 E","tags":["def","der"],"brief":"K,E 的定义、级数与 k→1 的对数发散。",
 "fig":"elliptic","figCap":"完全椭圆积分 K(k) 与 E(k) 随模数 k 的变化：K 在 k→1 发散，E 趋于 1",
 "body": wrap(
   defn("完全椭圆积分", p("在标准型中取 $\\varphi=\\pi/2$：")+
   fml("K(k)=\\int_0^{\\pi/2}\\frac{d\\theta}{\\sqrt{1-k^{2}\\sin^{2}\\theta}},\\qquad E(k)=\\int_0^{\\pi/2}\\sqrt{1-k^{2}\\sin^{2}\\theta}\\,d\\theta")+
   p("它们是单摆周期、椭圆弧长与波动方程分离变量中的核心量。"))+
   der(p("<strong>$K$ 的对数发散：</strong>令 $\\theta=\\pi/2-\\phi$，$\\sin\\theta=\\cos\\phi$。当 $k\\to1$ 时奇性来自 $\\phi\\to0$：")+
   fml("1-k^{2}\\cos^{2}\\phi = (1-k^{2})+k^{2}\\phi^{2}+\\cdots \\approx k'^{2}+\\phi^{2}")+
   p("其中 $k'=\\sqrt{1-k^{2}}$ 为余模数。于是：")+
   fml("K(k)\\approx\\int_0^{\\delta}\\frac{d\\phi}{\\sqrt{k'^{2}+\\phi^{2}}}=\\ln\\!\\left(\\frac{\\delta+\\sqrt{\\delta^{2}+k'^{2}}}{k'}\\right)\\sim\\ln\\frac{4}{k'}")+
   p("故 $K(k)\\sim\\ln\\frac{4}{k'}=\\ln\\frac{4}{\\sqrt{1-k^{2}}}$，为对数发散。"))+
   note(p("$E(k)$ 在 $k\\to1$ 时趋于有限值 $E(1)=1$，因为被积函数有界；两函数的这种不同行为对应单摆周期在接近倒立时发散、而弧长保持有限。"))
 )},
{"id":"sf7s2-2","name":"加法与倍角公式","tags":["der","thm"],"brief":"K,E 的 Legendre 关系与倍角变换。",
 "body": wrap(
   thm("勒让德关系", p("$K$ 与 $E$ 满足：")+
   fml("E(k)K(k')+E(k')K(k)-K(k)K(k')=\\frac{\\pi}{2}","勒让德关系式")+
   p("对 $k=k'=1/\\sqrt2$ 得 $E K=\\pi/4$，是数值检验的常用点。"))+
   der(p("<strong>倍角（Landen）变换：</strong>设 $k_1=\\frac{1-k'}{1+k'}$ 为下降模数。作换元 $\\sin(2\\theta')=\\frac{(1+k')\\sin\\theta}{1+k'\\sin^{2}\\theta}$，经代数化简可得：")+
   fml("K(k)=\\frac{1}{1+k'}K(k_1)")+
   p("该变换每次迭代使模数迅速减小，是 AGM 算法的基础。连续迭代：")+
   fml("K(k)=\\frac{\\pi/2}{\\mathrm{AGM}(1,k')},\\qquad \\mathrm{AGM}(a,b)=\\lim_{n\\to\\infty}a_n\\ \\ (a_{n+1}=\\tfrac{a_n+b_n}{2},\\ b_{n+1}=\\sqrt{a_nb_n})")+
   p("由于 AGM 二次收敛，几十步内即可达到机器精度。"))+
   exa(p("<strong>例：</strong>取 $k=1/\\sqrt2$，$k'=1/\\sqrt2$，$\\mathrm{AGM}(1,1/\\sqrt2)\\approx0.8472$，则 $K\\approx\\pi/(2\\cdot0.8472)=1.8541$，与精确值一致。"))+
   note(p("AGM 是高斯 18 岁的发现，把椭圆积分与算术-几何平均联系起来，也是现代高精度圆周率与椭圆积分数值算法的核心。"))
 )},
{"id":"sf7s2-3","name":"完全椭圆积分的导数","tags":["der","exa"],"brief":"dK/dk、dE/dk 的推导与相互表示。",
 "body": wrap(
   der(p("<strong>$K$ 与 $E$ 的导数：</strong>对 $E(k)=\\int_0^{\\pi/2}\\sqrt{1-k^{2}\\sin^{2}\\theta}\\,d\\theta$ 在积分号下对 $k$ 求导：")+
   fml("\\frac{dE}{dk}=\\int_0^{\\pi/2}\\frac{-k\\sin^{2}\\theta}{\\sqrt{1-k^{2}\\sin^{2}\\theta}}\\,d\\theta")+
   p("利用恒等式 $\\frac{k^{2}\\sin^{2}\\theta}{\\sqrt{1-k^{2}\\sin^{2}\\theta}}=\\frac{1}{\\sqrt{1-k^{2}\\sin^{2}\\theta}}-\\sqrt{1-k^{2}\\sin^{2}\\theta}$：")+
   fml("\\frac{dE}{dk}=\\frac1k\\left(E-K\\right)")+
   p("类似地对 $K$ 求导并整理得：")+
   fml("\\frac{dK}{dk}=\\frac{E-k'^{2}K}{k\\,k'^{2}}")+
   p("两式联立消去 $E$ 可得 $K$ 满足的二阶微分方程。"))+
   exa(p("<strong>例：</strong>在 $k=0$ 处 $E=K=\\pi/2$，故 $\\frac{dE}{dk}|_0=\\frac1k(E-K)=0$，与 $E(k)=\\frac{\\pi}{2}(1-\\frac{k^{2}}{4}-\\cdots)$ 无一次项一致。"))+
   note(p("这些导数关系是构造 $K,E$ 的 Padé 近似与高精度有理逼近的基础，也用于求解与椭圆积分相关的微分方程。"))
 )},
]},
{
"name": "7.3 椭圆函数的引入",
"color": "#818cf8",
"desc": "雅可比椭圆函数、加法公式与双周期性",
"items": [
{"id":"sf7s3-1","name":"雅可比椭圆函数","tags":["def","der"],"brief":"sn,cn,dn 由第一类椭圆积分的反演定义。",
 "fig":"jacobi_sn","figCap":"雅可比椭圆函数 sn(u,k)：以 4K 为实周期的双周期函数",
 "body": wrap(
   defn("雅可比椭圆函数", p("把第一类不完全椭圆积分看作幅角 $\\varphi$ 的函数：")+
   fml("u=\\int_0^{\\varphi}\\frac{d\\theta}{\\sqrt{1-k^{2}\\sin^{2}\\theta}}=F(\\varphi,k)")+
   p("其反函数给出幅角 $\\varphi=\\mathrm{am}(u,k)$，由此定义：")+
   fml("\\mathrm{sn}\\,u=\\sin\\varphi,\\quad \\mathrm{cn}\\,u=\\cos\\varphi,\\quad \\mathrm{dn}\\,u=\\sqrt{1-k^{2}\\sin^{2}\\varphi}")+
   p("它们分别是三角函数在「非圆」曲线上的推广（$k=0$ 时退化为 $\\sin,\\cos,1$）。"))+
   der(p("<strong>导数：</strong>由 $\\frac{du}{d\\varphi}=\\frac{1}{\\sqrt{1-k^{2}\\sin^{2}\\varphi}}=\\frac{1}{\\mathrm{dn}\\varphi}$，故 $\\frac{d\\varphi}{du}=\\mathrm{dn}\\,u$：")+
   fml("\\frac{d}{du}\\mathrm{sn}\\,u=\\cos\\varphi\\cdot\\frac{d\\varphi}{du}=\\mathrm{cn}\\,u\\,\\mathrm{dn}\\,u")+
   p("同理：")+
   fml("\\frac{d}{du}\\mathrm{cn}\\,u=-\\mathrm{sn}\\,u\\,\\mathrm{dn}\\,u,\\qquad \\frac{d}{du}\\mathrm{dn}\\,u=-k^{2}\\,\\mathrm{sn}\\,u\\,\\mathrm{cn}\\,u")+
   p("由定义直接得恒等式 $\\mathrm{sn}^{2}+\\mathrm{cn}^{2}=1$ 与 $k^{2}\\mathrm{sn}^{2}+\\mathrm{dn}^{2}=1$。"))+
   note(p("$\\mathrm{sn},\\mathrm{cn}$ 对应钟摆运动的坐标，$\\mathrm{dn}$ 对应「角速度」，三者构成椭圆函数的「三角关系」。"))
 )},
{"id":"sf7s3-2","name":"加法公式与倍角","tags":["der","thm"],"brief":"推导 sn(u+v) 的加法公式。",
 "body": wrap(
   thm("加法公式", p("雅可比椭圆函数满足：")+
   fml("\\mathrm{sn}(u+v)=\\frac{\\mathrm{sn}\\,u\\,\\mathrm{cn}\\,v\\,\\mathrm{dn}\\,v+\\mathrm{sn}\\,v\\,\\mathrm{cn}\\,u\\,\\mathrm{dn}\\,u}{1-k^{2}\\mathrm{sn}^{2}u\\,\\mathrm{sn}^{2}v}"))+
   der(p("<strong>推导：</strong>利用幅角的可加结构。设 $\\varphi=\\mathrm{am}\\,u$，$\\psi=\\mathrm{am}\\,v$，则由微分方程 $\\frac{du}{d\\varphi}=\\frac{1}{\\sqrt{1-k^{2}\\sin^{2}\\varphi}}$ 可验证 $u+v$ 对应的幅角 $\\Phi$ 满足：")+
   fml("\\cos\\Phi = \\frac{\\cos\\varphi\\cos\\psi-\\sin\\varphi\\sin\\psi\\sqrt{1-k^{2}\\sin^{2}\\varphi}\\sqrt{1-k^{2}\\sin^{2}\\psi}}{1-k^{2}\\sin^{2}\\varphi\\sin^{2}\\psi}")+
   p("令 $v\\to u$ 得倍角公式：")+
   fml("\\mathrm{sn}\\,2u=\\frac{2\\,\\mathrm{sn}\\,u\\,\\mathrm{cn}\\,u\\,\\mathrm{dn}\\,u}{1-k^{2}\\mathrm{sn}^{4}u}")+
   p("这些公式与三角恒等式形式相似，但分母出现 $k^{2}$ 修正，正体现了非圆几何的「形变」。"))+
   exa(p("<strong>例：</strong>取极限 $k\\to0$，加法公式退化为 $\\sin(u+v)=\\sin u\\cos v+\\cos u\\sin v$，回到普通三角函数。"))+
   note(p("椭圆函数的加法公式使其构成代数群结构（椭圆曲线上的群律），这是椭圆曲线密码学与可积系统的代数基础。"))
 )},
{"id":"sf7s3-3","name":"双周期性与周期","tags":["der"],"brief":"sn 以 4K 与 2iK' 为周期，构成双周期函数。",
 "body": wrap(
   der(p("<strong>实周期：</strong>由定义，$\\mathrm{sn}\\,u$ 是关于幅角 $\\varphi$ 的 $2\\pi$ 周期函数的像。当 $\\varphi$ 从 $0$ 增大到 $2\\pi$ 时，$u$ 增加：")+
   fml("4K = 4\\int_0^{\\pi/2}\\frac{d\\theta}{\\sqrt{1-k^{2}\\sin^{2}\\theta}}")+
   p("因为在 $\\varphi\\in[0,2\\pi]$ 中 $|\\sin\\varphi|$ 每 $\\pi$ 重复，且 $\\mathrm{sn}$ 在一个 $2\\pi$ 内完成两个完整振荡，故实周期为 $4K$。"))+
   der(p("<strong>虚周期与双周期性：</strong>当 $k'=\\sqrt{1-k^{2}}$ 存在时，把 $u$ 解析延拓到复平面，可验证：")+
   fml("\\mathrm{sn}(u+2iK')=\\mathrm{sn}\\,u,\\qquad K'=K(k')")+
   p("因此 $\\mathrm{sn}$ 是以 $4K$ 与 $2iK'$ 为周期的<strong>双周期函数</strong>，其周期比 $\\tau=iK'/K$ 决定了模形式与椭圆曲线的参数化。"))+
   exa(p("<strong>例：</strong>$k\\to0$ 时 $K\\to\\pi/2$，$4K\\to2\\pi$，回到 $\\sin$ 的周期；而 $K'\\to\\infty$，虚周期消失，符合三角函数的单周期性质。"))+
   note(p("双周期性是椭圆函数区别于所有单周期初等函数的本质特征；由 Liouville 定理，非平凡的双周期亚纯函数必有极点，故椭圆函数不可能处处全纯。"))
 )},
]},
{
"name": "7.4 椭圆积分的应用",
"color": "#4f46e5",
"desc": "单摆大角度、椭圆弧长与几何物理应用",
"items": [
{"id":"sf7s4-1","name":"单摆的大角度周期","tags":["app","der"],"brief":"T=4√(L/g)K(sin(θ0/2)) 的推导与展开。",
 "fig":"pendulum_elliptic","figCap":"大摆角单摆：周期由第一类完全椭圆积分给出，振幅越大周期越长",
 "body": wrap(
   app(p("单摆在大摆角下的精确周期是椭圆积分最经典的物理应用，也是测地学与精密计时中的基础问题。"))+
   der(p("<strong>能量守恒：</strong>单摆能量守恒 $\\frac12mL^{2}\\dot\\theta^{2}+mgL(1-\\cos\\theta)=mgL(1-\\cos\\theta_0)$，解得：")+
   fml("\\dot\\theta=\\sqrt{\\frac{2g}{L}\\left(\\cos\\theta-\\cos\\theta_0\\right)}")+
   p("用 $\\cos\\theta=1-2\\sin^{2}(\\theta/2)$，并令 $k=\\sin(\\theta_0/2)$：")+
   fml("\\cos\\theta-\\cos\\theta_0=2\\left[\\sin^{2}\\frac{\\theta_0}{2}-\\sin^{2}\\frac{\\theta}{2}\\right]=2k^{2}\\left[1-\\frac{\\sin^{2}(\\theta/2)}{k^{2}}\\right]")+
   p("再令 $\\sin(\\theta/2)=k\\sin\\phi$，$\\frac12\\cos(\\theta/2)d\\theta=k\\cos\\phi\\,d\\phi$，化为：")+
   fml("dt=\\sqrt{\\frac{L}{g}}\\,\\frac{d\\phi}{\\sqrt{1-k^{2}\\sin^{2}\\phi}}")+
   p("四分之一个周期对应 $\\phi:0\\to\\pi/2$，故：")+
   fml("T=4\\sqrt{\\frac{L}{g}}\\,K\\!\\left(\\sin\\frac{\\theta_0}{2}\\right)"))+
   exa(p("<strong>例：</strong>$\\theta_0=90^{\\circ}$ 时 $k=\\sin45^{\\circ}=0.7071$，$K=1.854$，故 $T\\approx1.18\\,T_0$，比小角度周期大 $18\\%$。"))+
   note(p("小角度展开给出 $T\\approx T_0[1+\\frac{\\theta_0^{2}}{16}+\\cdots]$，这正是钟摆校正在大摆角下需要考虑的修正项。"))
 )},
{"id":"sf7s4-2","name":"椭圆弧长与几何","tags":["app","der"],"brief":"L=4aE(e) 的推导与地球子午线测量。",
 "body": wrap(
   der(p("<strong>椭圆弧长：</strong>椭圆 $x=a\\sin\\theta$，$y=b\\cos\\theta$ 的弧长微元：")+
   fml("ds=\\sqrt{(a\\cos\\theta)^{2}+(b\\sin\\theta)^{2}}\\,d\\theta = a\\sqrt{1-e^{2}\\sin^{2}\\theta}\\,d\\theta")+
   p("其中偏心率 $e=\\sqrt{1-b^{2}/a^{2}}$。四分之一周长：")+
   fml("\\frac{L}{4}=a\\int_0^{\\pi/2}\\sqrt{1-e^{2}\\sin^{2}\\theta}\\,d\\theta = a\\,E(e)")+
   p("故 $L=4aE(e)$。当 $a=b$（$e=0$）时 $E(0)=\\pi/2$，回到圆周长 $2\\pi a$。"))+
   der(p("<strong>子午线弧长：</strong>把地球近似为旋转椭球，子午线从赤道到极点的弧长为 $a E(e)$，而纬度 $\\phi$ 处的一段弧为：")+
   fml("s(\\phi)=a\\int_0^{\\phi}\\sqrt{1-e^{2}\\sin^{2}\\varphi}\\,d\\varphi = a\\,E(\\varphi,e)")+
   p("这正是历史上定义「米」与进行大地测量时必须计算的不完全椭圆积分。"))+
   note(p("$E(e)$ 的奇异性质（$E(1)=1$）保证了椭圆即使在极度扁平时周长仍有限，这与 $K$ 的对数发散形成对比。"))
 )},
{"id":"sf7s4-3","name":"其他应用","tags":["app","der"],"brief":"在弹性、几何与物理中的其他椭圆积分应用。",
 "body": wrap(
   app(p("椭圆积分与椭圆函数广泛出现在几何、力学、电磁学与可积系统中。"))+
   der(p("<strong>弹性杆的大挠度：</strong>细长弹性杆在端部受力弯曲时，曲率与弯矩成正比 $\\kappa=M/EI$。取弧长 $s$ 为参数，切线角 $\\psi(s)$ 满足：")+
   fml("\\frac{d\\psi}{ds}=\\frac{M}{EI}\\propto \\cos\\psi")+
   p("分离变量并积分成 $\\int d\\psi/\\sqrt{1-k^{2}\\sin^{2}\\psi}$ 的形式，故大挠度弹性曲线由椭圆函数描述（Elastica）。")+
   p("<strong>单轴晶体中的光传播：</strong>波矢面（折射率椭球）上的光线方向与走时积分为椭圆积分，费马原理导出光线轨迹由椭圆函数给出。")+
   p("<strong>可积系统：</strong>KdV 方程的周期解（cnoidal wave）正是 cn 函数，其色散关系直接由 $K,E$ 表达：")+
   fml("u(x,t)=2k^{2}\\mathrm{cn}^{2}\\!\\left(x-ct;k\\right)"))+
   note(p("椭圆函数还是椭圆曲线与模形式的载体，$K(k)$ 作为模函数满足 SL(2,Z) 变换，是数论与现代密码学的对象。"))
 )},
]},
]

ch8_sections = [
{
"name": "8.1 马丢方程与参数",
"color": "#059669",
"desc": "方程的物理来源、特征值与周期解",
"items": [
{"id":"sf8s1-1","name":"马丢方程的来源与形式","tags":["def","der"],"brief":"由椭圆坐标分离变量得到 y''+(a-2q cos2z)y=0。",
 "body": wrap(
   defn("马丢方程", p("标准<strong>马丢方程</strong>为：")+
   fml("y''+(a-2q\\cos 2z)\\,y=0","a 为特征参数，q 为强度参数")+
   p("它具有周期系数，是周期性系数线性方程的原型。"))+
   der(p("<strong>由椭圆坐标分离变量：</strong>对二维波动方程在椭圆坐标 $(\\xi,\\eta)$ 中分离变量，得到：")+
   fml("\\frac{d^{2}X}{d\\xi^{2}}+\\left(\\lambda-2h^{2}\\cosh2\\xi\\right)X=0,\\qquad \\frac{d^{2}Y}{d\\eta^{2}}+\\left(\\lambda+2h^{2}\\cos2\\eta\\right)Y=0")+
   p("其中 $\\lambda$ 为分离常数（对应 $a$），$h$ 与椭圆偏心率相关（对应 $q$）。第二个方程为马丢方程的形式，第一个为其「双曲版本」（Modified Mathieu equation）。")+
   p("马丢方程也出现在：椭圆截面波导、周期势中的电子（Bloch 能带）、参量振子（Mathieu 摆）与离子阱稳定性分析中。"))+
   note(p("注意系数周期为 $\\pi$（因 $\\cos2z$），故解在 $z\\to z+\\pi$ 下变换，与通常周期系数的 Hill 方程一致。"))
 )},
{"id":"sf8s1-2","name":"特征值与周期解","tags":["def","der"],"brief":"存在 π 或 2π 周期解的 a 值 a_n(q), b_n(q)。",
 "fig":"mathieu_ce","figCap":"马丢特征值 a_n(q) 与 b_n(q) 随 q 分离，q=0 时分别趋于 n²",
 "body": wrap(
   defn("马丢特征值", p("对给定 $q$，只有特定的 $a$ 值使方程存在 $\\pi$ 或 $2\\pi$ 周期的解。这些 $a$ 值记为：")+
   fml("a_n(q)\\ (n=0,1,2,\\dots),\\qquad b_n(q)\\ (n=1,2,\\dots)")+
   p("$a_n$ 对应偶周期解 $\\mathrm{ce}_n(z,q)$，$b_n$ 对应奇周期解 $\\mathrm{se}_n(z,q)$。"))+
   der(p("<strong>$q=0$ 的退化：</strong>当 $q=0$ 时方程为 $y''+ay=0$，周期解要求 $a=n^{2}$。故：")+
   fml("a_0(0)=0,\\quad a_n(0)=b_n(0)=n^{2}\\ (n\\ge1)")+
   p("当 $q\\ne0$ 时，这些简并值分裂：$a_n(q)$ 与 $b_n(q)$ 分离，中间夹着不稳定区域（见 8.2）。")+
   p("<strong>周期解的奇偶性：</strong>由于方程在 $z\\to-z$ 与 $z\\to z+\\pi$ 下不变，周期解可按奇偶分类：$\\mathrm{ce}_n$ 为偶函数，$\\mathrm{se}_n$ 为奇函数。"))+
   note(p("$a_n(q),b_n(q)$ 是 $q$ 的解析函数（对充分小的 $q$），可按幂级数展开（见 8.3.2）。"))
 )},
{"id":"sf8s1-3","name":"傅里叶级数解","tags":["der"],"brief":"把周期解展开为傅里叶级数并推出三项递推。",
 "body": wrap(
   der(p("<strong>偶解展开：</strong>设 $\\mathrm{ce}_n(z,q)$ 为偶函数，周期 $2\\pi$，展开为余弦级数：")+
   fml("y(z)=\\sum_{k\\ge0}A_k\\cos(kz)")+
   p("代入马丢方程 $y''+(a-2q\\cos2z)y=0$，用到积化和差：")+
   fml("2\\cos2z\\cos kz=\\cos(k+2)z+\\cos(k-2)z")+
   p("比较 $\\cos(kz)$ 的系数得三项递推：")+
   fml("\\left(a-k^{2}\\right)A_k=q\\left(A_{k-2}+A_{k+2}\\right)")+
   p("写成矩阵形式，$A_k$ 满足无穷三对角（连分式）特征问题；行列式为零的条件即确定 $a_n(q)$。对奇解 $\\mathrm{se}_n$ 用正弦级数得到同类递推。"))+
   exa(p("<strong>例：</strong>取 $n=0$ 主项 $A_0$，$k=0$：$a A_0=q(A_{-2}+A_2)\\approx0$，说明 $a_0(0)=0$；下一阶修正给出 $a_0\\approx-q^{2}/2$（见 8.3.2）。"))+
   note(p("这个连分式递推是数值计算马丢特征值与周期解的实用算法，收敛快且稳定。"))
 )},
]},
{
"name": "8.2 马丢函数的解与稳定性",
"color": "#10b981",
"desc": "Floquet 理论、Ince-Strutt 图与稳定判据",
"items": [
{"id":"sf8s2-1","name":"Floquet 理论与单值矩阵","tags":["der","thm"],"brief":"周期系数方程解的结构与特征指数。",
 "fig":"mathieu_stability","figCap":"Ince-Strutt 稳定图：从 a=n² 出发的不稳定舌区随 q 张开",
 "body": wrap(
   thm("Floquet 定理", p("对周期系数线性方程 $y''+p(z)y=0$（$p(z+\\pi)=p(z)$），存在基本解系：")+
   fml("y_1(z)=e^{\\mu z}P_1(z),\\qquad y_2(z)=e^{-\\mu z}P_2(z)")+
   p("其中 $P_i(z+\\pi)=P_i(z)$，$\\mu$ 称特征指数（Floquet 指数）。"))+
   der(p("<strong>单值矩阵：</strong>取两个初值解构成基 $\\Phi(z)=(y_1,y_2)$，由 $\\Phi(z+\\pi)=\\Phi(z)M$ 定义单值矩阵 $M$（常数）。设 $\\Phi(0)=I$，则 $M=\\Phi(\\pi)$。$M$ 的特征值 $\\rho_{1,2}$ 为 Floquet 乘子：")+
   fml("\\rho_{1,2}=\\frac{\\operatorname{tr}M\\pm\\sqrt{(\\operatorname{tr}M)^{2}-4}}{2},\\qquad \\rho_1\\rho_2=\\det M=1")+
   p("（因 $\\det M=1$，Wronskian 守恒）。故 $\\rho=e^{\\pm\\mu\\pi}$，解有界当且仅当 $|\\rho|=1$。"))+
   note(p("这里 $\\operatorname{tr}M$ 是 $a,q$ 的函数；稳定条件 $|\\operatorname{tr}M|\\le2$ 的图像就是 Ince-Strutt 图。"))
 )},
{"id":"sf8s2-2","name":"稳定性图与舌区","tags":["der","app"],"brief":"不稳定区域从 a=n² 张开，宽度随 q 增大。",
 "body": wrap(
   der(p("<strong>舌区的来源：</strong>当 $q=0$ 时所有 $a\\ge0$ 都稳定（解为正弦），不稳定的只是「边界点」$a=n^{2}$（此时解线性增长）。当 $q>0$，这些点张开成楔形不稳定区（舌区）。")+
   p("在 $a=n^{2}$ 附近作微扰分析。设 $a=n^{2}+\\delta$，$\\delta\\sim O(q)$。把解写成慢变振幅形式，对 $n=1$ 的情形共振条件为：")+
   fml("\\omega_0^2=a\\approx1,\\quad \\text{驱动频率 }2\\ (\\cos2z)\\ \\text{与 }2\\omega_0\\ \\text{共振}")+
   p("这正是参量共振条件：驱动频率 $\\approx2\\omega_0$。用平均法（或 Lindstedt-Poincaré 法）可解出：")+
   fml("\\delta=\\pm\\frac{q}{2}+O(q^{2})")+
   p("即不稳定区边界为 $a=1\\pm\\frac{q}{2}+\\cdots$，宽度正比于 $q$；对一般 $n$，舌区从 $a=n^{2}$ 张开，宽度约 $\\propto q^{n}$，故只有低阶舌区在弱驱动下可见。"))+
   app(p("这解释了为什么秋千要「站立时下蹲、摆到最高点时起身」以泵入能量：驱动频率恰为固有频率的两倍时发生参量共振。"))+
   note(p("舌区宽度随 $n$ 快速变窄，因此实际系统中高阶不稳定区往往被阻尼或非线性抑制。"))
 )},
{"id":"sf8s2-3","name":"稳定判据","tags":["thm","der"],"brief":"|tr M|≤2 的证明与稳定边界的意义。",
 "body": wrap(
   thm("稳定判据", p("马丢方程的解有界（稳定）当且仅当：")+
   fml("|\\operatorname{tr}M|\\le2")+
   p("等号成立时为临界（周期解或线性增长解）。"))+
   der(p("<strong>证明：</strong>由 8.2.1，Floquet 乘子满足特征方程 $\\rho^{2}-(\\operatorname{tr}M)\\rho+1=0$。判别式 $\\Delta=(\\operatorname{tr}M)^{2}-4$：")+
   fml("|\\operatorname{tr}M|>2 \\Rightarrow \\rho_{1,2}\\in\\mathbb{R},\\ |\\rho|\\ne1 \\Rightarrow \\text{一增一减，无界}")+
   p("反之 $|\\operatorname{tr}M|<2$ 时：")+
   fml("\\rho_{1,2}=e^{\\pm i\\nu},\\quad \\cos\\nu=\\frac{\\operatorname{tr}M}{2} \\Rightarrow |\\rho|=1\\Rightarrow \\text{有界}")+
   p("边界 $|\\operatorname{tr}M|=2$ 时 $\\rho=+1$（周期解）或 $\\rho=-1$（反周期解），对应稳定区与不稳定区的分界曲线，即 Ince-Strutt 图中的 $a_n(q),b_n(q)$ 曲线。"))+
   exa(p("<strong>例：</strong>$q=0.5$ 时，$a=1$ 处 $\\operatorname{tr}M\\approx2\\cos($...$)$ 落到不稳定区（$|\\operatorname{tr}M|>2$），故存在指数增长解，这是参量激发的阈值。"))+
   note(p("该判据是周期势中能带结构、参量放大器阈值与离子阱稳定性的统一数学表述。"))
 )},
]},
{
"name": "8.3 马丢函数的性质与展开",
"color": "#047857",
"desc": "正交性、小 q 微扰与大 q 渐近",
"items": [
{"id":"sf8s3-1","name":"正交性与归一化","tags":["der"],"brief":"周期马丢函数在 [0,2π] 上正交。",
 "body": wrap(
   der(p("<strong>正交性：</strong>把马丢方程写成 Sturm-Liouville 形式：")+
   fml("\\frac{d}{dz}\\left(p\\frac{dy}{dz}\\right)+\\left(\\lambda w-\\tilde q(z)\\right)y=0")+
   p("以周期边界条件 $y(0)=y(2\\pi),\\ y'(0)=y'(2\\pi)$ 求解。对两个同 $q$ 但不同特征值的解 $y_m,y_n$ 作 Wronskian 型积分：两式分别乘 $y_n,y_m$ 相减并在 $[0,2\\pi]$ 上积分：")+
   fml("(a_m-a_n)\\int_0^{2\\pi}y_my_n\\,dz = \\left[y_m'y_n-y_m y_n'\\right]_0^{2\\pi}=0")+
   p("周期边界使边界项为零，故 $a_m\\ne a_n$ 时积分为零，即正交：")+
   fml("\\int_0^{2\\pi}\\mathrm{ce}_m\\,\\mathrm{ce}_n\\,dz=\\pi\\delta_{mn},\\qquad \\int_0^{2\\pi}\\mathrm{se}_m\\,\\mathrm{se}_n\\,dz=\\pi\\delta_{mn}")+
   p("归一化常数取 $\\pi$（对应傅里叶余弦/正弦的归一化）。"))+
   app(p("正交性是展开任意 $2\\pi$ 周期函数、求解非齐次马丢方程、以及量子力学中周期势微扰展开的基础。"))+
   note(p("偶解与奇解之间也正交（$\\int\\mathrm{ce}_m\\mathrm{se}_n=0$），故 $\\{\\mathrm{ce}_n,\\mathrm{se}_n\\}$ 构成 $L^{2}(0,2\\pi)$ 的正交基。"))
 )},
{"id":"sf8s3-2","name":"小 q 微扰展开","tags":["der"],"brief":"a_n(q)=n²+q²/(2(n²-1))+… 的推导。",
 "body": wrap(
   der(p("<strong>微扰计算（以 $n=1$ 为例）：</strong>设 $a=1+\\alpha_1 q+\\alpha_2 q^{2}+\\cdots$，解 $y=\\cos z+q\\,y_1+\\cdots$。代入马丢方程，$O(q)$ 项：")+
   fml("y_1''+y_1=\\alpha_1\\cos z-2\\cos2z\\cos z=\\alpha_1\\cos z-(\\cos3z+\\cos z)")+
   p("即 $y_1''+y_1=(\\alpha_1-1)\\cos z-\\cos3z$。为使解不含共振项（$\\cos z$ 会共振产生 $z\\sin z$），必须 $\\alpha_1-1=0$，故 $\\alpha_1=1$，得到边界 $a=1\\pm\\frac{q}{2}$（注意符号对应上下支）。")+
   p("对一般 $n$，类似计算得：")+
   fml("a_n(q)=n^{2}+\\frac{q^{2}}{2(n^{2}-1)}+O(q^{4})\\quad(n\\ge2),\\qquad a_0(q)=-\\frac{q^{2}}{2}+O(q^{4})")+
   p("可见所有 $n\\ge1$ 的特征值都因 $q$ 而<strong>上移</strong>，且 $a_n>b_n$，两者之差即不稳定区宽度。"))+
   exa(p("<strong>例：</strong>$n=2$，$q=0.5$：$a_2\\approx4+\\frac{0.25}{2\\cdot3}=4.0417$，与精确值 $4.0400$ 接近。"))+
   note(p("这些展开式在 $q\\ll n^{2}$ 时可靠；当 $q$ 很大时必须改用大 $q$ 渐近（见 8.3.3）。"))
 )},
{"id":"sf8s3-3","name":"大 q 渐近与指数区域","tags":["der"],"brief":"q→∞ 时特征值与解的渐近，及稳定/不稳定交替。",
 "fig":"mathieu_mode","figCap":"马丢函数 ce1(z,q) 的振荡解与指数增长解交替出现",
 "body": wrap(
   der(p("<strong>大 $q$ 渐近（WKB 法）：</strong>当 $q\\to\\infty$，方程 $y''+(a-2q\\cos2z)y=0$ 的系数在 $\\cos2z<0$ 处为负，产生指数型解。令 $Q(z)=2q\\cos2z-a$，在 $Q>0$ 区域用 WKB：")+
   fml("y\\sim Q^{-1/4}\\exp\\!\\left(\\pm i\\int\\sqrt{Q(z)}\\,dz\\right)")+
   p("在 $Q(z)=0$（转折点）之间需用 Airy 连接公式匹配，由此得到量子化条件。对最低特征值分支的渐近为：")+
   fml("a_n(q)\\sim -2q+(2n+1)\\sqrt{q}+O(1)\\quad(q\\to\\infty)")+
   p("这说明大 $q$ 时所有特征值随 $q$ 线性下移，且相邻分支间距 $\\sim\\sqrt q$，舌区在 $q$ 大时彼此重叠，几乎全平面不稳定。"))+
   exa(p("<strong>例：</strong>取 $q=100$，$a_0\\approx-200+\\sqrt{100}=-190$，与数值结果定性一致。"))+
   note(p("大 $q$ 的稳定性结构由半经典（WKB）与能带理论共同描述，与周期性势中电子能带的「允许带/禁带」互为对偶。"))
 )},
]},
{
"name": "8.4 马丢函数的应用",
"color": "#059669",
"desc": "椭圆膜、参量振荡与电磁波导",
"items": [
{"id":"sf8s4-1","name":"椭圆膜与鼓面振动","tags":["app","der"],"brief":"椭圆边界膜的振动模态由马丢函数给出。",
 "body": wrap(
   app(p("椭圆形状的膜（如椭圆鼓面）的振动模态是马丢函数最直观的应用。"))+
   der(p("<strong>波动方程分离变量：</strong>膜振动满足 $\\nabla^{2}u+k^{2}u=0$（$k=\\omega/c$）。椭圆坐标 $(\\xi,\\eta)$ 由 $x=c\\cosh\\xi\\cos\\eta$，$y=c\\sinh\\xi\\sin\\eta$ 定义，拉普拉斯算子在椭圆坐标中分离变量得：")+
   fml("\\frac{d^{2}X}{d\\xi^{2}}-\\left(\\lambda-2h^{2}\\cosh2\\xi\\right)X=0,\\qquad \\frac{d^{2}Y}{d\\eta^{2}}+\\left(\\lambda+2h^{2}\\cos2\\eta\\right)Y=0")+
   p("其中 $2h^{2}=c^{2}k^{2}$。$\\eta$ 方程即马丢方程，周期边界条件 $Y(\\eta+2\\pi)=Y(\\eta)$ 要求 $\\lambda=a_n(q)$ 或 $b_n(q)$：")+
   fml("Y(\\eta)=\\mathrm{ce}_n(\\eta,q)\\ \\text{或}\\ \\mathrm{se}_n(\\eta,q),\\qquad q=h^{2}=c^{2}k^{2}/2")+
   p("$\\xi$ 方程（修正马丢方程）则给出径向依赖，椭圆边界条件使其本征值离散化，从而得到分立的振动频率。"))+
   note(p("圆边界（$c\\to0$）时马丢函数退化，模态回到贝塞尔函数 $J_n$，这说明马丢函数是椭圆几何下的自然「简正模态」。"))
 )},
{"id":"sf8s4-2","name":"参量振荡与离子阱","tags":["app","der"],"brief":"Mathieu 摆与 Paul 阱的稳定性分析。",
 "body": wrap(
   app(p("马丢方程是参量振荡（Mathieu 摆）与四极离子阱（Paul trap）稳定性分析的核心。"))+
   der(p("<strong>Mathieu 摆：</strong>悬挂点作竖直振动 $y=-A\\cos\\omega t$ 的单摆，小角方程为：")+
   fml("\\ddot\\theta+\\left(\\frac{g}{L}-\\frac{A\\omega^{2}}{L}\\cos\\omega t\\right)\\sin\\theta=0")+
   p("小角化后令 $z=\\omega t/2$，化为标准马丢形式：")+
   fml("\\theta''+\\left(a-2q\\cos2z\\right)\\theta=0,\\quad a=\\frac{4g}{L\\omega^{2}},\\ q=\\frac{2A}{L}")+
   p("当 $(a,q)$ 落入不稳定区时摆幅指数增长（参量共振）；而当 $a>2q$（快速振动极限）时，竖直向上位形反被稳定——即著名的 Kapitza 摆。")+
   p("<strong>Paul 离子阱：</strong>离子在四极射频场中的径向运动满足：")+
   fml("\\ddot x+\\frac{e}{m}\\left(\\frac{2U}{r_0^{2}}+\\frac{2V}{r_0^{2}}\\cos\\omega t\\right)x=0")+
   p("同样化为马丢方程，参数 $a,q\\propto U,V$。离子被囚禁的条件正是 $(a,q)$ 落在 Ince-Strutt 图的稳定区内，由此得到阱的工作点设计。"))+
   note(p("Paul 因离子阱获 1989 年诺贝尔物理学奖；其稳定性图的数学本质就是马丢方程稳定区。"))
 )},
{"id":"sf8s4-3","name":"周期势中的能带与波动","tags":["app","der"],"brief":"周期势薛定谔方程与能带结构，及波导应用。",
 "body": wrap(
   app(p("周期性介质中的波传播与周期势中的电子都归结为马丢型方程，其稳定/不稳定分区正是「能带/禁带」结构。"))+
   der(p("<strong>周期势电子：</strong>在周期势 $V(x)=V_0\\cos(2\\pi x/d)$ 中，单电子薛定谔方程作变换 $z=\\pi x/d$ 后化为：")+
   fml("\\psi''+\\left(a-2q\\cos2z\\right)\\psi=0,\\quad a=\\frac{2m E d^{2}}{\\pi^{2}\\hbar^{2}},\\ q=\\frac{m V_0 d^{2}}{\\pi^{2}\\hbar^{2}}")+
   p("由 Bloch/Floquet 定理，稳定区对应<strong>允许带</strong>（电子可传播），不稳定区对应<strong>禁带</strong>（指数衰减，无本征态）。能带边界由 $a_n(q),b_n(q)$ 给出：")+
   fml("E_{\\text{边界}} = \\frac{\\pi^{2}\\hbar^{2}}{2md^{2}}a_n(q)")+
   p("在 $q\\to0$（弱周期势）时禁带宽度趋于零，回到自由电子；$q$ 增大时禁带张开、带宽变窄，最终接近原子极限。"))+
   der(p("<strong>周期性波导：</strong>周期性波纹波导或光子晶体中，横向模满足同型方程，稳定/不稳定界面对应频率禁带（光子带隙），这是布拉格反射镜与光子晶体光纤的工作原理。"))+
   note(p("从马丢方程到能带论，再到光子晶体与拓扑材料，周期系数方程提供了贯穿固体物理与光学的统一语言。"))
 )},
]},
]

CHAPTERS = [
    {"id":"sf-ch1","num":"第一章","title":"朗博W函数","en":"LAMBERT W FUNCTION",
     "desc":"朗博W函数的定义与隐函数求导、W0 与 W-1 实分支、函数方程与特殊值、拉格朗日反演的泰勒级数与双对数渐近展开，以及在超越方程求解、迭代指数与维恩位移律中的应用。",
     "sections": ch1_sections},
    {"id":"sf-ch2","num":"第二章","title":"伽马函数","en":"GAMMA FUNCTION",
     "desc":"伽马函数的积分定义与收敛性、递推关系与维尔斯特拉斯乘积、半整数特殊值、欧拉反射公式与勒让德倍角公式、贝塔函数及其与伽马函数的关系、斯特林公式与欧拉-麦克劳林级数，以及在组合计数、概率分布与物理公式中的应用。",
     "sections": ch2_sections},
    {"id":"sf-ch3","num":"第三章","title":"高斯积分","en":"GAUSSIAN INTEGRAL",
     "desc":"高斯积分的极坐标技巧与参数化、对参数求导的矩积分、高斯矩与矩生成函数、高斯的傅里叶变换、误差函数与余误差函数的级数与渐近、多维高斯积分与协方差、高维球体积与表面积，以及在正态分布、统计物理与量子力学中的应用。",
     "sections": ch3_sections},
    {"id":"sf-ch4","num":"第四章","title":"菲涅尔积分","en":"FRESNEL INTEGRALS",
     "desc":"菲涅尔余弦与正弦积分的定义、复误差函数表示与幂级数、科纽螺旋线的弧长与曲率、大 x 渐近展开与极限值、级数与渐近的数值衔接、复误差函数与 Faddeeva 函数，以及在直边衍射、单缝菲涅耳衍射与波带片中的应用。",
     "sections": ch4_sections},
    {"id":"sf-ch5","num":"第五章","title":"超几何函数","en":"HYPERGEOMETRIC FUNCTION",
     "desc":"高斯超几何级数的定义与收敛性、高斯求和公式、超几何微分方程与 Frobenius 解、欧拉与普法夫变换、反正切与勒让德函数等特殊情形、不完全贝塔函数、库默尔合流方程与 ₁F₁ 级数、拉盖尔与厄米多项式关系，以及氢原子与散射理论中的应用。",
     "sections": ch5_sections},
    {"id":"sf-ch6","num":"第六章","title":"厄米多项式","en":"HERMITE POLYNOMIALS",
     "desc":"厄米多项式的罗德里格斯公式、生成函数与显式展开、三项递推关系、厄米微分方程与导数关系、高斯权重下的正交性与积分性质、厄米函数完备性与展开，以及量子谐振子的定态波函数、升降算符代数与跃迁选择定则。",
     "sections": ch6_sections},
    {"id":"sf-ch7","num":"第七章","title":"椭圆积分","en":"ELLIPTIC INTEGRALS",
     "desc":"椭圆积分的一般定义与三类勒让德标准形式、退化情形、完全椭圆积分 K 与 E 的级数与对数发散、导数关系、Landen 变换与 AGM 算法、雅可比椭圆函数 sn/cn/dn、加法公式与双周期性，以及单摆大角度周期、椭圆弧长与弹性杆挠度中的应用。",
     "sections": ch7_sections},
    {"id":"sf-ch8","num":"第八章","title":"马丢函数","en":"MATHIEU FUNCTIONS",
     "desc":"马丢方程的形式与椭圆坐标来源、特征值 a_n 与 b_n、傅里叶级数解与三项递推、Floquet 理论与单值矩阵、Ince-Strutt 稳定图与舌区、稳定性判据 |tr M|≤2、周期马丢函数的正交性、小 q 微扰与大 q 渐近，以及椭圆膜振动、参量振荡、离子阱与周期势能带中的应用。",
     "sections": ch8_sections},
]

total_items = sum(sum(len(s["items"]) for s in ch["sections"]) for ch in CHAPTERS)
print(f"Total items: {total_items}")


def fix_lt_text(s):
    return s.replace("<", "&lt;")
def fix_svg_lt(s):
    import re
    return re.sub(r"<(?!/?(?:svg|g|defs|line|rect|circle|ellipse|path|polygon|polyline|text|tspan|use|marker|linearGradient|radialGradient|stop|clipPath|symbol|pattern|mask|filter|title|desc|animate|animateTransform|image|style)\b)([A-Za-z])", r"&lt;\1", s)

def gen_html():
    data_lines = []
    for ch in CHAPTERS:
        sec_strs = []
        for sec in ch["sections"]:
            item_strs = []
            for it in sec["items"]:
                tags_js = json.dumps(it["tags"], ensure_ascii=False)
                body_esc = js_escape(fix_lt_math(it["body"]))
                fig_field = f",fig:{json.dumps(it.get('fig',''),ensure_ascii=False)}" if it.get("fig") else ""
                figcap_field = f",figCap:{json.dumps(fix_lt_text(it.get('figCap','')),ensure_ascii=False)}" if it.get("figCap") else ""
                item_strs.append(
                    f"{{id:'{it['id']}',name:{json.dumps(it['name'],ensure_ascii=False)},"
                    f"tags:{tags_js},brief:{json.dumps(fix_lt_text(it['brief']),ensure_ascii=False)},"
                    f"body:`{body_esc}`{fig_field}{figcap_field}}}"
                )
            sec_strs.append(
                f"{{name:{json.dumps(sec['name'],ensure_ascii=False)},"
                f"color:'{sec['color']}',desc:{json.dumps(sec['desc'],ensure_ascii=False)},"
                f"items:[{','.join(item_strs)}]}}"
            )
        data_lines.append(
            f"{{id:'{ch['id']}',num:{json.dumps(ch['num'],ensure_ascii=False)},"
            f"title:{json.dumps(ch['title'],ensure_ascii=False)},en:'{ch['en']}',"
            f"desc:{json.dumps(ch['desc'],ensure_ascii=False)},"
            f"sections:[{','.join(sec_strs)}]}}"
        )
    la_data = "[" + ",".join(data_lines) + "]"

    fig_entries = []
    for k, v in FIG.items():
        fig_entries.append(f"{json.dumps(k)}:`{js_escape(fix_svg_lt(v))}`")
    fig_js = "{" + ",".join(fig_entries) + "}"
    tag_label_js = json.dumps(TAG_LABEL, ensure_ascii=False)

    nav_tabs = "".join(
        f'<a class="la-nav-tab c{i+1}" href="#{ch["id"]}">{ch["num"]} · {ch["title"]}</a>'
        for i, ch in enumerate(CHAPTERS)
    )

    css = '''  :root{--la-bg:#f4f7fb;--la-card:#ffffff;--la-ink:#152033;--la-muted:#607089;--la-shadow:0 12px 32px rgba(20,36,60,.09);}
  *{box-sizing:border-box}
  html{scroll-behavior:smooth}
  body{margin:0;font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Hiragino Sans GB","Microsoft YaHei",sans-serif;color:var(--la-ink);background:radial-gradient(circle at 10% 10%,rgba(37,99,235,.08),transparent 28%),radial-gradient(circle at 90% 10%,rgba(124,58,237,.08),transparent 28%),var(--la-bg);line-height:1.7}
  a{color:inherit}
  .la-wrap{width:min(1400px,94vw);margin:auto}
  .la-header{padding:52px 0 20px;text-align:center}
  .la-eyebrow{font-size:13px;letter-spacing:.22em;color:var(--la-muted);font-weight:700;text-transform:uppercase}
  h1{margin:10px 0 8px;font-size:clamp(30px,5vw,54px);line-height:1.08;letter-spacing:-.03em}
  .la-subtitle{margin:0 auto;color:var(--la-muted);font-size:16px;max-width:820px;line-height:1.8}
  .back-bar{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin:22px 0 6px}
  .back-btn{display:inline-flex;align-items:center;gap:8px;padding:10px 22px;border-radius:999px;text-decoration:none;font-size:14px;font-weight:800;background:#fff;color:#1e3a8a;border:1px solid #c7d7ee;box-shadow:0 8px 20px rgba(20,36,60,.08);transition:.25s;cursor:pointer}
  .back-btn:hover{transform:translateY(-2px);box-shadow:0 14px 30px rgba(20,36,60,.14);color:#4c1d95;border-color:#ddd6fe}
  .la-nav-tabs{display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin:22px 0 8px}
  .la-nav-tab{padding:8px 16px;border-radius:999px;text-decoration:none;font-weight:700;font-size:13px;border:1px solid #d5deea;background:#fff;transition:.25s;color:#334155}
  .la-nav-tab:hover{transform:translateY(-2px);box-shadow:0 8px 20px rgba(20,36,60,.1)}
  .la-nav-tab.c1{color:#2563eb;border-color:#bfdbfe}
  .la-nav-tab.c2{color:#7c3aed;border-color:#ddd6fe}
  .la-nav-tab.c3{color:#0d9488;border-color:#99f6e4}
  .la-nav-tab.c4{color:#c2410c;border-color:#fed7aa}
  .la-nav-tab.c5{color:#be185d;border-color:#fbcfe8}
  .la-nav-tab.c6{color:#0891b2;border-color:#a5f3fc}
  .la-nav-tab.c7{color:#4f46e5;border-color:#c7d2fe}
  .la-nav-tab.c8{color:#059669;border-color:#a7f3d0}
  .la-engagement-bar{display:flex;gap:12px;justify-content:center;flex-wrap:wrap;margin:26px 0 10px}
  .la-stat-item{display:inline-flex;align-items:center;gap:8px;padding:8px 16px;border-radius:999px;background:#fff;border:1px solid #e2e8f0;font-size:13px;color:#334155;font-weight:600}
  .la-stat-value{color:#6366f1;font-weight:800;font-size:15px}
  .la-stat-link{cursor:pointer;text-decoration:none;transition:.2s}
  .la-stat-link:hover{background:#eef2ff;border-color:#c7d2fe}
  .la-legend{display:flex;gap:8px;flex-wrap:wrap;justify-content:center;margin:0 0 24px;font-size:12px;color:#64748b}
  .la-legend-title{font-weight:700;margin-right:4px}
  .la-arc-badge{font-size:11px;padding:3px 10px;border-radius:999px;font-weight:700;letter-spacing:.04em}
  .la-arc-def{background:#dbeafe;color:#1e40af}
  .la-arc-thm{background:#ede9fe;color:#6d28d9}
  .la-arc-der{background:#e0f2fe;color:#0369a1}
  .la-arc-exa{background:#dcfce7;color:#15803d}
  .la-arc-app{background:#fef3c7;color:#b45309}
  .la-arc-note{background:#fee2e2;color:#b91c1c}
  .la-roadmap{padding:30px 0}
  .la-phase-title{font-size:24px;color:#1e293b;margin:40px 0 6px 18px;display:flex;align-items:center;gap:12px}
  .la-phase-title::before{content:"";width:6px;height:26px;border-radius:4px}
  .la-phase-title.sf-ch1::before{background:#2563eb}
  .la-phase-title.sf-ch2::before{background:#7c3aed}
  .la-phase-title.sf-ch3::before{background:#0d9488}
  .la-phase-title.sf-ch4::before{background:#c2410c}
  .la-phase-title.sf-ch5::before{background:#be185d}
  .la-phase-title.sf-ch6::before{background:#0891b2}
  .la-phase-title.sf-ch7::before{background:#4f46e5}
  .la-phase-title.sf-ch8::before{background:#059669}
  .la-phase-en{font-size:11px;letter-spacing:.36em;color:#94a3b8;font-weight:700;text-transform:uppercase;margin:0 0 12px 18px;font-style:italic}
  .la-phase-desc{color:var(--la-muted);font-size:14px;margin:0 0 24px 18px;line-height:1.8;max-width:960px}
  .la-domain{margin-bottom:26px;padding:16px 18px 18px 22px;position:relative;background:rgba(255,255,255,.6);border-radius:18px;border:1px solid #e5ebf2}
  .la-domain::before{content:"";position:absolute;left:6px;top:16px;bottom:16px;width:5px;border-radius:5px;background:var(--domain-color,#2563eb);box-shadow:0 0 12px rgba(37,99,235,.25)}
  .la-domain-header{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:12px}
  .la-domain-header h3{margin:0;font-size:17px;color:#1e293b}
  .la-domain-count{font-size:11px;padding:2px 10px;border-radius:999px;background:#eef2ff;color:#4f46e5;font-weight:700}
  .la-domain-desc{font-size:12px;color:#94a3b8}
  .la-domain-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px}
  .la-course-card{background:#fff;border:1px solid #e5ebf2;border-radius:14px;padding:14px 16px;cursor:pointer;transition:.22s;box-shadow:var(--la-shadow)}
  .la-course-card:hover{transform:translateY(-3px);border-color:#c7d2fe;box-shadow:0 16px 40px rgba(37,99,235,.12)}
  .la-course-card h4{margin:6px 0;font-size:15px;color:#1e293b}
  .la-course-card p{margin:4px 0 0;font-size:12.5px;color:#64748b;line-height:1.6}
  .la-arc-badges{display:flex;gap:5px;flex-wrap:wrap;margin-bottom:2px}
  .la-overlay{position:fixed;inset:0;background:rgba(15,23,42,.5);display:none;align-items:center;justify-content:center;padding:18px;z-index:60;backdrop-filter:blur(2px)}
  .la-overlay.show{display:flex}
  .la-modal{width:min(820px,96vw);background:white;border-radius:24px;padding:30px;box-shadow:0 24px 80px rgba(0,0,0,.28);animation:laPopIn .3s;max-height:90vh;overflow-y:auto}
  @keyframes laPopIn{from{transform:scale(.94);opacity:0}to{transform:scale(1);opacity:1}}
  .la-modal h2{margin:0 0 10px;font-size:23px;color:#1e293b;line-height:1.35}
  .la-modal .la-crumbs{font-size:12px;color:#94a3b8;margin:0 0 14px;font-weight:600;letter-spacing:.02em}
  .la-modal .la-arc-badges{margin:0 0 16px}
  .la-modal-body{color:#334155;font-size:15px;line-height:1.9}
  .la-modal-body p{margin:0 0 12px}
  .la-modal-body strong{color:#0f172a}
  .la-modal-body ul{margin:0 0 12px;padding-left:22px}
  .la-modal-body li{margin-bottom:6px}
  .la-fml{margin:16px 0;padding:14px 18px;background:linear-gradient(135deg,#f8fafc,#eef4fb);border-left:4px solid #93b4e8;border-radius:10px;overflow-x:auto;font-size:16px;color:#0f172a}
  .la-fml .note{display:block;font-size:12.5px;color:#8496ad;margin-top:8px;line-height:1.6;font-family:system-ui,-apple-system,"PingFang SC","Microsoft YaHei",sans-serif}
  .la-fml mjx-container[display="true"]{margin:0 !important}
  mjx-container, mjx-container *{color:#0f172a !important;opacity:1 !important}
  mjx-mi{font-style:italic !important}
  mjx-mo{color:#0f172a !important}
  .la-modal-body mjx-container, .la-modal-body mjx-container *{color:#0f172a !important;opacity:1 !important}
  .la-fig{margin:18px auto;padding:14px 16px 10px;background:#fafcff;border:1px solid #e2ebf7;border-radius:14px;display:flex;flex-direction:column;align-items:center;max-width:600px}
  .la-fig svg{display:block;width:100%;height:auto;max-width:560px}
  .la-fig .la-fig-cap{font-size:12px;color:#8496ad;margin-top:8px;text-align:center;letter-spacing:.02em}
  .la-callout{margin:14px 0;padding:12px 16px;background:#fffbeb;border-left:3px solid #fbbf24;border-radius:8px;font-size:13.5px;color:#78350f;line-height:1.8}
  .la-kp-sec{margin:0 0 18px;padding:14px 16px;border-radius:12px;background:#f8fafc;border:1px solid #eef2f7}
  .la-kp-sec h5{margin:0 0 10px;font-size:14px;color:#1e293b;letter-spacing:.04em;display:flex;align-items:center;gap:8px}
  .la-kp-sec h5::before{content:"";width:4px;height:14px;border-radius:2px;background:var(--la-accent,#3b82f6)}
  .la-kp-def{border-left:3px solid #3b82f6}
  .la-kp-thm{border-left:3px solid #8b5cf6;background:#faf7ff}
  .la-kp-der{border-left:3px solid #0ea5e9;background:#f0f9ff}
  .la-kp-exa{border-left:3px solid #10b981;background:#f0fdf4}
  .la-kp-app{border-left:3px solid #f59e0b;background:#fffbeb}
  .la-kp-note{border-left:3px solid #ef4444;background:#fef2f2}
  .la-kp-his{border-left:3px solid #64748b;background:#f8fafc}
  .la-kp-sec p:last-child{margin-bottom:0}
  .la-modal-close{margin-top:22px;background:#0f172a;color:white;border-color:#0f172a;padding:10px 20px;font-weight:bold}
  .la-footer{padding:34px 0 50px;color:var(--la-muted);text-align:center;font-size:13px;line-height:1.9}
  .la-core-fmls{margin:40px 0 20px;padding:28px 24px;background:linear-gradient(135deg,#f0f4ff,#faf7ff);border:1px solid #e0e7ff;border-radius:18px}
  .la-core-fmls h3{font-size:18px;color:#1e293b;margin:0 0 20px;text-align:center;letter-spacing:.04em}
  .la-core-fmls h3 .la-core-count{display:inline-block;background:#6366f1;color:#fff;font-size:13px;padding:2px 10px;border-radius:20px;margin-left:8px;vertical-align:middle}
  .la-core-item{display:flex;gap:12px;margin:0 0 14px;padding:12px 16px;background:#fff;border-radius:12px;border-left:3px solid #6366f1;align-items:flex-start}
  .la-core-num{flex-shrink:0;width:26px;height:26px;border-radius:50%;background:#6366f1;color:#fff;font-size:13px;display:flex;align-items:center;justify-content:center;font-weight:bold}
  .la-core-body{flex:1;min-width:0}
  .la-core-body .la-core-name{font-size:14px;font-weight:600;color:#1e293b;margin-bottom:4px}
  .la-core-body .la-fml{margin:6px 0 0;padding:8px 14px;font-size:15px}
  .la-back-top{display:inline-block;margin-top:20px;padding:10px 28px;background:#1e293b;color:#fff;border:none;border-radius:25px;font-size:14px;cursor:pointer;letter-spacing:.04em;transition:background .2s}
  .la-back-top:hover{background:#334155}
  @media(max-width:900px){.la-wrap{width:min(94vw,720px)}.la-roadmap{padding:20px}.la-phase-title{font-size:19px}.la-phase-en{font-size:10px;letter-spacing:.26em}.la-domain-desc{display:none}.la-domain-grid{grid-template-columns:repeat(auto-fill,minmax(160px,1fr))}.la-modal{padding:22px}}'''

    js = f'''const LA_DATA = {la_data};
const LA_TAG_LABEL = {tag_label_js};
const LA_FIG = {fig_js};
const LA_KP = {{}};
function laBuildCard(item){{
  const tags = item.tags.map(t => `<span class="la-arc-badge la-arc-${{t}}">${{LA_TAG_LABEL[t]}}</span>`).join('');
  return `<div class="la-course-card" onclick="showLaItem('${{item.id}}')"><div class="la-arc-badges">${{tags}}</div><h4>${{item.name}}</h4><p>${{item.brief}}</p></div>`;
}}
function renderLa(){{
  const root = document.getElementById('laRoadmap');
  let html = '';
  LA_DATA.forEach(ch => {{
    html += `<h2 class="la-phase-title ${{ch.id}}" id="${{ch.id}}">${{ch.num}} · ${{ch.title}}</h2>`;
    html += `<div class="la-phase-en">${{ch.en}}</div>`;
    html += `<p class="la-phase-desc">${{ch.desc}}</p>`;
    ch.sections.forEach(sec => {{
      html += `<div class="la-domain" style="--domain-color:${{sec.color}};"><div class="la-domain-header"><h3>${{sec.name}}</h3><span class="la-domain-count">${{sec.items.length}} 个知识点</span><span class="la-domain-desc">${{sec.desc}}</span></div><div class="la-domain-grid">`;
      sec.items.forEach(it => {{ html += laBuildCard(it); LA_KP[it.id] = {{item: it, section: sec.name, chapter: `${{ch.num}} · ${{ch.title}}`}}; }});
      html += `</div></div>`;
    }});
  }});
  root.innerHTML = html;
  const kCount = Object.keys(LA_KP).length;
  document.getElementById('laKCount').textContent = kCount;
}}
function showLaItem(id){{
  const rec = LA_KP[id];
  if(!rec) return;
  const it = rec.item;
  document.getElementById('laCrumbs').textContent = rec.chapter + ' ／ ' + rec.section;
  document.getElementById('laTitle').textContent = it.name;
  document.getElementById('laTags').innerHTML = it.tags.map(t => `<span class="la-arc-badge la-arc-${{t}}">${{LA_TAG_LABEL[t]}}</span>`).join('');
  let bodyHtml = it.body;
  if (it.fig && LA_FIG[it.fig]) {{
    const figHtml = `<div class="la-fig">${{LA_FIG[it.fig]}}<div class="la-fig-cap">${{it.figCap || ''}}</div></div>`;
    bodyHtml = figHtml + bodyHtml;
  }}
  document.getElementById('laBody').innerHTML = bodyHtml;
  document.getElementById('laOverlay').classList.add('show');
  document.querySelector('.la-modal').scrollTop = 0;
  if (window.MathJax && window.MathJax.typesetPromise) {{ window.MathJax.typesetPromise([document.getElementById('laBody')]).catch(()=>{{}}); }}
}}
function hideLaInfo(){{ document.getElementById('laOverlay').classList.remove('show'); }}
function closeLaInfo(e){{ if(e.target.id === 'laOverlay') hideLaInfo(); }}
document.addEventListener('keydown', e => {{ if(e.key === 'Escape') hideLaInfo(); }});
document.addEventListener('DOMContentLoaded', () => {{
  renderLa();
  if (window.MathJax && window.MathJax.typesetPromise) {{ window.MathJax.typesetPromise([document.getElementById('laRoadmap')]).catch(()=>{{}}); }}
}});'''

    html = f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="特殊函数知识体系：朗博W函数、伽马函数、高斯积分、菲涅尔积分、超几何函数、厄米多项式、椭圆积分、马丢函数">
<title>特殊函数 · 知识体系</title>
<script>
window.MathJax = {{
  tex: {{
    inlineMath: [['$','$'], ['\\\\(','\\\\)']],
    displayMath: [['$$','$$'], ['\\\\[','\\\\]']],
    processEscapes: true,
    packages: {{'[+]': ['ams','boldsymbol']}}
  }},
  options: {{
    skipHtmlTags: ['script','noscript','style','textarea','pre','code'],
    ignoreHtmlClass: 'tex2jax_ignore'
  }},
  svg: {{ fontCache: 'global' }}
}};
</script>
<script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js" id="MathJax-script" async></script>
<style>
{css}
</style>
</head>
<body>
<div class="la-wrap">
  <header class="la-header">
    <div class="la-eyebrow">SPECIAL FUNCTIONS · KNOWLEDGE MAP</div>
    <h1>特殊函数 · 知识体系</h1>
    <p class="la-subtitle">朗博W函数 · 伽马函数 · 高斯积分 · 菲涅尔积分 · 超几何函数 · 厄米多项式 · 椭圆积分 · 马丢函数</p>
    <div class="back-bar"><a class="back-btn" href="index.html">← 返回总览</a></div>
    <div class="la-nav-tabs">{nav_tabs}</div>
    <div class="la-engagement-bar">
      <div class="la-stat-item"><span>📘</span><span class="la-stat-value" id="laKCount">--</span><span>个知识点</span></div>
      <a class="la-stat-item la-stat-link" href="#laCoreFmls" onclick="event.preventDefault();document.getElementById('laCoreFmls').scrollIntoView({{behavior:'smooth',block:'start'}})"><span>🧮</span><span class="la-stat-value">{len(CORE_FORMULAS)}</span><span>条核心公式 · 点击速查</span></a>
    </div>
  </header>
  <div class="la-legend">
    <span class="la-legend-title">知识记号</span>
    <span class="la-arc-badge la-arc-def">定 义</span>
    <span class="la-arc-badge la-arc-thm">定 理</span>
    <span class="la-arc-badge la-arc-der">推 导</span>
    <span class="la-arc-badge la-arc-exa">例 子</span>
    <span class="la-arc-badge la-arc-app">应 用</span>
    <span class="la-arc-badge la-arc-note">备 注</span>
  </div>
  <main class="la-roadmap" id="laRoadmap"></main>
  <section class="la-core-fmls" id="laCoreFmls">
    <h3>核心公式速查 <span class="la-core-count">{len(CORE_FORMULAS)} 条</span></h3>
{chr(10).join(f'    <div class="la-core-item"><div class="la-core-num">{i+1}</div><div class="la-core-body"><div class="la-core-name">{name.replace("<","&lt;")}</div><div class="la-fml">$${latex.replace("<","&lt;")}$$</div><div class="note" style="font-size:12px;color:#8496ad;margin-top:4px">{desc.replace("<","&lt;")}</div></div></div>' for i,(name,latex,desc) in enumerate(CORE_FORMULAS))}
  </section>
  <footer class="la-footer">
    <div>特殊函数 · 知识体系可视化 · MathJax + SVG</div>
    <div style="margin-top:8px">基于特殊函数核心知识体系整理</div>
    <button class="la-back-top" onclick="window.scrollTo({{top:0,behavior:'smooth'}})">↑ 回到顶部</button>
  </footer>
</div>
<div class="la-overlay" id="laOverlay" onclick="closeLaInfo(event)">
  <div class="la-modal" onclick="event.stopPropagation()">
    <p class="la-crumbs" id="laCrumbs"></p>
    <h2 id="laTitle">知识点</h2>
    <div class="la-arc-badges" id="laTags"></div>
    <div class="la-modal-body" id="laBody"></div>
    <button class="la-modal-close" onclick="hideLaInfo()">关 闭</button>
  </div>
</div>
<script>
{js}
</script>
</body>
</html>'''
    return html

if __name__ == "__main__":
    html = gen_html()
    with open("/workspace/special-functions.html", "w", encoding="utf-8") as f:
        f.write(html)
    print(f"Generated special-functions.html ({len(html)} chars)")
