# -*- coding: utf-8 -*-
"""Generate mathematical-methods.html with 6 chapters: 复变函数/复数级数与留数定理/积分变换/数学物理方程/数理方程求解/特殊函数."""
import json

FIG = {
"complex_plane": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="20" y1="80" x2="226" y2="80" stroke="#94a3b8" stroke-width="1"/>
<line x1="120" y1="150" x2="120" y2="16" stroke="#94a3b8" stroke-width="1"/>
<polygon points="226,80 216,76 216,84" fill="#94a3b8"/>
<polygon points="120,16 116,26 124,26" fill="#94a3b8"/>
<text x="204" y="96" font-size="10" fill="#64748b">Re z</text>
<text x="126" y="26" font-size="10" fill="#64748b">Im z</text>
<line x1="120" y1="80" x2="182" y2="42" stroke="#2563eb" stroke-width="1.8"/>
<polygon points="182,42 171,43 176,51" fill="#2563eb"/>
<circle cx="182" cy="42" r="2.6" fill="#2563eb"/>
<text x="186" y="40" font-size="10" fill="#2563eb">z=x+iy</text>
<line x1="120" y1="80" x2="182" y2="118" stroke="#ef4444" stroke-width="1.3" stroke-dasharray="4 3"/>
<circle cx="182" cy="118" r="2.4" fill="#ef4444"/>
<text x="186" y="128" font-size="10" fill="#ef4444">z 的共轭</text>
<line x1="120" y1="42" x2="182" y2="42" stroke="#0ea5e9" stroke-width="1" stroke-dasharray="3 2"/>
<path d="M 142 80 A 22 22 0 0 0 137 64" fill="none" stroke="#0ea5e9" stroke-width="1"/>
<text x="132" y="74" font-size="10" fill="#0ea5e9">r</text>
<text x="146" y="66" font-size="10" fill="#0ea5e9">θ</text>
<text x="30" y="146" font-size="10" fill="#64748b">z=re^{iθ}，模 r 与辐角 θ</text>
</svg>''',
"cr_condition": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="22" y1="126" x2="226" y2="126" stroke="#94a3b8" stroke-width="1"/>
<line x1="22" y1="140" x2="22" y2="20" stroke="#94a3b8" stroke-width="1"/>
<text x="208" y="142" font-size="10" fill="#64748b">x</text>
<text x="6" y="24" font-size="10" fill="#64748b">y</text>
<rect x="60" y="44" width="86" height="82" fill="#eff6ff" stroke="#2563eb" stroke-width="1.5"/>
<text x="58" y="38" font-size="10" fill="#2563eb">z 平面：u(x,y), v(x,y)</text>
<line x1="60" y1="85" x2="146" y2="85" stroke="#0ea5e9" stroke-width="1" stroke-dasharray="3 2"/>
<line x1="103" y1="44" x2="103" y2="126" stroke="#0ea5e9" stroke-width="1" stroke-dasharray="3 2"/>
<circle cx="103" cy="85" r="3" fill="#1d4ed8"/>
<line x1="22" y1="152" x2="226" y2="152" stroke="#e2e8f0" stroke-width="1"/>
<text x="26" y="148" font-size="10" fill="#0284c7">u_x = v_y，u_y = −v_x</text>
<text x="118" y="72" font-size="10" fill="#1d4ed8">z₀</text>
</svg>''',
"conformal": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<rect x="16" y="30" width="86" height="86" fill="#f0f9ff" stroke="#94a3b8" stroke-width="1"/>
<g stroke="#0ea5e9" stroke-width="0.8">
<line x1="34" y1="30" x2="34" y2="116"/><line x1="52" y1="30" x2="52" y2="116"/>
<line x1="70" y1="30" x2="70" y2="116"/><line x1="88" y1="30" x2="88" y2="116"/>
<line x1="16" y1="48" x2="102" y2="48"/><line x1="16" y1="66" x2="102" y2="66"/>
<line x1="16" y1="84" x2="102" y2="84"/><line x1="16" y1="102" x2="102" y2="102"/>
</g>
<text x="22" y="146" font-size="10" fill="#64748b">z 平面正交网格</text>
<line x1="110" y1="73" x2="134" y2="73" stroke="#1d4ed8" stroke-width="1.6"/>
<polygon points="134,73 125,69 125,77" fill="#1d4ed8"/>
<text x="106" y="64" font-size="10" fill="#1d4ed8">w=f(z)</text>
<rect x="144" y="30" width="80" height="86" fill="#eff6ff" stroke="#94a3b8" stroke-width="1"/>
<g stroke="#2563eb" stroke-width="0.8" fill="none">
<path d="M 160 30 Q 176 73 160 116"/><path d="M 186 30 Q 202 73 186 116"/>
<path d="M 144 46 Q 184 58 224 46"/><path d="M 144 82 Q 184 94 224 82"/>
</g>
<text x="146" y="146" font-size="10" fill="#2563eb">像曲线仍正交（保角）</text>
</svg>''',
"contour": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<circle cx="120" cy="80" r="52" fill="#f0f9ff" stroke="#0284c7" stroke-width="1.8"/>
<line x1="120" y1="80" x2="172" y2="80" stroke="#0284c7" stroke-width="0.8" stroke-dasharray="3 2"/>
<circle cx="120" cy="80" r="2.8" fill="#1e40af"/>
<text x="124" y="94" font-size="10" fill="#1e40af">a</text>
<polygon points="120,28 112,40 120,36 128,40" fill="#0284c7"/>
<text x="96" y="22" font-size="10" fill="#0284c7">C 取正向</text>
<text x="22" y="150" font-size="10" fill="#64748b">∮_C f(z) dz = 0（C 内解析）</text>
</svg>''',
"cauchy_annulus": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<circle cx="120" cy="80" r="60" fill="#eff6ff" stroke="#0284c7" stroke-width="1.6" stroke-dasharray="5 3"/>
<circle cx="120" cy="80" r="26" fill="#fff" stroke="#ef4444" stroke-width="1.4"/>
<circle cx="120" cy="80" r="60" fill="none" stroke="#0284c7" stroke-width="1.6"/>
<text x="112" y="84" font-size="10" fill="#ef4444">挖去奇点</text>
<text x="34" y="28" font-size="10" fill="#0284c7">C 外边界</text>
<text x="24" y="148" font-size="10" fill="#64748b">多连通域：∮_C f dz = Σ∮_{C_k} f dz</text>
</svg>''',
"convergence_disk": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<circle cx="100" cy="80" r="56" fill="#f5f3ff" stroke="#7c3aed" stroke-width="1.6"/>
<circle cx="100" cy="80" r="2.8" fill="#5b21b6"/>
<text x="76" y="76" font-size="10" fill="#5b21b6">z₀</text>
<line x1="100" y1="80" x2="156" y2="80" stroke="#8b5cf6" stroke-width="1" stroke-dasharray="3 2"/>
<text x="120" y="74" font-size="10" fill="#8b5cf6">R</text>
<circle cx="100" cy="24" r="3.2" fill="#ef4444"/>
<text x="106" y="20" font-size="10" fill="#ef4444">最近奇点</text>
<text x="24" y="150" font-size="10" fill="#64748b">|z − z₀| &lt; R 内幂级数收敛</text>
</svg>''',
"laurent_annulus": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<circle cx="120" cy="80" r="62" fill="#f5f3ff" stroke="#a855f7" stroke-width="1.4"/>
<circle cx="120" cy="80" r="30" fill="#ede9fe" stroke="#7c3aed" stroke-width="1.5"/>
<line x1="120" y1="80" x2="150" y2="80" stroke="#7c3aed" stroke-width="1" stroke-dasharray="3 2"/>
<line x1="120" y1="80" x2="182" y2="80" stroke="#7c3aed" stroke-width="1" stroke-dasharray="3 2"/>
<text x="130" y="74" font-size="10" fill="#7c3aed">r</text>
<text x="166" y="74" font-size="10" fill="#7c3aed">R</text>
<text x="20" y="150" font-size="10" fill="#64748b">环域 r &lt; |z − z₀| &lt; R 内可展开</text>
</svg>''',
"singularity_types": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="20" y1="130" x2="226" y2="130" stroke="#94a3b8" stroke-width="1"/>
<line x1="28" y1="140" x2="28" y2="20" stroke="#94a3b8" stroke-width="1"/>
<text x="30" y="30" font-size="10" fill="#64748b">|f(z)|</text>
<text x="176" y="146" font-size="10" fill="#64748b">围绕 z₀</text>
<circle cx="70" cy="126" r="3" fill="#0ea5e9"/>
<text x="50" y="114" font-size="9" fill="#0ea5e9">可去奇点</text>
<line x1="120" y1="130" x2="120" y2="42" stroke="#7c3aed" stroke-width="1.8"/>
<text x="102" y="34" font-size="9" fill="#7c3aed">极点</text>
<g stroke="#ef4444" stroke-width="1">
<line x1="152" y1="130" x2="152" y2="58"/><line x1="160" y1="130" x2="160" y2="34"/>
<line x1="168" y1="130" x2="168" y2="70"/><line x1="176" y1="130" x2="176" y2="26"/>
<line x1="184" y1="130" x2="184" y2="54"/><line x1="192" y1="130" x2="192" y2="40"/>
</g>
<text x="150" y="20" font-size="9" fill="#ef4444">本性奇点</text>
</svg>''',
"residue_pole": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<circle cx="120" cy="80" r="54" fill="none" stroke="#6d28d9" stroke-width="1.8"/>
<circle cx="120" cy="80" r="7" fill="none" stroke="#ef4444" stroke-width="1.6"/>
<circle cx="120" cy="80" r="2.4" fill="#ef4444"/>
<text x="132" y="76" font-size="10" fill="#ef4444">z₀ 极点</text>
<line x1="120" y1="80" x2="120" y2="28" stroke="#ef4444" stroke-width="0.8" stroke-dasharray="3 2"/>
<text x="20" y="150" font-size="10" fill="#64748b">∮_C f dz = 2πi · Res f(z₀)</text>
</svg>''',
"fourier_pair": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="14" y1="52" x2="112" y2="52" stroke="#94a3b8" stroke-width="1"/>
<line x1="14" y1="58" x2="14" y2="14" stroke="#94a3b8" stroke-width="1"/>
<path d="M 22 52 L 42 52 L 42 20 L 62 20 L 62 52 L 82 52 L 82 34 L 100 34 L 100 52" fill="none" stroke="#0d9488" stroke-width="1.8"/>
<text x="18" y="14" font-size="10" fill="#0d9488">f(t)</text>
<text x="14" y="68" font-size="10" fill="#64748b">时域</text>
<line x1="130" y1="52" x2="228" y2="52" stroke="#94a3b8" stroke-width="1"/>
<line x1="132" y1="58" x2="132" y2="14" stroke="#94a3b8" stroke-width="1"/>
<path d="M 132 52 Q 160 12 180 52 Q 200 88 228 52" fill="none" stroke="#0f766e" stroke-width="1.8"/>
<text x="150" y="14" font-size="10" fill="#0f766e">F(ω)</text>
<text x="186" y="68" font-size="10" fill="#64748b">频域</text>
<polygon points="116,46 124,50 124,42" fill="#94a3b8"/>
<text x="22" y="100" font-size="10" fill="#64748b">F(ω)=∫ f(t)e^(−iωt) dt</text>
<text x="22" y="120" font-size="10" fill="#64748b">f(t)=1/(2π)∫ F(ω)e^(iωt) dω</text>
<text x="22" y="142" font-size="10" fill="#0d9488">时域与频域一一对应</text>
</svg>''',
"fourier_spectrum": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="20" y1="122" x2="228" y2="122" stroke="#94a3b8" stroke-width="1"/>
<line x1="26" y1="132" x2="26" y2="22" stroke="#94a3b8" stroke-width="1"/>
<text x="200" y="138" font-size="10" fill="#64748b">ω</text>
<text x="6" y="28" font-size="10" fill="#64748b">|F|</text>
<path d="M 32 26 Q 60 28 90 46 Q 120 80 132 104 Q 146 120 160 122" fill="none" stroke="#0d9488" stroke-width="1.8"/>
<path d="M 160 122 Q 174 120 188 104 Q 200 80 226 46" fill="none" stroke="#0d9488" stroke-width="1.8"/>
<circle cx="128" cy="98" r="2.4" fill="#0f766e"/><circle cx="192" cy="98" r="2.4" fill="#0f766e"/>
<text x="108" y="142" font-size="10" fill="#64748b">−2π/a</text>
<text x="176" y="142" font-size="10" fill="#64748b">2π/a</text>
<text x="30" y="18" font-size="10" fill="#0f766e">方脉冲 → sinc 型谱</text>
</svg>''',
"convolution": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="14" y1="60" x2="106" y2="60" stroke="#94a3b8" stroke-width="1"/>
<path d="M 24 60 L 24 28 L 54 28 L 54 60 L 94 60" fill="none" stroke="#0d9488" stroke-width="1.6"/>
<text x="18" y="78" font-size="10" fill="#0d9488">f(t)</text>
<path d="M 18 120 L 48 120 L 48 98 L 78 98 L 78 120 L 102 120" fill="none" stroke="#14b8a6" stroke-width="1.6"/>
<text x="18" y="138" font-size="10" fill="#14b8a6">g(t)</text>
<text x="60" y="22" font-size="10" fill="#64748b">卷积</text>
<line x1="128" y1="90" x2="154" y2="90" stroke="#0f766e" stroke-width="1.6"/>
<polygon points="154,90 144,86 144,94" fill="#0f766e"/>
<line x1="162" y1="90" x2="228" y2="90" stroke="#94a3b8" stroke-width="1"/>
<path d="M 162 90 L 180 90 L 180 48 L 198 48 L 198 90 L 226 90" fill="none" stroke="#115e59" stroke-width="1.8"/>
<text x="158" y="120" font-size="10" fill="#115e59">(f * g)(t)</text>
<text x="12" y="154" font-size="10" fill="#64748b">卷积定理：F{f * g} = F{f} · F{g}</text>
</svg>''',
"laplace_region": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="20" y1="80" x2="228" y2="80" stroke="#94a3b8" stroke-width="1"/>
<line x1="60" y1="140" x2="60" y2="20" stroke="#94a3b8" stroke-width="1"/>
<text x="204" y="96" font-size="10" fill="#64748b">Re s</text>
<text x="66" y="26" font-size="10" fill="#64748b">Im s</text>
<rect x="112" y="20" width="110" height="120" fill="#ccfbf1" stroke="#0d9488" stroke-width="1.2"/>
<line x1="112" y1="14" x2="112" y2="146" stroke="#0f766e" stroke-width="1.6" stroke-dasharray="5 3"/>
<text x="92" y="32" font-size="10" fill="#0f766e">σ₀</text>
<text x="140" y="86" font-size="10" fill="#0f766e">收敛域 Re s &gt; σ₀</text>
<text x="20" y="152" font-size="10" fill="#64748b">L{f}(s)=∫₀^∞ f(t)e^(−st) dt</text>
</svg>''',
"wave_string": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="20" y1="100" x2="220" y2="100" stroke="#cbd5e1" stroke-width="1" stroke-dasharray="4 3"/>
<path d="M 20 100 Q 70 30 120 100 Q 170 30 220 100" fill="none" stroke="#c2410c" stroke-width="2"/>
<circle cx="20" cy="100" r="3" fill="#9a3412"/><circle cx="220" cy="100" r="3" fill="#9a3412"/>
<text x="10" y="118" font-size="10" fill="#9a3412">0</text>
<text x="210" y="118" font-size="10" fill="#9a3412">L</text>
<line x1="70" y1="64" x2="70" y2="100" stroke="#ea580c" stroke-width="1"/>
<polygon points="70,64 66,74 74,74" fill="#ea580c"/>
<text x="74" y="74" font-size="10" fill="#ea580c">T</text>
<text x="70" y="150" font-size="10" fill="#64748b">u_tt = a²u_xx，弦的微小横振动</text>
</svg>''',
"heat_rod": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<rect x="30" y="56" width="180" height="30" rx="4" fill="#ffedd5" stroke="#c2410c" stroke-width="1.4"/>
<text x="92" y="76" font-size="10" fill="#9a3412">均匀细杆 x∈[0,L]</text>
<path d="M 30 108 C 70 100 110 92 150 92 C 180 92 200 100 210 108" fill="none" stroke="#ea580c" stroke-width="1.8"/>
<text x="132" y="128" font-size="10" fill="#ea580c">温度 u(x,t)</text>
<circle cx="30" cy="71" r="4" fill="#dc2626"/>
<text x="12" y="44" font-size="10" fill="#dc2626">热源</text>
<polygon points="228,71 210,66 210,76" fill="#ea580c"/>
<text x="42" y="146" font-size="10" fill="#64748b">u_t = a²u_xx，热传导方程</text>
</svg>''',
"boundary_conditions": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<rect x="40" y="34" width="160" height="86" fill="#fff7ed" stroke="#c2410c" stroke-width="1.4"/>
<text x="98" y="84" font-size="10" fill="#9a3412">区域 Ω</text>
<g stroke="#c2410c" stroke-width="2">
<line x1="40" y1="30" x2="40" y2="38"/><line x1="80" y1="30" x2="80" y2="38"/>
<line x1="120" y1="30" x2="120" y2="38"/><line x1="160" y1="30" x2="160" y2="38"/>
<line x1="200" y1="30" x2="200" y2="38"/></g>
<text x="42" y="24" font-size="9" fill="#c2410c">u|∂Ω = g（第一类）</text>
<g stroke="#0d9488" stroke-width="1.6">
<line x1="40" y1="120" x2="40" y2="130"/><line x1="90" y1="120" x2="90" y2="130"/>
<line x1="140" y1="120" x2="140" y2="130"/><line x1="190" y1="120" x2="190" y2="130"/></g>
<text x="42" y="146" font-size="9" fill="#0d9488">∂u/∂n = h（第二类）</text>
<text x="42" y="158" font-size="9" fill="#9a3412">∂u/∂n + σu = q（第三类）</text>
</svg>''',
"characteristics": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="20" y1="126" x2="228" y2="126" stroke="#94a3b8" stroke-width="1"/>
<line x1="30" y1="136" x2="30" y2="20" stroke="#94a3b8" stroke-width="1"/>
<text x="206" y="142" font-size="10" fill="#64748b">x</text>
<text x="14" y="26" font-size="10" fill="#64748b">y</text>
<line x1="44" y1="120" x2="88" y2="64" stroke="#c2410c" stroke-width="1.2"/>
<line x1="44" y1="64" x2="88" y2="120" stroke="#c2410c" stroke-width="1.2"/>
<text x="40" y="54" font-size="9" fill="#c2410c">双曲型 Δ &gt; 0</text>
<path d="M 148 96 Q 168 44 188 96 Q 208 44 224 96" fill="none" stroke="#0d9488" stroke-width="1.2"/>
<text x="134" y="34" font-size="9" fill="#0d9488">抛物型 Δ = 0</text>
<path d="M 104 44 Q 122 92 104 122" fill="none" stroke="#7c3aed" stroke-width="1.2"/>
<text x="94" y="140" font-size="9" fill="#7c3aed">椭圆型 Δ &lt; 0</text>
</svg>''',
"separation_vars": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="20" y1="110" x2="222" y2="110" stroke="#cbd5e1" stroke-width="1"/>
<path d="M 30 110 Q 60 40 90 110" fill="none" stroke="#be185d" stroke-width="1.6"/>
<path d="M 90 110 Q 120 62 150 110" fill="none" stroke="#db2777" stroke-width="1.6"/>
<path d="M 150 110 Q 180 74 210 110" fill="none" stroke="#e11d48" stroke-width="1.6"/>
<text x="42" y="36" font-size="10" fill="#be185d">n=1</text>
<text x="112" y="56" font-size="10" fill="#db2777">n=2</text>
<text x="176" y="70" font-size="10" fill="#e11d48">n=3</text>
<text x="30" y="140" font-size="10" fill="#64748b">u = Σ Xₙ(x) Tₙ(t)，分离变量</text>
</svg>''',
"eigenfunction_expansion": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="20" y1="120" x2="228" y2="120" stroke="#94a3b8" stroke-width="1"/>
<line x1="24" y1="130" x2="24" y2="20" stroke="#94a3b8" stroke-width="1"/>
<g fill="#fbcfe8" stroke="#be185d" stroke-width="1">
<rect x="44" y="78" width="14" height="42"/><rect x="86" y="58" width="14" height="62"/>
<rect x="128" y="68" width="14" height="52"/><rect x="170" y="90" width="14" height="30"/></g>
<text x="42" y="136" font-size="9" fill="#64748b">λ₁</text>
<text x="84" y="136" font-size="9" fill="#64748b">λ₂</text>
<text x="126" y="136" font-size="9" fill="#64748b">λ₃</text>
<text x="168" y="136" font-size="9" fill="#64748b">λ₄</text>
<text x="52" y="30" font-size="10" fill="#be185d">本征值 λₙ 与正交本征函数</text>
<text x="30" y="154" font-size="10" fill="#64748b">∫ X_m X_n dx = 0（m ≠ n）</text>
</svg>''',
"dalembert": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="20" y1="80" x2="228" y2="80" stroke="#cbd5e1" stroke-width="1"/>
<path d="M 30 80 L 70 40 L 110 80 L 150 120 L 190 80" fill="none" stroke="#be185d" stroke-width="1.8"/>
<path d="M 30 80 L 70 120 L 110 80 L 150 40 L 190 80" fill="none" stroke="#db2777" stroke-width="1.8" stroke-dasharray="5 3"/>
<text x="52" y="34" font-size="10" fill="#be185d">f(x−at) 右行波</text>
<text x="52" y="132" font-size="10" fill="#db2777">f(x+at) 左行波</text>
<text x="24" y="154" font-size="10" fill="#64748b">u = [f(x−at)+f(x+at)]/2</text>
</svg>''',
"green_function": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<circle cx="120" cy="80" r="8" fill="#fbcfe8" stroke="#be185d" stroke-width="1.4"/>
<circle cx="120" cy="80" r="1.8" fill="#9d174d"/>
<text x="128" y="76" font-size="10" fill="#9d174d">点源 x′</text>
<g stroke="#db2777" stroke-width="1">
<line x1="120" y1="80" x2="60" y2="42"/><line x1="120" y1="80" x2="180" y2="42"/>
<line x1="120" y1="80" x2="60" y2="120"/><line x1="120" y1="80" x2="180" y2="120"/></g>
<circle cx="60" cy="42" r="2" fill="#f472b6"/><circle cx="180" cy="42" r="2" fill="#f472b6"/>
<circle cx="60" cy="120" r="2" fill="#f472b6"/><circle cx="180" cy="120" r="2" fill="#f472b6"/>
<text x="20" y="150" font-size="10" fill="#64748b">−ΔG = δ(x−x′)，G 为点源响应</text>
<text x="30" y="24" font-size="10" fill="#be185d">u(x)=∫ G(x,x′) f(x′) dx′</text>
</svg>''',
"legendre": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="20" y1="80" x2="228" y2="80" stroke="#94a3b8" stroke-width="1"/>
<line x1="120" y1="140" x2="120" y2="20" stroke="#94a3b8" stroke-width="1"/>
<text x="204" y="96" font-size="10" fill="#64748b">x</text>
<text x="126" y="26" font-size="10" fill="#64748b">Pₙ</text>
<line x1="20" y1="40" x2="220" y2="40" stroke="#e2e8f0" stroke-width="1"/>
<line x1="40" y1="80" x2="200" y2="80" stroke="#0e7490" stroke-width="1.6"/>
<line x1="40" y1="110" x2="200" y2="50" stroke="#0891b2" stroke-width="1.6"/>
<path d="M 40 96 Q 120 22 200 96" fill="none" stroke="#06b6d4" stroke-width="1.6"/>
<text x="176" y="76" font-size="9" fill="#0e7490">P₀ = 1</text>
<text x="180" y="52" font-size="9" fill="#0891b2">P₁ = x</text>
<text x="112" y="36" font-size="9" fill="#06b6d4">P₂ = (3x²−1)/2</text>
<text x="16" y="154" font-size="10" fill="#64748b">勒让德多项式在 [−1,1] 上正交</text>
</svg>''',
"associated": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<circle cx="120" cy="82" r="52" fill="#ecfeff" stroke="#0891b2" stroke-width="1.2"/>
<ellipse cx="120" cy="82" rx="52" ry="18" fill="none" stroke="#06b6d4" stroke-width="1"/>
<ellipse cx="120" cy="82" rx="18" ry="52" fill="none" stroke="#06b6d4" stroke-width="1"/>
<line x1="120" y1="82" x2="120" y2="30" stroke="#0e7490" stroke-width="1.6"/>
<text x="126" y="28" font-size="10" fill="#0e7490">z</text>
<text x="150" y="72" font-size="10" fill="#0891b2">θ</text>
<text x="128" y="118" font-size="10" fill="#0e7490">φ</text>
<text x="20" y="150" font-size="10" fill="#64748b">Y_lm(θ,φ)：球面调和函数</text>
</svg>''',
"spherical": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<circle cx="92" cy="82" r="48" fill="#ecfeff" stroke="#0891b2" stroke-width="1.2"/>
<path d="M 44 70 Q 92 30 140 84" fill="none" stroke="#06b6d4" stroke-width="1.2"/>
<path d="M 58 40 Q 62 82 68 126" fill="none" stroke="#67e8f9" stroke-width="1"/>
<path d="M 122 44 Q 120 82 118 124" fill="none" stroke="#67e8f9" stroke-width="1"/>
<text x="150" y="42" font-size="10" fill="#0891b2">球面 Y_lm</text>
<line x1="38" y1="82" x2="152" y2="82" stroke="#0e7490" stroke-width="1"/>
<line x1="92" y1="28" x2="92" y2="136" stroke="#0e7490" stroke-width="1"/>
<text x="98" y="142" font-size="10" fill="#0e7490">x</text>
<text x="20" y="152" font-size="10" fill="#64748b">∇²Y = −l(l+1) Y / r²</text>
</svg>''',
"bessel": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="24" y1="80" x2="228" y2="80" stroke="#94a3b8" stroke-width="1"/>
<line x1="30" y1="140" x2="30" y2="18" stroke="#94a3b8" stroke-width="1"/>
<text x="206" y="96" font-size="10" fill="#64748b">r</text>
<text x="14" y="24" font-size="10" fill="#64748b">Jₙ</text>
<path d="M 30 30 Q 60 120 84 80 Q 108 20 140 60 Q 170 104 210 50" fill="none" stroke="#0891b2" stroke-width="1.8"/>
<path d="M 30 122 Q 46 60 70 84 Q 96 116 126 70 Q 160 20 210 62" fill="none" stroke="#06b6d4" stroke-width="1.6" stroke-dasharray="5 3"/>
<text x="40" y="36" font-size="9" fill="#0891b2">J₀</text>
<text x="40" y="134" font-size="9" fill="#06b6d4">J₁</text>
<text x="24" y="154" font-size="10" fill="#64748b">贝塞尔函数 J₀、J₁ 的振荡衰减</text>
</svg>''',
"hermite_laguerre": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="20" y1="90" x2="228" y2="90" stroke="#94a3b8" stroke-width="1"/>
<line x1="30" y1="140" x2="30" y2="18" stroke="#94a3b8" stroke-width="1"/>
<text x="208" y="106" font-size="10" fill="#64748b">x</text>
<path d="M 40 100 Q 70 20 100 90 Q 130 150 160 70 Q 190 20 220 80" fill="none" stroke="#0e7490" stroke-width="1.6"/>
<path d="M 40 130 Q 80 60 120 110 Q 160 60 210 118" fill="none" stroke="#06b6d4" stroke-width="1.6" stroke-dasharray="5 3"/>
<text x="42" y="30" font-size="9" fill="#0e7490">Hₙ（埃尔米特）</text>
<text x="146" y="136" font-size="9" fill="#06b6d4">Lₙ（拉盖尔）</text>
<text x="24" y="154" font-size="10" fill="#64748b">量子谐振子与氢原子径向解</text>
</svg>''',
"orthogonality": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="30" y1="110" x2="222" y2="110" stroke="#94a3b8" stroke-width="1"/>
<line x1="36" y1="130" x2="36" y2="22" stroke="#94a3b8" stroke-width="1"/>
<g fill="#a5f3fc" stroke="#0891b2" stroke-width="1">
<rect x="46" y="78" width="22" height="32"/><rect x="96" y="64" width="22" height="46"/>
<rect x="146" y="72" width="22" height="38"/><rect x="196" y="86" width="22" height="24"/></g>
<text x="40" y="136" font-size="9" fill="#64748b">1</text>
<text x="90" y="136" font-size="9" fill="#64748b">2</text>
<text x="140" y="136" font-size="9" fill="#64748b">3</text>
<text x="190" y="136" font-size="9" fill="#64748b">4</text>
<text x="48" y="26" font-size="10" fill="#0891b2">展开系数 aₙ = ⟨f,φₙ⟩ / ⟨φₙ,φₙ⟩</text>
<text x="40" y="154" font-size="10" fill="#64748b">∫ φ_m φ_n w dx = 0（m ≠ n）</text>
</svg>''',
}

TAG_LABEL = {"def":"定 义","thm":"定 理","der":"推 导","exa":"例 子","app":"应 用","his":"注 记","note":"备 注"}

CORE_FORMULAS = [
    ("欧拉公式", "\\mathrm{e}^{i\\theta}=\\cos\\theta+i\\sin\\theta", "把复指数与三角函数统一，是复变函数与积分变换的基石"),
    ("复数的模与辐角", "|z|=\\sqrt{x^2+y^2},\\quad \\arg z=\\theta", "复数在复平面上的极坐标表示 z=re^{iθ}"),
    ("棣莫弗公式", "(\\cos\\theta+i\\sin\\theta)^n=\\cos n\\theta+i\\sin n\\theta", "复数乘方与三角恒等式的桥梁"),
    ("复数方根", "\\sqrt[n]{z}=r^{1/n}\\mathrm{e}^{i(\\theta+2k\\pi)/n},\\ k=0,1,\\dots,n-1", "n 次方根在复平面上均匀分布"),
    ("柯西-黎曼条件", "u_x=v_y,\\qquad u_y=-v_x", "f=u+iv 可微的必要条件，也是解析性的核心判据"),
    ("解析函数导数", "f'(z)=u_x+iv_x=v_y-iu_y", "解析函数的导数可由偏导数给出"),
    ("拉普拉斯方程", "u_{xx}+u_{yy}=0", "解析函数的实部与虚部都是调和函数"),
    ("共轭调和函数", "\\mathrm{d}v=-u_y\\,\\mathrm{d}x+u_x\\,\\mathrm{d}y", "由 u 求共轭调和函数 v，使 u+iv 解析"),
    ("复变函数积分", "\\int_C f(z)\\,\\mathrm{d}z=\\int_C (u+iv)(\\mathrm{d}x+i\\,\\mathrm{d}y)", "复积分可化为一对实线积分之和"),
    ("柯西积分定理", "\\oint_C f(z)\\,\\mathrm{d}z=0", "单连通区域内解析函数的闭路积分为零"),
    ("复合闭路定理", "\\oint_C f(z)\\,\\mathrm{d}z=\\sum_{k}\\oint_{C_k} f(z)\\,\\mathrm{d}z", "多连通区域外边界积分等于各内边界积分之和"),
    ("柯西积分公式", "f(a)=\\frac{1}{2\\pi i}\\oint_C\\frac{f(z)}{z-a}\\,\\mathrm{d}z", "用边界值表示解析函数在内部的取值"),
    ("高阶导数公式", "f^{(n)}(a)=\\frac{n!}{2\\pi i}\\oint_C\\frac{f(z)}{(z-a)^{n+1}}\\,\\mathrm{d}z", "解析函数任意阶导数均存在并可由积分表达"),
    ("柯西不等式", "|f^{(n)}(a)|\\le\\frac{n!\\,M}{R^n}", "圆盘内解析函数导数模的估计"),
    ("刘维尔定理", "|f(z)|\\le M\\ \\Rightarrow\\ f\\equiv\\text{常数}", "有界整函数必为常数，是代数基本定理的基础"),
    ("最大模原理", "|f(z)|在区域内部无极值", "非常数解析函数的模只能在边界上取最大值"),
    ("泰勒级数", "f(z)=\\sum_{n=0}^{\\infty}a_n(z-z_0)^n", "解析函数在圆盘内可展开为幂级数"),
    ("泰勒系数", "a_n=\\frac{1}{n!}f^{(n)}(z_0)", "由各阶导数确定泰勒系数"),
    ("洛朗级数", "f(z)=\\sum_{n=-\\infty}^{\\infty}c_n(z-z_0)^n", "环域内解析函数的双边幂级数展开"),
    ("洛朗系数", "c_n=\\frac{1}{2\\pi i}\\oint_C\\frac{f(\\zeta)}{(\\zeta-z_0)^{n+1}}\\,\\mathrm{d}\\zeta", "由围道积分确定洛朗系数"),
    ("收敛半径", "\\frac{1}{R}=\\limsup_{n\\to\\infty}|a_n|^{1/n}", "柯西-阿达马公式，等于圆心到最近奇点的距离"),
    ("留数定义", "\\mathrm{Res}\\,f(z_0)=c_{-1}", "洛朗展开中 (z-z₀)^{-1} 项的系数"),
    ("留数定理", "\\oint_C f(z)\\,\\mathrm{d}z=2\\pi i\\sum_{k}\\mathrm{Res}\\,f(z_k)", "围道积分等于内部各留数之和的 2πi 倍"),
    ("一阶极点留数", "\\mathrm{Res}\\,f(a)=\\lim_{z\\to a}(z-a)f(z)", "一阶极点留数的简便求法"),
    ("m 阶极点留数", "\\mathrm{Res}\\,f(a)=\\frac{1}{(m-1)!}\\lim_{z\\to a}\\frac{\\mathrm{d}^{m-1}}{\\mathrm{d}z^{m-1}}\\big[(z-a)^m f(z)\\big]", "高阶极点留数由求导极限给出"),
    ("无穷远点留数", "\\sum_{k}\\mathrm{Res}\\,f(z_k)+\\mathrm{Res}\\,f(\\infty)=0", "复平面上全部留数之和为零"),
    ("约当引理", "\\lim_{R\\to\\infty}\\int_{C_R}f(z)\\mathrm{e}^{iaz}\\,\\mathrm{d}z=0\\ (a>0)", "大圆弧积分趋于零，是计算实积分的关键估计"),
    ("三角有理式积分", "\\int_0^{2\\pi}R(\\cos\\theta,\\sin\\theta)\\,\\mathrm{d}\\theta=2\\pi i\\sum\\mathrm{Res}", "令 z=e^{iθ} 化为单位圆上的留数计算"),
    ("傅里叶级数", "f(x)=\\frac{a_0}{2}+\\sum_{n=1}^{\\infty}\\left(a_n\\cos\\frac{n\\pi x}{l}+b_n\\sin\\frac{n\\pi x}{l}\\right)", "周期函数的三角级数展开"),
    ("傅里叶余弦系数", "a_n=\\frac{1}{l}\\int_{-l}^{l}f(x)\\cos\\frac{n\\pi x}{l}\\,\\mathrm{d}x", "由函数与余弦基的正交性确定系数"),
    ("傅里叶复数形式", "f(x)=\\sum_{n=-\\infty}^{\\infty}c_n\\mathrm{e}^{in\\pi x/l},\\quad c_n=\\frac{1}{2l}\\int_{-l}^{l}f(x)\\mathrm{e}^{-in\\pi x/l}\\,\\mathrm{d}x", "复数形式的周期展开，是傅里叶变换的桥梁"),
    ("傅里叶变换", "F(\\omega)=\\int_{-\\infty}^{\\infty}f(t)\\mathrm{e}^{-i\\omega t}\\,\\mathrm{d}t", "时域信号到频域的变换"),
    ("傅里叶逆变换", "f(t)=\\frac{1}{2\\pi}\\int_{-\\infty}^{\\infty}F(\\omega)\\mathrm{e}^{i\\omega t}\\,\\mathrm{d}\\omega", "频域到时域的还原式"),
    ("傅里叶积分定理", "f(t)=\\frac{1}{2\\pi}\\int_{-\\infty}^{\\infty}\\!\\!\\int_{-\\infty}^{\\infty}f(\\tau)\\mathrm{e}^{i\\omega(t-\\tau)}\\,\\mathrm{d}\\tau\\,\\mathrm{d}\\omega", "非周期函数由连续频率分量叠加而成"),
    ("位移性质", "\\mathcal{F}\\{f(t-t_0)\\}=F(\\omega)\\mathrm{e}^{-i\\omega t_0}", "时域平移对应频域乘上线性相位"),
    ("微分性质", "\\mathcal{F}\\{f^{(n)}(t)\\}=(i\\omega)^n F(\\omega)", "时域求导等价于频域乘以 iω"),
    ("尺度性质", "\\mathcal{F}\\{f(at)\\}=\\frac{1}{|a|}F\\!\\left(\\frac{\\omega}{a}\\right)", "时域压缩对应频域展宽"),
    ("卷积定理", "\\mathcal{F}\\{f*g\\}=F(\\omega)\\,G(\\omega)", "时域卷积化为频域乘积"),
    ("帕塞瓦尔定理", "\\int_{-\\infty}^{\\infty}|f(t)|^2\\,\\mathrm{d}t=\\frac{1}{2\\pi}\\int_{-\\infty}^{\\infty}|F(\\omega)|^2\\,\\mathrm{d}\\omega", "能量在时域与频域中守恒"),
    ("高斯函数变换", "\\mathcal{F}\\{\\mathrm{e}^{-at^2}\\}=\\sqrt{\\frac{\\pi}{a}}\\,\\mathrm{e}^{-\\omega^2/(4a)}", "高斯函数的傅里叶变换仍为高斯函数"),
    ("拉普拉斯变换", "L\\{f\\}(s)=\\int_0^{\\infty}f(t)\\mathrm{e}^{-st}\\,\\mathrm{d}t", "带阻尼的傅里叶变换，适用于初值问题"),
    ("拉普拉斯逆变换", "f(t)=\\frac{1}{2\\pi i}\\int_{\\sigma-i\\infty}^{\\sigma+i\\infty}F(s)\\mathrm{e}^{st}\\,\\mathrm{d}s", "梅林反演公式，可用留数计算"),
    ("单位阶跃的拉氏变换", "L\\{1\\}=\\frac{1}{s}", "最基本的拉普拉斯变换对"),
    ("指数函数的拉氏变换", "L\\{\\mathrm{e}^{at}\\}=\\frac{1}{s-a}", "收敛域 Re s > a"),
    ("幂函数的拉氏变换", "L\\{t^n\\}=\\frac{n!}{s^{n+1}}", "由指数变换对 s 求导得到"),
    ("正弦的拉氏变换", "L\\{\\sin\\omega t\\}=\\frac{\\omega}{s^2+\\omega^2}", "常用振荡信号的变换对"),
    ("拉氏微分性质", "L\\{f'(t)\\}=sF(s)-f(0)", "把初值问题化为代数方程的核心公式"),
    ("拉氏卷积定理", "L\\{f*g\\}=F(s)\\,G(s)", "时域卷积对应象函数乘积"),
    ("终值定理", "\\lim_{t\\to\\infty}f(t)=\\lim_{s\\to0}sF(s)", "由象函数直接读取稳态值"),
    ("一维波动方程", "u_{tt}=a^2u_{xx}", "弦振动方程，a 为波速"),
    ("三维波动方程", "u_{tt}=a^2\\nabla^2u", "声波与电磁波满足的方程"),
    ("热传导方程", "u_t=a^2\\nabla^2u", "扩散型方程，对时间一阶"),
    ("拉普拉斯方程", "\\nabla^2u=0", "稳态椭圆型方程，解为调和函数"),
    ("泊松方程", "\\nabla^2u=-f(\\mathbf{r})", "带源项的稳态方程"),
    ("达朗贝尔公式", "u=\\frac{1}{2}[\\varphi(x-at)+\\varphi(x+at)]+\\frac{1}{2a}\\int_{x-at}^{x+at}\\psi(\\xi)\\,\\mathrm{d}\\xi", "一维波动方程初值问题的解"),
    ("二阶方程判别式", "\\Delta=b^2-ac", "Δ>0 双曲型，Δ=0 抛物型，Δ<0 椭圆型"),
    ("特征方程", "a(\\mathrm{d}y)^2-2b\\,\\mathrm{d}x\\,\\mathrm{d}y+c(\\mathrm{d}x)^2=0", "由特征线把方程化为标准型"),
    ("分离变量", "u(x,t)=X(x)T(t)", "分离时空变量，把偏微分方程化为常微分方程"),
    ("本征值问题", "X''+\\lambda X=0,\\quad X(0)=X(l)=0", "齐次边界条件决定本征值与本征函数"),
    ("斯特姆-刘维尔方程", "\\frac{\\mathrm{d}}{\\mathrm{d}x}\\!\\left[p(x)\\frac{\\mathrm{d}y}{\\mathrm{d}x}\\right]+q(x)y+\\lambda\\rho(x)y=0", "统一描述勒让德、贝塞尔等方程"),
    ("本征函数正交性", "\\int_a^b\\varphi_m(x)\\varphi_n(x)\\rho(x)\\,\\mathrm{d}x=0\\ (m\\ne n)", "不同本征函数按权函数正交"),
    ("热核解", "u(x,t)=\\frac{1}{2a\\sqrt{\\pi t}}\\int_{-\\infty}^{\\infty}f(\\xi)\\mathrm{e}^{-(x-\\xi)^2/(4a^2t)}\\,\\mathrm{d}\\xi", "一维热传导方程初值问题的积分表示"),
    ("格林公式", "\\int_\\Omega(u\\nabla^2v-v\\nabla^2u)\\,\\mathrm{d}V=\\oint_{\\partial\\Omega}\\!\\left(u\\frac{\\partial v}{\\partial n}-v\\frac{\\partial u}{\\partial n}\\right)\\mathrm{d}S", "把体积分化为边面积分"),
    ("格林函数方程", "-\\nabla^2G(\\mathbf{r},\\mathbf{r}')=\\delta(\\mathbf{r}-\\mathbf{r}')", "点源响应，满足齐次边界条件"),
    ("三维基本解", "G=\\frac{1}{4\\pi|\\mathbf{r}-\\mathbf{r}'|}", "拉普拉斯算子的自由空间格林函数"),
    ("泊松积分公式", "u(\\mathbf{r})=\\int_\\Omega G(\\mathbf{r},\\mathbf{r}')f(\\mathbf{r}')\\,\\mathrm{d}V'", "由点源响应叠加得到解的积分表达式"),
    ("欧拉-拉格朗日方程", "\\frac{\\partial L}{\\partial y}-\\frac{\\mathrm{d}}{\\mathrm{d}x}\\!\\left(\\frac{\\partial L}{\\partial y'}\\right)=0", "泛函取极值的必要条件"),
    ("能量泛函", "J[u]=\\frac{1}{2}\\int_\\Omega|\\nabla u|^2\\,\\mathrm{d}V-\\int_\\Omega fu\\,\\mathrm{d}V", "拉普拉斯方程的变分原理（狄利克雷原理）"),
    ("拉普拉斯差分格式", "u_{i+1,j}+u_{i-1,j}+u_{i,j+1}+u_{i,j-1}-4u_{ij}=0", "五点差分格式，离散化拉普拉斯算子"),
    ("热方程稳定性", "r=\\frac{a^2\\Delta t}{(\\Delta x)^2}\\le\\frac{1}{2}", "显式差分格式的稳定性条件"),
    ("勒让德方程", "(1-x^2)y''-2xy'+l(l+1)y=0", "球坐标下分离变量得到的方程"),
    ("罗德里格斯公式", "P_l(x)=\\frac{1}{2^l l!}\\frac{\\mathrm{d}^l}{\\mathrm{d}x^l}(x^2-1)^l", "勒让德多项式的显式表达式"),
    ("勒让德正交性", "\\int_{-1}^{1}P_m(x)P_n(x)\\,\\mathrm{d}x=\\frac{2}{2n+1}\\delta_{mn}", "勒让德多项式的正交归一关系"),
    ("勒让德递推", "(n+1)P_{n+1}(x)=(2n+1)xP_n(x)-nP_{n-1}(x)", "由低阶生成高阶的递推关系"),
    ("连带勒让德方程", "(1-x^2)y''-2xy'+\\left[l(l+1)-\\frac{m^2}{1-x^2}\\right]y=0", "含方位角量子数 m 的推广方程"),
    ("球谐函数", "Y_{lm}(\\theta,\\varphi)=N_{lm}P_l^m(\\cos\\theta)\\mathrm{e}^{im\\varphi}", "球面上的正交完备函数系"),
    ("贝塞尔方程", "x^2y''+xy'+(x^2-n^2)y=0", "柱坐标下分离变量得到的方程"),
    ("贝塞尔函数级数", "J_n(x)=\\sum_{k=0}^{\\infty}\\frac{(-1)^k}{k!\\,\\Gamma(n+k+1)}\\left(\\frac{x}{2}\\right)^{2k+n}", "贝塞尔方程的级数解"),
    ("贝塞尔递推", "\\frac{\\mathrm{d}}{\\mathrm{d}x}[x^nJ_n(x)]=x^nJ_{n-1}(x)", "连接相邻阶贝塞尔函数"),
    ("贝塞尔正交性", "\\int_0^a J_n\\!\\left(\\mu_n^{(i)}\\frac{r}{a}\\right)J_n\\!\\left(\\mu_n^{(j)}\\frac{r}{a}\\right)r\\,\\mathrm{d}r=0\\ (i\\ne j)", "按权 r 正交，用于圆域展开"),
    ("埃尔米特方程", "y''-2xy'+2ny=0", "量子谐振子波函数满足的方程"),
    ("拉盖尔方程", "xy''+(1-x)y'+ny=0", "氢原子径向波函数满足的方程"),
]

def js_escape(s):
    return s.replace("\\","\\\\").replace("`","\\`").replace("${","\\${")
def fix_lt_math(s):
    import re
    return re.sub(r"\$\$[\s\S]*?\$\$|\$[^$\n]*?\$", lambda m: m.group(0).replace("<", "&lt;"), s)
def defn(t, body): return f'<section class="la-kp-sec la-kp-def"><h5>定 义</h5><p><strong>{t}</strong></p>{body}</section>'
def thm(t, body): return f'<section class="la-kp-sec la-kp-thm"><h5>定 理 · {t}</h5>{body}</section>'
def der(body): return f'<section class="la-kp-sec la-kp-der"><h5>推 导</h5>{body}</section>'
def exa(body): return f'<section class="la-kp-sec la-kp-exa"><h5>例 子</h5>{body}</section>'
def app(body): return f'<section class="la-kp-sec la-kp-app"><h5>应 用</h5>{body}</section>'
def note(body): return f'<section class="la-kp-sec la-kp-note"><h5>备 注</h5>{body}</section>'
def fml(latex, caption=""):
    cap = f'<span class="note">{caption}</span>' if caption else ""
    return f'<div class="la-fml">$${latex}$$ {cap}</div>'
def p(txt): return f'<p>{txt}</p>'
def wrap(body): return f'<div class="la-kp">{body}</div>'

ch1_sections = [
{
"name": "1.1 复数与复变函数",
"color": "#2563eb",
"desc": "复数的表示与运算、乘幂方根、复变函数与映射",
"items": [
{"id":"m1s1-1","name":"复数的表示与欧拉公式","tags":["def","der"],"brief":"复数可用点、向量与指数形式统一描述。",
 "fig":"complex_plane","figCap":"复平面上的复数 z=re^{iθ} 及其共轭",
 "body": wrap(
   defn("复数的三种表示",p("复数 $z=x+iy$ 可用有序实数对 $(x,y)$、复平面上的点或向量表示。其模 $|z|=\\sqrt{x^2+y^2}$，辐角 $\\arg z=\\theta$ 的多值性由 $2k\\pi$ 体现，主值取 $(-\\pi,\\pi]$。于是有三角表示与指数表示：")+
   fml("z=r(\\cos\\theta+i\\sin\\theta)=r\\mathrm{e}^{i\\theta}"))+
   der(p("<strong>欧拉公式的导出：</strong>把三个函数展开为泰勒级数：")+
   fml("\\mathrm{e}^{i\\theta}=\\sum_{n=0}^{\\infty}\\frac{(i\\theta)^n}{n!},\\quad \\cos\\theta=\\sum_{n=0}^{\\infty}\\frac{(-1)^n\\theta^{2n}}{(2n)!},\\quad \\sin\\theta=\\sum_{n=0}^{\\infty}\\frac{(-1)^n\\theta^{2n+1}}{(2n+1)!}")+
   p("按 $n$ 的奇偶拆开 $i^n$：偶数项 $i^{2n}=(-1)^n$，奇数项 $i^{2n+1}=(-1)^n i$，于是")+
   fml("\\mathrm{e}^{i\\theta}=\\sum_{n=0}^{\\infty}\\frac{(-1)^n\\theta^{2n}}{(2n)!}+i\\sum_{n=0}^{\\infty}\\frac{(-1)^n\\theta^{2n+1}}{(2n+1)!}=\\cos\\theta+i\\sin\\theta")+
   p("由此得指数的模恒为 $|\\mathrm{e}^{i\\theta}|=1$，指数表示把乘法化为辐角相加。"))+
   note(p("欧拉公式把复指数、三角函数与平面旋转统一起来；令 $\\theta=\\pi$ 即得 $\\mathrm{e}^{i\\pi}+1=0$。"))
 )},
{"id":"m1s1-2","name":"复数的乘幂与方根","tags":["der","exa"],"brief":"棣莫弗公式与 n 次方根的几何分布。",
 "body": wrap(
   exa(p("<strong>例：</strong>求 $(-1)^{1/3}$。因 $-1=\\mathrm{e}^{i\\pi}$，则三个根为")+
   fml("w_k=\\mathrm{e}^{i(\\pi+2k\\pi)/3},\\quad k=0,1,2")+
   p("即 $w_0=\\mathrm{e}^{i\\pi/3}$、$w_1=-1$、$w_2=\\mathrm{e}^{i5\\pi/3}$，均匀分布在单位圆上。")+
   note(p("三个根构成正三角形，这一对称性正是方程根与几何对称联系的体现。")))+
   der(p("<strong>棣莫弗公式的导出：</strong>由指数表示相乘时指数相加：")+
   fml("(r\\mathrm{e}^{i\\theta})^n=r^n\\mathrm{e}^{in\\theta}")+
   p("再写成三角形式即得：")+
   fml("(\\cos\\theta+i\\sin\\theta)^n=\\cos n\\theta+i\\sin n\\theta")+
   p("对开方，令 $w^n=z$，设 $w=\\rho\\mathrm{e}^{i\\varphi}$，则 $\\rho^n=r$、$n\\varphi=\\theta+2k\\pi$，解得")+
   fml("w_k=\\sqrt[n]{r}\\,\\mathrm{e}^{i(\\theta+2k\\pi)/n},\\quad k=0,1,\\dots,n-1")+
   p("$n$ 个根均匀分布在以原点为心、半径 $r^{1/n}$ 的圆上，相邻根辐角差 $2\\pi/n$。"))
 )},
{"id":"m1s1-3","name":"复变函数与映射","tags":["def","der"],"brief":"复变函数把 z 平面映射到 w 平面。",
 "body": wrap(
   defn("复变函数",p("设 $G$ 为复平面上的点集，若对每个 $z\\in G$ 按一定法则有唯一 $w$ 与之对应，则称 $w=f(z)$ 是 $G$ 上的复变函数。$w=f(z)$ 可视为把 $z$ 平面上的点集<strong>映射</strong>到 $w$ 平面。"))+
   der(p("<strong>以 $w=z^2$ 说明映射效果：</strong>令 $z=x+iy$，则")+
   fml("w=z^2=(x^2-y^2)+2ixy=u+iv")+
   p("取平行于虚轴的直线 $z=x_0+iy$，其像满足 $u=x_0^2-y^2$、$v=2x_0y$，消去 $y$ 得")+
   fml("v^2=4x_0^2(x_0^2-u)")+
   p("这是以实轴为对称轴的一族抛物线；同理 $z=x+iy_0$ 的像为另一族抛物线，两族在交点处仍互相正交，说明解析映射的保角性。"))+
   note(p("一般地，解析函数在导数非零处把两族正交曲线仍映为两族正交曲线，称为保角映射。"))
 )},
]},
{
"name": "1.2 极限、连续与导数",
"color": "#3b82f6",
"desc": "复变函数的极限、连续性、导数及方向无关性",
"items": [
{"id":"m1s2-1","name":"复变函数的极限","tags":["def","der"],"brief":"极限存在要求沿任意路径趋近都得到同一值。",
 "body": wrap(
   defn("极限",p("当 $z$ 沿任意路径趋于 $z_0$ 时 $f(z)$ 都趋于同一常数 $A$，则称 $A$ 为 $f(z)$ 当 $z\\to z_0$ 的极限，记 $\\lim_{z\\to z_0}f(z)=A$，等价于 $|f(z)-A|\\to0$。"))+
   der(p("<strong>证明极限路径无关的必要性：</strong>设 $\\lim_{z\\to z_0}f(z)=A$ 且另有一路径给出极限 $B\\ne A$。取 $\\varepsilon=|A-B|/3$，则存在 $\\delta$ 使两条路径上的点都满足 $|f(z)-A|<\\varepsilon$ 与 $|f(z)-B|<\\varepsilon$，于是")+
   fml("|A-B|\\le|f(z)-A|+|f(z)-B|<2\\varepsilon=\\frac{2}{3}|A-B|")+
   p("矛盾，故极限必唯一且与路径无关。"))+
   exa(p("<strong>例：</strong>$f(z)=\\bar z/z$ 在 $z\\to0$ 时无极限。沿实轴 $z=x$ 得 $f=1$，沿虚轴 $z=iy$ 得 $f=-1$：")+
   fml("\\lim_{x\\to0}\\frac{x}{x}=1,\\qquad \\lim_{y\\to0}\\frac{-iy}{iy}=-1")+
   p("两路径极限不同，故极限不存在。"))
 )},
{"id":"m1s2-2","name":"连续性与连续函数的运算","tags":["def","der"],"brief":"连续函数的四则运算仍连续。",
 "body": wrap(
   defn("连续",p("若 $\\lim_{z\\to z_0}f(z)=f(z_0)$，则称 $f(z)$ 在 $z_0$ 连续。区域上处处连续的函数称为连续函数；连续函数的和、差、积、商（分母不为零）仍连续。"))+
   der(p("<strong>证明乘积的连续性：</strong>设 $f$、$g$ 在 $z_0$ 连续，任给 $\\varepsilon>0$。因连续函数在 $z_0$ 附近有界，取 $M=1+\\max(|f(z_0)|,|g(z_0)|)$，存在 $\\delta>0$，当 $|z-z_0|<\\delta$ 时")+
   fml("|f(z)-f(z_0)|<\\frac{\\varepsilon}{2M},\\qquad |g(z)-g(z_0)|<\\frac{\\varepsilon}{2M}")+
   p("于是")+
   fml("|f g-f(z_0)g(z_0)|\\le|f||g-g(z_0)|+|g(z_0)||f-f(z_0)|<\\frac{\\varepsilon}{2}+\\frac{\\varepsilon}{2}=\\varepsilon")+
   p("故乘积 $fg$ 在 $z_0$ 连续。"))+
   note(p("复变函数的连续性与实部、虚部的连续性等价：$f=u+iv$ 连续当且仅当 $u$、$v$ 均连续。"))
 )},
{"id":"m1s2-3","name":"复变函数的导数","tags":["def","der"],"brief":"差商极限存在且与方向无关才可导。",
 "body": wrap(
   defn("导数",p("若极限 $\\lim_{\\Delta z\\to0}\\dfrac{f(z_0+\\Delta z)-f(z_0)}{\\Delta z}$ 存在且与 $\\Delta z\\to0$ 的方式无关，则称 $f$ 在 $z_0$ 可导，该极限记为 $f'(z_0)$。"))+
   der(p("<strong>由定义求 $f(z)=z^2$ 的导数：</strong>计算差商")+
   fml("\\frac{f(z+\\Delta z)-f(z)}{\\Delta z}=\\frac{(z+\\Delta z)^2-z^2}{\\Delta z}=2z+\\Delta z")+
   p("令 $\\Delta z\\to0$ 得 $f'(z)=2z$，结果与 $\\Delta z$ 的趋近路径无关。"))+
   der(p("<strong>再证 $f(z)=\\bar z$ 处处不可导：</strong>差商为")+
   fml("\\frac{\\overline{z+\\Delta z}-\\bar z}{\\Delta z}=\\frac{\\overline{\\Delta z}}{\\Delta z}")+
   p("沿实轴 $\\Delta z=\\Delta x$ 比值为 $1$，沿虚轴 $\\Delta z=i\\Delta y$ 比值为 $-1$，二者不等，故极限不存在，$\\bar z$ 处处不可导。"))+
   note(p("可导性要求差商与方向无关，这是复变函数与实变函数最本质的区别，也直接导致柯西-黎曼条件。"))
 )},
]},
{
"name": "1.3 柯西-黎曼条件与解析函数",
"color": "#1d4ed8",
"desc": "柯西-黎曼条件、解析函数的判定与求导运算",
"items": [
{"id":"m1s3-1","name":"柯西-黎曼条件","tags":["thm","der"],"brief":"可导的必要条件，也是解析性的核心判据。",
 "fig":"cr_condition","figCap":"柯西-黎曼条件：实部与虚部的偏导数相互联系",
 "body": wrap(
   thm("柯西-黎曼条件",p("设 $f(z)=u(x,y)+iv(x,y)$ 在点 $z$ 可导，则 $u$、$v$ 在该点可偏导且满足")+
   fml("\\frac{\\partial u}{\\partial x}=\\frac{\\partial v}{\\partial y},\\qquad \\frac{\\partial u}{\\partial y}=-\\frac{\\partial v}{\\partial x}"))+
   der(p("<strong>证明：</strong>由可导性，差商沿任意方向 $\\Delta z\\to0$ 都有同一极限。先取 $\\Delta z=\\Delta x$ 沿实轴：")+
   fml("f'(z)=\\lim_{\\Delta x\\to0}\\frac{[u(x+\\Delta x,y)-u]+i[v(x+\\Delta x,y)-v]}{\\Delta x}=u_x+iv_x")+
   p("再取 $\\Delta z=i\\Delta y$ 沿虚轴：")+
   fml("f'(z)=\\lim_{\\Delta y\\to0}\\frac{[u(x,y+\\Delta y)-u]+i[v(x,y+\\Delta y)-v]}{i\\Delta y}=\\frac{u_y+iv_y}{i}=v_y-iu_y")+
   p("两式相等，比较实部与虚部即得 $u_x=v_y$、$u_y=-v_x$。"))+
   note(p("C-R 条件是可导的必要条件；若 $u$、$v$ 可微且满足 C-R 条件，则 $f$ 可导，此即充要条件。"))
 )},
{"id":"m1s3-2","name":"解析函数及其判定","tags":["def","der"],"brief":"区域内处处可导的函数为解析函数。",
 "body": wrap(
   defn("解析函数",p("若 $f(z)$ 在 $z_0$ 的某个邻域内处处可导，则称 $f$ 在 $z_0$ 解析；在区域 $D$ 内处处解析则称 $f$ 为 $D$ 上的解析函数（全纯函数）。"))+
   der(p("<strong>证明：区域 $D$ 内 $f'(z)\\equiv0$ 则 $f$ 为常数。</strong>由 $f'=u_x+iv_x=0$ 得 $u_x=v_x=0$；由 C-R 条件又有 $v_y=u_x=0$、$u_y=-v_x=0$，故 $u$、$v$ 的四个一阶偏导全为零，于是")+
   fml("\\mathrm{d}u=u_x\\,\\mathrm{d}x+u_y\\,\\mathrm{d}y=0,\\qquad \\mathrm{d}v=v_x\\,\\mathrm{d}x+v_y\\,\\mathrm{d}y=0")+
   p("在连通的 $D$ 内 $u$、$v$ 均为常数，故 $f$ 为常数。"))+
   note(p("解析性是比可导更强的局部性质：解析函数在邻域内可展开为幂级数，因而具有任意阶导数。"))
 )},
{"id":"m1s3-3","name":"解析函数的导数运算","tags":["der","exa"],"brief":"和差积商与复合仍解析。",
 "body": wrap(
   der(p("<strong>推导乘积与复合求导法则：</strong>设 $f$、$g$ 解析。乘积差商可拆为")+
   fml("\\frac{f(z+\\Delta z)g(z+\\Delta z)-f(z)g(z)}{\\Delta z}=g(z)\\frac{\\Delta f}{\\Delta z}+f(z+\\Delta z)\\frac{\\Delta g}{\\Delta z}")+
   p("令 $\\Delta z\\to0$，利用 $g$ 与 $f$ 的连续性得 $(fg)'=f'g+fg'$。复合函数链式法则同理可得")+
   fml("\\frac{\\mathrm{d}}{\\mathrm{d}z}f(g(z))=f'(g(z))\\,g'(z)"))+
   exa(p("<strong>例：</strong>由乘积法则得 $(z^n)'=nz^{n-1}$，故任意多项式在复平面解析；有理函数除分母零点外解析。指数函数由幂级数定义，处处解析且")+
   fml("(\\mathrm{e}^z)'=\\mathrm{e}^z,\\qquad (\\sin z)'=\\cos z,\\qquad (\\cos z)'=-\\sin z"))+
   note(p("解析函数的和、差、积、商（分母非零）与复合仍解析，构成封闭的函数类。"))
 )},
]},
{
"name": "1.4 调和函数与解析函数的性质",
"color": "#0ea5e9",
"desc": "调和函数、共轭调和函数与保角映射",
"items": [
{"id":"m1s4-1","name":"调和函数","tags":["thm","der"],"brief":"满足拉普拉斯方程的函数，解析函数的实虚部均为调和函数。",
 "body": wrap(
   thm("调和函数",p("若二元函数 $\\varphi(x,y)$ 有二阶连续偏导且满足拉普拉斯方程")+
   fml("\\frac{\\partial^2\\varphi}{\\partial x^2}+\\frac{\\partial^2\\varphi}{\\partial y^2}=0")+
   p("则称 $\\varphi$ 为调和函数。"))+
   der(p("<strong>证明解析函数的实部与虚部都是调和函数：</strong>设 $f=u+iv$ 解析，则 $u$、$v$ 满足 C-R 条件。对 $u_x=v_y$ 关于 $x$ 求导、对 $u_y=-v_x$ 关于 $y$ 求导：")+
   fml("u_{xx}=v_{yx},\\qquad u_{yy}=-v_{xy}")+
   p("因二阶偏导连续有 $v_{yx}=v_{xy}$，两式相加得")+
   fml("u_{xx}+u_{yy}=v_{yx}-v_{xy}=0")+
   p("同理 $v_{xx}+v_{yy}=0$，故 $u$、$v$ 均为调和函数。"))+
   app(p("<strong>应用：</strong>调和函数描述无源区域的静电场势、稳定温度场与不可压缩无旋流动的势函数。"))
 )},
{"id":"m1s4-2","name":"共轭调和函数","tags":["def","der"],"brief":"由调和函数求共轭调和函数构造解析函数。",
 "body": wrap(
   defn("共轭调和函数",p("若 $u$、$v$ 都是调和函数且满足 C-R 条件，则称 $v$ 为 $u$ 的共轭调和函数，此时 $u+iv$ 为解析函数。"))+
   der(p("<strong>由 $u$ 求共轭调和函数 $v$：</strong>由 C-R 条件 $v_y=u_x$、$v_x=-u_y$，取全微分")+
   fml("\\mathrm{d}v=v_x\\,\\mathrm{d}x+v_y\\,\\mathrm{d}y=-u_y\\,\\mathrm{d}x+u_x\\,\\mathrm{d}y")+
   p("该全微分恰当的条件是 $\\partial(-u_y)/\\partial y=\\partial u_x/\\partial x$，即 $u_{xx}+u_{yy}=0$，恰因 $u$ 调和而成立。于是沿任意路径积分得")+
   fml("v(x,y)=\\int_{(x_0,y_0)}^{(x,y)}-u_y\\,\\mathrm{d}x+u_x\\,\\mathrm{d}y+C"))+
   exa(p("<strong>例：</strong>$u=x^2-y^2$ 为调和函数，由 $v_x=-u_y=2y$ 得 $v=2xy+\\varphi(y)$，再由 $v_y=u_x=2x$ 得 $\\varphi'(y)=0$，故 $v=2xy+C$，于是 $u+iv=(x^2-y^2)+2ixy=z^2+C$。"))
 )},
{"id":"m1s4-3","name":"保角映射","tags":["der","app"],"brief":"解析映射在导数非零处保持曲线夹角不变。",
 "fig":"conformal","figCap":"解析映射把正交网格映为正交曲线网（保角）",
 "body": wrap(
   der(p("<strong>证明解析映射的保角性：</strong>设 $f$ 在 $z_0$ 解析且 $f'(z_0)\\ne0$，过 $z_0$ 的两条光滑曲线 $C_1$、$C_2$ 的切向量为 $\\mathrm{d}z_1$、$\\mathrm{d}z_2$，其像曲线在 $w_0=f(z_0)$ 处的切向量为")+
   fml("\\mathrm{d}w_1=f'(z_0)\\,\\mathrm{d}z_1,\\qquad \\mathrm{d}w_2=f'(z_0)\\,\\mathrm{d}z_2")+
   p("两切向量的辐角差为")+
   fml("\\arg\\frac{\\mathrm{d}w_1}{\\mathrm{d}w_2}=\\arg\\frac{\\mathrm{d}z_1}{\\mathrm{d}z_2}")+
   p("即映射前后两曲线的夹角相等（大小与方向均保持），故为保角映射。"))+
   app(p("<strong>应用：</strong>保角映射把复杂区域化为简单区域（如把半平面、圆域、多边形化为上半平面），用于求解平面静电场、热传导与流体问题；儒可夫斯基变换用于机翼绕流分析。"))+
   note(p("保角性要求 $f'(z_0)\\ne0$；在 $f'=0$ 的点映射不再保角，称为临界点。"))
 )},
]},
{
"name": "1.5 复变函数的积分与柯西定理",
"color": "#0284c7",
"desc": "复积分、柯西积分定理与复合闭路定理",
"items": [
{"id":"m1s5-1","name":"复变函数的积分","tags":["def","der"],"brief":"复积分可化为实线积分，1/z 的闭路积分非零。",
 "body": wrap(
   defn("复积分",p("设 $C$ 为复平面上的有向光滑曲线，$f(z)$ 在 $C$ 上连续。把 $C$ 分成 $n$ 段，作和式 $\\sum f(\\zeta_k)\\Delta z_k$，当分割无限加细且极限存在时，定义 $f$ 沿 $C$ 的积分为 $\\int_C f(z)\\,\\mathrm{d}z$。"))+
   der(p("<strong>计算 $\\oint_{|z|=1}z^n\\,\\mathrm{d}z$（$n$ 为整数）：</strong>取参数 $z=\\mathrm{e}^{i\\theta}$，$\\theta$ 从 $0$ 到 $2\\pi$，$\\mathrm{d}z=i\\mathrm{e}^{i\\theta}\\mathrm{d}\\theta$，得")+
   fml("\\oint_{|z|=1}z^n\\,\\mathrm{d}z=\\int_0^{2\\pi}\\mathrm{e}^{in\\theta}i\\mathrm{e}^{i\\theta}\\,\\mathrm{d}\\theta=i\\int_0^{2\\pi}\\mathrm{e}^{i(n+1)\\theta}\\,\\mathrm{d}\\theta")+
   p("当 $n\\ne-1$ 时该积分为 $0$；当 $n=-1$ 时被积函数为 $1$，故")+
   fml("\\oint_{|z|=1}\\frac{\\mathrm{d}z}{z}=2\\pi i"))+
   note(p("该结果是留数理论与柯西积分公式的雏形：只有非解析项 $1/z$ 才能产生非零闭路积分。"))
 )},
{"id":"m1s5-2","name":"柯西积分定理","tags":["thm","der"],"brief":"单连通区域内解析函数的闭路积分为零。",
 "fig":"contour","figCap":"柯西积分定理：C 内解析则闭路积分为零",
 "body": wrap(
   thm("柯西积分定理",p("设 $f(z)$ 在单连通区域 $D$ 内解析，$C$ 为 $D$ 内任意简单闭曲线，则")+
   fml("\\oint_C f(z)\\,\\mathrm{d}z=0"))+
   der(p("<strong>用格林公式证明：</strong>把积分写成实形式")+
   fml("\\oint_C f\\,\\mathrm{d}z=\\oint_C(u\\,\\mathrm{d}x-v\\,\\mathrm{d}y)+i\\oint_C(v\\,\\mathrm{d}x+u\\,\\mathrm{d}y)")+
   p("对第一式用格林公式 $\\oint P\\,\\mathrm{d}x+Q\\,\\mathrm{d}y=\\iint(Q_x-P_y)\\,\\mathrm{d}x\\mathrm{d}y$：")+
   fml("\\oint_C(u\\,\\mathrm{d}x-v\\,\\mathrm{d}y)=\\iint_D\\left(-\\frac{\\partial v}{\\partial x}-\\frac{\\partial u}{\\partial y}\\right)\\mathrm{d}x\\,\\mathrm{d}y=0")+
   p("由 C-R 条件 $u_y=-v_x$ 该被积函数为零；同理第二式由 $v_y=u_x$ 为零，故 $\\oint_C f\\,\\mathrm{d}z=0$。"))+
   app(p("<strong>应用：</strong>解析函数沿区域内的积分只依赖于起点与终点，与路径无关，从而可定义原函数与不定积分。"))
 )},
{"id":"m1s5-3","name":"复合闭路定理与围道变形","tags":["der","app"],"brief":"多连通区域的积分等于各内边界积分之和。",
 "fig":"cauchy_annulus","figCap":"多连通区域：外边界积分等于各内边界积分之和",
 "body": wrap(
   der(p("<strong>证明复合闭路定理：</strong>设 $C$ 为外部简单闭曲线，$C_1,\\dots,C_n$ 为 $C$ 内部互不相交的简单闭曲线，$f$ 在它们所围区域上解析。用割线把区域化为单连通，每条割线被往返经过两次、积分相互抵消，于是")+
   fml("\\oint_C f\\,\\mathrm{d}z=\\sum_{k=1}^{n}\\oint_{C_k} f\\,\\mathrm{d}z")+
   p("这里各 $C_k$ 均取正向。它说明闭路积分只由内部所围奇点决定，围道可连续变形而不改变积分值。"))+
   app(p("<strong>应用：</strong>当被积函数在区域内有个别奇点时，可用小圆代替复杂围道逐点计算，这正是留数定理的思想。"))+
   note(p("多连通区域的柯西定理为 $\\oint_C f\\,\\mathrm{d}z=\\sum_k\\oint_{C_k} f\\,\\mathrm{d}z$，内外边界取向相反。"))
 )},
]},
{
"name": "1.6 柯西积分公式与高阶导数公式",
"color": "#1e40af",
"desc": "柯西积分公式、高阶导数公式、柯西不等式与刘维尔定理",
"items": [
{"id":"m1s6-1","name":"柯西积分公式","tags":["thm","der"],"brief":"解析函数在内部的值由边界值完全确定。",
 "body": wrap(
   thm("柯西积分公式",p("设 $f$ 在简单闭曲线 $C$ 及其内部解析，$a$ 为 $C$ 内任意一点，则")+
   fml("f(a)=\\frac{1}{2\\pi i}\\oint_C\\frac{f(z)}{z-a}\\,\\mathrm{d}z"))+
   der(p("<strong>证明：</strong>被积函数在 $z=a$ 处有奇点。以 $a$ 为心作足够小的圆 $C_\\rho$ 使 $\\rho<\\mathrm{dist}(a,C)$，由复合闭路定理")+
   fml("\\oint_C\\frac{f(z)}{z-a}\\,\\mathrm{d}z=\\oint_{C_\\rho}\\frac{f(z)}{z-a}\\,\\mathrm{d}z")+
   p("在 $C_\\rho$ 上 $z=a+\\rho\\mathrm{e}^{i\\theta}$，代入得")+
   fml("\\oint_{C_\\rho}\\frac{f(z)}{z-a}\\,\\mathrm{d}z=i\\int_0^{2\\pi}f(a+\\rho\\mathrm{e}^{i\\theta})\\,\\mathrm{d}\\theta")+
   p("令 $\\rho\\to0$，由 $f$ 的连续性该积分趋于 $2\\pi i f(a)$，即得公式。"))+
   app(p("<strong>应用：</strong>柯西公式表明解析函数在区域内部的值完全由边界值决定，是解析延拓与边界元方法的基础。"))
 )},
{"id":"m1s6-2","name":"高阶导数公式","tags":["thm","der"],"brief":"解析函数具有任意阶导数。",
 "body": wrap(
   thm("高阶导数公式",p("在柯西公式的条件下，$f$ 在 $a$ 处有任意阶导数，且")+
   fml("f^{(n)}(a)=\\frac{n!}{2\\pi i}\\oint_C\\frac{f(z)}{(z-a)^{n+1}}\\,\\mathrm{d}z"))+
   der(p("<strong>证明（对参数求导）：</strong>把柯西公式视为关于 $a$ 的积分，对 $a$ 求导时可把导数移入积分号：")+
   fml("f'(a)=\\frac{1}{2\\pi i}\\oint_C\\frac{\\partial}{\\partial a}\\!\\left[\\frac{f(z)}{z-a}\\right]\\mathrm{d}z=\\frac{1}{2\\pi i}\\oint_C\\frac{f(z)}{(z-a)^2}\\,\\mathrm{d}z")+
   p("重复 $n$ 次求导，被积核每次多出因子 $1/(z-a)$，并由归纳法可证求导移入积分号的合法性，得到")+
   fml("f^{(n)}(a)=\\frac{n!}{2\\pi i}\\oint_C\\frac{f(z)}{(z-a)^{n+1}}\\,\\mathrm{d}z")+
   p("特别地，解析函数自动具有任意阶导数。"))+
   note(p("这与实变函数形成鲜明对比：实可微函数的导数未必可微，而复解析函数的导数仍解析。"))
 )},
{"id":"m1s6-3","name":"柯西不等式与刘维尔定理","tags":["der","thm"],"brief":"由积分估计得到导数的界与整函数性质。",
 "body": wrap(
   der(p("<strong>证明柯西不等式：</strong>设 $f$ 在 $|z-a|\\le R$ 内解析且 $|f(z)|\\le M$，取 $C$ 为 $|z-a|=R$。由高阶导数公式")+
   fml("|f^{(n)}(a)|=\\frac{n!}{2\\pi}\\left|\\oint_C\\frac{f(z)}{(z-a)^{n+1}}\\,\\mathrm{d}z\\right|\\le\\frac{n!}{2\\pi}\\cdot\\frac{M}{R^{n+1}}\\cdot2\\pi R=\\frac{n!\\,M}{R^n"))+
   thm("刘维尔定理",p("有界整函数必为常数。"))+
   der(p("<strong>证明刘维尔定理：</strong>设 $f$ 在全平面解析且 $|f(z)|\\le M$。对任意点 $a$，由 $n=1$ 的柯西不等式")+
   fml("|f'(a)|\\le\\frac{M}{R}")+
   p("令 $R\\to\\infty$ 得 $f'(a)=0$；由 $a$ 的任意性知 $f'\\equiv0$，故 $f$ 恒为常数。"))+
   app(p("<strong>应用：</strong>刘维尔定理可简洁证明代数基本定理——若 $n$ 次多项式无零点，则 $1/P(z)$ 为有界整函数，必为常数，矛盾。"))
 )},
]},
]

ch2_sections = [
{
"name": "2.1 复数项级数与幂级数",
"color": "#7c3aed",
"desc": "复数项级数、收敛判别、幂级数与收敛半径",
"items": [
{"id":"m2s1-1","name":"复数项级数与收敛判别","tags":["def","der"],"brief":"绝对收敛蕴含收敛。",
 "body": wrap(
   defn("复数项级数",p("设 $z_n$ 为复数列，$\\sum_{n=1}^{\\infty}z_n$ 的部分和 $S_N=\\sum_{n=1}^{N}z_n$。若 $S_N$ 收敛，则称级数收敛；若 $\\sum|z_n|$ 收敛，则称级数绝对收敛。"))+
   der(p("<strong>证明绝对收敛必有收敛：</strong>记 $z_n=x_n+iy_n$，由 $|x_n|\\le|z_n|$、$|y_n|\\le|z_n|$ 知两级数 $\\sum x_n$、$\\sum y_n$ 均绝对收敛，故各自收敛。设它们的部分和分别趋于 $X$、$Y$，则")+
   fml("S_N=\\sum_{n=1}^{N}(x_n+iy_n)\\to X+iY")+
   p("即 $\\sum z_n$ 收敛，且收敛值等于实部级数与虚部级数之和。"))+
   note(p("判别法（比较、比值、根值）由复数模的相应不等式直接移植；绝对收敛的级数可任意重排而和不变。"))
 )},
{"id":"m2s1-2","name":"幂级数与收敛半径","tags":["thm","der"],"brief":"幂级数在收敛圆内绝对收敛、圆外发散。",
 "fig":"convergence_disk","figCap":"收敛圆：半径等于圆心到最近奇点的距离",
 "body": wrap(
   thm("柯西-阿达马公式",p("幂级数 $\\sum a_n(z-z_0)^n$ 的收敛半径由")+
   fml("\\frac{1}{R}=\\limsup_{n\\to\\infty}|a_n|^{1/n}")+
   p("给出：$|z-z_0|<R$ 时绝对收敛，$|z-z_0|>R$ 时发散。"))+
   der(p("<strong>由比值判别导出：</strong>记项 $u_n=a_n(z-z_0)^n$，由比值判别")+
   fml("\\lim_{n\\to\\infty}\\left|\\frac{u_{n+1}}{u_n}\\right|=|z-z_0|\\lim_{n\\to\\infty}\\left|\\frac{a_{n+1}}{a_n}\\right|<1")+
   p("即当 $|z-z_0|<\\lim|a_n/a_{n+1}|$ 时收敛，故收敛半径 $R=\\lim|a_n/a_{n+1}|$（当极限存在时）。"))+
   note(p("阿贝尔定理指出收敛圆内闭一致收敛、可逐项求导与积分；收敛半径等于圆心到最近奇点的距离。"))
 )},
{"id":"m2s1-3","name":"幂级数的系数与解析性","tags":["der","thm"],"brief":"幂级数的和函数在收敛圆内解析。",
 "body": wrap(
   der(p("<strong>推导系数公式：</strong>设 $f(z)=\\sum_{n=0}^{\\infty}a_n(z-z_0)^n$。由幂级数可逐项求导 $n$ 次，每次求导保留 $n!a_n$ 形式的系数，于是")+
   fml("f^{(n)}(z_0)=n!\\,a_n\\ \\Rightarrow\\ a_n=\\frac{f^{(n)}(z_0)}{n!}")+
   p("这说明幂级数的系数由和函数在中心处的各阶导数唯一确定。"))+
   der(p("<strong>和函数解析：</strong>对 $|z-z_0|<R$ 内的点，由系数公式与上一章的高阶导数估计可得幂级数逐项求导后仍收敛，故 $f$ 在收敛圆内无穷可导，即解析。"))+
   exa(p("<strong>例：</strong>$\\sum_{n=0}^{\\infty}\\dfrac{z^n}{n!}=\\mathrm{e}^z$，$\\sum_{n=0}^{\\infty}(-1)^n\\dfrac{z^{2n+1}}{(2n+1)!}=\\sin z$，$\\sum_{n=0}^{\\infty}(-1)^n\\dfrac{z^{2n}}{(2n)!}=\\cos z$，三者收敛半径均为无穷。"))
 )},
]},
{
"name": "2.2 泰勒级数与洛朗级数",
"color": "#8b5cf6",
"desc": "泰勒展开、洛朗展开及其典型例子",
"items": [
{"id":"m2s2-1","name":"泰勒级数","tags":["thm","der"],"brief":"解析函数在圆盘内可展为泰勒级数。",
 "body": wrap(
   thm("泰勒定理",p("设 $f$ 在圆盘 $|z-z_0|<R$ 内解析，则在该圆盘内")+
   fml("f(z)=\\sum_{n=0}^{\\infty}\\frac{f^{(n)}(z_0)}{n!}(z-z_0)^n"))+
   der(p("<strong>证明：</strong>在圆盘内取圆周 $C:|\\zeta-z_0|=\\rho$，$|z-z_0|<\\rho<R$。由柯西积分公式")+
   fml("f(z)=\\frac{1}{2\\pi i}\\oint_C\\frac{f(\\zeta)}{\\zeta-z}\\,\\mathrm{d}\\zeta")+
   p("利用几何级数展开（因 $|z-z_0|/|\\zeta-z_0|<1$）：")+
   fml("\\frac{1}{\\zeta-z}=\\frac{1}{(\\zeta-z_0)-(z-z_0)}=\\sum_{n=0}^{\\infty}\\frac{(z-z_0)^n}{(\\zeta-z_0)^{n+1}}")+
   p("逐项积分并用高阶导数公式即得泰勒展开。"))+
   note(p("泰勒级数的收敛半径等于 $z_0$ 到最近奇点的距离，展开唯一。"))
 )},
{"id":"m2s2-2","name":"洛朗级数","tags":["thm","der"],"brief":"环域内的解析函数可展为双边幂级数。",
 "fig":"laurent_annulus","figCap":"洛朗级数在环域 r 与 R 之间展开",
 "body": wrap(
   thm("洛朗定理",p("设 $f$ 在环域 $r<|z-z_0|<R$ 内解析，则")+
   fml("f(z)=\\sum_{n=-\\infty}^{\\infty}c_n(z-z_0)^n,\\quad c_n=\\frac{1}{2\\pi i}\\oint_C\\frac{f(\\zeta)}{(\\zeta-z_0)^{n+1}}\\,\\mathrm{d}\\zeta"))+
   der(p("<strong>证明思路：</strong>取环域内两条同心圆 $C_1$（内）与 $C_2$（外），对 $z$ 用柯西积分公式并沿多连通围道拆分：")+
   fml("f(z)=\\frac{1}{2\\pi i}\\oint_{C_2}\\frac{f(\\zeta)}{\\zeta-z}\\,\\mathrm{d}\\zeta-\\frac{1}{2\\pi i}\\oint_{C_1}\\frac{f(\\zeta)}{\\zeta-z}\\,\\mathrm{d}\\zeta")+
   p("对第一项用 $|z-z_0|<|\\zeta-z_0|$ 的几何级数展开得非负幂项；对第二项用 $|\\zeta-z_0|<|z-z_0|$ 展开得负幂项，合并即得双边级数。"))+
   note(p("同一函数在不同环域有不同洛朗展开；若 $f$ 在 $z_0$ 解析则洛朗级数退化为泰勒级数。"))
 )},
{"id":"m2s2-3","name":"洛朗展开的典型例子","tags":["exa","der"],"brief":"在奇点附近分环域展开。",
 "body": wrap(
   der(p("<strong>把 $f(z)=\\dfrac{1}{(z-1)(z-2)}$ 在环域中展开：</strong>先作部分分式分解")+
   fml("f(z)=\\frac{1}{z-2}-\\frac{1}{z-1}")+
   p("在第一环域 $1<|z|<2$ 内，$|z|>1$ 时 $\\dfrac{1}{z-1}=\\dfrac1z\\cdot\\dfrac{1}{1-1/z}=\\sum_{n=0}^{\\infty}\\dfrac{1}{z^{n+1}}$；$|z|<2$ 时 $\\dfrac{1}{z-2}=-\\dfrac12\\dfrac{1}{1-z/2}=-\\sum_{n=0}^{\\infty}\\dfrac{z^n}{2^{n+1}}$，故")+
   fml("f(z)=-\\sum_{n=0}^{\\infty}\\frac{z^n}{2^{n+1}}-\\sum_{n=0}^{\\infty}\\frac{1}{z^{n+1}}"))+
   exa(p("<strong>例：</strong>在 $0<|z|<1$ 内展开 $\\dfrac{\\mathrm{e}^z}{z}$，得 $\\dfrac{1}{z}+1+\\dfrac{z}{2}+\\dfrac{z^2}{6}+\\cdots$，可见 $z=0$ 为一阶极点，留数为 $1$。"))
 )},
]},
{
"name": "2.3 孤立奇点的分类",
"color": "#a855f7",
"desc": "可去奇点、极点与本性质奇点",
"items": [
{"id":"m2s3-1","name":"孤立奇点的类型","tags":["def","der"],"brief":"由洛朗展开的主部区分三类奇点。",
 "fig":"singularity_types","figCap":"三类孤立奇点的模随靠近 z₀ 的变化",
 "body": wrap(
   defn("孤立奇点",p("若 $f$ 在 $z_0$ 的某去心邻域内解析，则称 $z_0$ 为孤立奇点。按洛朗展开主部（负幂项）分类：无负幂项为可去奇点；只有有限个负幂项为极点；有无穷多个负幂项为本性奇点。"))+
   der(p("<strong>由展开判定：</strong>设去心邻域内 $f(z)=\\sum_{n=-\\infty}^{\\infty}c_n(z-z_0)^n$。若 $c_{-n}=0\\ (n\\ge1)$，令 $f(z_0)=c_0$ 即得解析延拓，为可去奇点；若 $c_{-m}\\ne0$ 而 $c_{-n}=0\\ (n>m)$，为 $m$ 阶极点；若有无穷多个 $c_{-n}\\ne0$，为本性奇点。"))+
   note(p("映射 $w=1/z$ 可把无穷远点附近的性态化为原点附近的性态，用于讨论 $f(\\infty)$ 的奇点类型。"))
 )},
{"id":"m2s3-2","name":"可去奇点与极点","tags":["thm","der"],"brief":"有界则奇点可去，趋于无穷则为极点。",
 "body": wrap(
   thm("极点判定",p("$z_0$ 为 $f$ 的 $m$ 阶极点当且仅当 $f(z)$ 在 $z_0$ 附近可写为")+
   fml("f(z)=\\frac{\\varphi(z)}{(z-z_0)^m},\\quad \\varphi(z_0)\\ne0,\\ \\varphi\\ \\text{解析}"))+
   der(p("<strong>证明极点与零点的对应：</strong>设 $f=\\dfrac{\\varphi}{(z-z_0)^m}$ 且 $\\varphi(z_0)\\ne0$，则 $\\lim_{z\\to z_0}|f(z)|=\\infty$。反之若 $\\lim|f|=+\\infty$，则 $g=1/f$ 在 $z_0$ 附近有界且解析，$z_0$ 为 $g$ 的零点，设其阶为 $m$，则 $f$ 有 $m$ 阶极点。"))+
   der(p("<strong>可去判据：</strong>若 $f$ 在 $z_0$ 的去心邻域内有界且解析，则洛朗系数满足 $|c_n|\\le M\\rho^{-n}\\to0\\ (\\rho\\to0^+,\\ n<0)$，故所有负幂系数为零，$z_0$ 可去。"))+
   note(p("有限点奇点分类的判据：有界为可去、趋于无穷为极点、既无界又无无穷极限为本性。"))
 )},
{"id":"m2s3-3","name":"本性奇点与皮卡定理","tags":["der","exa"],"brief":"本性奇点附近函数取值稠密。",
 "body": wrap(
   der(p("<strong>以 $\\mathrm{e}^{1/z}$ 为例：</strong>在原点的去心邻域内")+
   fml("\\mathrm{e}^{1/z}=\\sum_{n=0}^{\\infty}\\frac{1}{n!}\\,\\frac{1}{z^n}=1+\\frac1z+\\frac{1}{2z^2}+\\cdots")+
   p("含无穷多个负幂项，故 $z=0$ 为本性奇点。令 $z\\to0$ 沿正实轴得 $\\mathrm{e}^{1/z}\\to+\\infty$，沿负实轴得 $\\to0$，说明极限不存在。"))+
   der(p("<strong>取值稠密性的直观：</strong>对任意 $w\\ne0$，方程 $\\mathrm{e}^{1/z}=w$ 有解 $z=1/(\\ln w+2k\\pi i)$，当 $k\\to\\infty$ 时 $z\\to0$。故 $f$ 在 $z=0$ 的任意小邻域内取到除可能一点外的所有复数值。"))+
   note(p("皮卡大定理：解析函数在本性奇点的任意去心邻域内取遍除至多一个值以外的所有复数值，取值稠密且无穷多次。"))
 )},
]},
{
"name": "2.4 留数定理",
"color": "#9333ea",
"desc": "留数的定义、留数定理与无穷远点留数",
"items": [
{"id":"m2s4-1","name":"留数的定义","tags":["def","der"],"brief":"洛朗展开中 (z-z₀)⁻¹ 项的系数。",
 "body": wrap(
   defn("留数",p("设 $z_0$ 为 $f$ 的孤立奇点，$f$ 在该点去心邻域内的洛朗系数 $c_{-1}$ 称为 $f$ 在 $z_0$ 的留数，记 $\\mathrm{Res}\\,f(z_0)=c_{-1}$。"))+
   der(p("<strong>为何只有 $c_{-1}$ 起作用：</strong>在去心邻域内取小圆 $C:|z-z_0|=\\rho$，逐项积分洛朗级数")+
   fml("\\oint_C f(z)\\,\\mathrm{d}z=\\sum_{n=-\\infty}^{\\infty}c_n\\oint_C(z-z_0)^n\\,\\mathrm{d}z")+
   p("由 $n\\ne-1$ 时 $\\oint(z-z_0)^n\\mathrm{d}z=0$、$n=-1$ 时为 $2\\pi i$，故")+
   fml("\\oint_C f(z)\\,\\mathrm{d}z=2\\pi i\\,c_{-1}=2\\pi i\\,\\mathrm{Res}\\,f(z_0)"))+
   note(p("留数刻画了奇点处 $1/(z-z_0)$ 型项的强度，是围道积分的唯一来源。"))
 )},
{"id":"m2s4-2","name":"留数定理","tags":["thm","der"],"brief":"闭路积分等于内部各留数之和的 2πi 倍。",
 "fig":"residue_pole","figCap":"留数定理：围道积分由内部极点留数决定",
 "body": wrap(
   thm("留数定理",p("设 $f$ 在简单闭曲线 $C$ 所围区域 D 内除有限个孤立奇点 $z_1,\\dots,z_n$ 外解析，且在 $C$ 上解析，则")+
   fml("\\oint_C f(z)\\,\\mathrm{d}z=2\\pi i\\sum_{k=1}^{n}\\mathrm{Res}\\,f(z_k)"))+
   der(p("<strong>证明：</strong>以每个奇点 $z_k$ 为心作互不相交的小圆 $C_k$，使它们都在 $D$ 内。由复合闭路定理")+
   fml("\\oint_C f\\,\\mathrm{d}z=\\sum_{k=1}^{n}\\oint_{C_k} f\\,\\mathrm{d}z")+
   p("对每个 $C_k$，由留数定义 $\\oint_{C_k}f\\,\\mathrm{d}z=2\\pi i\\,\\mathrm{Res}\\,f(z_k)$，代入即得定理。"))+
   app(p("<strong>应用：</strong>留数定理把围道积分化为一组代数计算（求留数），是计算实积分、求和与解微分方程的有力工具。"))
 )},
{"id":"m2s4-3","name":"无穷远点的留数","tags":["der","thm"],"brief":"全部有限留数与无穷远点留数之和为零。",
 "body": wrap(
   der(p("<strong>定义与计算：</strong>设 $f$ 在无穷远点邻域 $|z|>R$ 解析，定义")+
   fml("\\mathrm{Res}\\,f(\\infty)=-c_{-1},\\quad f(z)=\\sum_{n=-\\infty}^{\\infty}c_nz^n\\ (|z|>R)")+
   p("负号来自无穷远点处围道取逆时针为正的相反定向。对包含所有有限奇点的大圆 $C_R$ 用留数定理，得留数总和公式")+
   fml("\\sum_{k=1}^{n}\\mathrm{Res}\\,f(z_k)+\\mathrm{Res}\\,f(\\infty)=0")+
   p("即复平面上全部留数之和为零。"))+
   exa(p("<strong>例：</strong>对 $f(z)=\\dfrac{1}{z^2+1}$，$z=\\pm i$ 处留数分别为 $\\mp\\dfrac{i}{2}$，和为 $0$，故 $\\mathrm{Res}\\,f(\\infty)=0$。"))+
   note(p("当有限奇点很多或计算量大时，可用无穷远点留数反求有限留数之和。"))
 )},
]},
{
"name": "2.5 留数的计算与类型",
"color": "#6d28d9",
"desc": "一阶极点、高阶极点与本性质奇点的留数求法",
"items": [
{"id":"m2s5-1","name":"一阶极点的留数","tags":["der","exa"],"brief":"用极限公式快速求一阶极点留数。",
 "body": wrap(
   der(p("<strong>推导：</strong>设 $z_0$ 为 $f$ 的一阶极点，则洛朗展开为")+
   fml("f(z)=\\frac{c_{-1}}{z-z_0}+c_0+c_1(z-z_0)+\\cdots")+
   p("两边乘以 $(z-z_0)$ 并令 $z\\to z_0$，其余项均趋于零，得")+
   fml("\\mathrm{Res}\\,f(z_0)=c_{-1}=\\lim_{z\\to z_0}(z-z_0)f(z)"))+
   der(p("<strong>有理函数特例：</strong>若 $f=P/Q$，$Q(z_0)=0$、$Q'(z_0)\\ne0$、$P(z_0)\\ne0$，则")+
   fml("\\mathrm{Res}\\,f(z_0)=\\lim_{z\\to z_0}\\frac{(z-z_0)P(z)}{Q(z)}=\\frac{P(z_0)}{Q'(z_0)}"))+
   exa(p("<strong>例：</strong>$f=\\dfrac{\\mathrm{e}^{iz}}{z^2+1}$ 在 $z=i$ 处，$Q'=2z$，故 $\\mathrm{Res}=\\dfrac{\\mathrm{e}^{-1}}{2i}$。"))
 )},
{"id":"m2s5-2","name":"高阶极点的留数","tags":["der"],"brief":"用求导极限公式处理 m 阶极点。",
 "body": wrap(
   der(p("<strong>推导：</strong>设 $z_0$ 为 $m$ 阶极点，则")+
   fml("f(z)=\\frac{c_{-m}}{(z-z_0)^m}+\\cdots+\\frac{c_{-1}}{z-z_0}+c_0+\\cdots")+
   p("两边乘以 $(z-z_0)^m$ 得解析函数 $g(z)=c_{-m}+\\cdots+c_{-1}(z-z_0)^{m-1}+\\cdots$。对 $g$ 求 $m-1$ 阶导数并取 $z\\to z_0$：")+
   fml("g^{(m-1)}(z_0)=(m-1)!\\,c_{-1}")+
   p("故")+
   fml("\\mathrm{Res}\\,f(z_0)=\\frac{1}{(m-1)!}\\lim_{z\\to z_0}\\frac{\\mathrm{d}^{m-1}}{\\mathrm{d}z^{m-1}}\\left[(z-z_0)^m f(z)\\right]"))+
   note(p("一阶极点公式是高阶公式 $m=1$ 的特例；$m$ 越大求导越繁，有时直接洛朗展开更简便。"))
 )},
{"id":"m2s5-3","name":"本性奇点的留数","tags":["der","exa"],"brief":"本性奇点留数须由洛朗展开读出。",
 "body": wrap(
   der(p("<strong>方法：</strong>本性奇点没有有限的极点阶数，必须直接求洛朗展开中 $1/(z-z_0)$ 项的系数。"))+
   exa(p("<strong>例：</strong>求 $f(z)=\\dfrac{\\mathrm{e}^{z}}{z^4}$ 在 $z=0$ 的留数。展开")+
   fml("\\frac{\\mathrm{e}^z}{z^4}=\\frac{1}{z^4}\\left(1+z+\\frac{z^2}{2}+\\frac{z^3}{6}+\\cdots\\right)=\\frac{1}{z^4}+\\frac{1}{z^3}+\\frac{1}{2z^2}+\\frac{1}{6z}+\\cdots")+
   p("故 $c_{-1}=\\dfrac16$，即 $\\mathrm{Res}\\,f(0)=\\dfrac16$。"))+
   exa(p("<strong>例：</strong>$f(z)=\\sin\\dfrac1z$ 的展开 $\\sum_{n=0}^{\\infty}\\dfrac{(-1)^n}{(2n+1)!}\\,\\dfrac{1}{z^{2n+1}}$ 中无 $1/z$ 项，故 $\\mathrm{Res}\\,f(0)=0$。"))+
   note(p("本性奇点处留数可为零，这与极点必 $c_{-1}\\ne0$（一阶）不同。"))
 )},
]},
{
"name": "2.6 利用留数计算实积分",
"color": "#5b21b6",
"desc": "三角函数有理式、有理函数与含指数函数积分的留数法",
"items": [
{"id":"m2s6-1","name":"三角函数有理式积分","tags":["der","exa"],"brief":"令 z=e^{iθ} 化为单位圆上的留数。",
 "body": wrap(
   der(p("<strong>方法推导：</strong>计算 $I=\\int_0^{2\\pi}R(\\cos\\theta,\\sin\\theta)\\,\\mathrm{d}\\theta$，$R$ 为有理函数。令 $z=\\mathrm{e}^{i\\theta}$，则")+
   fml("\\cos\\theta=\\frac{z+z^{-1}}{2},\\quad \\sin\\theta=\\frac{z-z^{-1}}{2i},\\quad \\mathrm{d}\\theta=\\frac{\\mathrm{d}z}{iz}")+
   p("积分化为单位圆 $|z|=1$ 上的围道积分")+
   fml("I=\\oint_{|z|=1}R\\!\\left(\\frac{z+z^{-1}}{2},\\frac{z-z^{-1}}{2i}\\right)\\frac{\\mathrm{d}z}{iz}=2\\pi i\\sum_{|z_k|<1}\\mathrm{Res}"))+
   exa(p("<strong>例：</strong>$\\int_0^{2\\pi}\\dfrac{\\mathrm{d}\\theta}{2+\\cos\\theta}=\\dfrac{2\\pi}{\\sqrt3}$，计算时被积函数化为 $\\dfrac{2}{i(z^2+4z+1)}$，在单位圆内只有极点 $z=-2+\\sqrt3$。"))
 )},
{"id":"m2s6-2","name":"有理函数的无穷积分","tags":["der","exa"],"brief":"用上半平面围道与留数计算实轴积分。",
 "body": wrap(
   der(p("<strong>方法：</strong>计算 $I=\\int_{-\\infty}^{\\infty}\\dfrac{P(x)}{Q(x)}\\,\\mathrm{d}x$，其中 $Q$ 的次数至少比 $P$ 高两次且 $Q$ 无实零点。取上半平面大围道：实轴 $[-R,R]$ 加大半圆 $C_R$。由 $|f(z)|=O(|z|^{-2})$ 得")+
   fml("\\left|\\int_{C_R} f(z)\\,\\mathrm{d}z\\right|\\le\\pi R\\cdot\\frac{M}{R^2}\\to0")+
   p("令 $R\\to\\infty$，积分化为上半平面留数之和：")+
   fml("I=2\\pi i\\sum_{\\mathrm{Im}\\,z_k>0}\\mathrm{Res}\\,f(z_k)"))+
   exa(p("<strong>例：</strong>$\\int_{-\\infty}^{\\infty}\\dfrac{\\mathrm{d}x}{1+x^2}=\\pi$，被积函数在上半平面只有极点 $z=i$，留数为 $\\dfrac{1}{2i}$，故积分等于 $2\\pi i\\cdot\\dfrac1{2i}=\\pi$。"))
 )},
{"id":"m2s6-3","name":"含指数函数的积分与约当引理","tags":["der"],"brief":"用约当引理处理振荡型积分。",
 "body": wrap(
   der(p("<strong>约当引理：</strong>设 $f$ 在上半平面 $|z|\\to\\infty$ 时一致趋于零，$a>0$，则")+
   fml("\\lim_{R\\to\\infty}\\int_{C_R}f(z)\\mathrm{e}^{iaz}\\,\\mathrm{d}z=0")+
   p("证明要点：在 $C_R$ 上 $z=R\\mathrm{e}^{i\\theta}$，$|\\mathrm{e}^{iaz}|=\\mathrm{e}^{-aR\\sin\\theta}$，利用 $\\sin\\theta\\ge\\dfrac{2}{\\pi}\\theta$ 得衰减因子，积分被 $\\dfrac{\\pi}{a}(1-\\mathrm{e}^{-aR})\\max|f|$ 控制而趋于零。"))+
   exa(p("<strong>例：</strong>计算 $\\int_{-\\infty}^{\\infty}\\dfrac{\\cos ax}{x^2+1}\\,\\mathrm{d}x$。取 $f(z)=\\dfrac{\\mathrm{e}^{iaz}}{z^2+1}$，留数 $=\\dfrac{\\mathrm{e}^{-a}}{2i}$，故积分为 $\\pi\\mathrm{e}^{-a}$，分别取实部即得余弦积分。"))+
   note(p("约当引理使 $\\int f(x)\\cos ax\\,\\mathrm{d}x$、$\\int f(x)\\sin ax\\,\\mathrm{d}x$ 型积分可用留数法计算，是傅里叶变换的重要工具。"))
 )},
]},
]

ch3_sections = [
{
"name": "3.1 傅里叶级数",
"color": "#0d9488",
"desc": "周期函数的三角级数、收敛性与复数形式",
"items": [
{"id":"m3s1-1","name":"周期函数的傅里叶级数","tags":["thm","der"],"brief":"用正弦余弦的完备正交系展开周期函数。",
 "body": wrap(
   thm("傅里叶级数",p("设 $f(x)$ 以 $2l$ 为周期且在 $[-l,l]$ 上可积，则")+
   fml("f(x)=\\frac{a_0}{2}+\\sum_{n=1}^{\\infty}\\left(a_n\\cos\\frac{n\\pi x}{l}+b_n\\sin\\frac{n\\pi x}{l}\\right)"))+
   der(p("<strong>系数公式的推导：</strong>利用三角函数系的正交性")+
   fml("\\int_{-l}^{l}\\cos\\frac{m\\pi x}{l}\\cos\\frac{n\\pi x}{l}\\,\\mathrm{d}x=l\\delta_{mn},\\quad \\int_{-l}^{l}\\sin\\frac{m\\pi x}{l}\\sin\\frac{n\\pi x}{l}\\,\\mathrm{d}x=l\\delta_{mn}")+
   p("对级数两边同乘 $\\cos\\frac{n\\pi x}{l}$ 并在 $[-l,l]$ 上积分，除第 $n$ 项外全部消去，得")+
   fml("a_n=\\frac{1}{l}\\int_{-l}^{l}f(x)\\cos\\frac{n\\pi x}{l}\\,\\mathrm{d}x,\\qquad b_n=\\frac{1}{l}\\int_{-l}^{l}f(x)\\sin\\frac{n\\pi x}{l}\\,\\mathrm{d}x")+
   p("同法同乘 $1$ 积分的 $a_0$ 公式与上式 $n=0$ 一致。"))+
   note(p("傅里叶级数把周期信号分解为不同频率的简谐分量，是频谱分析的起点。"))
 )},
{"id":"m3s1-2","name":"收敛性与狄利克雷条件","tags":["der","thm"],"brief":"分段光滑函数的傅里叶级数收敛于中点值。",
 "body": wrap(
   der(p("<strong>狄利克雷收敛定理：</strong>若 $f$ 在 $[-l,l]$ 上分段光滑（每点左右导数存在），则其傅里叶级数在连续点收敛于 $f(x)$，在间断点 $x_0$ 收敛于左右极限的平均值")+
   fml("\\frac{f(x_0^-)+f(x_0^+)}{2}")+
   p("证明要点：把部分和写成狄利克雷核的卷积，利用 $\\dfrac{\\sin(n+\\frac12)t}{2\\sin(t/2)}$ 的积分性质，把误差分解为连续点与跳跃点两部分的衰减估计，再由黎曼引理知余项趋于零。"))+
   exa(p("<strong>例：</strong>方波 $f(x)=\\mathrm{sgn}(x)\\ (|x|<\\pi)$ 的级数为 $\\dfrac{4}{\\pi}\\sum_{k=0}^{\\infty}\\dfrac{\\sin(2k+1)x}{2k+1}$，间断点 $x=0$ 处收敛于 $0$，恰为左右极限 $\\pm1$ 的平均。"))+
   note(p("由间断点收敛值可导出许多级数求和公式，如令 $x=\\pi/2$ 得莱布尼茨级数 $\\sum(-1)^k/(2k+1)=\\pi/4$。"))
 )},
{"id":"m3s1-3","name":"复数形式的傅里叶级数","tags":["der"],"brief":"用复指数统一正余弦项。",
 "fig":"fourier_spectrum","figCap":"周期信号的离散频谱：方波对应 sinc 型包络",
 "body": wrap(
   der(p("<strong>由三角形式导出复数形式：</strong>由欧拉公式")+
   fml("\\cos n\\omega x=\\frac{\\mathrm{e}^{in\\omega x}+\\mathrm{e}^{-in\\omega x}}{2},\\qquad \\sin n\\omega x=\\frac{\\mathrm{e}^{in\\omega x}-\\mathrm{e}^{-in\\omega x}}{2i}")+
   p("代入三角级数并合并同频项（$\\omega=\\pi/l$），得")+
   fml("f(x)=\\sum_{n=-\\infty}^{\\infty}c_n\\mathrm{e}^{in\\omega x},\\qquad c_n=\\frac{1}{2l}\\int_{-l}^{l}f(x)\\mathrm{e}^{-in\\omega x}\\,\\mathrm{d}x")+
   p("其中 $c_0=a_0/2$，$c_n=\\frac{a_n-ib_n}{2}$、$c_{-n}=\\frac{a_n+ib_n}{2}$。"))+
   note(p("复数形式的系数 $c_n$ 直接给出离散频谱的幅度与相位，为傅里叶变换提供统一框架。"))
 )},
]},
{
"name": "3.2 傅里叶变换",
"color": "#14b8a6",
"desc": "傅里叶积分定理、傅里叶变换与常见变换对",
"items": [
{"id":"m3s2-1","name":"傅里叶积分定理","tags":["der","thm"],"brief":"非周期函数由连续频谱叠加而成。",
 "body": wrap(
   der(p("<strong>从傅里叶级数过渡到积分：</strong>把 $f$ 视为周期 $2l\\to\\infty$ 的极限。频率间隔 $\\Delta\\omega=\\pi/l\\to0$，离散频率 $n\\omega$ 变为连续变量 $\\omega$。把 $c_n$ 代入复数级数：")+
   fml("f(x)=\\sum_{n=-\\infty}^{\\infty}\\left[\\frac{1}{2l}\\int_{-l}^{l}f(\\xi)\\mathrm{e}^{-in\\omega\\xi}\\,\\mathrm{d}\\xi\\right]\\mathrm{e}^{in\\omega x}")+
   p("利用 $2l=\\dfrac{2\\pi}{\\Delta\\omega}$ 把求和化为对 $\\omega$ 的黎曼和，令 $\\Delta\\omega\\to0$ 得")+
   fml("f(x)=\\frac{1}{2\\pi}\\int_{-\\infty}^{\\infty}\\!\\!\\int_{-\\infty}^{\\infty}f(\\xi)\\mathrm{e}^{i\\omega(x-\\xi)}\\,\\mathrm{d}\\xi\\,\\mathrm{d}\\omega"))+
   note(p("该式即傅里叶积分定理，要求 $f$ 在 $(-\\infty,\\infty)$ 上绝对可积且分段光滑。"))
 )},
{"id":"m3s2-2","name":"傅里叶变换及其逆变换","tags":["def","der"],"brief":"时域与频域之间的互为变换。",
 "fig":"fourier_pair","figCap":"傅里叶变换对：时域脉冲与频域谱一一对应",
 "body": wrap(
   defn("傅里叶变换",p("定义变换与逆变换为")+
   fml("F(\\omega)=\\int_{-\\infty}^{\\infty}f(t)\\mathrm{e}^{-i\\omega t}\\,\\mathrm{d}t,\\qquad f(t)=\\frac{1}{2\\pi}\\int_{-\\infty}^{\\infty}F(\\omega)\\mathrm{e}^{i\\omega t}\\,\\mathrm{d}\\omega"))+
   der(p("<strong>方脉冲的频谱：</strong>设 $f(t)=1\\ (|t|<a)$、$0\\ (|t|>a)$，则")+
   fml("F(\\omega)=\\int_{-a}^{a}\\mathrm{e}^{-i\\omega t}\\,\\mathrm{d}t=\\frac{\\mathrm{e}^{i\\omega a}-\\mathrm{e}^{-i\\omega a}}{i\\omega}=\\frac{2\\sin\\omega a}{\\omega}")+
   p("可见时域越窄（$a$ 越小），频域谱越宽；$a\\to0$ 时 $F(\\omega)\\to$ 常数，对应 $\\delta$ 函数的均匀谱。"))+
   note(p("傅里叶变换把微分、卷积等运算化为频域的乘法，是求解线性偏微分方程的通用工具。"))
 )},
{"id":"m3s2-3","name":"常见函数的傅里叶变换","tags":["der","exa"],"brief":"高斯函数与 δ 函数的变换。",
 "body": wrap(
   der(p("<strong>高斯函数：</strong>设 $f(t)=\\mathrm{e}^{-at^2}$，对其求导并配方：")+
   fml("F'(\\omega)=\\int_{-\\infty}^{\\infty}(-it)\\mathrm{e}^{-at^2}\\mathrm{e}^{-i\\omega t}\\,\\mathrm{d}t=\\frac{i}{2a}\\int_{-\\infty}^{\\infty}\\frac{\\mathrm{d}}{\\mathrm{d}t}\\left[\\mathrm{e}^{-at^2}\\right]\\mathrm{e}^{-i\\omega t}\\,\\mathrm{d}t")+
   p("分部积分后用变换本身的定义得微分方程 $F'(\\omega)=-\\dfrac{\\omega}{2a}F(\\omega)$，解得")+
   fml("F(\\omega)=\\sqrt{\\frac{\\pi}{a}}\\,\\mathrm{e}^{-\\omega^2/(4a)}"))+
   exa(p("<strong>例：</strong>$\\mathcal{F}\\{\\delta(t)\\}=1$，$\\mathcal{F}\\{1\\}=2\\pi\\delta(\\omega)$，$\\mathcal{F}\\{\\mathrm{e}^{i\\omega_0t}\\}=2\\pi\\delta(\\omega-\\omega_0)$，体现了时频对偶性。"))+
   note(p("高斯函数是变换的不动点（形状不变），这使高斯脉冲在信号与量子力学中有特殊地位。"))
 )},
]},
{
"name": "3.3 傅里叶变换的性质",
"color": "#0f766e",
"desc": "线性、位移、尺度、微分、卷积与帕塞瓦尔定理",
"items": [
{"id":"m3s3-1","name":"线性、位移与尺度性质","tags":["der"],"brief":"时域平移对应频域线性相位。",
 "body": wrap(
   der(p("<strong>位移性质：</strong>设 $\\mathcal{F}\\{f(t)\\}=F(\\omega)$，则")+
   fml("\\mathcal{F}\\{f(t-t_0)\\}=\\int_{-\\infty}^{\\infty}f(t-t_0)\\mathrm{e}^{-i\\omega t}\\,\\mathrm{d}t")+
   p("令 $u=t-t_0$，得")+
   fml("=\\mathrm{e}^{-i\\omega t_0}\\int_{-\\infty}^{\\infty}f(u)\\mathrm{e}^{-i\\omega u}\\,\\mathrm{d}u=F(\\omega)\\mathrm{e}^{-i\\omega t_0}"))+
   der(p("<strong>尺度性质：</strong>令 $u=at$，则")+
   fml("\\mathcal{F}\\{f(at)\\}=\\int_{-\\infty}^{\\infty}f(at)\\mathrm{e}^{-i\\omega t}\\,\\mathrm{d}t=\\frac{1}{|a|}\\int_{-\\infty}^{\\infty}f(u)\\mathrm{e}^{-i\\omega u/a}\\,\\mathrm{d}u=\\frac{1}{|a|}F\\!\\left(\\frac{\\omega}{a}\\right)")+
   p("时域压缩（$|a|>1$）对应频域展宽，体现测不准关系式的形式。"))+
   note(p("线性性质 $\\mathcal{F}\\{\\alpha f+\\beta g\\}=\\alpha F+\\beta G$ 由积分的线性直接得到。"))
 )},
{"id":"m3s3-2","name":"微分与积分性质","tags":["der"],"brief":"时域求导等价于频域乘 iω。",
 "body": wrap(
   der(p("<strong>微分性质：</strong>对逆变换求导")+
   fml("f'(t)=\\frac{1}{2\\pi}\\int_{-\\infty}^{\\infty}F(\\omega)(i\\omega)\\mathrm{e}^{i\\omega t}\\,\\mathrm{d}\\omega")+
   p("比较即得 $\\mathcal{F}\\{f'(t)\\}=i\\omega F(\\omega)$。反复应用得")+
   fml("\\mathcal{F}\\{f^{(n)}(t)\\}=(i\\omega)^n F(\\omega)"))+
   der(p("<strong>积分性质：</strong>设 $g(t)=\\int_{-\\infty}^{t}f(\\tau)\\,\\mathrm{d}\\tau$，则 $g'(t)=f(t)$。由微分性质 $i\\omega G(\\omega)=F(\\omega)$，故")+
   fml("G(\\omega)=\\frac{F(\\omega)}{i\\omega}+\\pi F(0)\\delta(\\omega)"))+
   note(p("正是这些性质把常系数线性微分方程化为 $F(\\omega)$ 的代数方程，便于求解。"))
 )},
{"id":"m3s3-3","name":"卷积定理与帕塞瓦尔定理","tags":["der","thm"],"brief":"时域卷积对应频域乘积，能量守恒。",
 "fig":"convolution","figCap":"卷积定理：时域卷积等于频域相乘",
 "body": wrap(
   defn("卷积",p("两函数 $f$、$g$ 的卷积定义为 $(f*g)(t)=\\int_{-\\infty}^{\\infty}f(\\tau)g(t-\\tau)\\,\\mathrm{d}\\tau$。"))+
   der(p("<strong>卷积定理：</strong>")+
   fml("\\mathcal{F}\\{f*g\\}=\\int_{-\\infty}^{\\infty}\\!\\!\\int_{-\\infty}^{\\infty}f(\\tau)g(t-\\tau)\\mathrm{e}^{-i\\omega t}\\,\\mathrm{d}\\tau\\,\\mathrm{d}t")+
   p("令 $u=t-\\tau$，变量分离为两个积分之积：")+
   fml("=\\int_{-\\infty}^{\\infty}f(\\tau)\\mathrm{e}^{-i\\omega\\tau}\\,\\mathrm{d}\\tau\\int_{-\\infty}^{\\infty}g(u)\\mathrm{e}^{-i\\omega u}\\,\\mathrm{d}u=F(\\omega)G(\\omega)"))+
   der(p("<strong>帕塞瓦尔定理：</strong>由卷积定理与变换定义可得")+
   fml("\\int_{-\\infty}^{\\infty}|f(t)|^2\\,\\mathrm{d}t=\\frac{1}{2\\pi}\\int_{-\\infty}^{\\infty}|F(\\omega)|^2\\,\\mathrm{d}\\omega")+
   p("它表明信号的总能量在时域与频域中一致，$|F(\\omega)|^2$ 即能量谱密度。"))+
   app(p("<strong>应用：</strong>卷积定理把滤波器的作用化为频域乘法，是傅里叶光学（空间滤波）与信号处理的共同基础。"))
 )},
]},
{
"name": "3.4 拉普拉斯变换",
"color": "#059669",
"desc": "拉普拉斯变换的定义、收敛域与常用变换对",
"items": [
{"id":"m3s4-1","name":"拉普拉斯变换的定义与收敛域","tags":["def","der"],"brief":"对傅里叶变换加阻尼，适用于初值问题。",
 "fig":"laplace_region","figCap":"拉普拉斯变换的收敛域 Re s > σ₀",
 "body": wrap(
   defn("拉普拉斯变换",p("设 $f(t)$ 在 $t\\ge0$ 上有定义，定义")+
   fml("L\\{f\\}(s)=\\int_0^{\\infty}f(t)\\mathrm{e}^{-st}\\,\\mathrm{d}t")+
   p("使积分收敛的 $s$ 的集合称为收敛域。"))+
   der(p("<strong>与傅里叶变换的关系：</strong>傅里叶变换要求 $f$ 绝对可积，对增长型函数失效。引入阻尼因子 $\\mathrm{e}^{-\\sigma t}$：")+
   fml("\\int_0^{\\infty}f(t)\\mathrm{e}^{-\\sigma t}\\mathrm{e}^{-i\\omega t}\\,\\mathrm{d}t=\\int_0^{\\infty}f(t)\\mathrm{e}^{-(\\sigma+i\\omega)t}\\,\\mathrm{d}t=F(\\sigma+i\\omega)")+
   p("令复变量 $s=\\sigma+i\\omega$ 即得拉普拉斯变换。若 $|f(t)|\\le M\\mathrm{e}^{\\sigma_0t}$，则当 $\\mathrm{Re}\\,s>\\sigma_0$ 时积分绝对收敛，故收敛域为右半平面。"))+
   note(p("拉普拉斯变换同时含 $t\\ge0$ 的初值信息，特别适合求解带初始条件的微分方程。"))
 )},
{"id":"m3s4-2","name":"常用函数的拉普拉斯变换","tags":["der","exa"],"brief":"阶跃、指数、幂函数与三角函数。",
 "body": wrap(
   der(p("<strong>基本变换对：</strong>由定义直接计算")+
   fml("L\\{1\\}=\\int_0^{\\infty}\\mathrm{e}^{-st}\\,\\mathrm{d}t=\\frac1s,\\qquad L\\{\\mathrm{e}^{at}\\}=\\int_0^{\\infty}\\mathrm{e}^{-(s-a)t}\\,\\mathrm{d}t=\\frac{1}{s-a}")+
   p("对 $L\\{1\\}=\\dfrac1s$ 关于 $s$ 求导 $n$ 次：")+
   fml("\\frac{\\mathrm{d}^n}{\\mathrm{d}s^n}\\frac1s=\\frac{(-1)^nn!}{s^{n+1}}=L\\{(-t)^n\\}")+
   p("故 $L\\{t^n\\}=\\dfrac{n!}{s^{n+1}}$。"))+
   exa(p("<strong>例：</strong>由欧拉公式 $L\\{\\sin\\omega t\\}=\\dfrac{\\omega}{s^2+\\omega^2}$，$L\\{\\cos\\omega t\\}=\\dfrac{s}{s^2+\\omega^2}$；$L\\{\\delta(t)\\}=1$。"))+
   note(p("拉氏变换表中每一条变换对都可由定义或基本性质推出，无需重复积分。"))
 )},
{"id":"m3s4-3","name":"拉普拉斯变换的存在条件","tags":["der","thm"],"brief":"指数阶函数在右半平面收敛。",
 "body": wrap(
   thm("存在定理",p("若 $f(t)$ 在 $t\\ge0$ 上分段连续且满足指数阶条件 $|f(t)|\\le M\\mathrm{e}^{\\sigma_0t}$，则 $L\\{f\\}(s)$ 在 $\\mathrm{Re}\\,s>\\sigma_0$ 内存在且解析。"))+
   der(p("<strong>证明收敛：</strong>对 $\\mathrm{Re}\\,s=\\sigma>\\sigma_0$，")+
   fml("\\left|\\int_0^{\\infty}f(t)\\mathrm{e}^{-st}\\,\\mathrm{d}t\\right|\\le\\int_0^{\\infty}M\\mathrm{e}^{-(\\sigma-\\sigma_0)t}\\,\\mathrm{d}t=\\frac{M}{\\sigma-\\sigma_0}<\\infty")+
   p("故积分绝对收敛。进一步可对 $s$ 求导并在积分号下交换次序，说明 $F(s)$ 在收敛半平面内解析。"))+
   note(p("指数阶条件排除了增长过快的函数（如 $\\mathrm{e}^{t^2}$）；分段连续允许有限个跳跃间断点。"))
 )},
]},
{
"name": "3.5 拉普拉斯变换的性质与逆变换",
"color": "#0f766e",
"desc": "位移、微分、卷积性质、逆变换与留数法",
"items": [
{"id":"m3s5-1","name":"位移、微分与积分性质","tags":["der"],"brief":"初值通过微分性质进入象函数。",
 "body": wrap(
   der(p("<strong>微分性质：</strong>由分部积分")+
   fml("L\\{f'\\}=\\int_0^{\\infty}f'(t)\\mathrm{e}^{-st}\\,\\mathrm{d}t=\\left[f\\mathrm{e}^{-st}\\right]_0^{\\infty}+s\\int_0^{\\infty}f\\mathrm{e}^{-st}\\,\\mathrm{d}t=sF(s)-f(0)")+
   p("反复应用得")+
   fml("L\\{f^{(n)}\\}=s^nF(s)-s^{n-1}f(0)-\\cdots-f^{(n-1)}(0)"))+
   der(p("<strong>位移性质：</strong>对 $s$ 平移 $L\\{\\mathrm{e}^{at}f(t)\\}=\\int_0^{\\infty}f(t)\\mathrm{e}^{-(s-a)t}\\,\\mathrm{d}t=F(s-a)$；对 $t$ 延迟")+
   fml("L\\{f(t-t_0)u(t-t_0)\\}=\\mathrm{e}^{-st_0}F(s)"))+
   note(p("延迟性质解释了纯延迟环节产生 $\\mathrm{e}^{-st_0}$ 因子，是系统分析中产生相位滞后的原因。"))
 )},
{"id":"m3s5-2","name":"卷积定理与初值终值定理","tags":["der","thm"],"brief":"时域卷积化为象函数乘积。",
 "body": wrap(
   der(p("<strong>卷积定理：</strong>定义 $(f*g)(t)=\\int_0^tf(\\tau)g(t-\\tau)\\,\\mathrm{d}\\tau$，交换积分次序：")+
   fml("L\\{f*g\\}=\\int_0^{\\infty}\\!\\!\\int_0^{t}f(\\tau)g(t-\\tau)\\mathrm{e}^{-st}\\,\\mathrm{d}\\tau\\,\\mathrm{d}t=\\int_0^{\\infty}f(\\tau)\\mathrm{e}^{-s\\tau}\\,\\mathrm{d}\\tau\\int_0^{\\infty}g(u)\\mathrm{e}^{-su}\\,\\mathrm{d}u")+
   p("即 $L\\{f*g\\}=F(s)G(s)$。"))+
   der(p("<strong>初值终值定理：</strong>由微分性质 $L\\{f'\\}=sF(s)-f(0)$，令 $s\\to\\infty$ 得 $sF(s)\\to f(0)$；令 $s\\to0$ 得 $\\lim_{t\\to\\infty}f(t)=\\lim_{s\\to0}sF(s)$。"))+
   note(p("初值终值定理无需反演即可读出系统的初态与稳态响应，在控制工程中广泛使用。"))
 )},
{"id":"m3s5-3","name":"逆变换与留数法","tags":["der","exa"],"brief":"用部分分式或围道留数求原函数。",
 "body": wrap(
   der(p("<strong>由梅林反演公式与留数：</strong>逆变换定义为 Bromwich 积分")+
   fml("f(t)=\\frac{1}{2\\pi i}\\int_{\\sigma-i\\infty}^{\\sigma+i\\infty}F(s)\\mathrm{e}^{st}\\,\\mathrm{d}s")+
   p("把围道补成左半平面的大半圆，当 $F(s)\\mathrm{e}^{st}\\to0$ 时可用留数定理：")+
   fml("f(t)=\\sum_{k}\\mathrm{Res}\\left[F(s)\\mathrm{e}^{st}\\right]_{s=s_k}"))+
   exa(p("<strong>例：</strong>求 $F(s)=\\dfrac{1}{s(s+1)}$ 的原函数。部分分式 $\\dfrac1s-\\dfrac{1}{s+1}$，故 $f(t)=1-\\mathrm{e}^{-t}\\ (t\\ge0)$；用留数法结果相同。"))+
   note(p("若 $F(s)=P(s)/Q(s)$ 且 $Q$ 的零点为 $s_k$，可写成 $\\sum\\dfrac{P(s_k)}{Q'(s_k)}\\mathrm{e}^{s_kt}$，即赫维赛德展开。"))
 )},
]},
{
"name": "3.6 积分变换的应用",
"color": "#115e59",
"desc": "解常微分方程、传递函数与偏微分方程",
"items": [
{"id":"m3s6-1","name":"用拉普拉斯变换解常微分方程","tags":["der","exa"],"brief":"把微分方程化为代数方程。",
 "body": wrap(
   der(p("<strong>一般步骤：</strong>对线性常系数方程 $a y''+by'+cy=f(t)$ 两边作拉氏变换，利用微分性质把初值 $y(0)$、$y'(0)$ 纳入：")+
   fml("(as^2+bs+c)Y(s)=F(s)+a\\,s\\,y(0)+a\\,y'(0)+b\\,y(0)")+
   p("解出 $Y(s)$ 后再反演得 $y(t)$。"))+
   exa(p("<strong>例：</strong>解 $y''+y=1$，$y(0)=y'(0)=0$。变换得 $Y(s)=\\dfrac{1}{s(s^2+1)}=\\dfrac1s-\\dfrac{s}{s^2+1}$，故 $y(t)=1-\\cos t$。"))+
   note(p("初值问题在拉氏变换下自动被包含，无需先求通解再定常数，这是它优于傅里叶变换之处。"))
 )},
{"id":"m3s6-2","name":"传递函数与系统响应","tags":["der","app"],"brief":"零初值下输出与输入的象函数之比。",
 "body": wrap(
   defn("传递函数",p("对线性时不变系统，零初值条件下定义传递函数")+
   fml("H(s)=\\frac{Y(s)}{F(s)}=\\frac{b_ms^m+\\cdots+b_0}{a_ns^n+\\cdots+a_0}"))+
   der(p("<strong>由卷积表示响应：</strong>由卷积定理 $Y(s)=H(s)F(s)$，反演得")+
   fml("y(t)=\\int_0^{t}h(t-\\tau)f(\\tau)\\,\\mathrm{d}\\tau,\\qquad h(t)=L^{-1}\\{H(s)\\}")+
   p("$h(t)$ 为冲激响应。系统稳定的充要条件是 $H(s)$ 的全部极点位于左半平面 $\\mathrm{Re}\\,s<0$，此时 $h(t)\\to0$。"))+
   app(p("<strong>应用：</strong>传递函数是控制理论与电路分析的核心，可分析频率响应 $H(i\\omega)$、增益裕度与相位裕度。"))
 )},
{"id":"m3s6-3","name":"用变换法解偏微分方程","tags":["der","app"],"brief":"对空间或时间变量作变换降维。",
 "body": wrap(
   der(p("<strong>热传导方程初值问题：</strong>解 $u_t=a^2u_{xx}$，$u(x,0)=f(x)$。对 $x$ 作傅里叶变换，令 $U(\\omega,t)=\\mathcal{F}\\{u\\}$，方程化为")+
   fml("\\frac{\\partial U}{\\partial t}=-a^2\\omega^2U\\ \\Rightarrow\\ U(\\omega,t)=F(\\omega)\\mathrm{e}^{-a^2\\omega^2t}")+
   p("由 $\\mathcal{F}\\{\\mathrm{e}^{-x^2/(4a^2t)}\\}\\propto\\mathrm{e}^{-a^2\\omega^2t}$ 及卷积定理，逆变换得高斯积分形式解")+
   fml("u(x,t)=\\frac{1}{2a\\sqrt{\\pi t}}\\int_{-\\infty}^{\\infty}f(\\xi)\\mathrm{e}^{-(x-\\xi)^2/(4a^2t)}\\,\\mathrm{d}\\xi"))+
   app(p("<strong>应用：</strong>积分变换法可处理无界或半无界区域问题；对时间作拉氏变换可处理有界区域的初边值问题，把偏微分方程降为常微分方程。"))
 )},
]},
]

ch4_sections = [
{
"name": "4.1 数学物理方程的导出",
"color": "#c2410c",
"desc": "从物理守恒律导出波动、热传导与拉普拉斯方程",
"items": [
{"id":"m4s1-1","name":"波动方程的导出","tags":["der"],"brief":"由弦元受力分析得到一维波动方程。",
 "fig":"wave_string","figCap":"弦的微元受力：张力恢复力驱动横振动",
 "body": wrap(
   der(p("<strong>弦的微元分析：</strong>设弦线密度为 $\\rho$、张力为 $T$，作微小横振动 $u(x,t)$。取 $[x,x+\\mathrm{d}x]$ 一小段，质量 $\\rho\\,\\mathrm{d}x$，两端张力在横向的分量为")+
   fml("T\\sin\\theta_2-T\\sin\\theta_1\\approx T(u_x|_{x+\\mathrm{d}x}-u_x|_x)=T\\,u_{xx}\\,\\mathrm{d}x")+
   p("由牛顿第二定律，横向合力等于质量乘加速度：")+
   fml("T\\,u_{xx}\\,\\mathrm{d}x=\\rho\\,\\mathrm{d}x\\,u_{tt}\\ \\Rightarrow\\ u_{tt}=a^2u_{xx},\\quad a=\\sqrt{\\frac{T}{\\rho}}"))+
   note(p("若弦上还有外力或弦很重（考虑竖直方向重力），方程右端应加上源项 $f(x,t)$，成为非齐次波动方程，波速 $a$ 由介质性质决定。"))
 )},
{"id":"m4s1-2","name":"热传导方程的导出","tags":["der"],"brief":"由能量守恒与傅里叶定律导出扩散方程。",
 "fig":"heat_rod","figCap":"细杆的热传导：热流由高温流向低温",
 "body": wrap(
   der(p("<strong>能量守恒分析：</strong>取细杆上 $[x,x+\\mathrm{d}x]$ 一段。由傅里叶定律，热流密度 $q=-k u_x$（$k$ 为导热系数，$u$ 为温度）。单位时间流入与流出之差为")+
   fml("q(x,t)-q(x+\\mathrm{d}x,t)=-q_x\\,\\mathrm{d}x=k\\,u_{xx}\\,\\mathrm{d}x")+
   p("该净热量使微元升温，由热平衡 $c\\rho u_t\\,\\mathrm{d}x=k\\,u_{xx}\\,\\mathrm{d}x$ 得")+
   fml("u_t=a^2u_{xx},\\quad a^2=\\frac{k}{c\\rho}")+
   p("其中 $c$ 为比热、$\\rho$ 为密度。三维情形为 $u_t=a^2\\nabla^2u$。"))+
   note(p("若内部有热源 $f(x,t)$，方程右端加 $f$；热传导方程对时间一阶，故只需一个初始条件。"))
 )},
{"id":"m4s1-3","name":"拉普拉斯方程的导出","tags":["der"],"brief":"稳态场满足的椭圆型方程。",
 "body": wrap(
   der(p("<strong>由热传导方程取稳态：</strong>当温度不随时间变化（$u_t=0$）时，热传导方程化为")+
   fml("\\nabla^2u=0")+
   p("即拉普拉斯方程，其解称为调和函数。"))+
   der(p("<strong>由高斯定律导出静电场势：</strong>无源区域 $\\nabla\\cdot\\mathbf{E}=0$，而 $\\mathbf{E}=-\\nabla\\varphi$，代入得")+
   fml("\\nabla\\cdot(-\\nabla\\varphi)=-\\nabla^2\\varphi=0")+
   p("即电势满足拉普拉斯方程；若区域内有电荷分布（体密度 $\\rho_e$），则 $\\nabla^2\\varphi=-\\rho_e/\\varepsilon_0$，为泊松方程。"))+
   app(p("<strong>应用：</strong>拉普拉斯方程描述稳态温度场、无源静电场、理想流体无旋流动与薄膜平衡形状等一大类稳态问题。"))
 )},
]},
{
"name": "4.2 三类典型方程",
"color": "#ea580c",
"desc": "波动方程、热传导方程与拉普拉斯方程的结构与物理意义",
"items": [
{"id":"m4s2-1","name":"波动方程","tags":["def","der"],"brief":"双曲型方程，描述可逆的波动传播。",
 "body": wrap(
   defn("波动方程",p("三维齐次波动方程为")+
   fml("u_{tt}=a^2\\nabla^2u")+
   p("它对时间二阶，描述波的传播；$a$ 为波速，边界与初始条件共同决定解。"))+
   der(p("<strong>解的传播特征：</strong>作自变量变换 $\\xi=x-at$、$\\eta=x+at$，则一维波动方程化为")+
   fml("\\frac{\\partial^2u}{\\partial\\xi\\partial\\eta}=0")+
   p("积分得通解 $u=f(\\xi)+g(\\eta)=f(x-at)+g(x+at)$，其中 $f$、$g$ 为任意二次可微函数，分别代表右行波与左行波。"))+
   note(p("波动方程具有有限传播速度 $a$，解在一点的取值只依赖于初值的影响锥；时间反演下形式不变，故过程可逆。"))
 )},
{"id":"m4s2-2","name":"热传导方程","tags":["der","def"],"brief":"抛物型方程，描述不可逆的扩散过程。",
 "body": wrap(
   defn("热传导方程",p("三维热传导方程为")+
   fml("u_t=a^2\\nabla^2u+f")+
   p("对时间一阶、对空间二阶，描述扩散型不可逆过程。"))+
   der(p("<strong>不可逆性：</strong>设 $f=0$，考虑能量泛函 $E(t)=\\dfrac12\\int u^2\\,\\mathrm{d}V$，则")+
   fml("\\frac{\\mathrm{d}E}{\\mathrm{d}t}=\\int u u_t\\,\\mathrm{d}V=a^2\\int u\\nabla^2u\\,\\mathrm{d}V=-a^2\\int|\\nabla u|^2\\,\\mathrm{d}V\\le0")+
   p("能量随时间单调减小，故过程不可逆，解具有光滑化效应。"))+
   note(p("热传导方程的传播速度为无限（任一时刻全空间都有响应），这与波动方程的有限传播速度形成对比。"))
 )},
{"id":"m4s2-3","name":"泊松方程与拉普拉斯方程","tags":["der","thm"],"brief":"稳态椭圆型方程及其基本解。",
 "body": wrap(
   der(p("<strong>泊松方程的基本解：</strong>考虑球对称情形 $-\\nabla^2G=\\delta(\\mathbf{r})$。在 $r\\ne0$ 处方程为 $\\nabla^2G=0$，其球对称解为 $G=C/r$。对小球体积分并用散度定理：")+
   fml("\\int_{|\\mathbf{r}|<\\epsilon}-\\nabla^2G\\,\\mathrm{d}V=-\\oint_{\\partial}\\frac{\\partial G}{\\partial n}\\,\\mathrm{d}S=1")+
   p("代入 $G=C/r$ 得 $-4\\pi C=1$，故 $G=\\dfrac{1}{4\\pi r}$。"))+
   der(p("<strong>泊松方程的特解：</strong>由叠加原理，源分布 $f$ 产生的解为")+
   fml("u(\\mathbf{r})=\\int\\frac{f(\\mathbf{r}')}{4\\pi|\\mathbf{r}-\\mathbf{r}'|}\\,\\mathrm{d}V'"))+
   note(p("拉普拉斯方程是泊松方程 $f=0$ 的特例；其解在区域内部不能取极值（极值原理），只有边界值决定内部解。"))
 )},
]},
{
"name": "4.3 定解条件与定解问题",
"color": "#d97706",
"desc": "初始条件、三类边界条件与定解问题的适定性",
"items": [
{"id":"m4s3-1","name":"初始条件","tags":["def","der"],"brief":"方程对时间阶数决定初始条件的个数。",
 "body": wrap(
   defn("初始条件",p("初始条件给出 $t=0$ 时刻的状态。波动方程对时间二阶，需要两个初始条件 $u(x,0)=\\varphi(x)$、$u_t(x,0)=\\psi(x)$；热传导方程对时间一阶，只需一个 $u(x,0)=f(x)$。"))+
   der(p("<strong>为何阶数决定个数：</strong>考察常微分方程 $y^{(n)}=F(x,y,\\dots,y^{(n-1)})$ 的初值问题，通解含 $n$ 个任意常数，须由 $n$ 个初始条件唯一确定。偏微分方程按时间方向的阶数同理：波动方程 $u_{tt}$ 含 $\\varphi$、$\\psi$ 两个任意函数（分别对应位移与速度），热方程 $u_t$ 只含 $f$ 一个。"))+
   note(p("物理上，波动需要初位移和初速度两个信息，扩散只需初始温度分布，正与方程的时间阶数对应。"))
 )},
{"id":"m4s3-2","name":"边界条件（三类）","tags":["def","der"],"brief":"直接、导数与混合三类边界条件。",
 "fig":"boundary_conditions","figCap":"三类边界条件：给定函数值、法向导数或二者线性组合",
 "body": wrap(
   defn("三类边界条件",p("在边界 $\\partial\\Omega$ 上：第一类（狄利克雷）给定 $u|_{\\partial\\Omega}=g$；第二类（诺伊曼）给定法向导数 $\\partial u/\\partial n|_{\\partial\\Omega}=h$；第三类（罗宾）给定 $\\left(\\partial u/\\partial n+\\sigma u\\right)|_{\\partial\\Omega}=q$。"))+
   der(p("<strong>第三类条件的来源：</strong>若边界与温度为 $u_0$ 的环境按牛顿冷却定律换热，则单位面积散热正比于温差 $u-u_0$，由能量守恒边界处流出热流等于换热热流：")+
   fml("-k\\frac{\\partial u}{\\partial n}=H(u-u_0)\\ \\Rightarrow\\ \\frac{\\partial u}{\\partial n}+\\frac{H}{k}u=\\frac{H}{k}u_0")+
   p("即 $\\sigma=H/k$、$q=Hu_0/k$ 的第三类条件；$H\\to0$ 退化为第二类（绝热），$H\\to\\infty$ 退化为第一类。"))+
   note(p("边界条件要与方程共同构成定解问题；方程、初始条件与边界条件三者缺一不可。"))
 )},
{"id":"m4s3-3","name":"定解问题与适定性","tags":["der","exa"],"brief":"存在、唯一、稳定三要素。",
 "body": wrap(
   defn("适定性",p("一个定解问题若满足：解存在、解唯一、解对定解数据连续依赖（稳定），则称它是适定的。"))+
   der(p("<strong>稳定性的重要性：</strong>设 $u_1$、$u_2$ 是同一方程对应微小不同数据 $(\\varphi_1,\\psi_1)$ 与 $(\\varphi_2,\\psi_2)$ 的解。令 $w=u_1-u_2$，则 $w$ 满足齐次方程与齐次定解条件。由能量估计可得")+
   fml("\\|w(\\cdot,t)\\|\\le C\\left(\\|\\varphi_1-\\varphi_2\\|+\\|\\psi_1-\\psi_2\\|\\right)")+
   p("即数据的小扰动只引起解的小变化，说明解稳定；不满足此性质的问题为不适定，数值求解时极易发散。"))+
   note(p("拉普拉斯方程的柯西问题是不适定的典型例子：边界上微小的扰动会使解发生巨大变化。"))
 )},
]},
{
"name": "4.4 二阶线性偏微分方程的分类",
"color": "#b45309",
"desc": "特征线、判别式与三类方程的比较",
"items": [
{"id":"m4s4-1","name":"二阶线性方程与特征线","tags":["der"],"brief":"用特征方程把方程化为标准型。",
 "body": wrap(
   der(p("<strong>化简思路：</strong>考虑二阶线性方程")+
   fml("A u_{xx}+2B u_{xy}+C u_{yy}+\\cdots=0")+
   p("作自变量变换 $\\xi=\\xi(x,y)$、$\\eta=\\eta(x,y)$，二阶项的系数按链式法则变换。为使新方程中 $u_{\\xi\\xi}$ 或 $u_{\\eta\\eta}$ 项消失，令变换满足特征方程")+
   fml("A y'^2-2B y'+C=0")+
   p("即 $\\dfrac{\\mathrm{d}y}{\\mathrm{d}x}=\\dfrac{B\\pm\\sqrt{B^2-AC}}{A}$，其解曲线称为特征线，沿特征线才能把方程化为标准型。"))+
   note(p("特征线的实数性由判别式 $\\Delta=B^2-AC$ 决定，直接导致方程的三类分类。"))
 )},
{"id":"m4s4-2","name":"方程分类判据","tags":["thm","der"],"brief":"由判别式符号分为双曲、抛物、椭圆三类。",
 "fig":"characteristics","figCap":"按判别式符号划分为双曲型、抛物型与椭圆型",
 "body": wrap(
   thm("分类定理",p("对方程 $Au_{xx}+2Bu_{xy}+Cu_{yy}+\\cdots=0$，令 $\\Delta=B^2-AC$，在变换下 $\\Delta$ 的符号不变。当 $\\Delta>0$ 为双曲型，$\\Delta=0$ 为抛物型，$\\Delta<0$ 为椭圆型。"))+
   der(p("<strong>证明判别式不变：</strong>设新变量下二阶项系数为 $A'$、$B'$、$C'$，由链式法则")+
   fml("A'=A\\xi_x^2+2B\\xi_x\\xi_y+C\\xi_y^2,\\quad B'=A\\xi_x\\eta_x+B(\\xi_x\\eta_y+\\xi_y\\eta_x)+C\\xi_y\\eta_y")+
   p("把 $A'$、$B'$、$C'$ 代入 $B'^2-A'C'$，一切交叉项恰好抵消，得到")+
   fml("B'^2-A'C'=(B^2-AC)\\,(\\xi_x\\eta_y-\\xi_y\\eta_x)^2")+
   p("即 $\\Delta'=\\Delta\\cdot J^2$，符号由 $\\Delta$ 保持，故分类是方程的内在性质，与坐标系无关。"))+
   note(p("一维波动方程 $\\Delta>0$ 双曲型、热传导方程 $\\Delta=0$ 抛物型、拉普拉斯方程 $\\Delta<0$ 椭圆型。"))
 )},
{"id":"m4s4-3","name":"三类方程的比较","tags":["der","app"],"brief":"从解的性质比较三类方程的差异。",
 "body": wrap(
   der(p("<strong>从标准型看差异：</strong>双曲型方程经特征变换化为 $u_{\\xi\\eta}=\\cdots$，其解由两族特征线携带信息，传播速度有限；抛物型化为 $u_\\eta=u_{\\xi\\xi}+\\cdots$，信息沿单向瞬时报导、过程不可逆；椭圆型化为 $u_{\\xi\\xi}+u_{\\eta\\eta}=\\cdots$，无实特征线，内部处处受边界影响，无传播方向。"))+
   der(p("<strong>定解条件的差异：</strong>双曲型（波动）需要给定 $t=0$ 的两个初值并配边界条件，为初值-边值问题；抛物型（热传导）只需一个初值；椭圆型（拉普拉斯）则只提边界条件，不提初值。这正与各自的时间阶数和信息传播方式相对应。"))+
   note(p("超定或欠定的定解条件会导致问题不适定，例如给拉普拉斯方程提两个边界条件通常无解。"))
 )},
]},
{
"name": "4.5 叠加原理与定解问题的适定性",
"color": "#9a3412",
"desc": "线性叠加、齐次化原理与能量法唯一性",
"items": [
{"id":"m4s5-1","name":"叠加原理","tags":["thm","der"],"brief":"线性方程的解可线性叠加。",
 "body": wrap(
   thm("叠加原理",p("若 $u_1,\\dots,u_n$ 分别是线性定解问题对应源项 $f_1,\\dots,f_n$ 的解，则 $u=\\sum c_i u_i$ 是对应源项 $\\sum c_i f_i$ 的解。"))+
   der(p("<strong>证明：</strong>设算子 $L$ 为线性偏微分算子，$Lu_i=f_i$。由 $L$ 的线性")+
   fml("L\\!\\left(\\sum_ic_iu_i\\right)=\\sum_ic_iLu_i=\\sum_ic_if_i")+
   p("若各 $u_i$ 还满足齐次定解条件，则线性组合也满足，故叠加原理适用于齐次定解问题。"))+
   app(p("<strong>应用：</strong>叠加原理把复杂源分解为简单源之和（如把初始条件展开为傅里叶级数），逐项求解后相加，是分离变量法与格林函数法的理论基础。"))
 )},
{"id":"m4s5-2","name":"齐次化原理（杜哈梅原理）","tags":["der"],"brief":"把非齐次源化为一系列齐次初值问题。",
 "body": wrap(
   der(p("<strong>推导：</strong>考虑非齐次波动方程 $u_{tt}=a^2u_{xx}+f(x,t)$，零初值。把 $f$ 视为在时刻 $\\tau$ 施加的瞬时冲量。设 $w(x,t;\\tau)$ 是齐次方程以 $\\tau$ 时刻初速度分布 $f(x,\\tau)$ 为数据的解，则由冲量叠加")+
   fml("u(x,t)=\\int_0^t w(x,t-\\tau;\\tau)\\,\\mathrm{d}\\tau")+
   p("验证：对 $t$ 求导两次，前一次导数给出被积函数在 $t$ 处的值，恰补出源项 $f(x,t)$，故组合式满足原方程。"))+
   note(p("杜哈梅原理把含源问题化为一系列齐次问题，使分离变量法与达朗贝尔公式都能处理非齐次方程。"))
 )},
{"id":"m4s5-3","name":"能量法与解的唯一性","tags":["der","thm"],"brief":"用能量守恒证明波动方程初边值问题解唯一。",
 "body": wrap(
   thm("唯一性定理",p("波动方程初边值问题的解在适当函数类中唯一。"))+
   der(p("<strong>用能量法证明：</strong>设 $u_1$、$u_2$ 为同一定解问题的两个解，令 $w=u_1-u_2$，则 $w$ 满足齐次方程、零初值、齐次边界。定义能量")+
   fml("E(t)=\\frac12\\int_0^l\\left(\\rho w_t^2+Tw_x^2\\right)\\mathrm{d}x\\ge0")+
   p("对时间求导并用分部积分与方程 $\\rho w_{tt}=Tw_{xx}$：")+
   fml("\\frac{\\mathrm{d}E}{\\mathrm{d}t}=\\int_0^l(\\rho w_tw_{tt}+Tw_xw_{xt})\\,\\mathrm{d}x=\\left[Tw_xw_t\\right]_0^l=0")+
   p("（边界项由齐次边界条件为零）。故 $E(t)=E(0)=0$，从而 $w_t=w_x=0$，$w$ 为常数；再由零初值 $w\\equiv0$，即 $u_1=u_2$，解唯一。"))+
   note(p("能量法是研究适定性的有力工具，也可用于热传导方程（能量单调下降）与证明稳定性。"))
 )},
]},
]

ch5_sections = [
{
"name": "5.1 分离变量法",
"color": "#be185d",
"desc": "分离变量思想、本征值问题与非齐次问题的本征函数展开",
"items": [
{"id":"m5s1-1","name":"分离变量法的基本思想","tags":["der"],"brief":"把偏微分方程分解为若干常微分方程。",
 "fig":"separation_vars","figCap":"分离变量得到的各阶本征模式叠加成解",
 "body": wrap(
   der(p("<strong>以两端固定弦的振动为例：</strong>解 $u_{tt}=a^2u_{xx}$，边界 $u(0,t)=u(l,t)=0$。设 $u(x,t)=X(x)T(t)$，代入方程：")+
   fml("X T''=a^2X''T\\ \\Rightarrow\\ \\frac{T''}{a^2T}=\\frac{X''}{X}")+
   p("左端只含 $t$、右端只含 $x$，故两边只能等于同一常数，记为 $-\\lambda$：")+
   fml("X''+\\lambda X=0,\\qquad T''+a^2\\lambda T=0")+
   p("由此把偏微分方程化为两个常微分方程，前者连同边界条件构成本征值问题。"))+
   note(p("分离变量的前提是方程与边界条件均为齐次；非齐次情形须先齐次化或采用本征函数展开。"))
 )},
{"id":"m5s1-2","name":"齐次边界条件下的本征值问题","tags":["thm","der"],"brief":"本征值与正交本征函数系。",
 "fig":"eigenfunction_expansion","figCap":"本征值 λₙ 与对应正交本征函数",
 "body": wrap(
   thm("本征值问题",p("边值问题 $X''+\\lambda X=0$，$X(0)=X(l)=0$ 有非平凡解当且仅当")+
   fml("\\lambda_n=\\left(\\frac{n\\pi}{l}\\right)^2,\\quad X_n(x)=\\sin\\frac{n\\pi}{l}x,\\quad n=1,2,\\dots"))+
   der(p("<strong>求解：</strong>当 $\\lambda=\\beta^2>0$ 时 $X=A\\cos\\beta x+B\\sin\\beta x$。由 $X(0)=A=0$，再由 $X(l)=B\\sin\\beta l=0$ 且 $B\\ne0$ 得 $\\sin\\beta l=0$，故 $\\beta=n\\pi/l$。当 $\\lambda\\le0$ 时只有零解，舍去。"))+
   der(p("<strong>正交性：</strong>对 $n\\ne m$，用 $X_m$ 乘 $X_n$ 的方程减去 $X_n$ 乘 $X_m$ 的方程并积分：")+
   fml("(\\lambda_n-\\lambda_m)\\int_0^lX_mX_n\\,\\mathrm{d}x=\\left[X_m'X_n-X_n'X_m\\right]_0^l=0")+
   p("因 $\\lambda_n\\ne\\lambda_m$，故 $\\int_0^lX_mX_n\\,\\mathrm{d}x=0$，本征函数系正交。"))+
   note(p("一般的斯特姆-刘维尔问题 $(py')'+qy+\\lambda\\rho y=0$ 均保证本征值可数、实、趋于无穷，本征函数按权 $\\rho$ 正交完备。"))
 )},
{"id":"m5s1-3","name":"非齐次问题与本征函数展开","tags":["der"],"brief":"用正交本征函数系展开任意给定函数。",
 "body": wrap(
   der(p("<strong>本征函数展开：</strong>设 $\\{X_n\\}$ 为完备正交系，任意满足边界条件的 $f(x)$ 可展开为")+
   fml("f(x)=\\sum_{n=1}^{\\infty}f_nX_n(x),\\qquad f_n=\\frac{\\int_0^lfX_n\\,\\mathrm{d}x}{\\int_0^lX_n^2\\,\\mathrm{d}x}")+
   p("把解设为 $u(x,t)=\\sum T_n(t)X_n(x)$，代入非齐次方程 $u_t-u_{xx}=f(x,t)$，利用 $X_n''=-\\lambda_nX_n$ 得")+
   fml("T_n'(t)+\\lambda_nT_n(t)=f_n(t)")+
   p("于是每个 $T_n$ 满足一个一阶常微分方程，可逐项解出，再把各本征模式叠加即得原问题的解。"))+
   exa(p("<strong>例：</strong>两端固定弦受分布力 $f(x,t)=A\\sin\\dfrac{\\pi x}{l}$，只需 $n=1$ 的模式；解出 $T_1$ 即得响应。"))+
   note(p("本征函数展开法把无穷维问题化为可数个独立的一维问题，是分离变量法处理非齐次问题的核心技巧。"))
 )},
]},
{
"name": "5.2 行波法与达朗贝尔公式",
"color": "#db2777",
"desc": "一维波动方程通解、达朗贝尔公式与端点反射",
"items": [
{"id":"m5s2-1","name":"一维波动方程的通解","tags":["der","def"],"brief":"解可分解为左右传播的两列波。",
 "body": wrap(
   der(p("<strong>特征变换：</strong>令 $\\xi=x-at$、$\\eta=x+at$，计算复合导数")+
   fml("u_{tt}=a^2(u_{\\xi\\xi}-2u_{\\xi\\eta}+u_{\\eta\\eta}),\\qquad u_{xx}=u_{\\xi\\xi}+2u_{\\xi\\eta}+u_{\\eta\\eta}")+
   p("代入 $u_{tt}=a^2u_{xx}$ 后 $u_{\\xi\\xi}$、$u_{\\eta\\eta}$ 相消，化为")+
   fml("\\frac{\\partial^2u}{\\partial\\xi\\partial\\eta}=0")+
   p("先对 $\\eta$ 积分得 $u_\\xi=g(\\xi)$，再对 $\\xi$ 积分得通解")+
   fml("u(x,t)=f(x-at)+g(x+at)"))+
   note(p("$f(x-at)$ 是速度 $a$ 向右传播的波，$g(x+at)$ 是向左传播的波，波形在传播中保持不变。"))
 )},
{"id":"m5s2-2","name":"达朗贝尔公式","tags":["thm","der"],"brief":"一维波动方程柯西问题的显式解。",
 "fig":"dalembert","figCap":"达朗贝尔解由左右行波叠加而成",
 "body": wrap(
   thm("达朗贝尔公式",p("一维波动方程 $u_{tt}=a^2u_{xx}$ 在 $x\\in\\mathbb{R}$ 上、初条件 $u(x,0)=\\varphi(x)$、$u_t(x,0)=\\psi(x)$ 的解为")+
   fml("u(x,t)=\\frac{1}{2}[\\varphi(x-at)+\\varphi(x+at)]+\\frac{1}{2a}\\int_{x-at}^{x+at}\\psi(\\xi)\\,\\mathrm{d}\\xi"))+
   der(p("<strong>推导：</strong>由通解 $u=f(x-at)+g(x+at)$。代入初值得")+
   fml("f(x)+g(x)=\\varphi(x),\\qquad -af'(x)+ag'(x)=\\psi(x)")+
   p("把第二式积分，$g(x)-f(x)=\\dfrac1a\\int_{x_0}^{x}\\psi(\\xi)\\,\\mathrm{d}\\xi+C$，与第一式联立解得 $f$、$g$，再以 $x\\mp at$ 替换即得公式。"))+
   note(p("从公式可见 $u(x,t)$ 只依赖于区间 $[x-at,x+at]$ 上的初值，即依赖区间；解在一点变化的传播速度为 $a$。"))
 )},
{"id":"m5s2-3","name":"半无界弦与端点反射","tags":["der","app"],"brief":"用奇偶延拓处理端点边界。",
 "body": wrap(
   der(p("<strong>固定端（$u(0,t)=0$）：</strong>把初值 $\\varphi$、$\\psi$ 作奇延拓到整个实轴，则达朗贝尔解自动满足 $u(0,t)=0$：")+
   fml("\\varphi_{\\text{odd}}(-x)=-\\varphi(x),\\qquad \\psi_{\\text{odd}}(-x)=-\\psi(x)")+
   p("此时波传播到端点后反射，波形反号，形成半波损失（相位突变 $\\pi$）。"))+
   der(p("<strong>自由端（$u_x(0,t)=0$）：</strong>改作偶延拓")+
   fml("\\varphi_{\\text{even}}(-x)=\\varphi(x),\\qquad \\psi_{\\text{even}}(-x)=\\psi(x)")+
   p("则 $u_x(0,t)=0$ 自动满足，反射波不反号，端点处位移加倍。"))+
   app(p("<strong>应用：</strong>端点反射是解释半无界弦振动、电信号在传输线末端反射与声波在管口反射的基础。"))
 )},
]},
{
"name": "5.3 积分变换法",
"color": "#e11d48",
"desc": "傅里叶变换法、拉普拉斯变换法及适用条件",
"items": [
{"id":"m5s3-1","name":"傅里叶变换法解无界问题","tags":["der"],"brief":"对空间变量作变换把方程化为常微分方程。",
 "body": wrap(
   der(p("<strong>解一维波动方程柯西问题：</strong>对 $x$ 作傅里叶变换，令 $U(\\omega,t)=\\mathcal{F}\\{u\\}$。方程化为")+
   fml("\\frac{\\partial^2U}{\\partial t^2}=-a^2\\omega^2U")+
   p("结合初值 $U(\\omega,0)=\\Phi(\\omega)$、$U_t(\\omega,0)=\\Psi(\\omega)$，解得")+
   fml("U(\\omega,t)=\\Phi(\\omega)\\cos a\\omega t+\\frac{\\Psi(\\omega)}{a\\omega}\\sin a\\omega t")+
   p("逆变换并用 $\\mathcal{F}^{-1}\\{\\cos a\\omega t\\}$ 对应的平移，即得达朗贝尔公式。"))+
   note(p("傅里叶变换法要求初值在无穷远处足够快地衰减（绝对可积），适合无界区域问题。"))
 )},
{"id":"m5s3-2","name":"拉普拉斯变换法解半无界问题","tags":["der","exa"],"brief":"对时间作变换处理初值问题。",
 "body": wrap(
   der(p("<strong>例：解半无界杆的热传导：</strong>$u_t=a^2u_{xx}\\ (x>0)$，$u(x,0)=0$，$u(0,t)=u_0$。对 $t$ 作拉氏变换，令 $\\bar u(x,s)=L\\{u\\}$：")+
   fml("s\\bar u=a^2\\bar u''\\ \\Rightarrow\\ \\bar u''-\\frac{s}{a^2}\\bar u=0")+
   p("边界条件变为 $\\bar u(0,s)=u_0/s$，并因 $x\\to\\infty$ 有界舍去增长解，得 $\\bar u=\\dfrac{u_0}{s}\\mathrm{e}^{-x\\sqrt{s}/a}$。"))+
   der(p("<strong>反演：</strong>由余误差函数的变换对")+
   fml("L^{-1}\\!\\left\\{\\frac{\\mathrm{e}^{-kx\\sqrt{s}}}{s}\\right\\}=\\mathrm{erfc}\\!\\left(\\frac{x}{2a\\sqrt t}\\right)")+
   p("得 $u(x,t)=u_0\\,\\mathrm{erfc}\\left(\\dfrac{x}{2a\\sqrt t}\\right)$，即半无界杆的温度分布。"))+
   note(p("拉氏变换自动包含 $t=0$ 的初值信息，特别适合半无界或有限区域的初边值问题。"))
 )},
{"id":"m5s3-3","name":"变换法的适用条件比较","tags":["der"],"brief":"依据区域与初边值类型选择变换。",
 "body": wrap(
   der(p("<strong>选择依据：</strong>若区域无界且要求解在无穷远衰减，用傅里叶变换；若区域为半无界或有限且给定 $t=0$ 的初值，用拉普拉斯变换（能自然吸收初值）；若方程含有的空间导数阶数高于时间导数，可对空间作变换把方程降为常微分方程。"))+
   der(p("<strong>收敛性要求：</strong>傅里叶变换要求 $\\int|u|\\,\\mathrm{d}x<\\infty$；拉氏变换要求 $u$ 为指数阶。对增长型或周期性问题可改用有限傅里叶变换或分离变量法。"))+
   note(p("实际求解时常把变换法与留数、卷积结合：先求象函数，再由部分分式或留数反演得到原问题的解。"))
 )},
]},
{
"name": "5.4 格林函数法",
"color": "#c026d3",
"desc": "格林函数的物理意义、格林公式与镜像法",
"items": [
{"id":"m5s4-1","name":"格林函数的物理意义","tags":["def","der"],"brief":"点源响应，解可表示为由源与格林函数的积分。",
 "fig":"green_function","figCap":"格林函数：点源产生的场，叠加得到一般源的解",
 "body": wrap(
   defn("格林函数",p("在区域 $\\Omega$ 内、给定齐次边界条件下，满足 $-\\nabla^2G(\\mathbf{r},\\mathbf{r}')=\\delta(\\mathbf{r}-\\mathbf{r}')$ 的解 $G$ 称为格林函数，即点源产生的场。"))+
   der(p("<strong>由叠加得到一般解：</strong>对源分布 $f$，设 $u(\\mathbf{r})=\\int G(\\mathbf{r},\\mathbf{r}')f(\\mathbf{r}')\\,\\mathrm{d}V'$，则")+
   fml("-\\nabla^2u=-\\int\\nabla^2G\\,f\\,\\mathrm{d}V'=\\int\\delta(\\mathbf{r}-\\mathbf{r}')f(\\mathbf{r}')\\,\\mathrm{d}V'=f(\\mathbf{r})")+
   p("故 $u$ 满足 $-\\nabla^2u=f$，且因 $G$ 满足齐次边界条件，$u$ 也满足相应边界条件。"))+
   note(p("格林函数体现了线性系统的可叠加性：只要知道点源响应，任意源分布的响应都可由积分得到。"))
 )},
{"id":"m5s4-2","name":"泊松方程的格林函数与格林公式","tags":["der","thm"],"brief":"用格林公式把解表为边界积分与体积分。",
 "body": wrap(
   der(p("<strong>格林第二公式：</strong>对区域 $\\Omega$ 上两个光滑函数 $u$、$G$，由散度定理得")+
   fml("\\int_\\Omega(u\\nabla^2G-G\\nabla^2u)\\,\\mathrm{d}V=\\oint_{\\partial\\Omega}\\left(u\\frac{\\partial G}{\\partial n}-G\\frac{\\partial u}{\\partial n}\\right)\\mathrm{d}S")+
   p("取 $G$ 为格林函数、$-\\nabla^2u=f$，并用 $-\\nabla^2G=\\delta$ 得泊松方程解的积分表示")+
   fml("u(\\mathbf{r})=\\int_\\Omega G(\\mathbf{r},\\mathbf{r}')f(\\mathbf{r}')\\,\\mathrm{d}V'+\\oint_{\\partial\\Omega}\\left(G\\frac{\\partial u}{\\partial n}-u\\frac{\\partial G}{\\partial n}\\right)\\mathrm{d}S'")+
   p("若边界条件为第一类，$G|_{\\partial\\Omega}=0$，边界项只剩含 $\\partial u/\\partial n$ 的项，但对狄利克雷问题该信息不需已知。"))+
   note(p("通过选取满足不同齐次边界条件的格林函数，可分别求解狄利克雷问题与诺伊曼问题。"))
 )},
{"id":"m5s4-3","name":"镜像法求格林函数","tags":["der","exa"],"brief":"用对称点源构造半空间格林函数。",
 "body": wrap(
   der(p("<strong>半空间镜像法：</strong>求上半空间 $z>0$ 内、边界 $z=0$ 上 $G=0$ 的格林函数。在 $\\mathbf{r}'$ 处放点电荷，为使边界电位为零，在对称点 $\\tilde{\\mathbf{r}}'$（$z$ 坐标取相反数）放等量异号镜像源，故")+
   fml("G(\\mathbf{r},\\mathbf{r}')=\\frac{1}{4\\pi|\\mathbf{r}-\\mathbf{r}'|}-\\frac{1}{4\\pi|\\mathbf{r}-\\tilde{\\mathbf{r}}'|}")+
   p("在 $z=0$ 上两距离相等，两项相消，边界条件满足；由唯一性这即为所求格林函数。"))+
   exa(p("<strong>例：</strong>下半空间接地导体平面上的点电荷感应场，其对导体平面的法向电场由镜像电荷给出，进而可求感应电荷面密度 $\\sigma=-\\varepsilon_0\\partial\\varphi/\\partial z|_{z=0}$。"))+
   note(p("镜像法适用于具对称边界的区域（半空间、球外、两平行板等）；球外点源可用球面反演构造镜像点。"))
 )},
]},
{
"name": "5.5 变分法初步",
"color": "#a21caf",
"desc": "泛函、欧拉-拉格朗日方程与变分原理",
"items": [
{"id":"m5s5-1","name":"泛函与变分","tags":["def","der"],"brief":"泛函的极值由变分取零刻画。",
 "body": wrap(
   defn("泛函与变分",p("泛函 $J[y]=\\int_a^bL(x,y,y')\\,\\mathrm{d}x$ 是函数的函数。若 $y_0$ 使 $J$ 取极值，则对任意扰动 $\\delta y=\\varepsilon\\eta(x)$（$\\eta(a)=\\eta(b)=0$）有 $\\left.\\dfrac{\\mathrm{d}}{\\mathrm{d}\\varepsilon}J[y_0+\\varepsilon\\eta]\\right|_{\\varepsilon=0}=0$。"))+
   der(p("<strong>一阶变分：</strong>")+
   fml("\\delta J=\\int_a^b\\left(\\frac{\\partial L}{\\partial y}\\eta+\\frac{\\partial L}{\\partial y'}\\eta'\\right)\\mathrm{d}x")+
   p("对第二项分部积分，利用 $\\eta(a)=\\eta(b)=0$ 消去边界项：")+
   fml("\\delta J=\\int_a^b\\left(\\frac{\\partial L}{\\partial y}-\\frac{\\mathrm{d}}{\\mathrm{d}x}\\frac{\\partial L}{\\partial y'}\\right)\\eta\\,\\mathrm{d}x=0")+
   p("由 $\\eta$ 任意性得欧拉-拉格朗日方程。"))+
   note(p("变分法的直观含义：在所有容许曲线中，使作用量 $J$ 取驻值的曲线才是物理上实现的路径。"))
 )},
{"id":"m5s5-2","name":"欧拉-拉格朗日方程","tags":["der","exa"],"brief":"泛函极值的必要条件。",
 "body": wrap(
   der(p("<strong>推导：</strong>由上一步 $\\delta J=0$ 并由 $\\eta$ 任意，被积函数中 $\\eta$ 的系数必为零，即")+
   fml("\\frac{\\partial L}{\\partial y}-\\frac{\\mathrm{d}}{\\mathrm{d}x}\\!\\left(\\frac{\\partial L}{\\partial y'}\\right)=0")+
   p("当 $L$ 不显含 $x$ 时，可化为首积分（贝尔特拉米恒等式）")+
   fml("L-y'\\frac{\\partial L}{\\partial y'}=C"))+
   exa(p("<strong>例（最速降线）：</strong>$L=\\dfrac{\\sqrt{1+y'^2}}{\\sqrt{2gy}}$，代入欧拉-拉格朗日方程可解得摆线。"))+
   app(p("<strong>应用：</strong>欧拉-拉格朗日方程是分析力学、光学（费马原理）与场论（拉格朗日密度）的共同出发点。"))
 )},
{"id":"m5s5-3","name":"变分原理与数理方程","tags":["der","app"],"brief":"偏微分方程可由能量泛函的变分得到。",
 "body": wrap(
   der(p("<strong>狄利克雷原理：</strong>考虑能量泛函")+
   fml("J[u]=\\frac12\\int_\\Omega|\\nabla u|^2\\,\\mathrm{d}V-\\int_\\Omega fu\\,\\mathrm{d}V")+
   p("对 $u$ 作变分 $u+\\varepsilon v$（$v|_{\\partial\\Omega}=0$），")+
   fml("\\delta J=\\int_\\Omega(\\nabla u\\cdot\\nabla v-fv)\\,\\mathrm{d}V=\\int_\\Omega(-\\nabla^2u-f)v\\,\\mathrm{d}V")+
   p("由 $v$ 任意得 $-\\nabla^2u=f$，即泊松方程。故泊松方程的解等价于能量泛函取极小，这就是狄利克雷原理。"))+
   app(p("<strong>应用：</strong>变分原理是有限元法的理论基础；力学中的最小势能原理、光学中的费马原理、量子力学中的变分近似都源于此。"))
 )},
]},
{
"name": "5.6 数值解法初步",
"color": "#831843",
"desc": "有限差分法、稳定性与收敛性、有限元法初步",
"items": [
{"id":"m5s6-1","name":"有限差分法","tags":["der"],"brief":"用差商代替导数，把方程离散化为代数方程组。",
 "body": wrap(
   der(p("<strong>五点差分格式：</strong>由泰勒展开")+
   fml("u(x\\pm h,y)=u\\pm hu_x+\\frac{h^2}{2}u_{xx}\\pm\\cdots,\\qquad u(x,y\\pm h)=u\\pm hu_y+\\frac{h^2}{2}u_{yy}\\pm\\cdots")+
   p("四式相加消去一阶项，得二阶导数的中心差分逼近：")+
   fml("u_{xx}+u_{yy}=\\frac{u_{i+1,j}+u_{i-1,j}+u_{i,j+1}+u_{i,j-1}-4u_{ij}}{h^2}+O(h^2)")+
   p("令其为零即得拉普拉斯方程的五点差分格式 $u_{i+1,j}+u_{i-1,j}+u_{i,j+1}+u_{i,j-1}-4u_{ij}=0$。"))+
   note(p("边界条件直接代入网格值；得到的是稀疏线性方程组，可用迭代法（高斯-赛德尔、SOR）或直接法求解。"))
 )},
{"id":"m5s6-2","name":"稳定性与收敛性","tags":["der","thm"],"brief":"显式格式必须满足稳定性条件。",
 "body": wrap(
   der(p("<strong>热方程显式格式的稳定性：</strong>用显式差分 $u_i^{n+1}=u_i^n+r(u_{i+1}^n-2u_i^n+u_{i-1}^n)$，$r=a^2\\Delta t/h^2$。设误差按傅里叶模式 $\\varepsilon_i^n=\\xi^n\\mathrm{e}^{ikih}$ 演化，得放大因子")+
   fml("\\xi=1-2r(1-\\cos kh)=1-4r\\sin^2\\frac{kh}{2}")+
   p("稳定要求 $|\\xi|\\le1$ 对所有 $k$，最不利情形 $\\sin^2=1$，得")+
   fml("r=\\frac{a^2\\Delta t}{h^2}\\le\\frac12")+
   p("这即热方程的稳定性条件（CFL 条件）。"))+
   note(p("拉克斯等价定理：对相容的线性格式，稳定性等价于收敛性；因此数值分析的核心是证明稳定性。"))
 )},
{"id":"m5s6-3","name":"有限元法初步","tags":["der","app"],"brief":"用弱形式与分片插值求解方程。",
 "body": wrap(
   der(p("<strong>弱形式（伽辽金法）：</strong>对 $-\\nabla^2u=f$ 两边乘以试探函数 $v$（$v|_{\\partial\\Omega}=0$）并积分，用格林公式把二阶导降为一阶导：")+
   fml("\\int_\\Omega\\nabla u\\cdot\\nabla v\\,\\mathrm{d}V=\\int_\\Omega fv\\,\\mathrm{d}V")+
   p("把区域剖分为单元，在每个单元上用分片多项式（如线性三角形）近似 $u=\\sum u_j\\phi_j$，代入弱形式得线性方程组")+
   fml("\\sum_j\\left(\\int_\\Omega\\nabla\\phi_j\\cdot\\nabla\\phi_i\\,\\mathrm{d}V\\right)u_j=\\int_\\Omega f\\phi_i\\,\\mathrm{d}V")+
   p("即 $\\mathbf{K}\\mathbf{u}=\\mathbf{b}$，$\\mathbf{K}$ 为刚度矩阵。"))+
   app(p("<strong>应用：</strong>有限元法适用于复杂几何与变系数问题，广泛用于结构力学、热传导、电磁场与流体计算。"))
 )},
]},
]

ch6_sections = [
{
"name": "6.1 勒让德多项式",
"color": "#0891b2",
"desc": "勒让德方程、罗德里格斯公式、性质与递推关系",
"items": [
{"id":"m6s1-1","name":"勒让德方程","tags":["der"],"brief":"球坐标分离变量得到的常微分方程。",
 "body": wrap(
   der(p("<strong>由球坐标分离变量导出：</strong>拉普拉斯方程在球坐标 $(r,\\theta,\\varphi)$ 下为")+
   fml("\\frac{1}{r^2}\\frac{\\partial}{\\partial r}\\!\\left(r^2\\frac{\\partial u}{\\partial r}\\right)+\\frac{1}{r^2\\sin\\theta}\\frac{\\partial}{\\partial\\theta}\\!\\left(\\sin\\theta\\frac{\\partial u}{\\partial\\theta}\\right)+\\frac{1}{r^2\\sin^2\\theta}\\frac{\\partial^2u}{\\partial\\varphi^2}=0")+
   p("令 $u=R(r)\\Theta(\\theta)$（轴对称情形，$\\varphi$ 无关），乘以 $r^2/(R\\Theta)$ 后分离变量，角向部分满足")+
   fml("\\frac{1}{\\sin\\theta}\\frac{\\mathrm{d}}{\\mathrm{d}\\theta}\\!\\left(\\sin\\theta\\frac{\\mathrm{d}\\Theta}{\\mathrm{d}\\theta}\\right)+l(l+1)\\Theta=0")+
   p("作变量替换 $x=\\cos\\theta$（$\\mathrm{d}/\\mathrm{d}\\theta=-\\sin\\theta\\,\\mathrm{d}/\\mathrm{d}x$），并记 $y(x)=\\Theta(\\theta)$，得勒让德方程")+
   fml("(1-x^2)y''-2xy'+l(l+1)y=0"))+
   note(p("该方程在 $x=\\pm1$（即 $\\theta=0,\\pi$）有正则奇点，要求解有界便要求 $l$ 为非负整数。"))
 )},
{"id":"m6s1-2","name":"勒让德多项式与罗德里格斯公式","tags":["thm","der"],"brief":"用求导公式给出勒让德多项式的显式表达。",
 "fig":"legendre","figCap":"前三个勒让德多项式 P₀、P₁、P₂ 的图形",
 "body": wrap(
   thm("罗德里格斯公式",p("勒让德多项式可表示为")+
   fml("P_l(x)=\\frac{1}{2^l l!}\\frac{\\mathrm{d}^l}{\\mathrm{d}x^l}(x^2-1)^l"))+
   der(p("<strong>验证它满足勒让德方程：</strong>记 $v=(x^2-1)^l$，则 $v$ 满足")+
   fml("(x^2-1)v'=2lx\\,v")+
   p("对上式用莱布尼茨公式求 $l+1$ 阶导数。因 $(x^2-1)$ 只有前两个导数非零，展开为")+
   fml("(x^2-1)v^{(l+2)}+2x(l+1)v^{(l+1)}+l(l+1)v^{(l)}=2lx\\,v^{(l+1)}+2l(l+1)v^{(l)}")+
   p("整理并用 $y\\propto v^{(l)}$ 得")+
   fml("(1-x^2)y''-2xy'+l(l+1)y=0")+
   p("即罗德里格斯公式给出的函数正是勒让德方程的多项式解，且 $P_l(1)=1$。"))+
   note(p("由 $v$ 的奇偶性可知 $P_l$ 与 $l$ 同奇偶：$P_0=1$、$P_1=x$、$P_2=\\dfrac{3x^2-1}{2}$。"))
 )},
{"id":"m6s1-3","name":"勒让德多项式的性质与递推","tags":["der"],"brief":"正交性与三项递推关系。",
 "body": wrap(
   der(p("<strong>正交性：</strong>对 $n\\ne m$，用 $P_m$ 乘 $P_n$ 的方程减去 $P_n$ 乘 $P_m$ 的方程并积分，边界项因 $(1-x^2)$ 在端点为零而消失：")+
   fml("(\\lambda_n-\\lambda_m)\\int_{-1}^{1}P_mP_n\\,\\mathrm{d}x=0\\ \\Rightarrow\\ \\int_{-1}^{1}P_mP_n\\,\\mathrm{d}x=\\frac{2}{2n+1}\\delta_{mn}")+
   p("归一化系数由 $\\int_{-1}^1P_n^2\\,\\mathrm{d}x=\\dfrac{2}{2n+1}$ 给出。"))+
   der(p("<strong>三项递推：</strong>由生成函数 $g(t,x)=(1-2xt+t^2)^{-1/2}=\\sum P_n(x)t^n$ 对 $t$ 求导：")+
   fml("(x-t)g=(1-2xt+t^2)\\frac{\\partial g}{\\partial t}")+
   p("比较 $t^n$ 的系数即得")+
   fml("(n+1)P_{n+1}(x)=(2n+1)xP_n(x)-nP_{n-1}(x)"))+
   app(p("<strong>应用：</strong>正交性使勒让德级数展开成为球坐标下拉普拉斯方程边值问题的标准求解途径，如带电球壳的电位分布。"))
 )},
]},
{
"name": "6.2 连带勒让德函数与球谐函数",
"color": "#06b6d4",
"desc": "连带勒让德方程与函数、球谐函数与球面展开",
"items": [
{"id":"m6s2-1","name":"连带勒让德方程","tags":["der"],"brief":"含方位角量子数的推广方程。",
 "body": wrap(
   der(p("<strong>由球坐标含 $\\varphi$ 的分离变量导出：</strong>令 $u=R(r)\\Theta(\\theta)\\Phi(\\varphi)$，方位角部分满足")+
   fml("\\Phi''+m^2\\Phi=0\\ \\Rightarrow\\ \\Phi=\\mathrm{e}^{im\\varphi},\\quad m=0,\\pm1,\\pm2,\\dots")+
   p("角向部分则化为含 $m^2$ 的方程：")+
   fml("\\frac{1}{\\sin\\theta}\\frac{\\mathrm{d}}{\\mathrm{d}\\theta}\\!\\left(\\sin\\theta\\frac{\\mathrm{d}\\Theta}{\\mathrm{d}\\theta}\\right)+\\left[l(l+1)-\\frac{m^2}{\\sin^2\\theta}\\right]\\Theta=0")+
   p("作替换 $x=\\cos\\theta$，得连带勒让德方程")+
   fml("(1-x^2)y''-2xy'+\\left[l(l+1)-\\frac{m^2}{1-x^2}\\right]y=0"))+
   note(p("$m=0$ 时退化为勒让德方程；要求解在 $\\theta=0,\\pi$ 有界，则 $l$ 为非负整数、$|m|\\le l$。"))
 )},
{"id":"m6s2-2","name":"连带勒让德函数","tags":["der"],"brief":"由勒让德多项式求导得到。",
 "fig":"associated","figCap":"球坐标下的角向函数与方位角因子",
 "body": wrap(
   der(p("<strong>构造：</strong>把 $y=(1-x^2)^{m/2}\\,v$ 代入连带勒让德方程，可化为勒让德方程，于是")+
   fml("P_l^m(x)=(1-x^2)^{m/2}\\,\\frac{\\mathrm{d}^m}{\\mathrm{d}x^m}P_l(x)")+
   p("对 $m>0$ 成立；对负 $m$ 用 $P_l^{-m}=(-1)^m\\dfrac{(l-m)!}{(l+m)!}P_l^m$ 定义。"))+
   der(p("<strong>归一化：</strong>由勒让德多项式的正交性与上述求导关系可得")+
   fml("\\int_{-1}^{1}P_l^m(x)P_{l'}^m(x)\\,\\mathrm{d}x=\\frac{2}{2l+1}\\frac{(l+m)!}{(l-m)!}\\,\\delta_{ll'}")+
   p("故标准归一化连带勒让德函数为 $\\sqrt{\\dfrac{2l+1}{2}\\dfrac{(l-m)!}{(l+m)!}}P_l^m$。"))+
   note(p("$P_l^m$ 在 $|x|\\to1$ 处有 $(1-x^2)^{m/2}$ 型零点因子，$m$ 越大在极轴附近的零点越密。"))
 )},
{"id":"m6s2-3","name":"球谐函数与球面展开","tags":["der","app"],"brief":"球面上的正交完备函数系。",
 "fig":"spherical","figCap":"球谐函数 Y_lm 在球面上的分布",
 "body": wrap(
   der(p("<strong>定义：</strong>把角向解合并为球谐函数")+
   fml("Y_{lm}(\\theta,\\varphi)=N_{lm}P_l^m(\\cos\\theta)\\,\\mathrm{e}^{im\\varphi},\\quad N_{lm}=\\sqrt{\\frac{2l+1}{4\\pi}\\frac{(l-m)!}{(l+m)!}}")+
   p("由 $P_l^m$ 的正交性与 $\\mathrm{e}^{im\\varphi}$ 的正交性，$Y_{lm}$ 在单位球面上满足")+
   fml("\\int_0^{2\\pi}\\!\\!\\int_0^{\\pi}Y_{lm}\\overline{Y_{l'm'}}\\sin\\theta\\,\\mathrm{d}\\theta\\,\\mathrm{d}\\varphi=\\delta_{ll'}\\delta_{mm'}"))+
   der(p("<strong>球面展开：</strong>任意球面上平方可积函数 $f(\\theta,\\varphi)$ 可按 $Y_{lm}$ 展开")+
   fml("f=\\sum_{l=0}^{\\infty}\\sum_{m=-l}^{l}f_{lm}Y_{lm},\\qquad f_{lm}=\\oint f\\overline{Y_{lm}}\\,\\mathrm{d}\\Omega")+
   p("加法公式 $\\sum_m|Y_{lm}|^2=\\dfrac{2l+1}{4\\pi}$ 进一步给出球面函数的旋转不变表示。"))+
   app(p("<strong>应用：</strong>球谐函数用于展开地球重力场与磁场、分析天体辐射的多极结构以及量子力学中角动量本征态。"))
 )},
]},
{
"name": "6.3 贝塞尔函数",
"color": "#0284c7",
"desc": "贝塞尔方程、级数解、递推关系与正交性",
"items": [
{"id":"m6s3-1","name":"贝塞尔方程","tags":["der"],"brief":"柱坐标分离变量得到的常微分方程。",
 "body": wrap(
   der(p("<strong>由柱坐标分离变量导出：</strong>在柱坐标 $(\\rho,\\varphi,z)$ 下，拉普拉斯方程对径向部分令 $u=R(\\rho)\\mathrm{e}^{im\\varphi}\\mathrm{e}^{ikz}$，得到")+
   fml("\\frac{\\mathrm{d}^2R}{\\mathrm{d}\\rho^2}+\\frac1\\rho\\frac{\\mathrm{d}R}{\\mathrm{d}\\rho}+\\left(k^2-\\frac{m^2}{\\rho^2}\\right)R=0")+
   p("令 $x=k\\rho$（或 $x=\\mu_n\\rho/a$），记 $y(x)=R(\\rho)$，得标准贝塞尔方程")+
   fml("x^2y''+xy'+(x^2-n^2)y=0"))+
   note(p("方程在 $x=0$ 处为正则奇点、$x=\\infty$ 处为非正则奇点，故用级数法（弗罗贝尼乌斯）求解，得到 $J_n$ 与 $Y_n$ 两类解。"))
 )},
{"id":"m6s3-2","name":"贝塞尔函数的级数解","tags":["der"],"brief":"用弗罗贝尼乌斯法得到 Jₙ。",
 "fig":"bessel","figCap":"贝塞尔函数 J₀ 与 J₁ 的振荡衰减行为",
 "body": wrap(
   der(p("<strong>级数求解：</strong>设 $y=x^{\\nu}\\sum_{k=0}^{\\infty}a_kx^k\\ (a_0\\ne0)$，代入方程的最低次幂给出指标方程")+
   fml("\\nu^2-n^2=0\\ \\Rightarrow\\ \\nu=\\pm n")+
   p("取 $\\nu=n$，比较 $x^{n+k}$ 的系数得递推")+
   fml("a_k=-\\frac{a_{k-2}}{k(2n+k)}")+
   p("因奇数项由 $a_{-1}=0$ 全为零，偶数项递推得")+
   fml("J_n(x)=\\sum_{k=0}^{\\infty}\\frac{(-1)^k}{k!\\,\\Gamma(n+k+1)}\\left(\\frac{x}{2}\\right)^{2k+n}")+
   p("取 $\\nu=-n$（$n$ 为整数）时给出线性相关的解，故第二解取诺伊曼函数 $Y_n(x)$。"))+
   note(p("$J_n$ 在 $x\\to0$ 有界，$Y_n$ 发散；物理上有界的柱对称问题取 $J_n$。"))
 )},
{"id":"m6s3-3","name":"贝塞尔函数的递推与正交性","tags":["der"],"brief":"递推把相邻阶联系起来，正交性用于圆域展开。",
 "body": wrap(
   der(p("<strong>递推关系：</strong>由级数逐项求导")+
   fml("\\frac{\\mathrm{d}}{\\mathrm{d}x}[x^nJ_n(x)]=x^nJ_{n-1}(x),\\qquad \\frac{\\mathrm{d}}{\\mathrm{d}x}[x^{-n}J_n(x)]=-x^{-n}J_{n+1}(x)")+
   p("两式联立可得 $J_{n-1}+J_{n+1}=\\dfrac{2n}{x}J_n$ 与 $J_{n-1}-J_{n+1}=2J_n'$。"))+
   der(p("<strong>正交性：</strong>把方程写成斯特姆-刘维尔型 $(x y')'+\\left(x-\\dfrac{n^2}{x}\\right)y=0$，权函数为 $x$。对满足 $J_n(\\mu_n^{(i)})=0$ 的零点，可证")+
   fml("\\int_0^a J_n\\!\\left(\\mu_n^{(i)}\\frac{r}{a}\\right)J_n\\!\\left(\\mu_n^{(j)}\\frac{r}{a}\\right)r\\,\\mathrm{d}r=\\frac{a^2}{2}J_{n+1}^2(\\mu_n^{(i)})\\,\\delta_{ij}"))+
   app(p("<strong>应用：</strong>由正交性可把圆域上给定的函数展开为傅里叶-贝塞尔级数，从而求解圆膜振动与圆柱内热传导问题。"))
 )},
]},
{
"name": "6.4 其他正交多项式",
"color": "#0e7490",
"desc": "埃尔米特多项式、拉盖尔多项式与正交多项式的一般理论",
"items": [
{"id":"m6s4-1","name":"埃尔米特多项式","tags":["der"],"brief":"量子谐振子波函数的来源。",
 "body": wrap(
   der(p("<strong>方程的来源：</strong>一维谐振子的定态薛定谔方程")+
   fml("-\\frac{\\hbar^2}{2m}\\psi''+\\frac12m\\omega^2x^2\\psi=E\\psi")+
   p("令 $\\xi=\\alpha x$、$\\psi=\\mathrm{e}^{-\\xi^2/2}H(\\xi)$，代入并消去指数因子，得埃尔米特方程")+
   fml("H''-2\\xi H'+2\\nu H=0,\\quad \\nu=\\frac{E}{\\hbar\\omega}-\\frac12")+
   p("用级数法求解并要求波函数在无穷远平方可积，级数须截断为多项式，得 $\\nu=n$ 为整数，即 $E_n=\\hbar\\omega\\left(n+\\dfrac12\\right)$。"))+
   der(p("<strong>多项式解：</strong>截断后得埃尔米特多项式，其罗德里格斯表示为")+
   fml("H_n(x)=(-1)^n\\mathrm{e}^{x^2}\\frac{\\mathrm{d}^n}{\\mathrm{d}x^n}\\mathrm{e}^{-x^2}"))+
   note(p("埃尔米特多项式按权 $\\mathrm{e}^{-x^2}$ 正交：$\\int_{-\\infty}^{\\infty}H_mH_n\\mathrm{e}^{-x^2}\\,\\mathrm{d}x=2^nn!\\sqrt\\pi\\,\\delta_{mn}$。"))
 )},
{"id":"m6s4-2","name":"拉盖尔多项式","tags":["der"],"brief":"氢原子径向波函数的来源。",
 "body": wrap(
   der(p("<strong>氢原子径向方程：</strong>库仑势 $V=-\\dfrac{e^2}{4\\pi\\varepsilon_0r}$ 下，径向部分令 $u=rR$，无量纲化后得到")+
   fml("\\frac{\\mathrm{d}^2u}{\\mathrm{d}\\rho^2}+\\left(-\\frac14+\\frac{\\lambda}{\\rho}-\\frac{l(l+1)}{\\rho^2}\\right)u=0")+
   p("令 $u=\\rho^{l+1}\\mathrm{e}^{-\\rho/2}L(\\rho)$，代入得连带拉盖尔方程")+
   fml("\\rho L''+(2l+2-\\rho)L'+\\left(\\lambda-l-1\\right)L=0")+
   p("要求 $u$ 平方可积使级数截断，得 $\\lambda=n$、$n\\ge l+1$，能量 $E_n=-\\dfrac{13.6}{n^2}\\,\\mathrm{eV}$。"))+
   der(p("<strong>拉盖尔多项式：</strong>由罗德里格斯表示")+
   fml("L_n(x)=\\frac{\\mathrm{e}^x}{n!}\\frac{\\mathrm{d}^n}{\\mathrm{d}x^n}\\left(x^n\\mathrm{e}^{-x}\\right)")+
   p("按权 $\\mathrm{e}^{-x}$ 正交，氢原子径向函数由它构成，量子数 $n,l,m$ 由此自然出现。"))+
   note(p("氢原子能级只依赖主量子数 $n$，简并度 $n^2$（计自旋为 $2n^2$），这一结论正来自径向解的截断条件。"))
 )},
{"id":"m6s4-3","name":"正交多项式的一般理论","tags":["der"],"brief":"斯特姆-刘维尔框架统一各类特殊函数。",
 "fig":"hermite_laguerre","figCap":"埃尔米特与拉盖尔多项式的振荡形态",
 "body": wrap(
   der(p("<strong>斯特姆-刘维尔方程：</strong>把勒让德、贝塞尔、埃尔米特、拉盖尔方程统一写为")+
   fml("\\frac{\\mathrm{d}}{\\mathrm{d}x}\\!\\left[p(x)y'\\right]+q(x)y+\\lambda\\rho(x)y=0")+
   p("则在本征值 $\\lambda_n$ 下的本征函数 $y_n$ 在相应区间上按权 $\\rho$ 正交：")+
   fml("\\int_a^by_my_n\\rho\\,\\mathrm{d}x=0\\ (m\\ne n)"))+
   der(p("<strong>证明正交性：</strong>用 $y_m$ 乘 $y_n$ 的方程减去 $y_n$ 乘 $y_m$ 的方程，得")+
   fml("(\\lambda_n-\\lambda_m)\\rho\\,y_my_n=\\frac{\\mathrm{d}}{\\mathrm{d}x}\\!\\left[p(y_m'y_n-y_ny_m')\\right]")+
   p("两边积分，右端等于边界值之差，在正则或适当奇异端点为 $p=0$ 或函数有界时为零，故积分正交。"))+
   app(p("<strong>应用：</strong>各类正交多项式均构成完备基，可用于函数展开、数值积分（高斯求积）与微分方程近似求解。"))
 )},
]},
{
"name": "6.5 特殊函数的性质与应用",
"color": "#155e75",
"desc": "生成函数、正交完备性与物理应用",
"items": [
{"id":"m6s5-1","name":"生成函数与递推关系","tags":["der"],"brief":"用一个母函数统一导出多项式的性质。",
 "body": wrap(
   der(p("<strong>勒让德生成函数：</strong>定义")+
   fml("g(t,x)=\\frac{1}{\\sqrt{1-2xt+t^2}}=\\sum_{n=0}^{\\infty}P_n(x)t^n")+
   p("$t=0$ 处 $g=1$ 给出 $P_0=1$；对 $x$ 求导 $\\dfrac{\\partial g}{\\partial x}=\\dfrac{t}{(1-2xt+t^2)^{3/2}}=g\\cdot\\dfrac{t}{1-2xt+t^2}$，比较 $t$ 的各次幂得递推关系。"))+
   der(p("<strong>贝塞尔生成函数：</strong>对含 $\\mathrm{e}^{i\\varphi}$ 的角向展开得到")+
   fml("\\mathrm{e}^{i x\\sin\\theta}=\\sum_{n=-\\infty}^{\\infty}J_n(x)\\mathrm{e}^{in\\theta}")+
   p("由此积分表示 $J_n(x)=\\dfrac{1}{2\\pi}\\int_{-\\pi}^{\\pi}\\mathrm{e}^{i(x\\sin\\theta-n\\theta)}\\,\\mathrm{d}\\theta$，并可导出全部递推关系。"))+
   note(p("生成函数把无穷多个特殊函数打包为一个解析函数，是研究其性质与推导递推的强有力工具。"))
 )},
{"id":"m6s5-2","name":"正交性与完备性","tags":["der"],"brief":"正交基用于函数展开。",
 "fig":"orthogonality","figCap":"按正交本征函数展开：各模式系数由内积确定",
 "body": wrap(
   der(p("<strong>展开系数的确定：</strong>设 $f(x)=\\sum_n a_n\\varphi_n(x)$，$\\{\\varphi_n\\}$ 按权 $\\rho$ 正交。两边乘以 $\\varphi_m\\rho$ 并积分：")+
   fml("\\int f\\varphi_m\\rho\\,\\mathrm{d}x=\\sum_na_n\\int\\varphi_n\\varphi_m\\rho\\,\\mathrm{d}x=a_m\\int\\varphi_m^2\\rho\\,\\mathrm{d}x")+
   p("故")+
   fml("a_n=\\frac{\\int f\\varphi_n\\rho\\,\\mathrm{d}x}{\\int\\varphi_n^2\\rho\\,\\mathrm{d}x}"))+
   der(p("<strong>完备性：</strong>若 $f$ 在相应区间平方可积，则其展开在均方意义下收敛于 $f$，即")+
   fml("\\lim_{N\\to\\infty}\\int\\left|f-\\sum_{n=0}^{N}a_n\\varphi_n\\right|^2\\rho\\,\\mathrm{d}x=0")+
   p("这来源于本征函数系的完备性（帕塞瓦尔等式 $\\int|f|^2\\rho=\\sum|a_n|^2\\|\\varphi_n\\|^2$）。"))+
   app(p("<strong>应用：</strong>傅里叶-勒让德级数、傅里叶-贝塞尔级数、勒让德多极展开都是完备正交展开的具体形式。"))
 )},
{"id":"m6s5-3","name":"特殊函数在物理中的应用","tags":["der","app"],"brief":"从膜振动到多极展开与量子力学。",
 "body": wrap(
   der(p("<strong>圆膜振动：</strong>半径为 $a$ 的边缘固定圆膜满足 $u_{tt}=c^2\\nabla^2u$。令 $u=R(r)\\mathrm{e}^{im\\varphi}T(t)$，径向部分为贝塞尔方程，边界 $R(a)=0$ 给出")+
   fml("\\omega_{nm}=\\frac{c\\,\\mu_m^{(n)}}{a}")+
   p("其中 $\\mu_m^{(n)}$ 为 $J_m$ 的第 $n$ 个零点，本征函数为 $J_m(\\mu r/a)\\cos m\\varphi$，构成圆膜的各阶振动模式。"))+
   der(p("<strong>多极展开：</strong>把远处的电势按勒让德多项式展开：")+
   fml("\\varphi(r,\\theta)=\\frac{1}{4\\pi\\varepsilon_0}\\sum_{l=0}^{\\infty}\\frac{1}{r^{l+1}}\\int r'^lP_l(\\cos\\gamma)\\,\\rho(\\mathbf{r}')\\,\\mathrm{d}V'")+
   p("$l=0,1,2$ 分别对应单极、偶极与四极项，是描述分子、原子核电磁性质的标准语言。"))+
   app(p("<strong>应用：</strong>球谐函数用于行星重力场与宇宙微波背景；贝塞尔函数用于光纤模式与衍射；埃尔米特、拉盖尔函数用于量子谐振子与氢原子。"))
 )},
]},
]

CHAPTERS = [
    {"id":"m-ch1","num":"第一章","title":"复变函数","en":"COMPLEX FUNCTIONS",
     "desc":"复数与复变函数、极限连续与导数、柯西-黎曼条件与解析函数、调和函数与共形映射、复变函数的积分与柯西定理、柯西积分公式与高阶导数公式。",
     "sections": ch1_sections},
    {"id":"m-ch2","num":"第二章","title":"复数级数与留数定理","en":"SERIES & RESIDUE THEOREM",
     "desc":"复数项级数与幂级数、泰勒级数与洛朗级数、孤立奇点的分类、留数定理、留数的计算与类型、利用留数计算实积分。",
     "sections": ch2_sections},
    {"id":"m-ch3","num":"第三章","title":"积分变换","en":"INTEGRAL TRANSFORMS",
     "desc":"傅里叶级数、傅里叶变换及其性质、拉普拉斯变换及其性质与逆变换、积分变换在常微分方程与偏微分方程中的应用。",
     "sections": ch3_sections},
    {"id":"m-ch4","num":"第四章","title":"数学物理方程","en":"EQUATIONS OF MATHEMATICAL PHYSICS",
     "desc":"数学物理方程的导出、三类典型方程、定解条件与定解问题、二阶线性偏微分方程的分类、叠加原理与定解问题的适定性。",
     "sections": ch4_sections},
    {"id":"m-ch5","num":"第五章","title":"数理方程求解","en":"SOLUTION METHODS",
     "desc":"分离变量法、行波法与达朗贝尔公式、积分变换法、格林函数法、变分法初步、数值解法初步。",
     "sections": ch5_sections},
    {"id":"m-ch6","num":"第六章","title":"数理方程常见特殊函数","en":"SPECIAL FUNCTIONS",
     "desc":"勒让德多项式、连带勒让德函数与球谐函数、贝塞尔函数、埃尔米特与拉盖尔多项式、特殊函数的性质与应用。",
     "sections": ch6_sections},
]

total_items = sum(sum(len(s["items"]) for s in ch["sections"]) for ch in CHAPTERS)
print(f"Total items: {total_items}")


def fix_lt_text(s):
    return s.replace("<", "&lt;")
def fix_svg_lt(s):
    import re
    return re.sub(r"<(?!/?(?:svg|g|defs|line|rect|circle|ellipse|path|polygon|polyline|text|tspan|use|marker|linearGradient|radialGradient|stop|clipPath|symbol|pattern|mask|filter|title|desc|animate|animateTransform|image|style)\b)([A-Za-z])", r"&lt;\1", s)

def gen_html():
    data_lines = []
    for ch in CHAPTERS:
        sec_strs = []
        for sec in ch["sections"]:
            item_strs = []
            for it in sec["items"]:
                tags_js = json.dumps(it["tags"], ensure_ascii=False)
                body_esc = js_escape(fix_lt_math(it["body"]))
                fig_field = f",fig:{json.dumps(it.get('fig',''),ensure_ascii=False)}" if it.get("fig") else ""
                figcap_field = f",figCap:{json.dumps(fix_lt_text(it.get('figCap','')),ensure_ascii=False)}" if it.get("figCap") else ""
                item_strs.append(
                    f"{{id:'{it['id']}',name:{json.dumps(it['name'],ensure_ascii=False)},"
                    f"tags:{tags_js},brief:{json.dumps(fix_lt_text(it['brief']),ensure_ascii=False)},"
                    f"body:`{body_esc}`{fig_field}{figcap_field}}}"
                )
            sec_strs.append(
                f"{{name:{json.dumps(sec['name'],ensure_ascii=False)},"
                f"color:'{sec['color']}',desc:{json.dumps(sec['desc'],ensure_ascii=False)},"
                f"items:[{','.join(item_strs)}]}}"
            )
        data_lines.append(
            f"{{id:'{ch['id']}',num:{json.dumps(ch['num'],ensure_ascii=False)},"
            f"title:{json.dumps(ch['title'],ensure_ascii=False)},en:'{ch['en']}',"
            f"desc:{json.dumps(ch['desc'],ensure_ascii=False)},"
            f"sections:[{','.join(sec_strs)}]}}"
        )
    la_data = "[" + ",".join(data_lines) + "]"

    fig_entries = []
    for k, v in FIG.items():
        fig_entries.append(f"{json.dumps(k)}:`{js_escape(fix_svg_lt(v))}`")
    fig_js = "{" + ",".join(fig_entries) + "}"
    tag_label_js = json.dumps(TAG_LABEL, ensure_ascii=False)

    nav_tabs = "".join(
        f'<a class="la-nav-tab c{i+1}" href="#{ch["id"]}">{ch["num"]} · {ch["title"]}</a>'
        for i, ch in enumerate(CHAPTERS)
    )

    css = '''  :root{--la-bg:#f4f7fb;--la-card:#ffffff;--la-ink:#152033;--la-muted:#607089;--la-shadow:0 12px 32px rgba(20,36,60,.09);}
  *{box-sizing:border-box}
  html{scroll-behavior:smooth}
  body{margin:0;font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Hiragino Sans GB","Microsoft YaHei",sans-serif;color:var(--la-ink);background:radial-gradient(circle at 10% 10%,rgba(37,99,235,.08),transparent 28%),radial-gradient(circle at 90% 10%,rgba(124,58,237,.08),transparent 28%),var(--la-bg);line-height:1.7}
  a{color:inherit}
  .la-wrap{width:min(1400px,94vw);margin:auto}
  .la-header{padding:52px 0 20px;text-align:center}
  .la-eyebrow{font-size:13px;letter-spacing:.22em;color:var(--la-muted);font-weight:700;text-transform:uppercase}
  h1{margin:10px 0 8px;font-size:clamp(30px,5vw,54px);line-height:1.08;letter-spacing:-.03em}
  .la-subtitle{margin:0 auto;color:var(--la-muted);font-size:16px;max-width:820px;line-height:1.8}
  .back-bar{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin:22px 0 6px}
  .back-btn{display:inline-flex;align-items:center;gap:8px;padding:10px 22px;border-radius:999px;text-decoration:none;font-size:14px;font-weight:800;background:#fff;color:#1e3a8a;border:1px solid #c7d7ee;box-shadow:0 8px 20px rgba(20,36,60,.08);transition:.25s;cursor:pointer}
  .back-btn:hover{transform:translateY(-2px);box-shadow:0 14px 30px rgba(20,36,60,.14);color:#4c1d95;border-color:#ddd6fe}
  .la-nav-tabs{display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin:22px 0 8px}
  .la-nav-tab{padding:8px 16px;border-radius:999px;text-decoration:none;font-weight:700;font-size:13px;border:1px solid #d5deea;background:#fff;transition:.25s;color:#334155}
  .la-nav-tab:hover{transform:translateY(-2px);box-shadow:0 8px 20px rgba(20,36,60,.1)}
  .la-nav-tab.c1{color:#2563eb;border-color:#bfdbfe}
  .la-nav-tab.c2{color:#7c3aed;border-color:#ddd6fe}
  .la-nav-tab.c3{color:#0d9488;border-color:#99f6e4}
  .la-nav-tab.c4{color:#c2410c;border-color:#fed7aa}
  .la-nav-tab.c5{color:#be185d;border-color:#fbcfe8}
  .la-nav-tab.c6{color:#0891b2;border-color:#a5f3fc}
  .la-engagement-bar{display:flex;gap:12px;justify-content:center;flex-wrap:wrap;margin:26px 0 10px}
  .la-stat-item{display:inline-flex;align-items:center;gap:8px;padding:8px 16px;border-radius:999px;background:#fff;border:1px solid #e2e8f0;font-size:13px;color:#334155;font-weight:600}
  .la-stat-value{color:#6366f1;font-weight:800;font-size:15px}
  .la-stat-link{cursor:pointer;text-decoration:none;transition:.2s}
  .la-stat-link:hover{background:#eef2ff;border-color:#c7d2fe}
  .la-legend{display:flex;gap:8px;flex-wrap:wrap;justify-content:center;margin:0 0 24px;font-size:12px;color:#64748b}
  .la-legend-title{font-weight:700;margin-right:4px}
  .la-arc-badge{font-size:11px;padding:3px 10px;border-radius:999px;font-weight:700;letter-spacing:.04em}
  .la-arc-def{background:#dbeafe;color:#1e40af}
  .la-arc-thm{background:#ede9fe;color:#6d28d9}
  .la-arc-der{background:#e0f2fe;color:#0369a1}
  .la-arc-exa{background:#dcfce7;color:#15803d}
  .la-arc-app{background:#fef3c7;color:#b45309}
  .la-arc-note{background:#fee2e2;color:#b91c1c}
  .la-roadmap{padding:30px 0}
  .la-phase-title{font-size:24px;color:#1e293b;margin:40px 0 6px 18px;display:flex;align-items:center;gap:12px}
  .la-phase-title::before{content:"";width:6px;height:26px;border-radius:4px}
  .la-phase-title.m-ch1::before{background:#2563eb}
  .la-phase-title.m-ch2::before{background:#7c3aed}
  .la-phase-title.m-ch3::before{background:#0d9488}
  .la-phase-title.m-ch4::before{background:#c2410c}
  .la-phase-title.m-ch5::before{background:#be185d}
  .la-phase-title.m-ch6::before{background:#0891b2}
  .la-phase-en{font-size:11px;letter-spacing:.36em;color:#94a3b8;font-weight:700;text-transform:uppercase;margin:0 0 12px 18px;font-style:italic}
  .la-phase-desc{color:var(--la-muted);font-size:14px;margin:0 0 24px 18px;line-height:1.8;max-width:960px}
  .la-domain{margin-bottom:26px;padding:16px 18px 18px 22px;position:relative;background:rgba(255,255,255,.6);border-radius:18px;border:1px solid #e5ebf2}
  .la-domain::before{content:"";position:absolute;left:6px;top:16px;bottom:16px;width:5px;border-radius:5px;background:var(--domain-color,#2563eb);box-shadow:0 0 12px rgba(37,99,235,.25)}
  .la-domain-header{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:12px}
  .la-domain-header h3{margin:0;font-size:17px;color:#1e293b}
  .la-domain-count{font-size:11px;padding:2px 10px;border-radius:999px;background:#eef2ff;color:#4f46e5;font-weight:700}
  .la-domain-desc{font-size:12px;color:#94a3b8}
  .la-domain-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px}
  .la-course-card{background:#fff;border:1px solid #e5ebf2;border-radius:14px;padding:14px 16px;cursor:pointer;transition:.22s;box-shadow:var(--la-shadow)}
  .la-course-card:hover{transform:translateY(-3px);border-color:#c7d2fe;box-shadow:0 16px 40px rgba(37,99,235,.12)}
  .la-course-card h4{margin:6px 0;font-size:15px;color:#1e293b}
  .la-course-card p{margin:4px 0 0;font-size:12.5px;color:#64748b;line-height:1.6}
  .la-arc-badges{display:flex;gap:5px;flex-wrap:wrap;margin-bottom:2px}
  .la-overlay{position:fixed;inset:0;background:rgba(15,23,42,.5);display:none;align-items:center;justify-content:center;padding:18px;z-index:60;backdrop-filter:blur(2px)}
  .la-overlay.show{display:flex}
  .la-modal{width:min(820px,96vw);background:white;border-radius:24px;padding:30px;box-shadow:0 24px 80px rgba(0,0,0,.28);animation:laPopIn .3s;max-height:90vh;overflow-y:auto}
  @keyframes laPopIn{from{transform:scale(.94);opacity:0}to{transform:scale(1);opacity:1}}
  .la-modal h2{margin:0 0 10px;font-size:23px;color:#1e293b;line-height:1.35}
  .la-modal .la-crumbs{font-size:12px;color:#94a3b8;margin:0 0 14px;font-weight:600;letter-spacing:.02em}
  .la-modal .la-arc-badges{margin:0 0 16px}
  .la-modal-body{color:#334155;font-size:15px;line-height:1.9}
  .la-modal-body p{margin:0 0 12px}
  .la-modal-body strong{color:#0f172a}
  .la-modal-body ul{margin:0 0 12px;padding-left:22px}
  .la-modal-body li{margin-bottom:6px}
  .la-fml{margin:16px 0;padding:14px 18px;background:linear-gradient(135deg,#f8fafc,#eef4fb);border-left:4px solid #93b4e8;border-radius:10px;overflow-x:auto;font-size:16px;color:#0f172a}
  .la-fml .note{display:block;font-size:12.5px;color:#8496ad;margin-top:8px;line-height:1.6;font-family:system-ui,-apple-system,"PingFang SC","Microsoft YaHei",sans-serif}
  .la-fml mjx-container[display="true"]{margin:0 !important}
  mjx-container, mjx-container *{color:#0f172a !important;opacity:1 !important}
  mjx-mi{font-style:italic !important}
  mjx-mo{color:#0f172a !important}
  .la-modal-body mjx-container, .la-modal-body mjx-container *{color:#0f172a !important;opacity:1 !important}
  .la-fig{margin:18px auto;padding:14px 16px 10px;background:#fafcff;border:1px solid #e2ebf7;border-radius:14px;display:flex;flex-direction:column;align-items:center;max-width:600px}
  .la-fig svg{display:block;width:100%;height:auto;max-width:560px}
  .la-fig .la-fig-cap{font-size:12px;color:#8496ad;margin-top:8px;text-align:center;letter-spacing:.02em}
  .la-callout{margin:14px 0;padding:12px 16px;background:#fffbeb;border-left:3px solid #fbbf24;border-radius:8px;font-size:13.5px;color:#78350f;line-height:1.8}
  .la-kp-sec{margin:0 0 18px;padding:14px 16px;border-radius:12px;background:#f8fafc;border:1px solid #eef2f7}
  .la-kp-sec h5{margin:0 0 10px;font-size:14px;color:#1e293b;letter-spacing:.04em;display:flex;align-items:center;gap:8px}
  .la-kp-sec h5::before{content:"";width:4px;height:14px;border-radius:2px;background:var(--la-accent,#3b82f6)}
  .la-kp-def{border-left:3px solid #3b82f6}
  .la-kp-thm{border-left:3px solid #8b5cf6;background:#faf7ff}
  .la-kp-der{border-left:3px solid #0ea5e9;background:#f0f9ff}
  .la-kp-exa{border-left:3px solid #10b981;background:#f0fdf4}
  .la-kp-app{border-left:3px solid #f59e0b;background:#fffbeb}
  .la-kp-note{border-left:3px solid #ef4444;background:#fef2f2}
  .la-kp-his{border-left:3px solid #64748b;background:#f8fafc}
  .la-kp-sec p:last-child{margin-bottom:0}
  .la-modal-close{margin-top:22px;background:#0f172a;color:white;border-color:#0f172a;padding:10px 20px;font-weight:bold}
  .la-footer{padding:34px 0 50px;color:var(--la-muted);text-align:center;font-size:13px;line-height:1.9}
  .la-core-fmls{margin:40px 0 20px;padding:28px 24px;background:linear-gradient(135deg,#f0f4ff,#faf7ff);border:1px solid #e0e7ff;border-radius:18px}
  .la-core-fmls h3{font-size:18px;color:#1e293b;margin:0 0 20px;text-align:center;letter-spacing:.04em}
  .la-core-fmls h3 .la-core-count{display:inline-block;background:#6366f1;color:#fff;font-size:13px;padding:2px 10px;border-radius:20px;margin-left:8px;vertical-align:middle}
  .la-core-item{display:flex;gap:12px;margin:0 0 14px;padding:12px 16px;background:#fff;border-radius:12px;border-left:3px solid #6366f1;align-items:flex-start}
  .la-core-num{flex-shrink:0;width:26px;height:26px;border-radius:50%;background:#6366f1;color:#fff;font-size:13px;display:flex;align-items:center;justify-content:center;font-weight:bold}
  .la-core-body{flex:1;min-width:0}
  .la-core-body .la-core-name{font-size:14px;font-weight:600;color:#1e293b;margin-bottom:4px}
  .la-core-body .la-fml{margin:6px 0 0;padding:8px 14px;font-size:15px}
  .la-back-top{display:inline-block;margin-top:20px;padding:10px 28px;background:#1e293b;color:#fff;border:none;border-radius:25px;font-size:14px;cursor:pointer;letter-spacing:.04em;transition:background .2s}
  .la-back-top:hover{background:#334155}
  @media(max-width:900px){.la-wrap{width:min(94vw,720px)}.la-roadmap{padding:20px}.la-phase-title{font-size:19px}.la-phase-en{font-size:10px;letter-spacing:.26em}.la-domain-desc{display:none}.la-domain-grid{grid-template-columns:repeat(auto-fill,minmax(160px,1fr))}.la-modal{padding:22px}}'''

    js = f'''const LA_DATA = {la_data};
const LA_TAG_LABEL = {tag_label_js};
const LA_FIG = {fig_js};
const LA_KP = {{}};
function laBuildCard(item){{
  const tags = item.tags.map(t => `<span class="la-arc-badge la-arc-${{t}}">${{LA_TAG_LABEL[t]}}</span>`).join('');
  return `<div class="la-course-card" onclick="showLaItem('${{item.id}}')"><div class="la-arc-badges">${{tags}}</div><h4>${{item.name}}</h4><p>${{item.brief}}</p></div>`;
}}
function renderLa(){{
  const root = document.getElementById('laRoadmap');
  let html = '';
  LA_DATA.forEach(ch => {{
    html += `<h2 class="la-phase-title ${{ch.id}}" id="${{ch.id}}">${{ch.num}} · ${{ch.title}}</h2>`;
    html += `<div class="la-phase-en">${{ch.en}}</div>`;
    html += `<p class="la-phase-desc">${{ch.desc}}</p>`;
    ch.sections.forEach(sec => {{
      html += `<div class="la-domain" style="--domain-color:${{sec.color}};"><div class="la-domain-header"><h3>${{sec.name}}</h3><span class="la-domain-count">${{sec.items.length}} 个知识点</span><span class="la-domain-desc">${{sec.desc}}</span></div><div class="la-domain-grid">`;
      sec.items.forEach(it => {{ html += laBuildCard(it); LA_KP[it.id] = {{item: it, section: sec.name, chapter: `${{ch.num}} · ${{ch.title}}`}}; }});
      html += `</div></div>`;
    }});
  }});
  root.innerHTML = html;
  const kCount = Object.keys(LA_KP).length;
  document.getElementById('laKCount').textContent = kCount;
}}
function showLaItem(id){{
  const rec = LA_KP[id];
  if(!rec) return;
  const it = rec.item;
  document.getElementById('laCrumbs').textContent = rec.chapter + ' ／ ' + rec.section;
  document.getElementById('laTitle').textContent = it.name;
  document.getElementById('laTags').innerHTML = it.tags.map(t => `<span class="la-arc-badge la-arc-${{t}}">${{LA_TAG_LABEL[t]}}</span>`).join('');
  let bodyHtml = it.body;
  if (it.fig && LA_FIG[it.fig]) {{
    const figHtml = `<div class="la-fig">${{LA_FIG[it.fig]}}<div class="la-fig-cap">${{it.figCap || ''}}</div></div>`;
    bodyHtml = figHtml + bodyHtml;
  }}
  document.getElementById('laBody').innerHTML = bodyHtml;
  document.getElementById('laOverlay').classList.add('show');
  document.querySelector('.la-modal').scrollTop = 0;
  if (window.MathJax && window.MathJax.typesetPromise) {{ window.MathJax.typesetPromise([document.getElementById('laBody')]).catch(()=>{{}}); }}
}}
function hideLaInfo(){{ document.getElementById('laOverlay').classList.remove('show'); }}
function closeLaInfo(e){{ if(e.target.id === 'laOverlay') hideLaInfo(); }}
document.addEventListener('keydown', e => {{ if(e.key === 'Escape') hideLaInfo(); }});
document.addEventListener('DOMContentLoaded', () => {{
  renderLa();
  if (window.MathJax && window.MathJax.typesetPromise) {{ window.MathJax.typesetPromise([document.getElementById('laRoadmap')]).catch(()=>{{}}); }}
}});'''

    html = f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="数学物理方法知识体系：复变函数、复数级数与留数定理、积分变换、数学物理方程、数理方程求解、数理方程常见特殊函数">
<title>数学物理方法 · 知识体系</title>
<script>
window.MathJax = {{
  tex: {{
    inlineMath: [['$','$'], ['\\\\(','\\\\)']],
    displayMath: [['$$','$$'], ['\\\\[','\\\\]']],
    processEscapes: true,
    packages: {{'[+]': ['ams','boldsymbol']}}
  }},
  options: {{
    skipHtmlTags: ['script','noscript','style','textarea','pre','code'],
    ignoreHtmlClass: 'tex2jax_ignore'
  }},
  svg: {{ fontCache: 'global' }}
}};
</script>
<script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js" id="MathJax-script" async></script>
<style>
{css}
</style>
</head>
<body>
<div class="la-wrap">
  <header class="la-header">
    <div class="la-eyebrow">METHODS OF MATHEMATICAL PHYSICS · KNOWLEDGE MAP</div>
    <h1>数学物理方法 · 知识体系</h1>
    <p class="la-subtitle">复变函数 · 复数级数与留数定理 · 积分变换 · 数学物理方程 · 数理方程求解 · 特殊函数</p>
    <div class="back-bar"><a class="back-btn" href="index.html">← 返回总览</a></div>
    <div class="la-nav-tabs">{nav_tabs}</div>
    <div class="la-engagement-bar">
      <div class="la-stat-item"><span>📘</span><span class="la-stat-value" id="laKCount">--</span><span>个知识点</span></div>
      <a class="la-stat-item la-stat-link" href="#laCoreFmls" onclick="event.preventDefault();document.getElementById('laCoreFmls').scrollIntoView({{behavior:'smooth',block:'start'}})"><span>🧮</span><span class="la-stat-value">{len(CORE_FORMULAS)}</span><span>条核心公式 · 点击速查</span></a>
    </div>
  </header>
  <div class="la-legend">
    <span class="la-legend-title">知识记号</span>
    <span class="la-arc-badge la-arc-def">定 义</span>
    <span class="la-arc-badge la-arc-thm">定 理</span>
    <span class="la-arc-badge la-arc-der">推 导</span>
    <span class="la-arc-badge la-arc-exa">例 子</span>
    <span class="la-arc-badge la-arc-app">应 用</span>
    <span class="la-arc-badge la-arc-note">备 注</span>
  </div>
  <main class="la-roadmap" id="laRoadmap"></main>
  <section class="la-core-fmls" id="laCoreFmls">
    <h3>核心公式速查 <span class="la-core-count">{len(CORE_FORMULAS)} 条</span></h3>
{chr(10).join(f'    <div class="la-core-item"><div class="la-core-num">{i+1}</div><div class="la-core-body"><div class="la-core-name">{name.replace("<","&lt;")}</div><div class="la-fml">$${latex.replace("<","&lt;")}$$</div><div class="note" style="font-size:12px;color:#8496ad;margin-top:4px">{desc.replace("<","&lt;")}</div></div></div>' for i,(name,latex,desc) in enumerate(CORE_FORMULAS))}
  </section>
  <footer class="la-footer">
    <div>数学物理方法 · 知识体系可视化 · MathJax + SVG</div>
    <div style="margin-top:8px">基于数学物理方法核心知识体系整理</div>
    <button class="la-back-top" onclick="window.scrollTo({{top:0,behavior:'smooth'}})">↑ 回到顶部</button>
  </footer>
</div>
<div class="la-overlay" id="laOverlay" onclick="closeLaInfo(event)">
  <div class="la-modal" onclick="event.stopPropagation()">
    <p class="la-crumbs" id="laCrumbs"></p>
    <h2 id="laTitle">知识点</h2>
    <div class="la-arc-badges" id="laTags"></div>
    <div class="la-modal-body" id="laBody"></div>
    <button class="la-modal-close" onclick="hideLaInfo()">关 闭</button>
  </div>
</div>
<script>
{js}
</script>
</body>
</html>'''
    return html

if __name__ == "__main__":
    html = gen_html()
    with open("/workspace/mathematical-methods.html", "w", encoding="utf-8") as f:
        f.write(html)
    print(f"Generated mathematical-methods.html ({len(html)} chars)")
