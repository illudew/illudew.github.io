# -*- coding: utf-8 -*-
"""Generate quantum-mechanics.html with 10 chapters: 波函数与薛定谔方程 / 一维定态 / 算符 / 表象 / 中心力场 / 自旋 / 微扰与变分 / 量子跃迁 / 散射 / 多体问题."""
import json

FIG = {
"wavepacket": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="10" y1="100" x2="230" y2="100" stroke="#cbd5e1" stroke-width="1"/>
<path d="M 20 100 Q 40 40 60 100 T 100 100" fill="none" stroke="#7c3aed" stroke-width="1.5" stroke-dasharray="4 3"/>
<path d="M 20 100 Q 30 70 40 100 T 60 100 T 80 100 T 100 100 T 120 100 T 140 100 T 160 100 T 180 100" fill="none" stroke="#2563eb" stroke-width="2"/>
<circle cx="100" cy="100" r="3" fill="#ef4444"/>
<text x="104" y="94" font-size="10" fill="#ef4444">x₀</text>
<text x="20" y="140" font-size="10" fill="#64748b">波包：许多平面波叠加 ⟹ Δx·Δp ~ ℏ</text>
<text x="150" y="50" font-size="10" fill="#7c3aed">包络</text>
</svg>''',
"infinitewell": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="40" y1="10" x2="40" y2="150" stroke="#475569" stroke-width="3"/>
<line x1="200" y1="10" x2="200" y2="150" stroke="#475569" stroke-width="3"/>
<line x1="40" y1="150" x2="200" y2="150" stroke="#475569" stroke-width="1.5"/>
<text x="20" y="18" font-size="10" fill="#475569">∞</text>
<text x="204" y="18" font-size="10" fill="#475569">∞</text>
<text x="100" y="158" font-size="10" fill="#475569">a</text>
<path d="M 40 130 Q 80 60 120 130 Q 160 200 200 130" fill="none" stroke="#2563eb" stroke-width="1.5"/>
<path d="M 40 100 L 70 60 L 100 100 L 130 140 L 160 100 L 200 60" fill="none" stroke="#0d9488" stroke-width="1.5"/>
<line x1="60" y1="40" x2="180" y2="40" stroke="#ef4444" stroke-width="1" stroke-dasharray="3 3"/>
<line x1="60" y1="80" x2="180" y2="80" stroke="#ef4444" stroke-width="1" stroke-dasharray="3 3"/>
<line x1="60" y1="120" x2="180" y2="120" stroke="#ef4444" stroke-width="1" stroke-dasharray="3 3"/>
<text x="186" y="38" font-size="10" fill="#ef4444">E₁</text>
<text x="186" y="78" font-size="10" fill="#ef4444">E₂</text>
<text x="186" y="118" font-size="10" fill="#ef4444">E₃</text>
</svg>''',
"harmonicosc": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="120" y1="10" x2="120" y2="150" stroke="#cbd5e1" stroke-width="1"/>
<path d="M 30 140 Q 120 20 210 140" fill="none" stroke="#7c3aed" stroke-width="2"/>
<text x="200" y="150" font-size="10" fill="#7c3aed">V=½mω²x²</text>
<line x1="40" y1="120" x2="200" y2="120" stroke="#ef4444" stroke-width="1" stroke-dasharray="3 3"/>
<line x1="60" y1="95" x2="180" y2="95" stroke="#ef4444" stroke-width="1" stroke-dasharray="3 3"/>
<line x1="75" y1="70" x2="165" y2="70" stroke="#ef4444" stroke-width="1" stroke-dasharray="3 3"/>
<path d="M 40 120 Q 60 100 80 120 Q 100 140 120 120 Q 140 100 160 120 Q 180 140 200 120" fill="none" stroke="#2563eb" stroke-width="1.2"/>
<path d="M 60 95 Q 80 70 100 95 Q 120 120 140 95 Q 160 70 180 95" fill="none" stroke="#0d9488" stroke-width="1.2"/>
<text x="14" y="122" font-size="10" fill="#ef4444">½ℏω</text>
<text x="14" y="92" font-size="10" fill="#ef4444">3⁄2ℏω</text>
<text x="14" y="66" font-size="10" fill="#ef4444">5⁄2ℏω</text>
</svg>''',
"tunneling": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="10" y1="100" x2="230" y2="100" stroke="#cbd5e1" stroke-width="1"/>
<rect x="110" y1="50" width="30" height="50" fill="#fee2e2" stroke="#ef4444" stroke-width="1.5"/>
<text x="112" y="44" font-size="10" fill="#ef4444">V₀</text>
<path d="M 10 90 Q 40 70 70 90 T 110 90" fill="none" stroke="#2563eb" stroke-width="2"/>
<path d="M 110 90 L 120 75 L 130 75 L 140 90" fill="none" stroke="#0d9488" stroke-width="1.5" stroke-dasharray="3 2"/>
<path d="M 140 90 Q 170 80 200 90 T 230 90" fill="none" stroke="#2563eb" stroke-width="2"/>
<text x="30" y="60" font-size="10" fill="#2563eb">入射</text>
<text x="180" y="60" font-size="10" fill="#2563eb">透射 T</text>
<text x="40" y="140" font-size="10" fill="#64748b">E < V₀ 时仍有隧穿概率</text>
</svg>''',
"periodic": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="10" y1="100" x2="230" y2="100" stroke="#cbd5e1" stroke-width="1"/>
<g fill="#ddd6fe" stroke="#7c3aed" stroke-width="1.2">
<rect x="20" y1="70" width="20" height="30"/>
<rect x="60" y1="70" width="20" height="30"/>
<rect x="100" y1="70" width="20" height="30"/>
<rect x="140" y1="70" width="20" height="30"/>
<rect x="180" y1="70" width="20" height="30"/>
</g>
<line x1="20" y1="50" x2="220" y2="50" stroke="#ef4444" stroke-width="1" stroke-dasharray="4 3"/>
<text x="14" y="46" font-size="10" fill="#ef4444">允带</text>
<line x1="20" y1="120" x2="220" y2="120" stroke="#0d9488" stroke-width="1" stroke-dasharray="4 3"/>
<text x="14" y="126" font-size="10" fill="#0d9488">禁带</text>
<text x="40" y="148" font-size="10" fill="#64748b">周期势场 ⟹ 能带结构</text>
</svg>''',
"operator": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<circle cx="50" cy="80" r="26" fill="#dbeafe" stroke="#2563eb" stroke-width="1.5"/>
<text x="38" y="86" font-size="13" fill="#1e3a8a">|ψ⟩</text>
<circle cx="190" cy="80" r="26" fill="#dcfce7" stroke="#10b981" stroke-width="1.5"/>
<text x="176" y="86" font-size="13" fill="#15803d">|φ⟩</text>
<line x1="80" y1="80" x2="160" y2="80" stroke="#7c3aed" stroke-width="2" marker-end="url(#arr)"/>
<defs><marker id="arr" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto"><path d="M0,0 L0,6 L9,3 z" fill="#7c3aed"/></marker></defs>
<text x="100" y="72" font-size="12" fill="#7c3aed">Â</text>
<text x="80" y="110" font-size="10" fill="#64748b">|φ⟩ = Â |ψ⟩</text>
</svg>''',
"hermitian": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="40" y1="120" x2="200" y2="120" stroke="#cbd5e1" stroke-width="1"/>
<line x1="120" y1="20" x2="120" y2="130" stroke="#cbd5e1" stroke-width="1"/>
<path d="M 50 110 Q 80 50 120 80 Q 160 110 190 40" fill="none" stroke="#2563eb" stroke-width="2"/>
<text x="60" y="40" font-size="10" fill="#2563eb">ψ*(x)</text>
<text x="150" y="50" font-size="10" fill="#0d9488">φ(x)</text>
<path d="M 50 40 Q 80 110 120 80 Q 160 50 190 110" fill="none" stroke="#0d9488" stroke-width="2"/>
<text x="40" y="150" font-size="10" fill="#64748b">∫ψ*Âφ = ∫(Âψ)*φ  ⟺  Â† = Â</text>
</svg>''',
"uncertainty": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="40" y1="120" x2="200" y2="120" stroke="#cbd5e1" stroke-width="1"/>
<line x1="120" y1="20" x2="120" y2="130" stroke="#cbd5e1" stroke-width="1"/>
<ellipse cx="120" cy="70" rx="50" ry="30" fill="none" stroke="#7c3aed" stroke-width="1.5"/>
<line x1="70" y1="70" x2="170" y2="70" stroke="#2563eb" stroke-width="1.5" stroke-dasharray="3 2"/>
<line x1="120" y1="40" x2="120" y2="100" stroke="#0d9488" stroke-width="1.5" stroke-dasharray="3 2"/>
<text x="110" y="30" font-size="10" fill="#0d9488">Δp</text>
<text x="175" y="66" font-size="10" fill="#2563eb">Δx</text>
<text x="60" y="150" font-size="10" fill="#64748b">Δx·Δp ≥ ℏ/2 （位置-动量不确定关系）</text>
</svg>''',
"matrixrep": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<g stroke="#475569" stroke-width="1">
<line x1="40" y1="30" x2="40" y2="130"/>
<line x1="44" y1="30" x2="44" y2="130"/>
<line x1="200" y1="30" x2="200" y2="130"/>
<line x1="196" y1="30" x2="196" y2="130"/>
<line x1="40" y1="30" x2="200" y2="30"/>
<line x1="40" y1="130" x2="200" y2="130"/>
</g>
<g font-size="11" fill="#2563eb" text-anchor="middle">
<text x="60" y="50">A₁₁</text><text x="90" y="50">A₁₂</text><text x="120" y="50">…</text><text x="180" y="50">A₁ₙ</text>
<text x="60" y="75">A₂₁</text><text x="90" y="75">A₂₂</text><text x="120" y="75">…</text><text x="180" y="75">A₂ₙ</text>
<text x="60" y="100">…</text><text x="90" y="100">…</text><text x="120" y="100">…</text><text x="180" y="100">…</text>
<text x="60" y="120">Aₙ₁</text><text x="90" y="120">…</text><text x="120" y="120">…</text><text x="180" y="120">Aₙₙ</text>
</g>
<text x="20" y="80" font-size="10" fill="#7c3aed">Aᵢⱼ=</text>
<text x="120" y="150" font-size="10" fill="#64748b">Aᵢⱼ = ⟨φᵢ|Â|φⱼ⟩</text>
</svg>''',
"unitary": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<circle cx="60" cy="80" r="24" fill="#dbeafe" stroke="#2563eb" stroke-width="1.5"/>
<text x="48" y="86" font-size="13" fill="#1e3a8a">|ψ⟩</text>
<circle cx="180" cy="80" r="24" fill="#fce7f3" stroke="#be185d" stroke-width="1.5"/>
<text x="166" y="86" font-size="13" fill="#9d174d">|ψ'⟩</text>
<path d="M 86 70 Q 120 30 154 70" fill="none" stroke="#7c3aed" stroke-width="2" marker-end="url(#uarr)"/>
<path d="M 154 90 Q 120 130 86 90" fill="none" stroke="#10b981" stroke-width="2" marker-end="url(#darr)"/>
<defs><marker id="uarr" markerWidth="9" markerHeight="9" refX="8" refY="3" orient="auto"><path d="M0,0 L0,6 L9,3 z" fill="#7c3aed"/></marker>
<marker id="darr" markerWidth="9" markerHeight="9" refX="8" refY="3" orient="auto"><path d="M0,0 L0,6 L9,3 z" fill="#10b981"/></marker></defs>
<text x="100" y="30" font-size="11" fill="#7c3aed">Û</text>
<text x="100" y="140" font-size="11" fill="#10b981">Û†</text>
<text x="80" y="152" font-size="10" fill="#64748b">Û†Û = ÛÛ† = 1</text>
</svg>''',
"dirac": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<rect x="30" y="55" width="70" height="50" rx="8" fill="#dbeafe" stroke="#2563eb" stroke-width="1.5"/>
<text x="44" y="86" font-size="14" fill="#1e3a8a">⟨ψ|</text>
<text x="44" y="100" font-size="9" fill="#64748b">bra</text>
<rect x="140" y="55" width="70" height="50" rx="8" fill="#fce7f3" stroke="#be185d" stroke-width="1.5"/>
<text x="154" y="86" font-size="14" fill="#9d174d">|φ⟩</text>
<text x="154" y="100" font-size="9" fill="#64748b">ket</text>
<line x1="100" y1="80" x2="140" y2="80" stroke="#7c3aed" stroke-width="1.5" stroke-dasharray="3 2"/>
<text x="105" y="72" font-size="10" fill="#7c3aed">⟨ψ|φ⟩</text>
<text x="60" y="140" font-size="10" fill="#64748b">⟨ψ|φ⟩ = ∫ψ*(x)φ(x)dx</text>
</svg>''',
"picture": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="20" y1="100" x2="220" y2="100" stroke="#cbd5e1" stroke-width="1"/>
<text x="14" y="40" font-size="10" fill="#2563eb">薛定谔绘景</text>
<path d="M 30 90 Q 80 50 130 90 T 220 90" fill="none" stroke="#2563eb" stroke-width="2"/>
<text x="14" y="140" font-size="10" fill="#0d9488">海森伯绘景</text>
<line x1="30" y1="110" x2="220" y2="110" stroke="#0d9488" stroke-width="2"/>
<circle cx="120" cy="110" r="4" fill="#0d9488"/>
<text x="60" y="60" font-size="9" fill="#64748b">态演化 |ψ(t)⟩=Û(t)|ψ⟩</text>
<text x="60" y="128" font-size="9" fill="#64748b">算符演化 Â(t)=Û†ÂÛ</text>
</svg>''',
"angmom": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="120" y1="20" x2="120" y2="140" stroke="#cbd5e1" stroke-width="1" stroke-dasharray="3 3"/>
<text x="124" y="22" font-size="10" fill="#64748b">z</text>
<circle cx="120" cy="90" r="50" fill="none" stroke="#7c3aed" stroke-width="1.2"/>
<circle cx="120" cy="90" r="35" fill="none" stroke="#2563eb" stroke-width="1.2"/>
<circle cx="120" cy="90" r="20" fill="none" stroke="#0d9488" stroke-width="1.2"/>
<line x1="120" y1="90" x2="160" y2="50" stroke="#ef4444" stroke-width="2"/>
<circle cx="160" cy="50" r="3" fill="#ef4444"/>
<line x1="120" y1="90" x2="120" y2="55" stroke="#ef4444" stroke-width="1" stroke-dasharray="2 2"/>
<text x="126" y="60" font-size="10" fill="#ef4444">mℏ</text>
<text x="140" y="40" font-size="10" fill="#ef4444">L</text>
<text x="50" y="150" font-size="10" fill="#64748b">L²=l(l+1)ℏ², Lz=mℏ</text>
</svg>''',
"hydrogen": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="60" y1="20" x2="60" y2="140" stroke="#475569" stroke-width="1.5"/>
<text x="44" y="28" font-size="10" fill="#475569">E</text>
<line x1="60" y1="130" x2="180" y2="130" stroke="#cbd5e1" stroke-width="1"/>
<line x1="60" y1="120" x2="180" y2="120" stroke="#2563eb" stroke-width="1.5"/>
<line x1="60" y1="100" x2="180" y2="100" stroke="#0d9488" stroke-width="1.5"/>
<line x1="60" y1="85" x2="180" y2="85" stroke="#7c3aed" stroke-width="1.5"/>
<line x1="60" y1="75" x2="180" y2="75" stroke="#be185d" stroke-width="1.5"/>
<text x="30" y="122" font-size="9" fill="#2563eb">n=1</text>
<text x="30" y="102" font-size="9" fill="#0d9488">n=2</text>
<text x="30" y="87" font-size="9" fill="#7c3aed">n=3</text>
<text x="30" y="77" font-size="9" fill="#be185d">n=4</text>
<text x="140" y="150" font-size="10" fill="#64748b">Eₙ = -13.6/n² eV</text>
</svg>''',
"sphericalwell": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="30" y1="100" x2="210" y2="100" stroke="#cbd5e1" stroke-width="1"/>
<rect x="30" y1="60" width="60" height="40" fill="#dbeafe" stroke="#2563eb" stroke-width="1.5"/>
<rect x="150" y1="60" width="60" height="40" fill="#dbeafe" stroke="#2563eb" stroke-width="1.5"/>
<text x="50" y="86" font-size="10" fill="#2563eb">−V₀</text>
<text x="170" y="86" font-size="10" fill="#2563eb">−V₀</text>
<text x="100" y="112" font-size="10" fill="#64748b">a</text>
<path d="M 30 80 Q 50 50 90 80 Q 110 100 130 80 Q 150 50 170 80 Q 190 100 210 80" fill="none" stroke="#7c3aed" stroke-width="1.5"/>
<text x="80" y="140" font-size="10" fill="#64748b">球方势阱的 s 波（l=0）束缚态</text>
</svg>''',
"osc3d": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="120" y1="20" x2="120" y2="140" stroke="#cbd5e1" stroke-width="1"/>
<line x1="20" y1="80" x2="220" y2="80" stroke="#cbd5e1" stroke-width="1"/>
<ellipse cx="120" cy="80" rx="80" ry="50" fill="none" stroke="#7c3aed" stroke-width="1.5"/>
<ellipse cx="120" cy="80" rx="55" ry="34" fill="none" stroke="#2563eb" stroke-width="1.5"/>
<ellipse cx="120" cy="80" rx="30" ry="18" fill="none" stroke="#0d9488" stroke-width="1.5"/>
<text x="60" y="40" font-size="10" fill="#7c3aed">N=2</text>
<text x="85" y="58" font-size="10" fill="#2563eb">N=1</text>
<text x="105" y="76" font-size="10" fill="#0d9488">N=0</text>
<text x="60" y="150" font-size="10" fill="#64748b">E_N=(N+3/2)ℏω, 简并度 (N+1)(N+2)/2</text>
</svg>''',
"spin": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="120" y1="20" x2="120" y2="140" stroke="#cbd5e1" stroke-width="1" stroke-dasharray="3 3"/>
<text x="124" y="22" font-size="10" fill="#64748b">B</text>
<circle cx="120" cy="90" r="4" fill="#0f172a"/>
<line x1="120" y1="90" x2="160" y2="50" stroke="#ef4444" stroke-width="2"/>
<circle cx="160" cy="50" r="3" fill="#ef4444"/>
<text x="164" y="48" font-size="10" fill="#ef4444">S=ℏ/2</text>
<line x1="120" y1="90" x2="80" y2="50" stroke="#2563eb" stroke-width="2" stroke-dasharray="4 3"/>
<text x="40" y="48" font-size="10" fill="#2563eb">自旋向上</text>
<text x="40" y="140" font-size="10" fill="#64748b">电子自旋 s=1/2，两个自旋态</text>
</svg>''',
"cg": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<circle cx="60" cy="80" r="22" fill="#dbeafe" stroke="#2563eb" stroke-width="1.5"/>
<text x="50" y="86" font-size="12" fill="#1e3a8a">j₁</text>
<circle cx="120" cy="80" r="22" fill="#fce7f3" stroke="#be185d" stroke-width="1.5"/>
<text x="110" y="86" font-size="12" fill="#9d174d">j₂</text>
<circle cx="180" cy="80" r="22" fill="#dcfce7" stroke="#10b981" stroke-width="1.5"/>
<text x="170" y="86" font-size="12" fill="#15803d">J</text>
<line x1="82" y1="80" x2="98" y2="80" stroke="#7c3aed" stroke-width="1.5"/>
<line x1="142" y1="80" x2="158" y2="80" stroke="#7c3aed" stroke-width="1.5"/>
<text x="80" y="130" font-size="10" fill="#64748b">|j₁−j₂| ≤ J ≤ j₁+j₂</text>
<text x="60" y="150" font-size="10" fill="#64748b">CG 系数 ⟨j₁m₁j₂m₂|JM⟩</text>
</svg>''',
"spinorbit": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="120" y1="20" x2="120" y2="140" stroke="#cbd5e1" stroke-width="1" stroke-dasharray="3 3"/>
<circle cx="120" cy="90" r="30" fill="none" stroke="#7c3aed" stroke-width="1.5"/>
<line x1="120" y1="90" x2="150" y2="60" stroke="#2563eb" stroke-width="2"/>
<text x="152" y="56" font-size="10" fill="#2563eb">L</text>
<line x1="120" y1="90" x2="90" y2="60" stroke="#be185d" stroke-width="2"/>
<text x="70" y="56" font-size="10" fill="#be185d">S</text>
<line x1="120" y1="90" x2="120" y2="45" stroke="#10b981" stroke-width="2" stroke-dasharray="4 2"/>
<text x="124" y="42" font-size="10" fill="#10b981">J</text>
<text x="40" y="150" font-size="10" fill="#64748b">H'=ξ(r) L·S  ⟹ 精细结构分裂</text>
</svg>''',
"zeeman": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="50" y1="20" x2="50" y2="140" stroke="#475569" stroke-width="1.5"/>
<line x1="50" y1="80" x2="200" y2="80" stroke="#cbd5e1" stroke-width="1"/>
<line x1="50" y1="80" x2="200" y2="80" stroke="#2563eb" stroke-width="1.5"/>
<line x1="50" y1="60" x2="200" y2="60" stroke="#0d9488" stroke-width="1.5"/>
<line x1="50" y1="100" x2="200" y2="100" stroke="#7c3aed" stroke-width="1.5"/>
<line x1="50" y1="40" x2="200" y2="40" stroke="#be185d" stroke-width="1.5"/>
<line x1="50" y1="120" x2="200" y2="120" stroke="#c2410c" stroke-width="1.5"/>
<text x="10" y="82" font-size="9" fill="#64748b">B=0</text>
<text x="200" y="82" font-size="9" fill="#64748b">B≠0</text>
<text x="60" y="150" font-size="10" fill="#64748b">塞曼效应：外磁场下能级按 m 分裂</text>
</svg>''',
"perturb": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="120" y1="20" x2="120" y2="140" stroke="#cbd5e1" stroke-width="1"/>
<line x1="30" y1="60" x2="110" y2="60" stroke="#2563eb" stroke-width="2"/>
<line x1="130" y1="50" x2="210" y2="50" stroke="#ef4444" stroke-width="1.5"/>
<line x1="130" y1="70" x2="210" y2="70" stroke="#ef4444" stroke-width="1.5"/>
<text x="14" y="62" font-size="9" fill="#2563eb">Eₙ⁽⁰⁾</text>
<text x="214" y="52" font-size="9" fill="#ef4444">Eₙ⁽⁰⁾+E⁽¹⁾</text>
<text x="124" y="90" font-size="10" fill="#7c3aed">H=H₀+λH'</text>
<text x="50" y="130" font-size="10" fill="#64748b">微扰展开：按 λ 幂级数逐级修正</text>
</svg>''',
"variational": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="30" y1="120" x2="210" y2="120" stroke="#cbd5e1" stroke-width="1"/>
<path d="M 40 110 Q 90 40 140 110 Q 170 130 200 100" fill="none" stroke="#7c3aed" stroke-width="2"/>
<line x1="30" y1="60" x2="210" y2="60" stroke="#ef4444" stroke-width="1" stroke-dasharray="4 3"/>
<text x="14" y="62" font-size="10" fill="#ef4444">E₀</text>
<circle cx="120" cy="55" r="3" fill="#10b981"/>
<text x="124" y="50" font-size="10" fill="#10b981">⟨H⟩ 极小</text>
<text x="50" y="150" font-size="10" fill="#64748b">变分原理：⟨ψ|H|ψ⟩ ≥ E₀</text>
</svg>''',
"stark": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="120" y1="20" x2="120" y2="140" stroke="#cbd5e1" stroke-width="1"/>
<line x1="30" y1="80" x2="110" y2="80" stroke="#2563eb" stroke-width="2"/>
<line x1="130" y1="50" x2="210" y2="50" stroke="#be185d" stroke-width="1.5"/>
<line x1="130" y1="110" x2="210" y2="110" stroke="#be185d" stroke-width="1.5"/>
<text x="14" y="82" font-size="9" fill="#2563eb">E=0</text>
<text x="214" y="52" font-size="9" fill="#be185d">E≠0</text>
<text x="60" y="140" font-size="10" fill="#64748b">斯塔克效应：电场使能级分裂与移动</text>
</svg>''',
"transition": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="30" y1="40" x2="210" y2="40" stroke="#2563eb" stroke-width="1.5"/>
<line x1="30" y1="100" x2="210" y2="100" stroke="#0d9488" stroke-width="1.5"/>
<text x="14" y="42" font-size="10" fill="#2563eb">E₂</text>
<text x="14" y="102" font-size="10" fill="#0d9488">E₁</text>
<line x1="120" y1="40" x2="120" y2="100" stroke="#ef4444" stroke-width="2" marker-end="url(#tarr)"/>
<defs><marker id="tarr" markerWidth="9" markerHeight="9" refX="8" refY="3" orient="auto"><path d="M0,0 L0,6 L9,3 z" fill="#ef4444"/></marker></defs>
<text x="126" y="70" font-size="10" fill="#ef4444">ℏω</text>
<text x="50" y="140" font-size="10" fill="#64748b">跃迁速率 ∝ |⟨f|H'|i⟩|² ρ(E_f)</text>
</svg>''',
"scattering": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<circle cx="120" cy="80" r="14" fill="#fee2e2" stroke="#ef4444" stroke-width="1.5"/>
<text x="110" y="84" font-size="10" fill="#ef4444">靶</text>
<line x1="20" y1="80" x2="100" y2="80" stroke="#2563eb" stroke-width="2" marker-end="url(#sarr)"/>
<line x1="135" y1="65" x2="200" y2="35" stroke="#0d9488" stroke-width="1.5" marker-end="url(#sarr2)"/>
<line x1="135" y1="95" x2="200" y2="125" stroke="#0d9488" stroke-width="1.5" marker-end="url(#sarr2)"/>
<defs><marker id="sarr" markerWidth="8" markerHeight="8" refX="7" refY="3" orient="auto"><path d="M0,0 L0,6 L8,3 z" fill="#2563eb"/></marker>
<marker id="sarr2" markerWidth="8" markerHeight="8" refX="7" refY="3" orient="auto"><path d="M0,0 L0,6 L8,3 z" fill="#0d9488"/></marker></defs>
<text x="30" y="70" font-size="10" fill="#2563eb">入射</text>
<text x="180" y="30" font-size="10" fill="#0d9488">散射</text>
<text x="50" y="150" font-size="10" fill="#64748b">dσ/dΩ = |f(θ)|²</text>
</svg>''',
"partialwave": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="20" y1="80" x2="220" y2="80" stroke="#cbd5e1" stroke-width="1"/>
<path d="M 30 80 Q 60 50 90 80 T 150 80 T 210 80" fill="none" stroke="#2563eb" stroke-width="1.5"/>
<path d="M 30 80 Q 60 50 90 80 T 150 80 T 210 60" fill="none" stroke="#0d9488" stroke-width="1.5" stroke-dasharray="4 2"/>
<text x="40" y="40" font-size="10" fill="#2563eb">入射平面波</text>
<text x="160" y="50" font-size="10" fill="#0d9488">散射出射波</text>
<text x="60" y="140" font-size="10" fill="#64748b">f(θ)=(1/k)Σ(2l+1)e^{iδₗ}sinδₗ Pₗ(cosθ)</text>
</svg>''',
"identical": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<circle cx="80" cy="80" r="20" fill="#dbeafe" stroke="#2563eb" stroke-width="1.5"/>
<circle cx="160" cy="80" r="20" fill="#dbeafe" stroke="#2563eb" stroke-width="1.5"/>
<text x="74" y="84" font-size="11" fill="#1e3a8a">1</text>
<text x="154" y="84" font-size="11" fill="#1e3a8a">2</text>
<path d="M 60 70 Q 120 30 180 70" fill="none" stroke="#7c3aed" stroke-width="1.5" stroke-dasharray="4 2"/>
<path d="M 60 90 Q 120 130 180 90" fill="none" stroke="#be185d" stroke-width="1.5" stroke-dasharray="4 2"/>
<text x="120" y="28" font-size="9" fill="#7c3aed">交换</text>
<text x="40" y="140" font-size="10" fill="#64748b">玻色子对称 ψ(1,2)=ψ(2,1)；费米子反对称</text>
</svg>''',
"secondquant": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<rect x="30" y="40" width="20" height="100" fill="#f1f5f9" stroke="#94a3b8"/>
<rect x="70" y="40" width="20" height="100" fill="#f1f5f9" stroke="#94a3b8"/>
<rect x="110" y="40" width="20" height="100" fill="#f1f5f9" stroke="#94a3b8"/>
<rect x="150" y="40" width="20" height="100" fill="#f1f5f9" stroke="#94a3b8"/>
<circle cx="40" cy="120" r="6" fill="#2563eb"/>
<circle cx="80" cy="90" r="6" fill="#2563eb"/>
<circle cx="120" cy="60" r="6" fill="#2563eb"/>
<circle cx="120" cy="120" r="6" fill="#be185d"/>
<text x="56" y="138" font-size="9" fill="#64748b">a†ₖ</text>
<text x="96" y="138" font-size="9" fill="#64748b">产生算符</text>
<text x="30" y="32" font-size="9" fill="#64748b">k₁</text>
<text x="70" y="32" font-size="9" fill="#64748b">k₂</text>
<text x="110" y="32" font-size="9" fill="#64748b">k₃</text>
<text x="150" y="32" font-size="9" fill="#64748b">k₄</text>
<text x="160" y="140" font-size="9" fill="#64748b">费米子 aₖa†ₖ'+a†ₖ'aₖ=δₖₖ'</text>
</svg>''',
"hartreefock": '''<svg viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
<line x1="120" y1="20" x2="120" y2="140" stroke="#cbd5e1" stroke-width="1"/>
<g fill="#dbeafe" stroke="#2563eb" stroke-width="1.2">
<rect x="60" y="40" width="120" height="14"/>
<rect x="60" y="64" width="120" height="14"/>
<rect x="60" y="88" width="120" height="14"/>
<rect x="60" y="112" width="120" height="14"/>
</g>
<circle cx="120" cy="47" r="4" fill="#ef4444"/>
<circle cx="110" cy="71" r="4" fill="#ef4444"/>
<circle cx="130" cy="71" r="4" fill="#be185d"/>
<circle cx="120" cy="95" r="4" fill="#ef4444"/>
<text x="40" y="52" font-size="9" fill="#64748b">φ₁</text>
<text x="40" y="76" font-size="9" fill="#64748b">φ₂</text>
<text x="40" y="100" font-size="9" fill="#64748b">φ₃</text>
<text x="50" y="150" font-size="10" fill="#64748b">Slater 行列式 ⟹ 泡利不相容</text>
</svg>''',
}

TAG_LABEL = {"def":"定 义","thm":"定 理","der":"推 导","exa":"例 子","app":"应 用","his":"注 记","note":"备 注"}

CORE_FORMULAS = [
    ("德布罗意关系", "\\lambda = \\frac{h}{p},\\quad \\omega = \\frac{E}{\\hbar}", "物质波的波长与动量、角频率与能量的关系"),
    ("波函数统计诠释", "\\rho(\\mathbf{r},t) = |\\psi(\\mathbf{r},t)|^2", "波函数模平方为粒子在该点出现的概率密度"),
    ("归一化条件", "\\int |\\psi(\\mathbf{r},t)|^2 d^3r = 1", "全空间找到粒子的总概率为 1"),
    ("概率流密度", "\\mathbf{j} = \\frac{\\hbar}{2mi}(\\psi^*\\nabla\\psi - \\psi\\nabla\\psi^*)", "概率守恒的流密度矢量"),
    ("连续性方程", "\\frac{\\partial\\rho}{\\partial t} + \\nabla\\cdot\\mathbf{j} = 0", "概率守恒的微分形式"),
    ("薛定谔方程", "i\\hbar\\frac{\\partial\\psi}{\\partial t} = \\hat{H}\\psi", "量子力学的基本运动方程"),
    ("哈密顿算符", "\\hat{H} = -\\frac{\\hbar^2}{2m}\\nabla^2 + V(\\mathbf{r})", "动能与势能算符之和"),
    ("定态薛定谔方程", "\\hat{H}\\psi = E\\psi", "能量本征值方程，定态波函数可分离变量"),
    ("定态波函数", "\\psi(\\mathbf{r},t) = \\psi(\\mathbf{r})e^{-iEt/\\hbar}", "能量本征态的时间演化"),
    ("期望值", "\\langle A \\rangle = \\int \\psi^* \\hat{A} \\psi \\, d^3r", "力学量 A 的量子期望值"),
    ("守恒量条件", "\\frac{d\\langle A\\rangle}{dt} = \\frac{i}{\\hbar}\\langle[\\hat{H},\\hat{A}]\\rangle = 0", "不显含时间且与哈密顿量对易的量为守恒量"),
    ("无限深方势阱能级", "E_n = \\frac{n^2\\pi^2\\hbar^2}{2ma^2},\\quad n=1,2,3,\\cdots", "宽度为 a 的一维无限深势阱的能量本征值"),
    ("无限深方势阱波函数", "\\psi_n(x) = \\sqrt{\\frac{2}{a}}\\sin\\frac{n\\pi x}{a}", "无限深方势阱的归一化定态波函数"),
    ("谐振子哈密顿量", "\\hat{H} = \\frac{\\hat{p}^2}{2m} + \\frac12 m\\omega^2\\hat{x}^2", "一维简谐振子的哈密顿量"),
    ("升降算符", "\\hat{a} = \\sqrt{\\frac{m\\omega}{2\\hbar}}\\left(\\hat{x}+\\frac{i\\hat{p}}{m\\omega}\\right),\\quad \\hat{a}^\\dagger = \\sqrt{\\frac{m\\omega}{2\\hbar}}\\left(\\hat{x}-\\frac{i\\hat{p}}{m\\omega}\\right)", "谐振子湮灭与产生算符"),
    ("对易关系 [a,a†]", "[\\hat{a},\\hat{a}^\\dagger] = 1", "谐振子升降算符的基本对易关系"),
    ("谐振子能级", "E_n = \\left(n+\\frac12\\right)\\hbar\\omega,\\quad n=0,1,2,\\cdots", "谐振子等间距能级，零点能 ℏω/2"),
    ("基态波函数", "\\psi_0(x) = \\left(\\frac{m\\omega}{\\pi\\hbar}\\right)^{1/4} e^{-m\\omega x^2/2\\hbar}", "谐振子基态高斯波函数"),
    ("势垒穿透系数", "T \\approx e^{-2\\kappa a},\\quad \\kappa = \\sqrt{\\frac{2m(V_0-E)}{\\hbar^2}}", "E<V₀ 时方势垒的隧穿概率（厚势垒近似）"),
    ("透射系数精确式", "T = \\frac{1}{1+\\frac{V_0^2\\sinh^2(\\kappa a)}{4E(V_0-E)}}", "方势垒透射系数的精确表达式"),
    ("布洛赫定理", "\\psi_{n\\mathbf{k}}(\\mathbf{r}) = e^{i\\mathbf{k}\\cdot\\mathbf{r}}u_{n\\mathbf{k}}(\\mathbf{r})", "周期势场中波函数为调幅平面波"),
    ("厄米算符定义", "\\int \\psi^* \\hat{A}\\phi\\,d\\tau = \\int (\\hat{A}\\psi)^*\\phi\\,d\\tau", "厄米算符满足的内积条件"),
    ("厄米算符本征值", "\\hat{A}\\psi_n = a_n\\psi_n,\\quad a_n \\in \\mathbb{R}", "厄米算符的本征值必为实数"),
    ("本征函数正交性", "\\int \\psi_m^*\\psi_n\\,d\\tau = \\delta_{mn}", "厄米算符不同本征值的本征函数正交归一"),
    ("完备性", "\\sum_n |\\psi_n\\rangle\\langle\\psi_n| = \\hat{1}", "厄米算符本征函数集的完备性关系"),
    ("对易子", "[\\hat{A},\\hat{B}] = \\hat{A}\\hat{B} - \\hat{B}\\hat{A}", "两个算符的对易子定义"),
    ("坐标动量对易", "[\\hat{x},\\hat{p}] = i\\hbar", "正则对易关系"),
    ("角动量对易", "[\\hat{L}_x,\\hat{L}_y] = i\\hbar\\hat{L}_z", "角动量分量的基本对易关系"),
    ("不确定关系", "\\Delta A\\,\\Delta B \\geq \\frac12|\\langle[\\hat{A},\\hat{B}]\\rangle|", "任意两个力学量的不确定关系"),
    ("位置动量不确定", "\\Delta x\\,\\Delta p \\geq \\frac{\\hbar}{2}", "海森伯位置-动量不确定关系"),
    ("矩阵元", "A_{mn} = \\langle \\psi_m | \\hat{A} | \\psi_n \\rangle", "算符在某表象中的矩阵元"),
    ("本征方程矩阵形式", "\\sum_n (A_{mn} - a\\delta_{mn})c_n = 0", "矩阵形式的本征值方程"),
    ("幺正变换", "\\hat{U}^\\dagger\\hat{U} = \\hat{U}\\hat{U}^\\dagger = \\hat{1}", "幺正算符的定义"),
    ("幺正变换下矩阵", "A' = U A U^\\dagger", "算符矩阵在幺正变换下的变换规则"),
    ("狄拉克符号内积", "\\langle \\phi | \\psi \\rangle = \\int \\phi^*\\psi\\,d\\tau", "bra 与 ket 的内积"),
    ("完备性关系", "\\sum_n |n\\rangle\\langle n| = \\hat{1}", "用狄拉克符号表示的完备性"),
    ("薛定谔绘景态演化", "|\\psi(t)\\rangle = e^{-i\\hat{H}t/\\hbar}|\\psi(0)\\rangle", "薛定谔绘景中态矢的时间演化"),
    ("海森伯方程", "\\frac{d\\hat{A}_H(t)}{dt} = \\frac{i}{\\hbar}[\\hat{H},\\hat{A}_H(t)]", "海森伯绘景中算符的运动方程"),
    ("角动量平方本征值", "\\hat{L}^2|lm\\rangle = l(l+1)\\hbar^2|lm\\rangle", "角动量平方的本征值"),
    ("角动量 z 分量", "\\hat{L}_z|lm\\rangle = m\\hbar|lm\\rangle", "角动量 z 分量的本征值"),
    ("升降算符 L±", "\\hat{L}_\\pm = \\hat{L}_x \\pm i\\hat{L}_y", "角动量升降算符"),
    ("L± 作用", "\\hat{L}_\\pm|lm\\rangle = \\hbar\\sqrt{l(l+1)-m(m\\pm1)}|l,m\\pm1\\rangle", "升降算符作用于角动量本征态"),
    ("球谐函数", "Y_l^m(\\theta,\\varphi) = (-1)^m\\sqrt{\\frac{(2l+1)(l-m)!}{4\\pi(l+m)!}}P_l^m(\\cos\\theta)e^{im\\varphi}", "角动量本征函数"),
    ("氢原子能级", "E_n = -\\frac{me^4}{2\\hbar^2 n^2} = -\\frac{13.6\\,\\text{eV}}{n^2}", "氢原子的束缚态能级"),
    ("玻尔半径", "a_0 = \\frac{\\hbar^2}{me^2} \\approx 0.529\\,\\text{\\AA}", "氢原子基态的特征长度"),
    ("径向方程", "\\left[-\\frac{\\hbar^2}{2m}\\frac{d^2}{dr^2}+\\frac{l(l+1)\\hbar^2}{2mr^2}+V(r)\\right]u(r)=Eu(r)", "中心力场的径向方程，u(r)=rR(r)"),
    ("氢原子径向波函数", "R_{nl}(r) \\propto e^{-r/na_0}\\left(\\frac{2r}{na_0}\\right)^l L_{n-l-1}^{2l+1}\\left(\\frac{2r}{na_0}\\right)", "氢原子径向波函数与关联拉盖尔多项式"),
    ("泡利矩阵", "\\sigma_x=\\begin{pmatrix}0&1\\\\1&0\\end{pmatrix},\\ \\sigma_y=\\begin{pmatrix}0&-i\\\\i&0\\end{pmatrix},\\ \\sigma_z=\\begin{pmatrix}1&0\\\\0&-1\\end{pmatrix}", "描述自旋 1/2 的泡利矩阵"),
    ("泡利矩阵对易", "[\\sigma_i,\\sigma_j] = 2i\\varepsilon_{ijk}\\sigma_k", "泡利矩阵的对易关系"),
    ("泡利矩阵反对易", "\\{\\sigma_i,\\sigma_j\\} = 2\\delta_{ij}", "泡利矩阵的反对易关系"),
    ("自旋算符", "\\hat{\\mathbf{S}} = \\frac{\\hbar}{2}\\boldsymbol{\\sigma}", "电子自旋算符与泡利矩阵的关系"),
    ("自旋本征态", "|\\uparrow\\rangle=\\begin{pmatrix}1\\\\0\\end{pmatrix},\\quad |\\downarrow\\rangle=\\begin{pmatrix}0\\\\1\\end{pmatrix}", "自旋沿 z 轴的本征态"),
    ("CG 系数定义", "|JM\\rangle = \\sum_{m_1m_2}\\langle j_1m_1j_2m_2|JM\\rangle|j_1m_1\\rangle|j_2m_2\\rangle", "角动量耦合的克莱布希-高登系数"),
    ("耦合角动量范围", "|j_1-j_2| \\leq J \\leq j_1+j_2", "两个角动量耦合后总角动量的取值范围"),
    ("自旋轨道耦合", "\\hat{H}_{SO} = \\xi(r)\\hat{\\mathbf{L}}\\cdot\\hat{\\mathbf{S}}", "自旋-轨道耦合相互作用哈密顿量"),
    ("L·S 表达式", "\\hat{\\mathbf{L}}\\cdot\\hat{\\mathbf{S}} = \\frac12(\\hat{J}^2-\\hat{L}^2-\\hat{S}^2)", "用总角动量表示的 L·S"),
    ("塞曼效应哈密顿", "\\hat{H}_Z = \\frac{eB}{2m_e}(\\hat{L}_z+2\\hat{S}_z)", "外磁场中的塞曼相互作用"),
    ("非简并微扰一级能移", "E_n^{(1)} = \\langle n^{(0)}|\\hat{H}'|n^{(0)}\\rangle", "非简并定态微扰论一级能量修正"),
    ("非简并微扰二级能移", "E_n^{(2)} = \\sum_{k\\neq n}\\frac{|\\langle k^{(0)}|\\hat{H}'|n^{(0)}\\rangle|^2}{E_n^{(0)}-E_k^{(0)}}", "非简并微扰论二级能量修正"),
    ("非简并波函数一级修正", "|n^{(1)}\\rangle = \\sum_{k\\neq n}\\frac{\\langle k^{(0)}|\\hat{H}'|n^{(0)}\\rangle}{E_n^{(0)}-E_k^{(0)}}|k^{(0)}\\rangle", "微扰论一级波函数修正"),
    ("简并微扰久期方程", "\\det(H'_{ij}-E^{(1)}\\delta_{ij}) = 0", "简并情况下求解一级修正的久期方程"),
    ("变分原理", "\\langle\\psi|\\hat{H}|\\psi\\rangle \\geq E_0", "任意试探波函数的能量期望不低于基态能量"),
    ("瑞利-里兹变分", "E_0 \\leq \\frac{\\langle\\psi|\\hat{H}|\\psi\\rangle}{\\langle\\psi|\\psi\\rangle}", "基态能量的变分上界"),
    ("氢原子极化率", "\\alpha = \\frac{9}{2}a_0^3", "氢原子基态的电极化率"),
    ("斯塔克效应能移", "\\Delta E = -\\frac12\\alpha E^2", "外电场中原子能级的二次斯塔克移动"),
    ("含时微扰一级振幅", "c_f^{(1)}(t) = -\\frac{i}{\\hbar}\\int_0^t \\langle f|\\hat{H}'(t')|i\\rangle e^{i\\omega_{fi}t'}dt'", "含时微扰论一级跃迁振幅"),
    ("费米黄金规则", "\\Gamma_{i\\to f} = \\frac{2\\pi}{\\hbar}|\\langle f|\\hat{H}'|i\\rangle|^2\\rho(E_f)", "连续谱末态的跃迁速率"),
    ("跃迁频率", "\\omega_{fi} = \\frac{E_f-E_i}{\\hbar}", "初末态能量差对应的角频率"),
    ("电偶极跃迁矩阵元", "\\mathbf{d}_{fi} = \\langle f|e\\mathbf{r}|i\\rangle", "电偶极辐射的跃迁矩阵元"),
    ("电偶极选择定则", "\\Delta l = \\pm1,\\quad \\Delta m = 0,\\pm1", "电偶极辐射的角量子数选择定则"),
    ("散射截面", "\\sigma = \\int |f(\\theta)|^2 d\\Omega", "总散射截面与散射振幅的关系"),
    ("分波展开", "f(\\theta) = \\frac{1}{k}\\sum_{l=0}^\\infty (2l+1)e^{i\\delta_l}\\sin\\delta_l\\,P_l(\\cos\\theta)", "散射振幅按分波的展开"),
    ("分波截面", "\\sigma_l = \\frac{4\\pi}{k^2}(2l+1)\\sin^2\\delta_l", "第 l 分波对散射截面的贡献"),
    ("玻恩近似一阶", "f(\\theta) = -\\frac{m}{2\\pi\\hbar^2}\\int V(\\mathbf{r}')e^{i(\\mathbf{k}-\\mathbf{k}')\\cdot\\mathbf{r}'}d^3r'", "一阶玻恩近似的散射振幅"),
    ("玻恩近似形式", "f(\\theta) = -\\frac{m}{2\\pi\\hbar^2}\\tilde{V}(\\mathbf{q}),\\quad \\mathbf{q}=\\mathbf{k}-\\mathbf{k}'", "散射振幅为势的傅里叶变换"),
    ("全同粒子波函数对称性", "\\psi(1,2) = \\pm\\psi(2,1)", "玻色子对称、费米子反对称"),
    ("产生湮灭算符（玻色子）", "[\\hat{a}_\\mathbf{k},\\hat{a}_{\\mathbf{k}'}^\\dagger] = \\delta_{\\mathbf{k}\\mathbf{k}'}", "玻色子二次量子化算符的对易关系"),
    ("产生湮灭算符（费米子）", "\\{\\hat{c}_\\mathbf{k},\\hat{c}_{\\mathbf{k}'}^\\dagger\\} = \\delta_{\\mathbf{k}\\mathbf{k}'}", "费米子二次量子化算符的反对易关系"),
    ("粒子数算符", "\\hat{N} = \\sum_\\mathbf{k} \\hat{a}_\\mathbf{k}^\\dagger\\hat{a}_\\mathbf{k}", "二次量子化中的总粒子数算符"),
    ("Slater 行列式", "\\psi = \\frac{1}{\\sqrt{N!}}\\det[\\phi_i(\\mathbf{r}_j)]", "N 个费米子的反对称波函数"),
]

def js_escape(s):
    return s.replace("\\","\\\\").replace("`","\\`").replace("${","\\${")
def fix_lt_math(s):
    import re
    return re.sub(r"\$\$[\s\S]*?\$\$|\$[^$\n]*?\$", lambda m: m.group(0).replace("<", "&lt;"), s)
def defn(t, body): return f'<section class="la-kp-sec la-kp-def"><h5>定 义</h5><p><strong>{t}</strong></p>{body}</section>'
def thm(t, body): return f'<section class="la-kp-sec la-kp-thm"><h5>定 理 · {t}</h5>{body}</section>'
def der(body): return f'<section class="la-kp-sec la-kp-der"><h5>推 导</h5>{body}</section>'
def exa(body): return f'<section class="la-kp-sec la-kp-exa"><h5>例 子</h5>{body}</section>'
def app(body): return f'<section class="la-kp-sec la-kp-app"><h5>应 用</h5>{body}</section>'
def note(body): return f'<section class="la-kp-sec la-kp-note"><h5>备 注</h5>{body}</section>'
def fml(latex, caption=""):
    cap = f'<span class="note">{caption}</span>' if caption else ""
    return f'<div class="la-fml">$${latex}$$ {cap}</div>'
def p(txt): return f'<p>{txt}</p>'
def wrap(body): return f'<div class="la-kp">{body}</div>'

ch1_sections = [
{
"name": "1.1 波函数的统计诠释",
"color": "#7c3aed",
"desc": "波函数的概率诠释、归一化与概率流密度",
"items": [
{"id":"qm1s1-1","name":"波函数与统计诠释","tags":["def","der"],"brief":"波函数模平方给出粒子位置的概率密度。",
 "fig":"wavepacket","figCap":"波包：许多平面波叠加形成的局域态",
 "body": wrap(
   defn("波函数的统计诠释",p("微观粒子的状态由波函数 $\\psi(\\mathbf{r},t)$ 描述，其模平方 $|\\psi(\\mathbf{r},t)|^2$ 表示 $t$ 时刻在位置 $\\mathbf{r}$ 处单位体积内找到粒子的概率，即概率密度：")+
   fml("\\rho(\\mathbf{r},t) = |\\psi(\\mathbf{r},t)|^2")+
   p("这是玻恩于 1926 年提出的统计诠释，是量子力学的基本假设之一。"))+
   der(p("<strong>由双缝实验理解：</strong>电子双缝实验中，单个电子落点随机，但大量电子形成与光相同的干涉条纹。设波函数 $\\psi=\\psi_1+\\psi_2$，则概率分布为：")+
   fml("|\\psi|^2 = |\\psi_1|^2+|\\psi_2|^2+\\psi_1^*\\psi_2+\\psi_1\\psi_2^*")+
   p("后两项为干涉项，正是条纹的来源。单个电子的行为由概率描述，而非确定轨道。"))+
   note(p("波函数本身不可直接测量，可测量的是概率（模平方）及由算符得到的期望值；相位差可通过干涉效应间接观测。"))+
   app(p("<strong>实验验证：</strong>电子双缝、中子干涉、C60 富勒烯干涉等实验均证实物质波的统计诠释。单电子双缝实验中，逐个发射的电子长时间累积后形成干涉条纹，证明波函数描述的是单个粒子的概率幅，而非大量粒子的统计分布。量子力学的概率性是内禀的，并非源于信息不完备。"))
 )},
{"id":"qm1s1-2","name":"归一化条件","tags":["def","der"],"brief":"全空间概率和为 1 要求波函数归一化。",
 "body": wrap(
   defn("归一化",p("由于粒子必然在空间某处出现，全空间概率积分应等于 1：")+
   fml("\\int |\\psi(\\mathbf{r},t)|^2 d^3r = 1")+
   p("若波函数未归一化，可乘以常数 $N$ 使之满足 $\\int |N\\psi|^2 d^3r=1$，即 $N=1/\\sqrt{\\int|\\psi|^2 d^3r}$。"))+
   der(p("<strong>归一化常数不随时间变化：</strong>对归一化积分求时间导数：")+
   fml("\\frac{d}{dt}\\int|\\psi|^2 d^3r = \\int(\\psi^*\\dot\\psi+\\dot\\psi^*\\psi)d^3r")+
   p("代入薛定谔方程 $i\\hbar\\dot\\psi=\\hat{H}\\psi$ 及其共轭，利用哈密顿量厄米性可证上式为零，故归一化在演化中保持不变。"))+
   note(p("对散射态等非束缚态，波函数不能按通常方式归一化，需采用箱归一化或 $\\delta$ 函数归一化。"))+
   note(p("<strong>相对相位的物理意义：</strong>归一化只确定波函数的模，整体相位 $e^{i\\theta}$ 不影响物理结果（规范自由度）。但两个波函数叠加时的<strong>相对相位</strong>至关重要，它决定干涉条纹的位置与对比度。态叠加原理与相对相位共同构成量子干涉的数学基础。"))
 )},
{"id":"qm1s1-3","name":"概率流密度与连续性方程","tags":["der","thm"],"brief":"概率守恒由连续性方程与概率流描述。",
 "body": wrap(
   defn("概率流密度",p("定义概率流密度矢量 $\\mathbf{j}$，表示单位时间通过单位面积的概率：")+
   fml("\\mathbf{j} = \\frac{\\hbar}{2mi}(\\psi^*\\nabla\\psi - \\psi\\nabla\\psi^*)")+
   p("对自由粒子平面波 $\\psi=Ae^{i\\mathbf{k}\\cdot\\mathbf{r}}$，得 $\\mathbf{j}=|A|^2\\hbar\\mathbf{k}/m=|A|^2\\mathbf{v}$，符合经典流密度的直觉。"))+
   thm("连续性方程",p("概率守恒要求概率密度与流密度满足连续性方程：")+
   fml("\\frac{\\partial\\rho}{\\partial t} + \\nabla\\cdot\\mathbf{j} = 0"))+
   der(p("<strong>推导：</strong>由薛定谔方程 $i\\hbar\\partial_t\\psi=-(\\hbar^2/2m)\\nabla^2\\psi+V\\psi$ 及其共轭，取模平方的时间导数：")+
   fml("\\partial_t|\\psi|^2 = \\psi^*\\dot\\psi+\\dot\\psi^*\\psi = \\frac{i\\hbar}{2m}(\\psi^*\\nabla^2\\psi-\\psi\\nabla^2\\psi^*)")+
   p("利用恒等式 $\\psi^*\\nabla^2\\psi-\\psi\\nabla^2\\psi^*=\\nabla\\cdot(\\psi^*\\nabla\\psi-\\psi\\nabla\\psi^*)$，整理即得连续性方程，表明概率局域守恒。"))
 )},
]},
{
"name": "1.2 薛定谔方程的建立",
"color": "#7c3aed",
"desc": "从德布罗意关系与能量守恒导出薛定谔方程",
"items": [
{"id":"qm1s2-1","name":"德布罗意关系与物质波","tags":["def","der"],"brief":"粒子具有波动性，波长与动量成反比。",
 "body": wrap(
   defn("德布罗意关系",p("德布罗意提出，一切实物粒子都具有波粒二象性，其波长与动量、频率与能量满足：")+
   fml("\\lambda = \\frac{h}{p},\\qquad \\nu = \\frac{E}{h}\\quad\\Longleftrightarrow\\quad \\mathbf{p}=\\hbar\\mathbf{k},\\ E=\\hbar\\omega")+
   p("其中 $\\hbar=h/(2\\pi)$，$\\mathbf{k}$ 为波矢，$\\omega$ 为角频率。"))+
   der(p("<strong>自由粒子平面波：</strong>对能量 $E=p^2/(2m)$ 的自由粒子，德布罗意波为平面波：")+
   fml("\\psi(\\mathbf{r},t) = A e^{i(\\mathbf{k}\\cdot\\mathbf{r}-\\omega t)} = A e^{i(\\mathbf{p}\\cdot\\mathbf{r}-Et)/\\hbar}")+
   p("对时间求偏导得 $i\\hbar\\partial_t\\psi=E\\psi$，对空间求梯度得 $-i\\hbar\\nabla\\psi=\\mathbf{p}\\psi$，这暗示算符替换 $E\\to i\\hbar\\partial_t$、$\\mathbf{p}\\to -i\\hbar\\nabla$。"))+
   note(p("电子衍射实验（戴维逊-革末、G.P.汤姆逊）证实了物质波的存在，德布罗意因此获 1929 年诺贝尔物理学奖。"))
 )},
{"id":"qm1s2-2","name":"薛定谔方程的建立","tags":["der","thm"],"brief":"由能量关系与算符替换导出薛定谔方程。",
 "body": wrap(
   thm("薛定谔方程",p("质量为 $m$、在势场 $V(\\mathbf{r})$ 中运动的粒子，其波函数满足：")+
   fml("i\\hbar\\frac{\\partial\\psi}{\\partial t} = \\left[-\\frac{\\hbar^2}{2m}\\nabla^2 + V(\\mathbf{r})\\right]\\psi = \\hat{H}\\psi"))+
   der(p("<strong>推导：</strong>经典能量关系 $E=p^2/(2m)+V(\\mathbf{r})$。将能量与动量替换为算符：")+
   fml("E \\to i\\hbar\\frac{\\partial}{\\partial t},\\qquad \\mathbf{p} \\to -i\\hbar\\nabla")+
   p("作用于波函数 $\\psi$ 上，得到：")+
   fml("i\\hbar\\frac{\\partial\\psi}{\\partial t} = -\\frac{\\hbar^2}{2m}\\nabla^2\\psi + V(\\mathbf{r})\\psi")+
   p("这就是含时薛定谔方程。它是线性、齐次的偏微分方程，保证了态叠加原理成立；一阶时间导数决定了给定初态 $\\psi(\\mathbf{r},0)$ 后整个时间演化被唯一确定。"))+
   note(p("薛定谔方程是非相对论性的，不适用于速度接近光速的粒子；后者需用狄拉克方程或克莱因-戈登方程。"))+
   note(p("<strong>薛定谔方程的地位与性质：</strong>薛定谔方程是量子力学的基本运动方程，其地位相当于经典力学中的牛顿第二定律。它具有几个关键性质：<strong>线性性</strong>——方程是线性的，故满足叠加原理，两个解的线性组合仍是解；<strong>幺正性</strong>——时间演化算符 $\\hat{U}(t)=e^{-i\\hat{H}t/\\hbar}$ 是幺正的，保证概率守恒与内积不变；<strong>确定性</strong>——给定初始波函数，未来演化完全确定，随机性仅在测量时出现（波函数坍缩）。薛定谔于 1926 年建立波动力学，同年证明与海森伯的矩阵力学等价，共同构成非相对论量子力学的完整框架。"))
 )},
{"id":"qm1s2-3","name":"波函数的标准条件","tags":["def","der"],"brief":"波函数须单值、有限、连续且导数连续。",
 "body": wrap(
   defn("标准条件",p("物理上可接受的波函数必须满足：<strong>单值</strong>（概率唯一）、<strong>有限</strong>（概率密度有限）、<strong>连续</strong>（概率连续），且在势场有限阶跃处一阶导数也连续。"))+
   der(p("<strong>导数连续性的来源：</strong>对一维薛定谔方程 $-\\frac{\\hbar^2}{2m}\\psi''+V\\psi=E\\psi$ 在 $x_0$ 邻域 $[x_0-\\varepsilon,x_0+\\varepsilon]$ 积分：")+
   fml("-\\frac{\\hbar^2}{2m}[\\psi'(x_0+\\varepsilon)-\\psi'(x_0-\\varepsilon)]+\\int_{x_0-\\varepsilon}^{x_0+\\varepsilon}(V-E)\\psi\\,dx=0")+
   p("若 $V$ 在 $x_0$ 处有限（或有限阶跃），积分项随 $\\varepsilon\\to0$ 趋于零，故 $\\psi'(x_0^+)=\\psi'(x_0^-)$，即导数连续。若 $V$ 为无穷大跳跃（如无限深势阱壁），则导数可不连续。"))+
   note(p("波函数的标准条件是求解定态问题时得到能量量子化的关键：只有满足边界条件的解才对应物理上可实现的态。"))+
   note(p("<strong>边界条件的作用：</strong>波函数的标准条件与边界条件共同决定了能量的量子化。在无限深势阱中，波函数在边界为零的条件直接导致 $k=n\\pi/a$，从而 $E_n\\propto n^2$；在三维中心力场中，波函数在 $r=0$ 处有限（排除 $r^{-l-1}$ 发散解）与 $r\\to\\infty$ 处束缚态衰减的条件，分别给出角向与径向量子化。可以说，<strong>量子化是边界条件的数学结果</strong>，而非人为假设。对于散射态，边界条件为无穷远的平面波加出射球面波，此时能量连续。"))
 )},
]},
{
"name": "1.3 定态薛定谔方程",
"color": "#7c3aed",
"desc": "定态分离变量、能量本征值与定态性质",
"items": [
{"id":"qm1s3-1","name":"定态与分离变量","tags":["der","thm"],"brief":"势能不显含时间时可用分离变量求解。",
 "body": wrap(
   thm("定态薛定谔方程",p("当 $V(\\mathbf{r})$ 不显含时间时，令 $\\psi(\\mathbf{r},t)=\\psi(\\mathbf{r})f(t)$，代入薛定谔方程分离变量得：")+
   fml("\\hat{H}\\psi(\\mathbf{r}) = E\\psi(\\mathbf{r}),\\qquad f(t)=e^{-iEt/\\hbar}"))+
   der(p("<strong>分离变量推导：</strong>将 $\\psi(\\mathbf{r},t)=\\psi(\\mathbf{r})f(t)$ 代入 $i\\hbar\\partial_t\\psi=\\hat{H}\\psi$：")+
   fml("i\\hbar\\psi(\\mathbf{r})f'(t) = f(t)\\hat{H}\\psi(\\mathbf{r})")+
   p("两边除以 $\\psi f$，左边只与 $t$ 有关，右边只与 $\\mathbf{r}$ 有关，故等于同一常数 $E$：")+
   fml("i\\hbar\\frac{f'}{f}=E \\implies f(t)=Ce^{-iEt/\\hbar},\\qquad \\hat{H}\\psi=E\\psi")+
   p("其中 $E$ 具有能量量纲，称为能量本征值，$\\psi(\\mathbf{r})$ 为能量本征函数。"))+
   note(p("定态是能量取确定值的状态，其概率密度 $|\\psi|^2$ 不随时间变化，任何力学量的期望值也不随时间变化。"))+
   note(p("<strong>定态叠加与非定态：</strong>虽然单个定态的概率密度不随时间变化，但多个定态的叠加一般不是定态。例如 $\\psi=c_1\\psi_{E_1}e^{-iE_1t/\\hbar}+c_2\\psi_{E_2}e^{-iE_2t/\\hbar}$，其概率密度 $|\\psi|^2=|c_1|^2|\\psi_{E_1}|^2+|c_2|^2|\\psi_{E_2}|^2+2\\text{Re}(c_1^*c_2\\psi_{E_1}^*\\psi_{E_2}e^{i(E_2-E_1)t/\\hbar})$ 含时间振荡项，频率为 $(E_2-E_1)/\\hbar$。这正是量子跃迁与辐射的物理基础：原子处于定态叠加时，电偶极矩随时间振荡，从而辐射或吸收光子。量子拍（quantum beat）现象即源于此。"))
 )},
{"id":"qm1s3-2","name":"定态的性质","tags":["thm","der"],"brief":"定态下概率密度与力学量期望不随时间变化。",
 "body": wrap(
   thm("定态性质",p("定态 $\\psi(\\mathbf{r},t)=\\psi_E(\\mathbf{r})e^{-iEt/\\hbar}$ 具有以下性质：(1) 概率密度 $|\\psi|^2$ 与时间无关；(2) 任何不显含时间的力学量的期望值与时间无关；(3) 测量能量必得到 $E$。"))+
   der(p("<strong>力学量期望的时间无关性：</strong>对不显含时间的算符 $\\hat{A}$，其期望值为：")+
   fml("\\langle A\\rangle = \\int \\psi^*\\hat{A}\\psi\\,d^3r = \\int \\psi_E^*e^{iEt/\\hbar}\\hat{A}\\psi_E e^{-iEt/\\hbar}d^3r = \\int\\psi_E^*\\hat{A}\\psi_E\\,d^3r")+
   p("时间相位因子相消，故 $\\langle A\\rangle$ 与时间无关。概率密度 $|\\psi|^2=|\\psi_E|^2$ 同理不随时间变化。"))+
   exa(p("<strong>例：</strong>哈密顿量本身在定态下 $\\langle H\\rangle=E$，且 $\\Delta H=0$，即能量完全确定。"))
 )},
{"id":"qm1s3-3","name":"叠加态与时间演化","tags":["der"],"brief":"一般态是定态的线性组合，各分量独立演化。",
 "body": wrap(
   defn("叠加态",p("若 $\\psi_n(\\mathbf{r})$ 是 $\\hat{H}$ 的本征态，对应能量 $E_n$，则一般态可展开为：")+
   fml("\\psi(\\mathbf{r},t) = \\sum_n c_n \\psi_n(\\mathbf{r})e^{-iE_n t/\\hbar}")+
   p("其中展开系数 $c_n$ 由初始条件确定，$|c_n|^2$ 为测量能量得到 $E_n$ 的概率。"))+
   der(p("<strong>由初态确定展开系数：</strong>设 $t=0$ 时 $\\psi(\\mathbf{r},0)=\\sum_n c_n\\psi_n(\\mathbf{r})$，利用本征函数正交性 $\\int\\psi_m^*\\psi_n d^3r=\\delta_{mn}$：")+
   fml("c_n = \\int \\psi_n^*(\\mathbf{r})\\psi(\\mathbf{r},0)\\,d^3r = \\langle\\psi_n|\\psi(0)\\rangle")+
   p("各定态分量以各自相位 $e^{-iE_nt/\\hbar}$ 独立演化，叠加后产生量子拍频等含时现象。"))+
   note(p("只有当态是单一能量本征态时才是真正的定态；叠加态一般不是定态，其概率分布与力学量期望可随时间振荡。"))+
   note(p("<strong>量子拍频与相干性：</strong>当体系处于两个能量本征态的叠加 $\\psi=c_1\\psi_1e^{-iE_1t/\\hbar}+c_2\\psi_2e^{-iE_2t/\\hbar}$ 时，概率密度 $|\\psi|^2=|c_1|^2|\\psi_1|^2+|c_2|^2|\\psi_2|^2+2c_1^*c_2\\psi_1^*\\psi_2\\cos((E_2-E_1)t/\\hbar)$，以角频率 $\\omega_{21}=(E_2-E_1)/\\hbar$ 振荡，称为量子拍频。这种振荡是量子相干性的直接体现：两定态分量保持确定相位关系，干涉产生时间依赖的可观测效应。若体系与环境耦合导致相位随机化（退相干），拍频将被阻尼。量子拍频在原子物理（如能级寿命测量）、量子信息（量子比特操纵）中有重要应用。"))
 )},
]},
{
"name": "1.4 守恒量与对称性",
"color": "#7c3aed",
"desc": "守恒量的判据、对称性与诺特定理、宇称",
"items": [
{"id":"qm1s4-1","name":"守恒量的判据","tags":["thm","der"],"brief":"不显含时间且与哈密顿量对易的量为守恒量。",
 "body": wrap(
   thm("守恒量判据",p("若力学量 $A$ 不显含时间（$\\partial_t\\hat{A}=0$）且与哈密顿量对易 $[\\hat{H},\\hat{A}]=0$，则 $A$ 为守恒量，其期望值与概率分布都不随时间变化。"))+
   der(p("<strong>期望值的时间演化：</strong>对 $\\langle A\\rangle=\\langle\\psi|\\hat{A}|\\psi\\rangle$ 求导：")+
   fml("\\frac{d\\langle A\\rangle}{dt} = \\left\\langle\\frac{\\partial\\hat{A}}{\\partial t}\\right\\rangle + \\frac{1}{i\\hbar}\\langle[\\hat{A},\\hat{H}]\\rangle")+
   p("当 $\\partial_t\\hat{A}=0$ 且 $[\\hat{A},\\hat{H}]=0$ 时 $d\\langle A\\rangle/dt=0$。进一步可证测量 $A$ 得各本征值的概率也不随时间改变。"))+
   exa(p("<strong>例：</strong>自由粒子 $\\hat{H}=\\hat{p}^2/(2m)$，动量 $\\hat{p}$ 与 $\\hat{H}$ 对易，故动量守恒；中心力场中 $\\hat{H}$ 与 $\\hat{L}^2,\\hat{L}_z$ 对易，故角动量守恒。"))
 )},
{"id":"qm1s4-2","name":"对称性与守恒律","tags":["der","app"],"brief":"连续对称性对应守恒律（诺特定理）。",
 "body": wrap(
   defn("对称性",p("若体系在某种变换 $\\hat{U}$ 下哈密顿量不变 $\\hat{U}\\hat{H}\\hat{U}^\\dagger=\\hat{H}$，即 $[\\hat{U},\\hat{H}]=0$，则称体系具有该变换下的对称性。"))+
   der(p("<strong>诺特定理（量子版）：</strong>连续对称变换可写为 $\\hat{U}(\\epsilon)=e^{-i\\epsilon\\hat{G}/\\hbar}$（$\\hat{G}$ 为厄米生成元）。由 $[\\hat{U},\\hat{H}]=0$ 对无穷小 $\\epsilon$ 展开得：")+
   fml("[\\hat{G},\\hat{H}] = 0")+
   p("故生成元 $\\hat{G}$ 是守恒量。例如：空间平移对称性对应动量守恒，时间平移对应能量守恒，空间旋转对应角动量守恒。"))+
   app(p("<strong>应用：</strong>中心力场具有旋转对称性，故角动量守恒；晶格具有离散平移对称性，故准动量（布洛赫波矢）守恒。对称性分析是简化量子力学问题的有力工具。"))+
   note(p("<strong>对称性的方法论价值：</strong>在量子力学中，对称性不仅给出守恒律，还能深刻简化问题求解。例如，中心力场中角动量守恒使波函数可分离为径向函数与球谐函数，将三维问题降为一维径向问题。通过对称性可以判断矩阵元的选择定则（角向选择定则 $\\Delta l=\\pm1$）、能级简并度（如氢原子的 $n^2$ 简并源于 SO(4) 对称性）等。在粒子物理中，内部对称性（同位旋、SU(3) 色、SU(2) 弱等）是分类基本粒子与相互作用的核心工具。可以说，对称性是现代物理学的第一原理。"))
 )},
{"id":"qm1s4-3","name":"宇称","tags":["def","der"],"brief":"空间反演对称性对应宇称守恒。",
 "body": wrap(
   defn("宇称",p("空间反演算符 $\\hat{P}$ 定义为 $\\hat{P}\\psi(\\mathbf{r})=\\psi(-\\mathbf{r})$。若 $\\hat{P}\\psi=\\pm\\psi$，则称态具有偶宇称（+）或奇宇称（-）。"))+
   der(p("<strong>宇称的本征值：</strong>两次反演 $\\hat{P}^2\\psi(\\mathbf{r})=\\psi(\\mathbf{r})$，故 $\\hat{P}^2=1$，本征值 $p$ 满足 $p^2=1$，即 $p=\\pm1$。若势能是偶函数 $V(-\\mathbf{r})=V(\\mathbf{r})$，则 $[\\hat{P},\\hat{H}]=0$，宇称为守恒量，定态波函数具有确定宇称。"))+
   exa(p("<strong>例：</strong>一维谐振子波函数 $\\psi_n(-x)=(-1)^n\\psi_n(x)$，宇称为 $(-1)^n$；中心力场波函数的宇称由角量子数 $l$ 决定，为 $(-1)^l$。"))+
   note(p("弱相互作用中宇称不守恒（李政道、杨振宁 1956 年提出，吴健雄实验证实），这是对称性破缺的著名例子。"))
 )},
]},
]

ch2_sections = [
{
"name": "2.1 一维无限深势阱",
"color": "#2563eb",
"desc": "无限深方势阱的能级、波函数与性质",
"items": [
{"id":"qm2s1-1","name":"无限深方势阱的能级","tags":["der","thm"],"brief":"边界条件导致能量量子化。",
 "fig":"infinitewell","figCap":"一维无限深方势阱的能级与波函数",
 "body": wrap(
   thm("无限深方势阱能级",p("宽度为 $a$ 的一维无限深方势阱中粒子的能量本征值为：")+
   fml("E_n = \\frac{n^2\\pi^2\\hbar^2}{2ma^2},\\quad n=1,2,3,\\cdots"))+
   der(p("<strong>推导：</strong>势阱内 $V=0$，薛定谔方程为 $-\\frac{\\hbar^2}{2m}\\psi''=E\\psi$，通解为 $\\psi(x)=A\\sin kx+B\\cos kx$，$k=\\sqrt{2mE}/\\hbar$。边界条件 $\\psi(0)=\\psi(a)=0$：")+
   fml("\\psi(0)=B=0,\\qquad \\psi(a)=A\\sin(ka)=0 \\implies ka=n\\pi")+
   p("故 $k_n=n\\pi/a$，代入 $E=\\hbar^2k^2/(2m)$ 得 $E_n=n^2\\pi^2\\hbar^2/(2ma^2)$。$n=0$ 给出零解（无物理意义），故 $n\\geq1$，基态能量 $E_1=\\pi^2\\hbar^2/(2ma^2)>0$，即零点能。"))+
   note(p("能量量子化完全来自边界条件，而非方程本身；零点能的存在是不确定关系的必然结果。"))+
   app(p("<strong>应用与推广：</strong>无限深势阱是量子限域效应的最简模型。半导体量子阱（如 GaAs/AlGaAs 异质结）中电子被限制在纳米尺度，能级离散化，导致吸收光谱的蓝移与量子化光电导。碳纳米管、量子点中的电子态也可用势阱模型描述。此外，粒子在圆周上运动（周期性边界条件）给出 $E_n=n^2\\hbar^2/(2mR^2)$，与势阱的正弦解形成对比。"))
 )},
{"id":"qm2s1-2","name":"波函数与正交归一","tags":["der"],"brief":"正弦波函数满足正交归一完备性。",
 "body": wrap(
   defn("本征波函数",p("归一化的本征波函数为：")+
   fml("\\psi_n(x) = \\sqrt{\\frac{2}{a}}\\sin\\frac{n\\pi x}{a},\\quad 0<x<a"))+
   der(p("<strong>归一化与正交性：</strong>归一化条件 $\\int_0^a|\\psi_n|^2dx=1$：")+
   fml("|A|^2\\int_0^a\\sin^2\\frac{n\\pi x}{a}dx = |A|^2\\cdot\\frac{a}{2}=1 \\implies A=\\sqrt{2/a}")+
   p("正交性利用 $\\int_0^a\\sin(n\\pi x/a)\\sin(m\\pi x/a)dx=\\frac{a}{2}\\delta_{mn}$，故：")+
   fml("\\int_0^a\\psi_m^*(x)\\psi_n(x)dx = \\delta_{mn}")+
   p("这组函数在 $[0,a]$ 上构成完备正交系，任意满足边界条件的波函数可展开为傅里叶正弦级数。"))+
   exa(p("<strong>例：</strong>基态 $n=1$ 在 $x=a/2$ 处概率密度最大；第一激发态 $n=2$ 在 $x=a/2$ 处为节点（概率为零）。节点数随 $n$ 增多。"))
 )},
{"id":"qm2s1-3","name":"有限深势阱","tags":["der"],"brief":"有限深势阱存在隧穿且束缚态数有限。",
 "body": wrap(
   defn("有限深对称方势阱",p("势能 $V(x)=0$（$|x|<a/2$），$V(x)=V_0$（$|x|>a/2$）。当 $E<V_0$ 时存在束缚态，波函数在阱外指数衰减。"))+
   der(p("<strong>偶宇称束缚态：</strong>阱内 $\\psi(x)=A\\cos kx$（偶宇称），$k=\\sqrt{2mE}/\\hbar$；阱外 $\\psi(x)=Be^{-\\kappa|x|}$，$\\kappa=\\sqrt{2m(V_0-E)}/\\hbar$。在 $x=a/2$ 处 $\\psi$ 与 $\\psi'$ 连续：")+
   fml("A\\cos\\frac{ka}{2}=Be^{-\\kappa a/2},\\quad -Ak\\sin\\frac{ka}{2}=-B\\kappa e^{-\\kappa a/2}")+
   p("两式相除得超越方程 $k\\tan(ka/2)=\\kappa$。结合 $k^2+\\kappa^2=2mV_0/\\hbar^2$，可用图解法求束缚态能级。束缚态数目有限，由 $V_0a^2$ 决定。"))+
   note(p("无论势阱多浅多窄，至少存在一个偶宇称束缚态；奇宇称态需要一定深度才能存在。阱外波函数非零即量子隧穿效应。"))+
   note(p("<strong>有限深势阱的物理意义：</strong>有限深势阱是无限深势阱向真实物理的过渡。束缚态能量的超越方程无法解析求解，需图解或数值法，这体现了大多数量子力学问题需近似处理的现实。阱外波函数的指数衰减是量子隧穿的原型：粒子有概率出现在经典禁区（$E<V$）。这一效应导致了 $\\alpha$ 衰变（伽莫夫隧穿理论）、扫描隧道显微镜（STM）、约瑟夫森结等重要现象。有限深势阱也是量子点（quantum dot）的简化模型，量子点中电子被限制在有限势阱内，形成离散能级，具有类原子的光学与电学性质。"))
 )},
]},
{
"name": "2.2 一维谐振子",
"color": "#2563eb",
"desc": "谐振子能级、升降算符与波函数",
"items": [
{"id":"qm2s2-1","name":"升降算符与对易关系","tags":["der","thm"],"brief":"用代数方法求解谐振子。",
 "fig":"harmonicosc","figCap":"谐振子势能曲线与等间距能级",
 "body": wrap(
   defn("升降算符",p("对谐振子 $\\hat{H}=\\frac{\\hat{p}^2}{2m}+\\frac12 m\\omega^2\\hat{x}^2$，引入无量纲算符：")+
   fml("\\hat{a}=\\sqrt{\\frac{m\\omega}{2\\hbar}}\\left(\\hat{x}+\\frac{i\\hat{p}}{m\\omega}\\right),\\quad \\hat{a}^\\dagger=\\sqrt{\\frac{m\\omega}{2\\hbar}}\\left(\\hat{x}-\\frac{i\\hat{p}}{m\\omega}\\right)"))+
   der(p("<strong>对易关系：</strong>利用 $[\\hat{x},\\hat{p}]=i\\hbar$ 计算：")+
   fml("[\\hat{a},\\hat{a}^\\dagger] = \\frac{m\\omega}{2\\hbar}\\left[\\hat{x}+\\frac{i\\hat{p}}{m\\omega},\\hat{x}-\\frac{i\\hat{p}}{m\\omega}\\right] = \\frac{m\\omega}{2\\hbar}\\cdot\\frac{2\\hbar}{m\\omega}=1")+
   p("将 $\\hat{x},\\hat{p}$ 用 $\\hat{a},\\hat{a}^\\dagger$ 反解并代入哈密顿量：")+
   fml("\\hat{H} = \\hbar\\omega\\left(\\hat{a}^\\dagger\\hat{a}+\\frac12\\right) = \\hbar\\omega\\left(\\hat{N}+\\frac12\\right)")+
   p("其中 $\\hat{N}=\\hat{a}^\\dagger\\hat{a}$ 为粒子数算符。"))+
   note(p("代数方法无需解微分方程即可得到全部能级，是量子力学中最优美的解法之一，也为二次量子化奠定基础。"))
 )},
{"id":"qm2s2-2","name":"谐振子能级与基态","tags":["der","thm"],"brief":"等间距能级与非零零点能。",
 "body": wrap(
   thm("谐振子能级",p("谐振子的能量本征值为：")+
   fml("E_n = \\left(n+\\frac12\\right)\\hbar\\omega,\\quad n=0,1,2,\\cdots"))+
   der(p("<strong>由升降算符推导：</strong>设 $|n\\rangle$ 为 $\\hat{N}$ 的本征态，$\\hat{N}|n\\rangle=n|n\\rangle$。计算对易子 $[\\hat{N},\\hat{a}]=-\\hat{a}$，$[\\hat{N},\\hat{a}^\\dagger]=\\hat{a}^\\dagger$，故：")+
   fml("\\hat{N}\\hat{a}|n\\rangle = (\\hat{a}\\hat{N}-\\hat{a})|n\\rangle = (n-1)\\hat{a}|n\\rangle")+
   p("即 $\\hat{a}|n\\rangle$ 是 $\\hat{N}$ 本征值为 $n-1$ 的本征态（除常数）。同理 $\\hat{a}^\\dagger|n\\rangle$ 对应 $n+1$。由于能量有下界，重复作用 $\\hat{a}$ 必终止于基态 $|0\\rangle$，满足 $\\hat{a}|0\\rangle=0$，对应 $n=0$、$E_0=\\hbar\\omega/2$。故 $n$ 为非负整数。"))+
   exa(p("<strong>例：</strong>双原子分子的振动可近似为谐振子，$\\hbar\\omega$ 为振动能级间距，红外光谱即源于振动能级跃迁。"))+
   note(p("<strong>零点能的物理意义：</strong>谐振子基态能量 $E_0=\\hbar\\omega/2$ 称为零点能，即使在绝对零度也不为零。这是不确定关系的必然结果：若粒子静止于 $x=0$，则 $\\Delta x=0$、$\\Delta p=0$，违反不确定关系。零点能导致了可观测的物理效应：例如液氦-4 在绝对零度（常压下）仍保持液态而不凝固，正是因为零点能太大；卡西米尔效应（两块平行金属板间的吸引力）也源于电磁场的零点能。振动基态的存在还使分子在绝对零度仍有振动振幅，影响 X 射线衍射的德拜-沃勒因子。"))
 )},
{"id":"qm2s2-3","name":"谐振子波函数","tags":["der"],"brief":"厄米多项式与高斯函数乘积。",
 "body": wrap(
   defn("基态波函数",p("由 $\\hat{a}\\psi_0=0$ 得微分方程 $\\left(x+\\frac{\\hbar}{m\\omega}\\frac{d}{dx}\\right)\\psi_0=0$，解得：")+
   fml("\\psi_0(x) = \\left(\\frac{m\\omega}{\\pi\\hbar}\\right)^{1/4} e^{-m\\omega x^2/2\\hbar}"))+
   der(p("<strong>激发态波函数：</strong>由 $|n\\rangle=\\frac{(\\hat{a}^\\dagger)^n}{\\sqrt{n!}}|0\\rangle$，在坐标表象中 $\\hat{a}^\\dagger$ 作用相当于微分算符，可导出：")+
   fml("\\psi_n(x) = \\frac{1}{\\sqrt{2^n n!}}\\left(\\frac{m\\omega}{\\pi\\hbar}\\right)^{1/4} H_n\\left(\\sqrt{\\frac{m\\omega}{\\hbar}}x\\right) e^{-m\\omega x^2/2\\hbar}")+
   p("其中 $H_n(\\xi)$ 为厄米多项式，满足递推关系 $H_{n+1}=2\\xi H_n-2nH_{n-1}$。$\\psi_n$ 的宇称为 $(-1)^n$，有 $n$ 个节点。"))+
   note(p("谐振子波函数在经典允许区外（$|x|>\\sqrt{2E/(m\\omega^2)}$）仍非零，体现量子隧穿；高量子数下概率分布趋近经典结果（对应原理）。"))
 )},
]},
{
"name": "2.3 势垒贯穿与隧道效应",
"color": "#2563eb",
"desc": "方势垒的透射系数与隧穿效应",
"items": [
{"id":"qm2s3-1","name":"方势垒的透射系数","tags":["der"],"brief":"E<V₀ 时粒子仍有概率穿透势垒。",
 "fig":"tunneling","figCap":"粒子穿透高于自身能量的势垒（隧穿效应）",
 "body": wrap(
   defn("势垒贯穿",p("能量 $E<V_0$ 的粒子入射方势垒 $V(x)=V_0$（$0<x<a$）时，按经典力学应完全反射，但量子力学中波函数在势垒内指数衰减，透射系数不为零，称为隧道效应。"))+
   der(p("<strong>透射系数推导：</strong>三个区域的波函数分别为：")+
   fml("\\psi_1=Ae^{ikx}+Be^{-ikx},\\ \\psi_2=Ce^{\\kappa x}+De^{-\\kappa x},\\ \\psi_3=Fe^{ikx}")+
   p("其中 $k=\\sqrt{2mE}/\\hbar$，$\\kappa=\\sqrt{2m(V_0-E)}/\\hbar$。在 $x=0$ 和 $x=a$ 处 $\\psi$、$\\psi'$ 连续，消去 $B,C,D$ 后得到透射系数：")+
   fml("T = \\frac{|F|^2}{|A|^2} = \\frac{1}{1+\\frac{V_0^2\\sinh^2(\\kappa a)}{4E(V_0-E)}}")+
   p("当 $\\kappa a\\gg1$ 时，$\\sinh(\\kappa a)\\approx\\frac12 e^{\\kappa a}$，近似为 $T\\approx e^{-2\\kappa a}$。"))+
   app(p("<strong>应用：</strong>隧道效应是扫描隧道显微镜（STM）、$\\alpha$ 衰变、约瑟夫森结、隧道二极管等的物理基础。"))+
   note(p("<strong>WKB 近似下的隧穿：</strong>对任意形状势垒 $V(x)$，当势垒远宽于德布罗意波长时，WKB 近似给出透射系数 $T\\approx\\exp\\left[-\\frac{2}{\\hbar}\\int_{x_1}^{x_2}\\sqrt{2m(V(x)-E)}dx\\right]$，其中 $x_1,x_2$ 为经典转折点。这一公式广泛用于 $\\alpha$ 衰变半衰期（伽莫夫公式）与场致发射（福勒-诺德海姆公式）的计算。"))
 )},
{"id":"qm2s3-2","name":"E>V₀ 的势垒散射","tags":["der"],"brief":"能量高于势垒时仍有反射。",
 "body": wrap(
   defn("势垒上方散射",p("当 $E>V_0$ 时，势垒内波矢 $k'=\\sqrt{2m(E-V_0)}/\\hbar$ 为实数，波函数在势垒内为振荡形式，但在界面处仍有反射。"))+
   der(p("<strong>透射系数：</strong>将 $\\kappa\\to ik'$ 代入 $E<V_0$ 的结果，利用 $\\sinh(ik'a)=i\\sin(k'a)$，得：")+
   fml("T = \\frac{1}{1+\\frac{V_0^2\\sin^2(k'a)}{4E(E-V_0)}}")+
   p("当 $k'a=n\\pi$（即势垒宽度为半波长整数倍）时 $T=1$，发生共振透射，此时势垒对粒子完全透明。"))+
   note(p("经典力学中 $E>V_0$ 时粒子必然全部穿过，量子力学中却因波的反射而出现振荡的透射系数，这是波动性的体现。"))
 )},
{"id":"qm2s3-3","name":"WKB 近似","tags":["der"],"brief":"缓变势场中的半经典近似。",
 "body": wrap(
   defn("WKB 近似",p("当势场 $V(x)$ 变化缓慢（德布罗意波长 $\\lambda(x)$ 远小于势场变化尺度）时，可用 WKB（温策尔-克拉默斯-布里渊）近似求解波函数。"))+
   der(p("<strong>隧穿概率：</strong>对势垒 $V(x)>E$（$x_1<x<x_2$），WKB 近似给出透射系数：")+
   fml("T \\approx \\exp\\left(-\\frac{2}{\\hbar}\\int_{x_1}^{x_2}\\sqrt{2m(V(x)-E)}\\,dx\\right)")+
   p("对 $\\alpha$ 衰变，库仑势垒 $V(r)=2Ze^2/(4\\pi\\varepsilon_0 r)$，积分给出盖革-努塔尔定律，定量解释了 $\\alpha$ 衰变半衰期与能量的关系。"))+
   app(p("<strong>应用：</strong>WKB 近似广泛用于势垒贯穿、束缚态能级（玻尔-索末菲量子化条件）、转折点附近的连接公式等。"))
 )},
]},
{
"name": "2.4 周期势场与能带",
"color": "#2563eb",
"desc": "布洛赫定理、能带结构与 Kronig-Penney 模型",
"items": [
{"id":"qm2s4-1","name":"布洛赫定理","tags":["thm","der"],"brief":"周期势中波函数为调幅平面波。",
 "fig":"periodic","figCap":"周期势场形成允带与禁带交替的能带结构",
 "body": wrap(
   thm("布洛赫定理",p("在周期势场 $V(\\mathbf{r}+\\mathbf{R}_n)=V(\\mathbf{r})$ 中，单电子波函数具有如下形式：")+
   fml("\\psi_{n\\mathbf{k}}(\\mathbf{r}) = e^{i\\mathbf{k}\\cdot\\mathbf{r}}u_{n\\mathbf{k}}(\\mathbf{r})")+
   p("其中 $u_{n\\mathbf{k}}(\\mathbf{r}+\\mathbf{R}_n)=u_{n\\mathbf{k}}(\\mathbf{r})$ 与晶格同周期。"))+
   der(p("<strong>推导：</strong>周期势使平移算符 $\\hat{T}_{\\mathbf{R}_n}$ 与 $\\hat{H}$ 对易，它们有共同本征态。设 $\\hat{T}_{\\mathbf{a}_i}\\psi=\\lambda_i\\psi$，由于平移对称性 $|\\lambda_i|=1$，令 $\\lambda_i=e^{ik_i a_i}$，则 $\\psi(\\mathbf{r}+\\mathbf{a}_i)=e^{ik_i a_i}\\psi(\\mathbf{r})$。定义 $u(\\mathbf{r})=e^{-i\\mathbf{k}\\cdot\\mathbf{r}}\\psi(\\mathbf{r})$，可验证 $u$ 具有晶格周期性。"))+
   note(p("布洛赫定理是能带理论的基础，$\\mathbf{k}$ 称为简约波矢（准动量），在第一布里渊区内取值。"))
 )},
{"id":"qm2s4-2","name":"能带与禁带","tags":["der"],"brief":"周期势导致连续能级分裂为能带。",
 "body": wrap(
   defn("能带结构",p("周期势场中，电子能量 $E_n(\\mathbf{k})$ 作为波矢的函数形成一系列能带，带与带之间不存在允许能级的区域称为禁带（带隙）。"))+
   der(p("<strong>禁带的来源：</strong>在自由电子模型中，$E=\\hbar^2k^2/(2m)$ 连续。引入周期势后，当 $\\mathbf{k}$ 落在布里渊区边界时，入射波与布拉格反射波叠加形成驻波，导致能量劈裂：")+
   fml("E_\\pm = E_0 \\pm |V_G|")+
   p("其中 $E_0=\\hbar^2k^2/(2m)$，$V_G$ 为周期势的傅里叶分量。两个驻波的电荷分布不同，与离子实的相互作用能不同，从而在布里渊区边界处产生能隙。"))+
   app(p("<strong>应用：</strong>导体、绝缘体、半导体的区别由能带填充情况决定：价带全满且带隙宽为绝缘体；带隙窄为半导体；价带半满为导体。"))
 )},
{"id":"qm2s4-3","name":"Kronig-Penney 模型","tags":["der"],"brief":"周期方势阱的可解模型。",
 "body": wrap(
   defn("Kronig-Penney 模型",p("由等间距方势阱（或势垒）组成的一维周期势，是能带理论的简单可解模型。"))+
   der(p("<strong>周期边界条件：</strong>设周期为 $a+b$，在一个周期内分段求解薛定谔方程，利用布洛赫条件 $\\psi(x+a+b)=e^{ik(a+b)}\\psi(x)$，得到允许 $k$ 与 $E$ 满足的超越方程：")+
   fml("\\cos k(a+b) = \\cos(\\alpha a)\\cosh(\\beta b) + \\frac{\\beta^2-\\alpha^2}{2\\alpha\\beta}\\sin(\\alpha a)\\sinh(\\beta b)")+
   p("其中 $\\alpha=\\sqrt{2mE}/\\hbar$，$\\beta=\\sqrt{2m(V_0-E)}/\\hbar$。由于左边取值范围为 $[-1,1]$，仅当右边落在此区间时 $k$ 为实数，对应允带；否则为禁带。"))+
   note(p("Kronig-Penney 模型定性展示了能带与禁带的形成，当 $b\\to0,V_0\\to\\infty$ 而 $V_0b$ 有限时退化为 $\\delta$ 函数周期势。"))
 )},
]},
]

ch3_sections = [
{
"name": "3.1 算符的一般性质",
"color": "#0d9488",
"desc": "线性算符、对易关系、逆算符与厄米共轭",
"items": [
{"id":"qm3s1-1","name":"线性算符与算符代数","tags":["def","der"],"brief":"算符的线性性与基本运算。",
 "fig":"operator","figCap":"算符将一个态映射为另一个态",
 "body": wrap(
   defn("线性算符",p("若算符 $\\hat{A}$ 满足 $\\hat{A}(c_1\\psi_1+c_2\\psi_2)=c_1\\hat{A}\\psi_1+c_2\\hat{A}\\psi_2$，则称为线性算符。量子力学中的力学量均由线性算符表示。"))+
   der(p("<strong>算符的乘积与对易子：</strong>算符乘积 $\\hat{A}\\hat{B}$ 定义为依次作用。一般 $\\hat{A}\\hat{B}\\neq\\hat{B}\\hat{A}$，定义对易子：")+
   fml("[\\hat{A},\\hat{B}] = \\hat{A}\\hat{B} - \\hat{B}\\hat{A}")+
   p("对易子满足雅可比恒等式 $[\\hat{A},[\\hat{B},\\hat{C}]]+[\\hat{B},[\\hat{C},\\hat{A}]]+[\\hat{C},[\\hat{A},\\hat{B}]]=0$，以及分配律 $[\\hat{A},\\hat{B}\\hat{C}]=[\\hat{A},\\hat{B}]\\hat{C}+\\hat{B}[\\hat{A},\\hat{C}]$。"))+
   exa(p("<strong>例：</strong>坐标 $\\hat{x}$ 与动量 $\\hat{p}_x=-i\\hbar\\partial_x$ 的对易关系为 $[\\hat{x},\\hat{p}_x]=i\\hbar$，这是量子力学最基本的对易关系。"))+
   note(p("<strong>对易关系的物理意义：</strong>两个算符对易（$[\\hat{A},\\hat{B}]=0$）当且仅当它们有共同的完备本征态集，此时对应力学量可同时取确定值。不对易的算符（如 $x$ 与 $p_x$）不能同时精确测量，受不确定关系制约。可以说，<strong>对易关系是量子力学区别于经典力学的核心数学结构</strong>：经典泊松括号 $\\{A,B\\}$ 在量子化后变为 $i\\hbar[A,B]$，这一对应（狄拉克量子化规则）是从经典力学到量子力学的桥梁。"))
 )},
{"id":"qm3s1-2","name":"厄米共轭与幺正算符","tags":["def","der"],"brief":"厄米共轭的定义与幺正算符。",
 "body": wrap(
   defn("厄米共轭",p("算符 $\\hat{A}$ 的厄米共轭 $\\hat{A}^\\dagger$ 定义为对任意 $\\psi,\\phi$ 满足：")+
   fml("\\int \\psi^* \\hat{A}^\\dagger \\phi\\, d\\tau = \\int (\\hat{A}\\psi)^* \\phi\\, d\\tau")+
   p("若 $\\hat{A}^\\dagger=\\hat{A}$，则 $\\hat{A}$ 为厄米算符；若 $\\hat{A}^\\dagger=\\hat{A}^{-1}$，则为幺正算符。"))+
   der(p("<strong>厄米共轭的性质：</strong>$(\\hat{A}+\\hat{B})^\\dagger=\\hat{A}^\\dagger+\\hat{B}^\\dagger$，$(\\hat{A}\\hat{B})^\\dagger=\\hat{B}^\\dagger\\hat{A}^\\dagger$，$(c\\hat{A})^\\dagger=c^*\\hat{A}^\\dagger$，$(\\hat{A}^\\dagger)^\\dagger=\\hat{A}$。幺正算符 $\\hat{U}^\\dagger\\hat{U}=1$ 保持内积不变：")+
   fml("\\langle \\hat{U}\\psi | \\hat{U}\\phi \\rangle = \\langle \\psi | \\hat{U}^\\dagger\\hat{U} | \\phi \\rangle = \\langle \\psi | \\phi \\rangle")+
   p("故幺正变换不改变态的模长与内积，对应表象变换或对称性变换。"))+
   note(p("量子力学中可观测量由厄米算符表示，而态的演化由幺正算符（时间演化算符）实现。"))
 )},
{"id":"qm3s1-3","name":"期望值与测量","tags":["der","thm"],"brief":"力学量期望值由算符在态中的平均给出。",
 "body": wrap(
   defn("期望值",p("在态 $\\psi$ 中测量力学量 $A$ 的期望值（平均值）为：")+
   fml("\\langle A \\rangle = \\langle \\psi | \\hat{A} | \\psi \\rangle = \\int \\psi^* \\hat{A} \\psi\\, d\\tau"))+
   der(p("<strong>测量值与概率：</strong>将 $\\psi$ 按 $\\hat{A}$ 的本征态 $\\psi_n$ 展开 $\\psi=\\sum_n c_n\\psi_n$，则测量 $A$ 得到本征值 $a_n$ 的概率为 $|c_n|^2$，期望值：")+
   fml("\\langle A\\rangle = \\sum_n |c_n|^2 a_n")+
   p("由 $c_n=\\langle\\psi_n|\\psi\\rangle$ 可直接验证与积分定义一致。测量后态坍缩到对应本征态 $\\psi_n$（波函数坍缩假设）。"))+
   note(p("期望值是多次相同测量的统计平均，单次测量结果必为某一本征值，不能取介于本征值之间的值。"))
 )},
]},
{
"name": "3.2 厄米算符与本征值",
"color": "#0d9488",
"desc": "厄米算符的本征值为实数、本征函数正交",
"items": [
{"id":"qm3s2-1","name":"厄米算符本征值为实数","tags":["thm","der"],"brief":"厄米算符的本征值必为实数。",
 "fig":"hermitian","figCap":"厄米算符的内积对称性示意",
 "body": wrap(
   thm("本征值的实数性",p("厄米算符 $\\hat{A}$ 的本征值必为实数，本征函数的正交性。"))+
   der(p("<strong>实数性证明：</strong>设 $\\hat{A}\\psi=a\\psi$，则 $\\langle\\psi|\\hat{A}|\\psi\\rangle=a\\langle\\psi|\\psi\\rangle$。取共轭：")+
   fml("\\langle\\psi|\\hat{A}|\\psi\\rangle^* = \\langle\\hat{A}\\psi|\\psi\\rangle = a^*\\langle\\psi|\\psi\\rangle")+
   p("由厄米性 $\\langle\\psi|\\hat{A}|\\psi\\rangle=\\langle\\hat{A}\\psi|\\psi\\rangle$，故 $a=a^*$，即 $a$ 为实数。这保证了可观测量的测量值为实数。"))+
   der(p("<strong>正交性证明：</strong>设 $\\hat{A}\\psi_m=a_m\\psi_m$、$\\hat{A}\\psi_n=a_n\\psi_n$，$a_m\\neq a_n$。则：")+
   fml("a_m\\langle\\psi_m|\\psi_n\\rangle=\\langle\\hat{A}\\psi_m|\\psi_n\\rangle=\\langle\\psi_m|\\hat{A}|\\psi_n\\rangle=a_n\\langle\\psi_m|\\psi_n\\rangle")+
   p("故 $(a_m-a_n)\\langle\\psi_m|\\psi_n\\rangle=0$，因 $a_m\\neq a_n$ 得 $\\langle\\psi_m|\\psi_n\\rangle=0$。"))+
   note(p("<strong>可观测量与厄米算符：</strong>量子力学的基本假设之一是：每个可观测量（可测量的物理量）对应一个厄米算符，测量结果为该算符的本征值之一，测量后态坍缩到相应本征态。厄米性保证了：（1）本征值为实数，与测量值的实数性一致；（2）不同本征值的本征态正交，构成可对角化的基；（3）本征函数集通常完备，可展开任意态。这三条性质是量子力学数学框架的基石。"))
 )},
{"id":"qm3s2-2","name":"简并与正交化","tags":["der"],"brief":"简并本征态可通过 Gram-Schmidt 正交化。",
 "body": wrap(
   defn("简并",p("若一个本征值 $a$ 对应 $f$ 个线性无关的本征函数，则称该本征值 $f$ 重简并。简并通常源于体系的某种对称性。"))+
   der(p("<strong>Gram-Schmidt 正交化：</strong>对简并子空间中的一组线性无关态 $\\psi_1,\\dots,\\psi_f$，可构造正交归一基：")+
   fml("\\phi_1 = \\frac{\\psi_1}{\\|\\psi_1\\|},\\quad \\phi_k = \\frac{\\psi_k-\\sum_{j<k}\\langle\\phi_j|\\psi_k\\rangle\\phi_j}{\\|\\psi_k-\\sum_{j<k}\\langle\\phi_j|\\psi_k\\rangle\\phi_j\\|}")+
   p("正交化后，厄米算符的全部本征函数可构成正交归一集。简并态的选择不是唯一的，可通过线性组合仍为同一本征值的本征态。"))+
   note(p("对于连续谱（如自由粒子动量），本征函数不能按通常方式归一化，需用 $\\delta$ 函数归一化：$\\langle p'|p\\rangle=\\delta(p'-p)$。"))
 )},
{"id":"qm3s2-3","name":"共同本征态","tags":["thm","der"],"brief":"两算符对易当且仅当存在共同完备本征态。",
 "body": wrap(
   thm("共同本征态定理",p("两个厄米算符 $\\hat{A},\\hat{B}$ 具有共同的完备本征函数系当且仅当 $[\\hat{A},\\hat{B}]=0$。"))+
   der(p("<strong>必要性：</strong>若 $\\psi_n$ 是 $\\hat{A},\\hat{B}$ 的共同本征态，$\\hat{A}\\psi_n=a_n\\psi_n$、$\\hat{B}\\psi_n=b_n\\psi_n$，则：")+
   fml("[\\hat{A},\\hat{B}]\\psi_n = \\hat{A}\\hat{B}\\psi_n-\\hat{B}\\hat{A}\\psi_n = (a_nb_n-b_na_n)\\psi_n=0")+
   p("对完备集张成的空间中任意态均成立，故 $[\\hat{A},\\hat{B}]=0$。充分性：若 $[\\hat{A},\\hat{B}]=0$，在 $\\hat{A}$ 的每个简并子空间中 $\\hat{B}$ 也是厄米算符，可同时对角化。"))+
   app(p("<strong>应用：</strong>$\\hat{H}$ 与 $\\hat{L}^2,\\hat{L}_z$ 在中心力场中互相对易，故存在 $|nlm\\rangle$ 共同本征态，使问题可分离变量求解。"))
 )},
]},
{
"name": "3.3 共同本征态与完备性",
"color": "#0d9488",
"desc": "完备性、展开定理与 CSCO",
"items": [
{"id":"qm3s3-1","name":"本征函数的完备性","tags":["thm","der"],"brief":"厄米算符本征函数构成完备基。",
 "body": wrap(
   thm("完备性定理",p("厄米算符的本征函数系 $\\{\\psi_n\\}$ 是完备的，即任意满足适当边界条件的波函数 $\\psi$ 可展开为：")+
   fml("\\psi = \\sum_n c_n \\psi_n,\\qquad c_n = \\langle \\psi_n | \\psi \\rangle"))+
   der(p("<strong>完备性关系：</strong>将展开系数代回，有 $\\psi=\\sum_n|\\psi_n\\rangle\\langle\\psi_n|\\psi\\rangle$，故：")+
   fml("\\sum_n |\\psi_n\\rangle\\langle\\psi_n| = \\hat{1}")+
   p("这称为完备性关系（单位算符的谱分解）。对连续谱，求和改为积分：$\\int d\\alpha |\\alpha\\rangle\\langle\\alpha|=\\hat{1}$。完备性保证了任意态都能用本征态展开，是表象理论的基础。"))+
   note(p("自伴算符的谱定理保证了完备性；物理中通常假设可观测量对应的算符为自伴算符。"))+
   note(p("<strong>完备性的物理意义：</strong>完备性意味着测量某力学量 $\\hat{A}$ 时，所有可能的结果（本征值）及其概率（$|c_n|^2$）已被本征函数系完全描述，没有遗漏。这与经典物理中坐标系的完备性类似：只要基矢完备，任意矢量都可表示为基矢的线性组合。对于连续谱（如位置、动量），本征函数为 $\\delta$ 函数型（非平方可积），需用 rigged Hilbert space（装备希尔伯特空间）严格处理。完备性与正交归一性共同构成傅里叶分析、表象变换、微扰论等量子力学计算方法的数学基础。"))
 )},
{"id":"qm3s3-2","name":"完备集（CSCO）","tags":["def","app"],"brief":"用一组相互对易的算符唯一标记态。",
 "body": wrap(
   defn("对易完备集（CSCO）",p("一组相互对易的厄米算符 $\\hat{A}_1,\\hat{A}_2,\\dots$，若它们的共同本征态无简并（即各组本征值唯一确定一个态），则称为对易完备集（CSCO）。"))+
   der(p("<strong>氢原子的 CSCO：</strong>氢原子中 $\\hat{H},\\hat{L}^2,\\hat{L}_z$ 互相对易，且它们的本征值 $\\{n,l,m\\}$ 唯一确定定态（不计自旋），故 $\\{\\hat{H},\\hat{L}^2,\\hat{L}_z\\}$ 构成 CSCO。若考虑自旋，则需加入 $\\hat{S}_z$ 或 $\\hat{J}^2,\\hat{J}_z$。"))+
   note(p("CSCO 的选择不是唯一的，例如氢原子也可选 $\\{\\hat{H},\\hat{L}^2,\\hat{L}_z,\\hat{S}_z\\}$ 或 $\\{\\hat{H},\\hat{J}^2,\\hat{J}_z,\\hat{L}^2\\}$，视问题方便而定。"))
 )},
{"id":"qm3s3-3","name":"投影算符与测量假设","tags":["der"],"brief":"测量后态投影到对应本征子空间。",
 "body": wrap(
   defn("投影算符",p("设 $\\hat{A}$ 本征值 $a$ 对应的本征子空间为 $V_a$，则投影到该子空间的投影算符为：")+
   fml("\\hat{P}_a = \\sum_{n: a_n=a} |\\psi_n\\rangle\\langle\\psi_n|")+
   p("满足 $\\hat{P}_a^2=\\hat{P}_a$（幂等）、$\\hat{P}_a^\\dagger=\\hat{P}_a$（厄米）。"))+
   der(p("<strong>测量假设：</strong>测量 $A$ 得 $a$ 的概率为 $p(a)=\\langle\\psi|\\hat{P}_a|\\psi\\rangle$，测量后态变为：")+
   fml("|\\psi'\\rangle = \\frac{\\hat{P}_a|\\psi\\rangle}{\\sqrt{p(a)}}")+
   p("对非简并情形 $\\hat{P}_a=|a\\rangle\\langle a|$，测量后态即坍缩到 $|a\\rangle$。投影算符满足 $\\sum_a\\hat{P}_a=\\hat{1}$，故总概率为 1。"))+
   note(p("这是量子力学测量公设的精确表述，是理解量子测量、退相干与量子信息的基础。"))
 )},
]},
{
"name": "3.4 不确定关系的严格推导",
"color": "#0d9488",
"desc": "由柯西-施瓦茨不等式导出不确定关系",
"items": [
{"id":"qm3s4-1","name":"不确定关系的推导","tags":["der","thm"],"brief":"由内积的柯西-施瓦茨不等式严格证明。",
 "fig":"uncertainty","figCap":"位置-动量不确定关系示意",
 "body": wrap(
   thm("不确定关系",p("对任意两个厄米算符 $\\hat{A},\\hat{B}$，有：")+
   fml("\\Delta A\\cdot\\Delta B \\geq \\frac12\\left|\\langle[\\hat{A},\\hat{B}]\\rangle\\right|")+
   p("其中 $\\Delta A=\\sqrt{\\langle\\hat{A}^2\\rangle-\\langle\\hat{A}\\rangle^2}$ 为标准差。"))+
   der(p("<strong>由柯西-施瓦茨不等式推导：</strong>令 $\\hat{A}_0=\\hat{A}-\\langle\\hat{A}\\rangle$，$\\hat{B}_0=\\hat{B}-\\langle\\hat{B}\\rangle$，则 $(\\Delta A)^2=\\langle\\psi|\\hat{A}_0^2|\\psi\\rangle$，$(\\Delta B)^2=\\langle\\psi|\\hat{B}_0^2|\\psi\\rangle$。由柯西-施瓦茨不等式：")+
   fml("(\\Delta A)^2(\\Delta B)^2 = \\langle\\hat{A}_0^2\\rangle\\langle\\hat{B}_0^2\\rangle \\geq |\\langle\\hat{A}_0\\hat{B}_0\\rangle|^2")+
   p("而 $\\hat{A}_0\\hat{B}_0=\\frac12\\{\\hat{A}_0,\\hat{B}_0\\}+\\frac12[\\hat{A}_0,\\hat{B}_0]$，反对易子期望为实、对易子期望为纯虚，故：")+
   fml("|\\langle\\hat{A}_0\\hat{B}_0\\rangle|^2 \\geq \\frac14|\\langle[\\hat{A},\\hat{B}]\\rangle|^2")+
   p("开方即得不确定关系。对 $\\hat{x},\\hat{p}_x$，$[\\hat{x},\\hat{p}_x]=i\\hbar$，得 $\\Delta x\\Delta p_x\\geq\\hbar/2$。"))+
   note(p("<strong>物理含义：</strong>不确定关系是波粒二象性的定量表述，并非测量仪器的技术限制。它表明粒子不可能同时具有确定的位置和动量：位置越确定（$\\Delta x$ 小），动量越不确定（$\\Delta p$ 大），反之亦然。最小不确定态（相干态）满足 $\\Delta x\\Delta p=\\hbar/2$，其波包形状为高斯。能量-时间不确定关系则与能级宽度、寿命密切相关：寿命 $\\tau$ 越短，能级宽度 $\\Gamma\\sim\\hbar/\\tau$ 越大，对应谱线的自然展宽。"))
 )},
{"id":"qm3s4-2","name":"能量-时间不确定关系","tags":["der","note"],"brief":"能量-时间不确定关系的特殊含义。",
 "body": wrap(
   der(p("<strong>推导：</strong>对不显含时间的算符 $\\hat{A}$，由 Ehrenfest 定理 $d\\langle A\\rangle/dt=\\frac{i}{\\hbar}\\langle[\\hat{H},\\hat{A}]\\rangle$。代入不确定关系 $\\Delta H\\Delta A\\geq\\frac12|\\langle[\\hat{H},\\hat{A}]\\rangle|$：")+
   fml("\\Delta E\\cdot\\Delta A \\geq \\frac{\\hbar}{2}\\left|\\frac{d\\langle A\\rangle}{dt}\\right|")+
   p("定义特征时间 $\\tau_A=\\Delta A/|d\\langle A\\rangle/dt|$（$\\langle A\\rangle$ 变化一个标准差所需时间），则：")+
   fml("\\Delta E\\cdot\\tau_A \\geq \\frac{\\hbar}{2}")+
   p("这就是能量-时间不确定关系。它不是两个力学量的不确定关系，而是能量不确定度与过程特征时间的关系。"))+
   note(p("能量-时间不确定关系的物理含义：若体系处于某态的寿命为 $\\tau$，则其能量不确定度（能级宽度）$\\Gamma\\geq\\hbar/(2\\tau)$，这解释了光谱线的自然宽度。"))+
   note(p("<strong>与位置-动量不确定关系的本质区别：</strong>位置-动量不确定关系是两个不对易力学量的内禀不确定度之积，源于对易关系 $[\\hat{x},\\hat{p}_x]=i\\hbar$。能量-时间不确定关系则不同：时间 $t$ 在非相对论量子力学中不是力学量算符，而是参数，因此 $\\Delta E\\Delta t\\geq\\hbar/2$ 中的 $\\Delta t$ 不是“时间的不确定度”，而是体系演化的特征时间（寿命、测量时间等）。这一关系反映了能量守恒在短时间内的“量子涨落”——虚过程可在 $\\Delta t\\sim\\hbar/\\Delta E$ 时间内“借用”能量 $\\Delta E$，这是量子场论中虚粒子存在的理论基础。"))
 )},
{"id":"qm3s4-3","name":"最小不确定态","tags":["der","exa"],"brief":"高斯波包是位置-动量的最小不确定态。",
 "body": wrap(
   defn("最小不确定态",p("使不确定关系取等号的态称为最小不确定态。对位置-动量，等号成立当且仅当 $\\hat{A}_0\\psi$ 与 $\\hat{B}_0\\psi$ 成正比（柯西-施瓦茨等号条件）且反对易子期望为零。"))+
   der(p("<strong>高斯波包：</strong>设 $\\psi(x)=Ne^{-\\alpha x^2}$，计算得 $\\langle x\\rangle=0$、$\\langle p\\rangle=0$、$\\langle x^2\\rangle=1/(4\\alpha)$、$\\langle p^2\\rangle=\\hbar^2\\alpha$，故：")+
   fml("\\Delta x = \\frac{1}{2\\sqrt{\\alpha}},\\quad \\Delta p = \\hbar\\sqrt{\\alpha} \\implies \\Delta x\\Delta p = \\frac{\\hbar}{2}")+
   p("恰好取等号，故高斯波包是位置-动量的最小不确定态。谐振子基态正是高斯波包，因此是最小不确定态。"))+
   app(p("<strong>应用：</strong>高斯波包是量子光学中相干态的波函数，也是激光光束的横向分布，在精密测量中具有基础重要性。"))
 )},
]},
]

ch4_sections = [
{
"name": "4.1 态与算符的矩阵表示",
"color": "#4f46e5",
"desc": "离散表象中的态矢与算符矩阵",
"items": [
{"id":"qm4s1-1","name":"态的矩阵表示","tags":["def","der"],"brief":"态在某表象中用列矢量表示。",
 "fig":"matrixrep","figCap":"算符在某表象中的矩阵元",
 "body": wrap(
   defn("表象",p("选定一组完备正交归一基 $\\{|n\\rangle\\}$（某力学量的本征态），任意态 $|\\psi\\rangle$ 可展开为：")+
   fml("|\\psi\\rangle = \\sum_n c_n|n\\rangle,\\qquad c_n=\\langle n|\\psi\\rangle")+
   p("系数列 $(c_1,c_2,\\dots)^T$ 就是态 $|\\psi\\rangle$ 在该表象中的表示（列矢量）。"))+
   der(p("<strong>内积与归一化的矩阵形式：</strong>两态内积 $\\langle\\phi|\\psi\\rangle=\\sum_n\\langle\\phi|n\\rangle\\langle n|\\psi\\rangle=\\sum_n b_n^*c_n$，即行矢量与列矢量的矩阵乘积。归一化条件 $\\sum_n|c_n|^2=1$ 对应列矢量模长为 1。"))+
   exa(p("<strong>例：</strong>在自旋 1/2 的 $\\hat{S}_z$ 表象中，基为 $|\\uparrow\\rangle=(1,0)^T$、$|\\downarrow\\rangle=(0,1)^T$，任意自旋态为 $\\chi=a|\\uparrow\\rangle+b|\\downarrow\\rangle=(a,b)^T$。"))+
   note(p("<strong>表象的几何类比：</strong>表象的选择类似于在欧几里得空间中选择坐标系。态矢量 $|\\psi\\rangle$ 是不依赖于表象的抽象矢量，而列矢量 $(c_n)$ 是其在某组基下的坐标分量。不同表象之间通过幺正变换联系，正如不同坐标系之间通过正交变换联系。概率解释 $|c_n|^2$ 给出测量力学量取 $n$ 本征值的概率，这是玻恩规则的矩阵形式。完备性关系 $\\sum_n|n\\rangle\\langle n|=\\hat{I}$ 是表象理论的核心，它使任何算符都可表示为矩阵。"))
 )},
{"id":"qm4s1-2","name":"算符的矩阵表示","tags":["der"],"brief":"算符由其在基矢间的矩阵元表示。",
 "body": wrap(
   defn("矩阵元",p("算符 $\\hat{A}$ 在表象 $\\{|n\\rangle\\}$ 中的矩阵元定义为：")+
   fml("A_{mn} = \\langle m|\\hat{A}|n\\rangle")+
   p("矩阵 $A=(A_{mn})$ 即为 $\\hat{A}$ 在该表象中的表示。厄米算符对应厄米矩阵 $A_{mn}=A_{nm}^*$，幺正算符对应幺正矩阵。"))+
   der(p("<strong>算符作用的矩阵形式：</strong>设 $|\\phi\\rangle=\\hat{A}|\\psi\\rangle$，两边左乘 $\\langle m|$ 并插入完备性关系：")+
   fml("b_m = \\langle m|\\hat{A}|\\psi\\rangle = \\sum_n\\langle m|\\hat{A}|n\\rangle\\langle n|\\psi\\rangle = \\sum_n A_{mn}c_n")+
   p("即 $\\mathbf{b}=A\\mathbf{c}$，算符作用对应矩阵与列矢量相乘。算符乘积对应矩阵乘积：$(AB)_{mn}=\\sum_k A_{mk}B_{kn}$。"))+
   note(p("本征方程 $\\hat{A}|\\psi\\rangle=a|\\psi\\rangle$ 化为矩阵本征方程 $A\\mathbf{c}=a\\mathbf{c}$，久期方程 $\\det(A-aI)=0$ 给出本征值。"))
 )},
{"id":"qm4s1-3","name":"动量表象与坐标表象","tags":["der","exa"],"brief":"连续谱表象中的波函数。",
 "body": wrap(
   defn("坐标表象",p("以位置本征态 $|\\mathbf{r}\\rangle$ 为基，态 $|\\psi\\rangle$ 的表示即波函数 $\\psi(\\mathbf{r})=\\langle\\mathbf{r}|\\psi\\rangle$。算符 $\\hat{x}=x$（乘子），$\\hat{p}_x=-i\\hbar\\partial/\\partial x$。"))+
   der(p("<strong>动量表象：</strong>以动量本征态 $|\\mathbf{p}\\rangle$ 为基，态的表示为动量空间波函数 $\\phi(\\mathbf{p})=\\langle\\mathbf{p}|\\psi\\rangle$。$\\hat{p}_x=p_x$（乘子），$\\hat{x}=i\\hbar\\partial/\\partial p_x$。两种表象通过傅里叶变换联系：")+
   fml("\\phi(\\mathbf{p}) = \\frac{1}{(2\\pi\\hbar)^{3/2}}\\int\\psi(\\mathbf{r})e^{-i\\mathbf{p}\\cdot\\mathbf{r}/\\hbar}d^3r")+
   p("即动量表象是坐标表象波函数的傅里叶变换，这正体现了位置与动量的共轭关系。"))+
   exa(p("<strong>例：</strong>坐标表象中 $\\hat{p}=-i\\hbar\\nabla$，动量表象中 $\\hat{x}=i\\hbar\\nabla_p$，二者形式对称，体现正则共轭性。"))
 )},
]},
{
"name": "4.2 表象变换与幺正变换",
"color": "#4f46e5",
"desc": "不同表象间的幺正变换关系",
"items": [
{"id":"qm4s2-1","name":"幺正变换矩阵","tags":["der","thm"],"brief":"表象变换由幺正矩阵实现。",
 "fig":"unitary","figCap":"幺正变换及其逆变换",
 "body": wrap(
   thm("表象变换",p("设旧基 $\\{|n\\rangle\\}$ 与新基 $\\{|\\alpha\\rangle\\}$，变换矩阵 $U_{n\\alpha}=\\langle n|\\alpha\\rangle$ 为幺正矩阵，态与算符的变换为：")+
   fml("\\mathbf{c}' = U^\\dagger\\mathbf{c},\\qquad A' = U^\\dagger A U"))+
   der(p("<strong>推导：</strong>新基用旧基展开 $|\\alpha\\rangle=\\sum_n|n\\rangle\\langle n|\\alpha\\rangle=\\sum_n U_{n\\alpha}|n\\rangle$。态的新系数 $c'_\\alpha=\\langle\\alpha|\\psi\\rangle=\\sum_n\\langle\\alpha|n\\rangle\\langle n|\\psi\\rangle=\\sum_n U_{n\\alpha}^*c_n=(U^\\dagger\\mathbf{c})_\\alpha$。算符矩阵元：")+
   fml("A'_{\\alpha\\beta}=\\langle\\alpha|\\hat{A}|\\beta\\rangle=\\sum_{mn}\\langle\\alpha|m\\rangle\\langle m|\\hat{A}|n\\rangle\\langle n|\\beta\\rangle=(U^\\dagger A U)_{\\alpha\\beta}")+
   p("由基的正交归一性可证 $U^\\dagger U=I$，故 $U$ 为幺正矩阵。"))+
   note(p("幺正变换保持内积、本征值、迹与行列式不变，是量子力学中连接不同表象的桥梁。"))+
   note(p("<strong>表象选择的实用意义：</strong>不同表象下同一问题的难易程度差别巨大。坐标表象适合解束缚态微分方程（如氢原子）；动量表象中势能变为卷积算符，但自由粒子问题最简单；能量表象（$\\hat{H}$ 对角）是微扰论的自然框架。幺正变换的不变性保证：无论选择何种表象，物理预言（本征值、测量概率、期望值）完全相同。这体现了量子力学的表象无关性——物理实在独立于数学描述的选择。"))
 )},
{"id":"qm4s2-2","name":"幺正变换的不变量","tags":["der"],"brief":"本征值、迹、行列式在幺正变换下不变。",
 "body": wrap(
   thm("不变量",p("幺正变换不改变算符的本征值、迹（$\\text{tr}A$）与行列式（$\\det A$），也不改变态的模长与内积。"))+
   der(p("<strong>迹不变性：</strong>$\\text{tr}(U^\\dagger A U)=\\text{tr}(A U U^\\dagger)=\\text{tr}A$（迹的循环性）。行列式不变性：$\\det(U^\\dagger A U)=\\det U^\\dagger\\det A\\det U=\\det A$（因 $|\\det U|=1$）。本征值不变性：$\\det(U^\\dagger A U-\\lambda I)=\\det(U^\\dagger(A-\\lambda I)U)=\\det(A-\\lambda I)$，故特征方程相同。"))+
   exa(p("<strong>例：</strong>哈密顿量在自身表象中为对角矩阵，对角元即能量本征值；将其变换到坐标表象则为微分算符 $-\\hbar^2\\nabla^2/(2m)+V$，但其本征值仍相同。"))
 )},
{"id":"qm4s2-3","name":"表象的选择","tags":["app","note"],"brief":"根据问题特点选择方便的表象。",
 "body": wrap(
   defn("表象选择原则",p("选择表象的原则是使问题尽可能简化：通常选取与体系哈密顿量有密切关系的力学量的本征态作为基，以便哈密顿量尽量对角化。"))+
   der(p("<strong>对角化即求本征态：</strong>若算符 $\\hat{A}$ 在某表象中非对角，可通过解久期方程 $\\det(A-aI)=0$ 求得本征值，再由本征矢构造幺正矩阵 $U$，使 $U^\\dagger A U$ 对角化。这个过程就是从旧表象变换到 $\\hat{A}$ 自身表象。"))+
   app(p("<strong>应用：</strong>谐振子选能量表象（数表象）最方便，角动量问题选 $\\hat{L}^2,\\hat{L}_z$ 共同表象，自旋问题选 $\\hat{S}_z$ 表象。合适的表象可大幅简化计算。"))
 )},
]},
{
"name": "4.3 狄拉克符号",
"color": "#4f46e5",
"desc": "bra-ket 符号与抽象矢量空间",
"items": [
{"id":"qm4s3-1","name":"ket 与 bra","tags":["def","der"],"brief":"右矢与左矢的共轭对偶关系。",
 "fig":"dirac","figCap":"bra 与 ket 及其内积",
 "body": wrap(
   defn("狄拉克符号",p("量子态用右矢（ket）$|\\psi\\rangle$ 表示，其对偶空间中的左矢（bra）记为 $\\langle\\psi|$，二者一一对应（反同构）。$|\\psi\\rangle$ 与 $|\\phi\\rangle$ 的内积记为 $\\langle\\phi|\\psi\\rangle$。"))+
   der(p("<strong>内积性质：</strong>$\\langle\\phi|\\psi\\rangle=\\langle\\psi|\\phi\\rangle^*$，$\\langle\\psi|\\psi\\rangle\\geq0$，且 $\\langle\\psi|\\psi\\rangle=0$ 当且仅当 $|\\psi\\rangle=0$。算符 $\\hat{A}$ 作用于右矢得右矢 $\\hat{A}|\\psi\\rangle$，其对偶左矢为 $\\langle\\psi|\\hat{A}^\\dagger$。矩阵元：")+
   fml("\\langle\\phi|\\hat{A}|\\psi\\rangle")+
   p("可理解为 $\\langle\\phi|$ 与 $\\hat{A}|\\psi\\rangle$ 的内积，也可理解为 $\\langle\\phi|\\hat{A}$ 与 $|\\psi\\rangle$ 的内积。"))+
   note(p("狄拉克符号不依赖具体表象，使量子力学公式简洁优美，是处理抽象态矢空间的标准工具。"))+
   note(p("<strong>狄拉克符号的优势：</strong>狄拉克符号将态矢量与内积抽象化，使公式在任意表象下形式不变。例如期望值 $\\langle A\\rangle=\\langle\\psi|\\hat{A}|\\psi\\rangle$、完备性关系 $\\sum_n|n\\rangle\\langle n|=\\hat{1}$、跃迁矩阵元 $\\langle f|\\hat{H}'|i\\rangle$ 等，都无需指定坐标或动量表象。这种抽象性使量子力学的代数结构（希尔伯特空间、线性算符、幺正变换）得到最清晰的表达，也便于推广到多体与场论。狄拉克于 1939 年引入这套符号，现已成为量子理论的通用语言。"))
 )},
{"id":"qm4s3-2","name":"投影算符与完备性关系","tags":["der"],"brief":"用狄拉克符号表示投影与完备性。",
 "body": wrap(
   defn("外积与投影算符",p("$|\\psi\\rangle\\langle\\phi|$ 是一个算符，作用于任意 $|\\chi\\rangle$ 得 $(|\\psi\\rangle\\langle\\phi|)|\\chi\\rangle=|\\psi\\rangle\\langle\\phi|\\chi\\rangle$。当 $|\\psi\\rangle$ 归一时，$|\\psi\\rangle\\langle\\psi|$ 是投影到 $|\\psi\\rangle$ 方向的投影算符。"))+
   der(p("<strong>完备性关系：</strong>对正交归一集 $\\{|n\\rangle\\}$，有：")+
   fml("\\sum_n |n\\rangle\\langle n| = \\hat{1},\\qquad \\langle m|n\\rangle = \\delta_{mn}")+
   p("在推导中插入完备性关系 $\\hat{1}$ 是常用技巧。例如：$\\langle\\phi|\\hat{A}|\\psi\\rangle=\\sum_n\\langle\\phi|\\hat{A}|n\\rangle\\langle n|\\psi\\rangle$。对连续基 $|x\\rangle$，$\\int dx|x\\rangle\\langle x|=\\hat{1}$，$\\langle x'|x\\rangle=\\delta(x'-x)$。"))+
   exa(p("<strong>例：</strong>态 $|\\psi\\rangle$ 在坐标表象的波函数 $\\psi(x)=\\langle x|\\psi\\rangle$，在动量表象 $\\phi(p)=\\langle p|\\psi\\rangle$，由 $\\psi(x)=\\int dp\\langle x|p\\rangle\\langle p|\\psi\\rangle=\\int dp\\frac{e^{ipx/\\hbar}}{\\sqrt{2\\pi\\hbar}}\\phi(p)$ 即得傅里叶变换。"))
 )},
{"id":"qm4s3-3","name":"表象变换的狄拉克表述","tags":["der"],"brief":"用狄拉克符号统一处理不同表象。",
 "body": wrap(
   der(p("<strong>波函数作为内积：</strong>态 $|\\psi\\rangle$ 在 $Q$ 表象中的波函数 $\\psi(q)=\\langle q|\\psi\\rangle$，是态矢与基矢的内积。算符的矩阵元 $A(q,q')=\\langle q|\\hat{A}|q'\\rangle$。薛定谔方程可写成与表象无关的形式：")+
   fml("i\\hbar\\frac{d}{dt}|\\psi(t)\\rangle = \\hat{H}|\\psi(t)\\rangle")+
   p("左乘 $\\langle q|$ 并插入完备性关系即得坐标表象的薛定谔方程。这种抽象写法使物理内容清晰，具体计算时再选择表象。"))+
   note(p("狄拉克符号是量子力学的「世界语」，能统一处理离散与连续谱、有界与无界算符，是现代量子力学的标准语言。"))
 )},
]},
{
"name": "4.4 绘景变换",
"color": "#4f46e5",
"desc": "薛定谔绘景、海森伯绘景与相互作用绘景",
"items": [
{"id":"qm4s4-1","name":"薛定谔绘景与海森伯绘景","tags":["thm","der"],"brief":"两种绘景分别让态与算符随时间演化。",
 "fig":"picture","figCap":"薛定谔绘景（态演化）与海森伯绘景（算符演化）",
 "body": wrap(
   thm("海森伯绘景",p("在海森伯绘景中，态矢 $|\\psi\\rangle_H=|\\psi(0)\\rangle$ 不随时间变化，算符随时间演化：")+
   fml("\\hat{A}_H(t) = e^{i\\hat{H}t/\\hbar}\\hat{A}_S e^{-i\\hat{H}t/\\hbar}")+
   p("其中 $\\hat{A}_S$ 是薛定谔绘景中的算符。"))+
   der(p("<strong>绘景等价性：</strong>薛定谔绘景中 $|\\psi(t)\\rangle_S=e^{-i\\hat{H}t/\\hbar}|\\psi(0)\\rangle$。期望值：")+
   fml("_S\\langle\\psi(t)|\\hat{A}_S|\\psi(t)\\rangle_S = \\langle\\psi(0)|e^{i\\hat{H}t/\\hbar}\\hat{A}_S e^{-i\\hat{H}t/\\hbar}|\\psi(0)\\rangle = _H\\langle\\psi|\\hat{A}_H(t)|\\psi\\rangle_H")+
   p("两种绘景给出完全相同的物理预言（期望值、测量概率），只是数学描述方式不同。"))+
   note(p("薛定谔绘景中态演化、算符固定；海森伯绘景中态固定、算符演化。后者形式上更接近经典力学（哈密顿方程）。"))+
   note(p("<strong>绘景选择的实用考量：</strong>薛定谔绘景直观，波函数随时间演化，适合求解含时薛定谔方程与束缚态问题；海森伯绘景算符演化满足海森伯运动方程 $d\\hat{A}_H/dt=(i/\\hbar)[\\hat{H},\\hat{A}_H]$，与经典哈密顿方程 $dA/dt=\\{A,H\\}$ 形式对应，便于讨论算符的时间演化与守恒律。相互作用绘景（$\\hat{H}=\\hat{H}_0+\\hat{H}'$）中，态的演化只由相互作用 $\\hat{H}'$ 决定，算符由 $\\hat{H}_0$ 演化，是微扰论（费曼图）的自然框架。三种绘景在物理上完全等价，选择哪种仅取决于计算便利。"))
 )},
{"id":"qm4s4-2","name":"海森伯运动方程","tags":["der","thm"],"brief":"海森伯绘景中算符的运动方程。",
 "body": wrap(
   thm("海森伯方程",p("海森伯绘景中算符的时间演化为：")+
   fml("\\frac{d\\hat{A}_H(t)}{dt} = \\frac{i}{\\hbar}[\\hat{H},\\hat{A}_H(t)] + \\left(\\frac{\\partial\\hat{A}}{\\partial t}\\right)_H"))+
   der(p("<strong>推导：</strong>对 $\\hat{A}_H(t)=e^{i\\hat{H}t/\\hbar}\\hat{A}_S e^{-i\\hat{H}t/\\hbar}$ 求导：")+
   fml("\\frac{d\\hat{A}_H}{dt} = \\frac{i}{\\hbar}\\hat{H}e^{i\\hat{H}t/\\hbar}\\hat{A}_S e^{-i\\hat{H}t/\\hbar} + e^{i\\hat{H}t/\\hbar}\\frac{\\partial\\hat{A}_S}{\\partial t}e^{-i\\hat{H}t/\\hbar} - \\frac{i}{\\hbar}e^{i\\hat{H}t/\\hbar}\\hat{A}_S e^{-i\\hat{H}t/\\hbar}\\hat{H}")+
   p("整理得 $\\frac{d\\hat{A}_H}{dt}=\\frac{i}{\\hbar}[\\hat{H},\\hat{A}_H]+(\\partial_t\\hat{A})_H$。若 $\\hat{A}$ 不显含时间且 $[\\hat{H},\\hat{A}]=0$，则 $\\hat{A}_H$ 为常数，即守恒量。"))+
   exa(p("<strong>例：</strong>自由粒子 $\\hat{H}=\\hat{p}^2/(2m)$，海森伯方程给出 $d\\hat{x}_H/dt=\\hat{p}_H/m$、$d\\hat{p}_H/dt=0$，形式与经典牛顿方程一致，这是对应原理的体现。"))
 )},
{"id":"qm4s4-3","name":"相互作用绘景","tags":["der","app"],"brief":"把哈密顿量分为未受扰与相互作用部分。",
 "body": wrap(
   defn("相互作用绘景",p("设 $\\hat{H}=\\hat{H}_0+\\hat{H}'$，相互作用绘景定义为：")+
   fml("|\\psi(t)\\rangle_I = e^{i\\hat{H}_0 t/\\hbar}|\\psi(t)\\rangle_S,\\qquad \\hat{A}_I(t)=e^{i\\hat{H}_0 t/\\hbar}\\hat{A}_S e^{-i\\hat{H}_0 t/\\hbar}"))+
   der(p("<strong>运动方程：</strong>对相互作用绘景态矢求导：")+
   fml("i\\hbar\\frac{d}{dt}|\\psi\\rangle_I = -\\hat{H}_0|\\psi\\rangle_I + e^{i\\hat{H}_0t/\\hbar}(\\hat{H}_0+\\hat{H}')|\\psi\\rangle_S = \\hat{H}'_I(t)|\\psi\\rangle_I")+
   p("其中 $\\hat{H}'_I(t)=e^{i\\hat{H}_0t/\\hbar}\\hat{H}'e^{-i\\hat{H}_0t/\\hbar}$。相互作用绘景中算符按 $\\hat{H}_0$ 演化（自由演化），态矢仅由相互作用 $\\hat{H}'$ 引起变化，这正是含时微扰论的自然框架。"))+
   app(p("<strong>应用：</strong>相互作用绘景是量子场论与含时微扰论的标准框架，费曼图即基于此绘景发展而来。"))
 )},
]},
]

ch5_sections = [
{
"name": "5.1 角动量的本征值与本征态",
"color": "#0891b2",
"desc": "角动量对易关系、本征值与球谐函数",
"items": [
{"id":"qm5s1-1","name":"角动量算符与对易关系","tags":["def","der"],"brief":"角动量分量满足 SU(2) 对易关系。",
 "fig":"angmom","figCap":"角动量矢量在 z 轴的投影与进动",
 "body": wrap(
   defn("轨道角动量",p("轨道角动量算符 $\\hat{\\mathbf{L}}=\\hat{\\mathbf{r}}\\times\\hat{\\mathbf{p}}$，分量为 $\\hat{L}_x=y\\hat{p}_z-z\\hat{p}_y$ 等。其基本对易关系为：")+
   fml("[\\hat{L}_x,\\hat{L}_y]=i\\hbar\\hat{L}_z,\\quad [\\hat{L}_y,\\hat{L}_z]=i\\hbar\\hat{L}_x,\\quad [\\hat{L}_z,\\hat{L}_x]=i\\hbar\\hat{L}_y")+
   p("可统一写为 $[\\hat{L}_i,\\hat{L}_j]=i\\hbar\\varepsilon_{ijk}\\hat{L}_k$。"))+
   der(p("<strong>推导对易关系：</strong>由正则对易关系 $[x_i,p_j]=i\\hbar\\delta_{ij}$ 计算：")+
   fml("[\\hat{L}_x,\\hat{L}_y]=[y\\hat{p}_z-z\\hat{p}_y,z\\hat{p}_x-x\\hat{p}_z]=y[\\hat{p}_z,z]\\hat{p}_x+x\\hat{p}_y[z,\\hat{p}_z]=i\\hbar(x\\hat{p}_y-y\\hat{p}_x)=i\\hbar\\hat{L}_z")+
   p("其余分量循环可得。角动量平方 $\\hat{L}^2=\\hat{L}_x^2+\\hat{L}_y^2+\\hat{L}_z^2$ 与每个分量都对易：$[\\hat{L}^2,\\hat{L}_i]=0$。"))+
   note(p("任意满足上述对易关系的算符都称为角动量算符，包括自旋 $\\hat{\\mathbf{S}}$ 与总角动量 $\\hat{\\mathbf{J}}=\\hat{\\mathbf{L}}+\\hat{\\mathbf{S}}$。"))+
   note(p("<strong>角动量与转动对称性：</strong>角动量算符是空间转动的生成元。绕 $\\mathbf{n}$ 轴转 $\\theta$ 角的幺正算符为 $\\hat{R}(\\theta\\mathbf{n})=e^{-i\\theta\\mathbf{n}\\cdot\\hat{\\mathbf{J}}/\\hbar}$。体系具有转动对称性当且仅当哈密顿量与角动量对易，此时角动量守恒。这是诺特定理在量子力学中的体现：连续对称性对应守恒量。角动量的对易关系 $[J_i,J_j]=i\\hbar\\varepsilon_{ijk}J_k$ 定义了李代数 $\\mathfrak{su}(2)$，其不可约表示由 $j$ 标记，维数为 $2j+1$，这正是角动量量子化的群论根源。"))
 )},
{"id":"qm5s1-2","name":"角动量的本征值","tags":["thm","der"],"brief":"由升降算符严格导出角动量本征值。",
 "body": wrap(
   thm("角动量本征值",p("$\\hat{J}^2$ 与 $\\hat{J}_z$ 的共同本征态 $|jm\\rangle$ 满足：")+
   fml("\\hat{J}^2|jm\\rangle=j(j+1)\\hbar^2|jm\\rangle,\\qquad \\hat{J}_z|jm\\rangle=m\\hbar|jm\\rangle")+
   p("其中 $j=0,\\frac12,1,\\frac32,\\dots$，$m=-j,-j+1,\\dots,j$，共 $2j+1$ 个值。"))+
   der(p("<strong>用升降算符推导：</strong>定义 $\\hat{J}_\\pm=\\hat{J}_x\\pm i\\hat{J}_y$，对易关系 $[\\hat{J}_z,\\hat{J}_\\pm]=\\pm\\hbar\\hat{J}_\\pm$，故 $\\hat{J}_\\pm|jm\\rangle$ 是 $\\hat{J}_z$ 本征值为 $(m\\pm1)\\hbar$ 的态。又 $\\hat{J}^2=\\hat{J}_-\\hat{J}_++\\hat{J}_z^2+\\hbar\\hat{J}_z$，故 $\\langle jm|\\hat{J}_-\\hat{J}_+|jm\\rangle=\\hbar^2[j(j+1)-m(m+1)]\\geq0$，得 $m\\leq j$。同理 $m\\geq-j$。升降不能无限进行，故存在最大 $m=j$、最小 $m=-j$，相差为整数，故 $2j$ 为非负整数。"))+
   exa(p("<strong>例：</strong>轨道角动量 $l$ 为整数（由波函数单值性要求 $e^{im\\varphi}$ 周期为 $2\\pi$），自旋 $s$ 可为半整数。"))+
   note(p("<strong>角动量量子化的深刻含义：</strong>角动量本征值的量子化（$j$ 取整数或半整数、$m$ 间隔为 1）是角动量对易关系 $[J_i,J_j]=i\\hbar\\varepsilon_{ijk}J_k$ 的直接代数推论，不依赖于具体势能形式。这展示了量子力学中代数方法的威力：仅从对易关系出发，无需解微分方程，即可得到完整的本征值谱。轨道角动量 $l$ 必须为整数，因为波函数在方位角 $\\varphi$ 上须单值（$Y_l^m(\\theta,\\varphi+2\\pi)=Y_l^m(\\theta,\\varphi)$）；而自旋无坐标波函数，不受此限制，故可半整数（$s=1/2,3/2,\\dots$）。这是轨道角动量与内禀自旋的本质区别之一。"))
 )},
{"id":"qm5s1-3","name":"球谐函数","tags":["der"],"brief":"轨道角动量的本征函数。",
 "body": wrap(
   defn("球谐函数",p("$\\hat{L}^2$ 与 $\\hat{L}_z$ 的共同本征函数为球谐函数 $Y_l^m(\\theta,\\varphi)$：")+
   fml("\\hat{L}^2 Y_l^m=l(l+1)\\hbar^2 Y_l^m,\\qquad \\hat{L}_z Y_l^m=m\\hbar Y_l^m")+
   p("$l=0,1,2,\\dots$，$m=-l,\\dots,l$。"))+
   der(p("<strong>具体形式：</strong>在球坐标中 $\\hat{L}_z=-i\\hbar\\partial/\\partial\\varphi$，故 $Y_l^m\\propto e^{im\\varphi}\\Theta_l^m(\\theta)$。$\\hat{L}^2$ 的本征方程化为关联勒让德方程，解为关联勒让德多项式 $P_l^m(\\cos\\theta)$：")+
   fml("Y_l^m(\\theta,\\varphi)=(-1)^m\\sqrt{\\frac{(2l+1)(l-m)!}{4\\pi(l+m)!}}P_l^m(\\cos\\theta)e^{im\\varphi}")+
   p("球谐函数满足正交归一 $\\int Y_{l'}^{m'*}Y_l^m d\\Omega=\\delta_{ll'}\\delta_{mm'}$，并构成单位球面上的完备正交系。"))+
   note(p("前几个球谐函数：$Y_0^0=1/\\sqrt{4\\pi}$（s 轨道，球对称），$Y_1^0=\\sqrt{3/(4\\pi)}\\cos\\theta$（p_z 轨道）等。"))+
   note(p("<strong>球谐函数的数学性质：</strong>球谐函数是球面上的傅里叶基，在数学物理中地位重要。它们满足加法定理 $\\sum_m Y_l^{m*}(\\hat{\\mathbf{r}})Y_l^m(\\hat{\\mathbf{r}}')=(2l+1)/(4\\pi)P_l(\\cos\\gamma)$（$\\gamma$ 为两方向夹角），是多极展开与球谐变换的基础。在量子化学中，s、p、d、f 轨道的角向部分正是球谐函数（或其线性组合）：p 轨道对应 $l=1$（3 重简并），d 轨道 $l=2$（5 重简并），f 轨道 $l=3$（7 重简并），其角度分布决定了化学键的方向性与分子几何构型。"))
 )},
]},
{
"name": "5.2 氢原子",
"color": "#0891b2",
"desc": "氢原子能级、径向方程与波函数",
"items": [
{"id":"qm5s2-1","name":"中心力场的分离变量","tags":["der"],"brief":"中心力场中波函数分离为径向与角向。",
 "body": wrap(
   thm("中心力场分离变量",p("在中心势 $V(r)$ 中，定态薛定谔方程可分离变量：$\\psi(\\mathbf{r})=R(r)Y_l^m(\\theta,\\varphi)$，径向函数 $R(r)$ 满足：")+
   fml("\\left[-\\frac{\\hbar^2}{2m}\\frac{d^2}{dr^2}+V(r)+\\frac{l(l+1)\\hbar^2}{2mr^2}\\right]u(r)=Eu(r)")+
   p("其中 $u(r)=rR(r)$。"))+
   der(p("<strong>推导：</strong>哈密顿量 $\\hat{H}=-\\frac{\\hbar^2}{2m}\\nabla^2+V(r)$，球坐标中拉普拉斯算子 $\\nabla^2=\\frac1{r^2}\\partial_r(r^2\\partial_r)+\\frac{\\hat{L}^2}{\\hbar^2r^2}$。因 $[\\hat{H},\\hat{L}^2,\\hat{L}_z]=0$，共同本征态可写为 $R(r)Y_l^m$。代入并约去 $Y_l^m$：")+
   fml("-\\frac{\\hbar^2}{2mr^2}\\frac{d}{dr}\\left(r^2\\frac{dR}{dr}\\right)+\\left[V(r)+\\frac{l(l+1)\\hbar^2}{2mr^2}\\right]R=ER")+
   p("令 $u(r)=rR(r)$ 化简为标准形式，其中 $l(l+1)\\hbar^2/(2mr^2)$ 为离心势。"))+
   note(p("能量与 $m$ 无关（中心力场的旋转对称性），对给定 $l$ 有 $2l+1$ 重简并；氢原子中还存在关于 $l$ 的偶然简并（Runge-Lenz 矢量对称性）。"))
 )},
{"id":"qm5s2-2","name":"氢原子能级","tags":["thm","der"],"brief":"氢原子能级由主量子数 n 决定。",
 "fig":"hydrogen","figCap":"氢原子能级图（n=1,2,3,4）",
 "body": wrap(
   thm("氢原子能级",p("氢原子（$V(r)=-e^2/(4\\pi\\varepsilon_0 r)$）的束缚态能级为：")+
   fml("E_n = -\\frac{me^4}{2\\hbar^2(4\\pi\\varepsilon_0)^2}\\cdot\\frac{1}{n^2} = -\\frac{13.6\\,\\text{eV}}{n^2},\\quad n=1,2,3,\\dots"))+
   der(p("<strong>推导：</strong>对库仑势的径向方程作变量代换 $\\rho=\\kappa r$（$\\kappa=\\sqrt{-8mE}/\\hbar$），在 $\\rho\\to0$ 处 $u\\sim\\rho^{l+1}$，在 $\\rho\\to\\infty$ 处要求收敛引入截断条件，得到级数必须中断为多项式：")+
   fml("\\frac{me^2}{4\\pi\\varepsilon_0\\hbar^2\\kappa} = n_r+l+1 \\equiv n")+
   p("其中径向量子数 $n_r=0,1,2,\\dots$，主量子数 $n=n_r+l+1\\geq1$。代回 $\\kappa$ 即得能级公式。玻尔半径 $a_0=4\\pi\\varepsilon_0\\hbar^2/(me^2)\\approx0.529\\,\\text{\\AA}$。"))+
   note(p("能级只与 $n$ 有关，对给定 $n$，$l=0,1,\\dots,n-1$，$m=-l,\\dots,l$，简并度为 $\\sum_{l=0}^{n-1}(2l+1)=n^2$（不计自旋）。"))+
   app(p("<strong>氢光谱与里德伯公式：</strong>能级差 $\\Delta E=E_{n_2}-E_{n_1}=13.6\\,\\text{eV}(1/n_1^2-1/n_2^2)$ 对应光子波数 $\\tilde\\nu=R_\\infty(1/n_1^2-1/n_2^2)$，其中里德伯常数 $R_\\infty=me^4/(8\\varepsilon_0^2h^3c)\\approx1.097\\times10^7\\,\\text{m}^{-1}$。$n_1=1$ 为莱曼系（紫外），$n_1=2$ 为巴耳末系（可见光，Hα 656 nm），$n_1=3$ 为帕邢系（红外）。这是量子力学最早的成功预言之一，精确解释了氢原子光谱的实验规律。"))
 )},
{"id":"qm5s2-3","name":"氢原子波函数与概率分布","tags":["der","exa"],"brief":"径向波函数与电子云分布。",
 "body": wrap(
   defn("氢原子波函数",p("氢原子定态波函数为：")+
   fml("\\psi_{nlm}(r,\\theta,\\varphi) = R_{nl}(r)Y_l^m(\\theta,\\varphi)")+
   p("径向波函数 $R_{nl}(r)$ 由关联拉盖尔多项式给出。"))+
   der(p("<strong>径向概率分布：</strong>在半径 $r$ 处单位球壳内找到电子的概率为 $|R_{nl}(r)|^2 r^2 dr$。基态（$1s$，$n=1,l=0$）$R_{10}\\propto e^{-r/a_0}$，最概然半径：")+
   fml("\\frac{d}{dr}(r^2 e^{-2r/a_0})=0 \\implies r=a_0")+
   p("即玻尔半径。$2p$ 态（$n=2,l=1$）最概然半径为 $4a_0$。一般地，类氢原子最概然半径 $r_{\\max}=n^2a_0/Z$。"))+
   exa(p("<strong>例：</strong>基态 $\\langle r\\rangle=3a_0/2$，$\\langle r^2\\rangle=3a_0^2$，$\\Delta r=\\sqrt{3}/2\\,a_0$。电子并非在固定轨道上运动，而是以概率云分布。"))
 )},
]},
{
"name": "5.3 球方势阱",
"color": "#0891b2",
"desc": "球对称方势阱的 s 波束缚态",
"items": [
{"id":"qm5s3-1","name":"球方势阱的 s 波","tags":["der"],"brief":"l=0 时球方势阱退化为一维问题。",
 "fig":"sphericalwell","figCap":"球方势阱的 s 波（l=0）波函数",
 "body": wrap(
   defn("球方势阱",p("球对称方势阱 $V(r)=-V_0$（$r<a$），$V(r)=0$（$r>a$）。$l=0$ 时离心势为零，径向方程最简单。"))+
   der(p("<strong>s 波（l=0）径向方程：</strong>$u(r)=rR(r)$ 满足：")+
   fml("u''+k^2u=0\\ (r<a),\\ k=\\sqrt{2m(E+V_0)}/\\hbar;\\qquad u''-\\kappa^2u=0\\ (r>a),\\ \\kappa=\\sqrt{-2mE}/\\hbar")+
   p("边界条件 $u(0)=0$（波函数有限），故阱内 $u=A\\sin(kr)$。阱外 $u=Be^{-\\kappa r}$。在 $r=a$ 处 $u$ 与 $u'$ 连续：")+
   fml("A\\sin(ka)=Be^{-\\kappa a},\\quad Ak\\cos(ka)=-B\\kappa e^{-\\kappa a} \\implies k\\cot(ka)=-\\kappa")+
   p("这是决定 s 波束缚态能级的超越方程。"))+
   note(p("存在束缚态的条件：$V_0a^2\\geq\\pi^2\\hbar^2/(8m)$。与一维有限深势阱不同，球方势阱太浅时不存在束缚态。"))+
   note(p("<strong>三维与一维束缚态的本质区别：</strong>一维任意浅势阱都至少有一个束缚态，但三维球方势阱必须满足 $V_0a^2\\geq\\pi^2\\hbar^2/(8m)$ 才有 s 波束缚态。这一差异源于离心势垒与三维空间的几何效应：在三维中，粒子要被束缚需克服更大的“离心排斥”。这一结果对核物理有重要意义：氘核（质子-中子束缚态）是仅有的束缚二核子态，其弱束缚（结合能 $2.2$ MeV）正是因为核力的 $V_0a^2$ 刚超过束缚阈值。$l\\geq1$ 的态因离心势垒 $\\hbar^2l(l+1)/(2mr^2)$ 更难束缚，需更深的势阱。"))
 )},
{"id":"qm5s3-2","name":"三维无限深球方势阱","tags":["der"],"brief":"球贝塞尔函数给出能级。",
 "body": wrap(
   defn("三维无限深球方势阱",p("$V(r)=0$（$r<a$），$V(r)=\\infty$（$r>a$）。边界条件 $R(a)=0$。"))+
   der(p("<strong>能级：</strong>阱内径向方程为球贝塞尔方程，解为球贝塞尔函数 $j_l(kr)$。边界条件 $j_l(ka)=0$，设 $j_l$ 的第 $n_r$ 个零点为 $\\alpha_{ln_r}$，则：")+
   fml("k=\\frac{\\alpha_{ln_r}}{a},\\qquad E_{ln_r}=\\frac{\\hbar^2\\alpha_{ln_r}^2}{2ma^2}")+
   p("例如 $j_0(x)=\\sin x/x$，零点为 $n\\pi$，故 s 波能级 $E_{0n_r}=n_r^2\\pi^2\\hbar^2/(2ma^2)$。能级对 $m$ 简并（$2l+1$ 重），但不同 $l$ 一般不同。"))+
   note(p("球贝塞尔函数 $j_l(x)$ 与半整数阶贝塞尔函数有关：$j_l(x)=\\sqrt{\\pi/(2x)}J_{l+1/2}(x)$。"))
 )},
{"id":"qm5s3-3","name":"中心力场的一般性质","tags":["der","note"],"brief":"离心势与有效势的物理意义。",
 "body": wrap(
   der(p("<strong>离心势的来源：</strong>径向方程中 $l(l+1)\\hbar^2/(2mr^2)$ 称为离心势，源于角向动能。有效势为：")+
   fml("V_{\\text{eff}}(r) = V(r) + \\frac{l(l+1)\\hbar^2}{2mr^2}")+
   p("$l$ 越大，离心势垒越高，粒子越难靠近原点，故高 $l$ 态在原点附近概率密度小。这与经典力学中角动量守恒导致的离心效应一致。"))+
   note(p("中心力场中能量与 $m$ 无关（旋转对称性），但通常与 $l$ 有关；氢原子的 $l$ 简并是库仑势的特殊对称性（Runge-Lenz 矢量守恒）所致，一般中心场不具有此简并。"))
 )},
]},
{
"name": "5.4 三维各向同性谐振子",
"color": "#0891b2",
"desc": "三维谐振子的能级与简并度",
"items": [
{"id":"qm5s4-1","name":"三维谐振子能级","tags":["der","thm"],"brief":"能级等间距，简并度与 N 有关。",
 "fig":"osc3d","figCap":"三维各向同性谐振子的等间距能级",
 "body": wrap(
   thm("三维谐振子能级",p("三维各向同性谐振子 $V(r)=\\frac12 m\\omega^2 r^2$ 的能级为：")+
   fml("E_N = \\left(N+\\frac32\\right)\\hbar\\omega,\\quad N=n_x+n_y+n_z=0,1,2,\\dots"))+
   der(p("<strong>推导：</strong>哈密顿量 $\\hat{H}=\\sum_{i=x,y,z}\\left(\\frac{\\hat{p}_i^2}{2m}+\\frac12 m\\omega^2\\hat{x}_i^2\\right)$，可分解为三个独立一维谐振子。每个方向量子数 $n_i$，能量 $E_i=(n_i+1/2)\\hbar\\omega$，总能量：")+
   fml("E = (n_x+n_y+n_z+3/2)\\hbar\\omega = (N+3/2)\\hbar\\omega")+
   p("其中 $N=n_x+n_y+n_z$。给定 $N$，$n_x,n_y,n_z$ 的非负整数解数目为组合数 $C(N+2,2)$，故简并度：")+
   fml("f_N = \\frac{(N+1)(N+2)}{2}"))+
   note(p("在球坐标中求解时，同一 $N$ 对应 $l=N,N-2,\\dots$（与 $N$ 同奇偶），简并度同样为 $(N+1)(N+2)/2$，与直角坐标结果一致。"))
 )},
{"id":"qm5s4-2","name":"直角坐标与球坐标解的关系","tags":["der"],"brief":"两种表象通过幺正变换联系。",
 "body": wrap(
   der(p("<strong>直角坐标解：</strong>波函数为三个一维谐振子波函数之积 $\\psi_{n_xn_yn_z}=\\psi_{n_x}(x)\\psi_{n_y}(y)\\psi_{n_z}(z)$，是 $\\hat{H},\\hat{n}_x,\\hat{n}_y,\\hat{n}_z$ 的共同本征态。"))+
   der(p("<strong>球坐标解：</strong>波函数为 $R_{nl}(r)Y_l^m(\\theta,\\varphi)$，是 $\\hat{H},\\hat{L}^2,\\hat{L}_z$ 的共同本征态。同一 $N$ 的直角坐标本征态张成简并子空间，球坐标本征态是该子空间中按角动量分类的另一组基，二者通过幺正变换联系。"))+
   note(p("例如 $N=1$ 时有 3 重简并，直角坐标基为 $\\psi_{100},\\psi_{010},\\psi_{001}$，球坐标基为 $l=1,m=-1,0,1$，两组基线性相关。"))
 )},
{"id":"qm5s4-3","name":"谐振子模型的应用","tags":["app","exa"],"brief":"原子核壳模型与离子晶体振动。",
 "body": wrap(
   app(p("<strong>应用：</strong>三维各向同性谐振子是原子核壳模型的基础平均场，解释了原子核的「幻数」（2,8,20,28,50,82,126）的前几个。其等间距能级、高简并度与自旋轨道耦合的结合给出壳层结构。"))+
   der(p("<strong>零点能：</strong>三维谐振子基态能量 $E_0=3\\hbar\\omega/2$，是三个方向零点能之和。即使在绝对零度，粒子仍具有零点振动能，这是量子效应的直接体现，可通过中子散射实验测量。"))+
   note(p("分子振动、离子在晶格中的振动等都可近似为三维谐振子；低温下零点振动对固体性质有显著影响（如氦在常压下不凝固）。"))
 )},
]},
]

ch6_sections = [
{
"name": "6.1 电子自旋与泡利矩阵",
"color": "#be185d",
"desc": "电子自旋假设、泡利矩阵与自旋态",
"items": [
{"id":"qm6s1-1","name":"电子自旋的实验证据","tags":["def","der"],"brief":"斯特恩-盖拉赫实验揭示自旋。",
 "fig":"spin","figCap":"电子自旋在磁场中的两种取向",
 "body": wrap(
   defn("电子自旋",p("电子具有内禀角动量（自旋），自旋量子数 $s=1/2$，在任意方向的投影只能取 $\\pm\\hbar/2$ 两个值。自旋不是机械自转，而是微观粒子的内禀属性。"))+
   der(p("<strong>斯特恩-盖拉赫实验：</strong>银原子束通过非均匀磁场后分裂为两束，说明电子磁矩在磁场方向只有两个取向。若只有轨道角动量，束数应为奇数（$2l+1$），两束的结果表明存在半整数角动量——自旋。自旋磁矩 $\\boldsymbol\\mu_s=-g_s(e/2m_e)\\mathbf{S}$，$g_s\\approx2$。"))+
   note(p("自旋是相对论量子力学的自然结果（狄拉克方程），泡利与古兹密特、乌伦贝克于 1925 年提出自旋假设。"))+
   app(p("<strong>自旋的现代应用：</strong>电子自旋是自旋电子学（spintronics）的核心：巨磁阻效应（GMR）利用自旋极化输运实现硬盘读写磁头；自旋转移力矩（STT）用于磁随机存储器（MRAM）；量子计算中电子自旋、核自旋作为量子比特（qubit），因其较长的退相干时间而备受关注。核磁共振（NMR）与磁共振成像（MRI）则利用核自旋在磁场中的进动。"))
 )},
{"id":"qm6s1-2","name":"泡利矩阵","tags":["der","thm"],"brief":"描述自旋 1/2 的矩阵及其代数。",
 "body": wrap(
   defn("泡利矩阵",p("在 $\\hat{S}_z$ 表象中，自旋算符 $\\hat{\\mathbf{S}}=\\frac{\\hbar}{2}\\boldsymbol{\\sigma}$，泡利矩阵为：")+
   fml("\\sigma_x=\\begin{pmatrix}0&1\\\\1&0\\end{pmatrix},\\ \\sigma_y=\\begin{pmatrix}0&-i\\\\i&0\\end{pmatrix},\\ \\sigma_z=\\begin{pmatrix}1&0\\\\0&-1\\end{pmatrix}"))+
   der(p("<strong>代数性质：</strong>泡利矩阵满足：")+
   fml("[\\sigma_i,\\sigma_j]=2i\\varepsilon_{ijk}\\sigma_k,\\quad \\{\\sigma_i,\\sigma_j\\}=2\\delta_{ij},\\quad \\sigma_i^2=I,\\quad \\sigma_i^\\dagger=\\sigma_i")+
   p("由对易与反对易关系可推出 $\\sigma_i\\sigma_j=\\delta_{ij}I+i\\varepsilon_{ijk}\\sigma_k$。任意方向单位矢量 $\\mathbf{n}$ 的自旋投影 $\\hat{S}_{\\mathbf{n}}=\\frac{\\hbar}{2}\\mathbf{n}\\cdot\\boldsymbol{\\sigma}$ 的本征值为 $\\pm\\hbar/2$。"))+
   exa(p("<strong>例：</strong>$\\sigma_x$ 的本征态为 $(|\\uparrow\\rangle\\pm|\\downarrow\\rangle)/\\sqrt2$，对应 $S_x=\\pm\\hbar/2$；$\\sigma_y$ 的本征态为 $(|\\uparrow\\rangle\\pm i|\\downarrow\\rangle)/\\sqrt2$。"))
 )},
{"id":"qm6s1-3","name":"自旋态的表示与测量","tags":["der"],"brief":"二分量旋量与自旋测量概率。",
 "body": wrap(
   defn("自旋态",p("电子自旋态为二分量旋量（在 $S_z$ 表象中）：")+
   fml("\\chi = \\begin{pmatrix}a\\\\b\\end{pmatrix} = a|\\uparrow\\rangle+b|\\downarrow\\rangle,\\qquad |a|^2+|b|^2=1")+
   p("其中 $|a|^2$、$|b|^2$ 分别为测量 $S_z$ 得 $+\\hbar/2$、$-\\hbar/2$ 的概率。"))+
   der(p("<strong>任意方向的自旋投影：</strong>测量 $S_{\\mathbf{n}}$（$\\mathbf{n}=(\\sin\\theta\\cos\\varphi,\\sin\\theta\\sin\\varphi,\\cos\\theta)$）得 $+\\hbar/2$ 的概率为 $|\\langle\\uparrow_{\\mathbf{n}}|\\chi\\rangle|^2$，其中 $|\\uparrow_{\\mathbf{n}}\\rangle=\\cos(\\theta/2)|\\uparrow\\rangle+\\sin(\\theta/2)e^{i\\varphi}|\\downarrow\\rangle$。对纯 $|\\uparrow\\rangle$ 态，测量 $S_{\\mathbf{n}}$ 得 $+\\hbar/2$ 的概率为 $\\cos^2(\\theta/2)$。"))+
   app(p("<strong>应用：</strong>自旋态是量子比特的物理实现之一，泡利矩阵对应量子计算中的 Pauli-X、Y、Z 门。"))+
   note(p("<strong>自旋测量的非对易性：</strong>自旋测量生动体现了量子力学的非对易性。若电子处于 $|\\uparrow_z\\rangle$ 态，测量 $S_z$ 必然得 $+\\hbar/2$；但测量 $S_x$ 则各以 $1/2$ 概率得 $\\pm\\hbar/2$。更精妙的是：先测 $S_x$ 得 $+\\hbar/2$（态坍缩到 $|\\uparrow_x\\rangle$），再测 $S_z$，又各以 $1/2$ 概率得 $\\pm\\hbar/2$。这表明测量会扰动系统状态，且不对易力学量不能同时取确定值。自旋 $1/2$ 的态空间是最简单的二维希尔伯特空间，是理解量子叠加、坍缩、纠缠等基本概念的理想平台，也是量子信息中量子比特的标准模型。"))
 )},
]},
{
"name": "6.2 角动量耦合与 CG 系数",
"color": "#be185d",
"desc": "两个角动量的耦合、CG 系数与 3j 符号",
"items": [
{"id":"qm6s2-1","name":"角动量耦合","tags":["der","thm"],"brief":"两个角动量耦合后的总角动量。",
 "fig":"cg","figCap":"两个角动量耦合为总角动量",
 "body": wrap(
   thm("角动量耦合定理",p("两个角动量 $\\hat{\\mathbf{J}}_1$、$\\hat{\\mathbf{J}}_2$ 耦合为总角动量 $\\hat{\\mathbf{J}}=\\hat{\\mathbf{J}}_1+\\hat{\\mathbf{J}}_2$，总角动量量子数 $J$ 的取值为：")+
   fml("|j_1-j_2| \\leq J \\leq j_1+j_2")+
   p("所有取值间隔为 1（三角形法则）。"))+
   der(p("<strong>推导：</strong>耦合表象基 $|JM\\rangle$ 是 $\\hat{J}^2,\\hat{J}_z$ 的共同本征态，由无耦合基 $|j_1m_1j_2m_2\\rangle$ 线性组合。$M=m_1+m_2$，故 $M$ 最大值为 $j_1+j_2$，对应 $J_{\\max}=j_1+j_2$。$M$ 次大值 $j_1+j_2-1$ 出现两次（一个来自 $J=j_1+j_2$，一个来自新的 $J=j_1+j_2-1$），依此类推，直到 $J=|j_1-j_2|$。总态数 $\\sum_{J=|j_1-j_2|}^{j_1+j_2}(2J+1)=(2j_1+1)(2j_2+1)$，与无耦合基数目一致。"))+
   note(p("例如 $j_1=l$（轨道）、$j_2=s=1/2$（自旋）耦合为总角动量 $j=l\\pm1/2$，这是自旋-轨道耦合的基础。"))+
   note(p("<strong>角动量耦合的物理意义：</strong>当两个角动量对应的哈密顿量项（如自旋-轨道相互作用 $\\xi(r)\\mathbf{L}\\cdot\\mathbf{S}$）存在时，$\\mathbf{L}$ 与 $\\mathbf{S}$ 不再分别守恒，而总角动量 $\\mathbf{J}=\\mathbf{L}+\\mathbf{S}$ 守恒。因此选择耦合表象（$|JM\\rangle$）而非无耦合表象（$|lm_lsm_s\\rangle$）作为定态基更自然。耦合系数 CG 是将两个不可约表示张量积分解为不可约表示直和的变换矩阵，在原子物理、核物理中广泛用于计算矩阵元与选择定则。"))
 )},
{"id":"qm6s2-2","name":"克莱布希-高登系数","tags":["def","der"],"brief":"无耦合基到耦合基的变换系数。",
 "body": wrap(
   defn("CG 系数",p("耦合基用无耦合基展开：")+
   fml("|JM\\rangle = \\sum_{m_1m_2}\\langle j_1m_1j_2m_2|JM\\rangle|j_1m_1j_2m_2\\rangle")+
   p("展开系数 $\\langle j_1m_1j_2m_2|JM\\rangle$ 称为克莱布希-高登（CG）系数。"))+
   der(p("<strong>CG 系数的性质：</strong>(1) 仅当 $M=m_1+m_2$ 时非零；(2) 仅当 $|j_1-j_2|\\leq J\\leq j_1+j_2$ 时非零；(3) 正交归一性 $\\sum_{m_1m_2}\\langle j_1m_1j_2m_2|JM\\rangle\\langle j_1m_1j_2m_2|J'M'\\rangle=\\delta_{JJ'}\\delta_{MM'}$；(4) 对称性由 Racah 公式给出。CG 系数可由递推关系（利用 $\\hat{J}_\\pm$ 作用）导出。"))+
   exa(p("<strong>例：</strong>$j_1=1,j_2=1/2,J=3/2,M=1/2$ 时，$|\\tfrac32,\\tfrac12\\rangle=\\sqrt{\\tfrac23}|1,0\\rangle|\\tfrac12,\\tfrac12\\rangle+\\sqrt{\\tfrac13}|1,1\\rangle|\\tfrac12,-\\tfrac12\\rangle$。"))
 )},
{"id":"qm6s2-3","name":"自旋轨道耦合与总角动量","tags":["der"],"brief":"L·S 耦合给出精细结构。",
 "fig":"spinorbit","figCap":"轨道角动量 L 与自旋 S 耦合为总角动量 J",
 "body": wrap(
   defn("自旋-轨道耦合",p("电子在原子核电场中运动时，其自旋磁矩与轨道运动产生的磁场相互作用，哈密顿量为：")+
   fml("\\hat{H}_{SO} = \\xi(r)\\hat{\\mathbf{L}}\\cdot\\hat{\\mathbf{S}}"))+
   der(p("<strong>L·S 表达式：</strong>由 $\\hat{\\mathbf{J}}=\\hat{\\mathbf{L}}+\\hat{\\mathbf{S}}$，平方得 $\\hat{J}^2=\\hat{L}^2+\\hat{S}^2+2\\hat{\\mathbf{L}}\\cdot\\hat{\\mathbf{S}}$，故：")+
   fml("\\hat{\\mathbf{L}}\\cdot\\hat{\\mathbf{S}} = \\frac12(\\hat{J}^2-\\hat{L}^2-\\hat{S}^2)")+
   p("在 $|lsjm_j\\rangle$ 表象中，$\\hat{H}_{SO}$ 对角，其本征值为 $\\frac12\\hbar^2[j(j+1)-l(l+1)-s(s+1)]\\langle\\xi(r)\\rangle$。对给定 $l$，$j=l+1/2$ 与 $j=l-1/2$ 能量不同，产生精细结构分裂。"))+
   note(p("氢原子的精细结构（兰姆移位之前的修正）即由自旋-轨道耦合与相对论动能修正共同产生，使 $2p_{1/2}$ 与 $2p_{3/2}$ 能级分裂。"))+
   note(p("<strong>精细结构的量级：</strong>自旋-轨道耦合能量 $\\Delta E_{SO}\\sim\\alpha^2 E_n$，其中 $\\alpha=e^2/(4\\pi\\varepsilon_0\\hbar c)\\approx1/137$ 为精细结构常数。例如氢原子 $2p$ 能级的精细结构分裂约 $4.5\\times10^{-5}$ eV，对应波长差约 0.01 nm，需高分辨光谱才能观测。精细结构常数 $\\alpha$ 是量子电动力学（QED）的基本参数，衡量电磁相互作用的强度，其倒数的精确测量是检验标准模型的重要手段。"))
 )},
]},
{
"name": "6.3 精细结构与自旋轨道耦合",
"color": "#be185d",
"desc": "氢原子精细结构、LS 耦合与 jj 耦合",
"items": [
{"id":"qm6s3-1","name":"氢原子的精细结构","tags":["der"],"brief":"相对论修正与自旋轨道耦合。",
 "body": wrap(
   defn("精细结构",p("氢原子能级在考虑相对论效应后，由主量子数 $n$ 与总角动量 $j$ 共同决定，同一 $n$、不同 $j$ 的能级发生分裂，称为精细结构。"))+
   der(p("<strong>相对论修正：</strong>哈密顿量的相对论修正包括动能修正 $\\hat{H}_r=-\\hat{p}^4/(8m^3c^2)$ 和自旋-轨道耦合 $\\hat{H}_{SO}$。用微扰论计算得能级的精细结构修正：")+
   fml("\\Delta E_{nj} = -\\frac{mc^2\\alpha^4}{2n^4}\\left(\\frac{n}{j+1/2}-\\frac34\\right)")+
   p("其中 $\\alpha=e^2/(4\\pi\\varepsilon_0\\hbar c)\\approx1/137$ 为精细结构常数。修正后能级只与 $n,j$ 有关，$l$ 相同但 $j$ 不同的态分裂，$j$ 相同但 $l$ 不同的态仍简并（此简并被 QED 兰姆移位解除）。"))+
   note(p("精细结构常数 $\\alpha$ 是电磁相互作用强度的量度，在原子物理中极为重要；氢原子 $2p_{3/2}$ 与 $2p_{1/2}$ 的分裂约为 $4.5\\times10^{-5}\\,\\text{eV}$。"))+
   note(p("<strong>兰姆移位与 QED：</strong>精细结构预言 $2s_{1/2}$ 与 $2p_{1/2}$ 能级简并，但 1947 年兰姆与雷瑟福实验发现二者相差约 $1057$ MHz（$4.37\\times10^{-6}$ eV），称为兰姆移位。这一效应源于电子与量子化电磁场的相互作用（真空涨落与虚光子发射吸收），只能用量子电动力学（QED）解释。兰姆移位是 QED 最精确的验证之一，其理论计算与实验符合到 12 位有效数字，被誉为“物理学中最精确的预测”。"))
 )},
{"id":"qm6s3-2","name":"LS 耦合与 jj 耦合","tags":["def","der"],"brief":"多电子原子的两种角动量耦合方案。",
 "body": wrap(
   defn("LS 耦合（罗素-桑德斯耦合）",p("当电子间剩余库仑相互作用大于自旋-轨道耦合时，先将各电子轨道角动量耦合为总轨道 $\\mathbf{L}=\\sum\\mathbf{l}_i$，自旋耦合为总自旋 $\\mathbf{S}=\\sum\\mathbf{s}_i$，再耦合为总角动量 $\\mathbf{J}=\\mathbf{L}+\\mathbf{S}$。"))+
   der(p("<strong>光谱项：</strong>LS 耦合下的能级用光谱项 $^{2S+1}L_J$ 标记，其中 $L=0,1,2,\\dots$ 对应 S,P,D,F,...。例如氦原子基态 $^1S_0$（单态，自旋反平行），第一激发态有 $^3S_1$（三重态，自旋平行），二者能量不同（交换效应）。"))+
   note(p("轻元素（低 $Z$）适用 LS 耦合；重元素（高 $Z$）自旋-轨道耦合较强，适用 jj 耦合：每个电子的 $\\mathbf{j}_i=\\mathbf{l}_i+\\mathbf{s}_i$ 先耦合，再耦合为总 $\\mathbf{J}=\\sum\\mathbf{j}_i$。"))
 )},
{"id":"qm6s3-3","name":"洪特定则与能级顺序","tags":["app","der"],"brief":"确定原子基态光谱项的经验规则。",
 "body": wrap(
   defn("洪特定则",p("对给定电子组态，基态光谱项满足：(1) 自旋多重度 $2S+1$ 最大者能量最低；(2) 同 $S$ 时 $L$ 最大者最低；(3) 壳层半满前 $J=|L-S|$ 最低，半满后 $J=L+S$ 最低。"))+
   der(p("<strong>物理依据：</strong>S 最大意味着自旋平行的电子多，由泡利原理它们的空间波函数反对称，电子间距离较远，库仑排斥能低，故能量低。L 最大则电子轨道运动的「相关性」使库仑能降低。"))+
   exa(p("<strong>例：</strong>碳原子基态组态 $1s^22s^22p^2$，两个 p 电子。S 最大为 1（自旋平行），L 最大为 1（P 态），半满前 $J=0$，故基态 $^3P_0$。"))
 )},
]},
{
"name": "6.4 塞曼效应与反常塞曼效应",
"color": "#be185d",
"desc": "外磁场下的能级分裂与谱线",
"items": [
{"id":"qm6s4-1","name":"正常塞曼效应","tags":["der"],"brief":"外磁场下自旋单态的能级分裂。",
 "fig":"zeeman","figCap":"塞曼效应：外磁场使能级按 m 分裂",
 "body": wrap(
   defn("正常塞曼效应",p("当原子的总自旋 $S=0$（单态）时，外磁场 $B$ 使能级按 $m_L$ 分裂，相邻能级间隔为 $\\mu_B B$（$\\mu_B=e\\hbar/(2m_e)$ 为玻尔磁子）。"))+
   der(p("<strong>塞曼哈密顿量：</strong>$\\hat{H}_Z=-\\boldsymbol\\mu\\cdot\\mathbf{B}=\\frac{eB}{2m_e}\\hat{L}_z=\\mu_B B\\hat{L}_z/\\hbar$。在 $|Lm_L\\rangle$ 表象中，附加能量 $\\Delta E=m_L\\mu_B B$，$m_L=-L,\\dots,L$，共 $2L+1$ 个等间距能级。跃迁选择定则 $\\Delta m_L=0,\\pm1$，故每条谱线分裂为三条。"))+
   note(p("正常塞曼效应可由经典理论与玻尔模型解释，但反常塞曼效应（含自旋）必须用量子力学自旋解释。"))
 )},
{"id":"qm6s4-2","name":"反常塞曼效应","tags":["der"],"brief":"含自旋时能级分裂更复杂。",
 "body": wrap(
   der(p("<strong>含自旋的塞曼哈密顿量：</strong>总磁矩 $\\boldsymbol\\mu=-(e/2m_e)(\\hat{\\mathbf{L}}+2\\hat{\\mathbf{S}})$，故：")+
   fml("\\hat{H}_Z = \\frac{eB}{2m_e}(\\hat{L}_z+2\\hat{S}_z) = \\mu_B B(\\hat{J}_z+\\hat{S}_z)/\\hbar")+
   p("在 $|JM\\rangle$ 表象中，$\\hat{S}_z$ 非对角。用微扰论（弱场）得一级修正：")+
   fml("\\Delta E = g_J M\\mu_B B,\\qquad g_J=1+\\frac{J(J+1)+S(S+1)-L(L+1)}{2J(J+1)}")+
   p("朗德 g 因子 $g_J$ 随态而异，导致谱线分裂为多条（非均匀），即反常塞曼效应。"))+
   note(p("强磁场下（$B$ 很大，超过自旋-轨道耦合），LS 耦合解除，$\\hat{L}_z$、$\\hat{S}_z$ 近似守恒，能级按 $m_L+2m_S$ 分裂，谱线趋于三条（帕邢-巴克效应）。"))
 )},
{"id":"qm6s4-3","name":"电子顺磁共振与核磁共振","tags":["app"],"brief":"塞曼效应在磁共振中的应用。",
 "body": wrap(
   defn("磁共振",p("处于外磁场中的自旋磁矩在相邻塞曼能级间跃迁，当外加射频场频率满足 $h\\nu=\\Delta E=g\\mu_B B$（电子）或 $h\\nu=g_N\\mu_N B$（核）时发生共振吸收，称为电子顺磁共振（EPR）或核磁共振（NMR）。"))+
   der(p("<strong>共振条件：</strong>电子自旋 $S=1/2$ 在磁场 $B$ 中分裂为 $E_\\pm=\\pm g_s\\mu_B B/2$，能级差 $\\Delta E=g_s\\mu_B B$。共振时射频光子能量 $h\\nu=g_s\\mu_B B$。通过测量共振频率或磁场可得到 $g$ 因子，反映电子所处的化学环境。"))+
   app(p("<strong>应用：</strong>NMR 是化学结构分析（NMR 谱）与医学成像（MRI）的基础；EPR 用于研究自由基与顺磁中心；原子钟利用氢原子基态超精细跃迁的塞曼效应实现高精度计时。"))
 )},
]},
]

ch7_sections = [
{
"name": "7.1 非简并定态微扰论",
"color": "#c2410c",
"desc": "非简并能级的一、二级微扰修正",
"items": [
{"id":"qm7s1-1","name":"微扰论的基本思想","tags":["def","der"],"brief":"将哈密顿量分为可解部分与小微扰。",
 "fig":"perturb","figCap":"微扰使能级与波函数发生移动",
 "body": wrap(
   defn("定态微扰论",p("设 $\\hat{H}=\\hat{H}_0+\\lambda\\hat{H}'$，其中 $\\hat{H}_0$ 的本征值 $E_n^{(0)}$ 与本征态 $|n^{(0)}\\rangle$ 已知，$\\lambda\\hat{H}'$ 为小微扰（$\\lambda\\ll1$）。将能级与波函数展开为 $\\lambda$ 的幂级数：")+
   fml("E_n = E_n^{(0)}+\\lambda E_n^{(1)}+\\lambda^2 E_n^{(2)}+\\cdots,\\quad |n\\rangle=|n^{(0)}\\rangle+\\lambda|n^{(1)}\\rangle+\\lambda^2|n^{(2)}\\rangle+\\cdots"))+
   der(p("<strong>逐级方程：</strong>代入 $\\hat{H}|n\\rangle=E_n|n\\rangle$，比较 $\\lambda$ 各阶：")+
   fml("\\lambda^0:\\ \\hat{H}_0|n^{(0)}\\rangle=E_n^{(0)}|n^{(0)}\\rangle")+
   fml("\\lambda^1:\\ (\\hat{H}_0-E_n^{(0)})|n^{(1)}\\rangle = -(\\hat{H}'-E_n^{(1)})|n^{(0)}\\rangle")+
   p("左乘 $\\langle n^{(0)}|$ 并利用 $\\hat{H}_0$ 厄米性，得一级能量修正 $E_n^{(1)}=\\langle n^{(0)}|\\hat{H}'|n^{(0)}\\rangle$。"))+
   note(p("微扰论是近似方法，要求微扰足够小（能级间隔远大于微扰矩阵元），否则级数可能不收敛。"))+
   note(p("<strong>收敛性与适用条件：</strong>非简并微扰论的收敛条件为 $|H'_{kn}|/|E_k^{(0)}-E_n^{(0)}|\\ll1$ 对所有 $k\\neq n$。当存在简并或近简并能级时，普通非简并公式失效（分母趋零），必须使用简并微扰论，先在简并子空间内对角化微扰哈密顿量以消除奇异性。实际计算中，微扰级数通常为渐近级数，取前几阶即可获得高精度结果。"))
 )},
{"id":"qm7s1-2","name":"一级波函数与二级能量","tags":["der","thm"],"brief":"非简并微扰的二级修正公式。",
 "body": wrap(
   thm("非简并微扰修正",p("非简并情况下，能级与波函数的微扰修正为：")+
   fml("E_n^{(1)} = H'_{nn},\\quad E_n^{(2)} = \\sum_{k\\neq n}\\frac{|H'_{kn}|^2}{E_n^{(0)}-E_k^{(0)}},\\quad |n^{(1)}\\rangle = \\sum_{k\\neq n}\\frac{H'_{kn}}{E_n^{(0)}-E_k^{(0)}}|k^{(0)}\\rangle")+
   p("其中 $H'_{kn}=\\langle k^{(0)}|\\hat{H}'|n^{(0)}\\rangle$。"))+
   der(p("<strong>二级能量推导：</strong>一级波函数按未受扰基展开 $|n^{(1)}\\rangle=\\sum_{k\\neq n}c_k^{(1)}|k^{(0)}\\rangle$（取 $c_n^{(1)}=0$ 固定相位）。代入一级方程并左乘 $\\langle k^{(0)}|$（$k\\neq n$）：")+
   fml("(E_k^{(0)}-E_n^{(0)})c_k^{(1)} = -H'_{kn} \\implies c_k^{(1)}=\\frac{H'_{kn}}{E_n^{(0)}-E_k^{(0)}}")+
   p("二级方程左乘 $\\langle n^{(0)}|$：$E_n^{(2)}=\\langle n^{(0)}|\\hat{H}'|n^{(1)}\\rangle=\\sum_{k\\neq n}H'_{nk}c_k^{(1)}=\\sum_{k\\neq n}|H'_{kn}|^2/(E_n^{(0)}-E_k^{(0)})$。"))+
   note(p("二级修正符号：基态 $E_0^{(0)}$ 最低，$E_0^{(0)}-E_k^{(0)}<0$，故 $E_0^{(2)}<0$，微扰降低基态能量。"))+
   note(p("<strong>二级修正的物理意义：</strong>二级能量修正 $E_n^{(2)}=\\sum_{k\\neq n}|H'_{kn}|^2/(E_n^{(0)}-E_k^{(0)})$ 可理解为微扰使态 $|n^{(0)}\\rangle$ 与其它态 $|k^{(0)}\\rangle$ 发生混合（一级波函数修正），这种混合总是降低基态能量（因所有 $E_k>E_0$，分母为负）。对激发态，二级修正可正可负，取决于邻近视能级的相对位置。二级修正的存在意味着：即使微扰在一级为零（如电偶极矩对球对称基态），仍可通过与激发态的虚混合产生可观测效应（如原子极化率、范德瓦尔斯力）。这是量子力学中“虚跃迁”概念的体现。"))
 )},
{"id":"qm7s1-3","name":"电偶极微扰实例","tags":["der","exa"],"brief":"谐振子在电场中的能级移动。",
 "body": wrap(
   exa(p("<strong>例：</strong>一维谐振子受均匀电场 $\\mathcal{E}$，微扰 $\\hat{H}'=-q\\mathcal{E}\\hat{x}$。由于 $\\langle n|x|n\\rangle=0$，一级修正为零。二级修正：")+
   fml("E_n^{(2)} = q^2\\mathcal{E}^2\\sum_{k\\neq n}\\frac{|\\langle k|x|n\\rangle|^2}{E_n^{(0)}-E_k^{(0)}}")+
   p("利用 $\\langle k|x|n\\rangle$ 仅当 $k=n\\pm1$ 非零，计算得 $E_n^{(2)}=-q^2\\mathcal{E}^2/(2m\\omega^2)$，与电场中谐振子精确解（势能极小点移动）一致。"))+
   der(p("<strong>极化率：</strong>能级移动 $\\Delta E=-\\frac12\\alpha\\mathcal{E}^2$，故极化率 $\\alpha=q^2/(m\\omega^2)$。对谐振子 $\\langle x^2\\rangle=(n+1/2)\\hbar/(m\\omega)$，感应偶极矩 $\\langle p\\rangle=q\\langle x\\rangle=q^2\\mathcal{E}/(m\\omega^2)=\\alpha\\mathcal{E}$，自洽。"))+
   app(p("<strong>应用：</strong>微扰论广泛用于原子、分子在外场中的能级移动（斯塔克效应、极化率）、固体中的缺陷能级等。"))
 )},
]},
{
"name": "7.2 简并微扰论",
"color": "#c2410c",
"desc": "简并能级的微扰处理与久期方程",
"items": [
{"id":"qm7s2-1","name":"简并微扰的问题","tags":["def","der"],"brief":"非简并公式在简并时失效。",
 "body": wrap(
   defn("简并微扰论",p("当未受扰能级 $E_n^{(0)}$ 为 $f$ 重简并（对应 $f$ 个线性无关本征态）时，非简并微扰公式中分母 $E_n^{(0)}-E_k^{(0)}$ 可为零，导致发散，需用简并微扰论处理。"))+
   der(p("<strong>零级波函数的确定：</strong>设简并子空间基为 $|n\\alpha^{(0)}\\rangle$（$\\alpha=1,\\dots,f$），正确的零级波函数是它们的线性组合 $|n^{(0)}\\rangle=\\sum_\\alpha c_\\alpha|n\\alpha^{(0)}\\rangle$。代入一级方程并要求非齐次项与简并子空间正交，得：")+
   fml("\\sum_\\alpha (H'_{\\beta\\alpha}-E^{(1)}\\delta_{\\beta\\alpha})c_\\alpha = 0")+
   p("其中 $H'_{\\beta\\alpha}=\\langle n\\beta^{(0)}|\\hat{H}'|n\\alpha^{(0)}\\rangle$。这是 $f$ 阶线性齐次方程组，有非零解条件为久期方程 $\\det(H'-E^{(1)}I)=0$。"))+
   note(p("解久期方程得一级能量修正 $E^{(1)}$ 的 $f$ 个根，对应 $f$ 个分裂后的能级；简并被微扰部分或完全解除。"))
 )},
{"id":"qm7s2-2","name":"久期方程的求解","tags":["der","thm"],"brief":"久期方程给出一级能量修正。",
 "body": wrap(
   thm("简并微扰一级修正",p("简并能级的一级能量修正由久期方程的根给出：")+
   fml("\\det(H'_{\\beta\\alpha} - E^{(1)}\\delta_{\\beta\\alpha}) = 0")+
   p("每个根对应一个一级修正后的能级与零级波函数。"))+
   der(p("<strong>推导：</strong>微扰 $\\hat{H}'$ 在简并子空间中可视为一个 $f\\times f$ 厄米矩阵。将其对角化即得一级能量修正（矩阵本征值）与零级波函数（本征矢）。这等价于在简并子空间中选择使 $\\hat{H}'$ 对角的基。若微扰完全解除简并，则 $f$ 个根互不相同；若仍有相同根，则残余简并需用更高阶微扰或考虑对称性。"))+
   exa(p("<strong>例：</strong>氢原子 $n=2$ 能级四重简并（$2s,2p_{-1},2p_0,2p_{+1}$），外加电场时斯塔克效应使其中 $2s$ 与 $2p_0$ 混合，久期方程为 $2\\times2$，解得能级分裂为三条。"))+
   note(p("<strong>简并微扰论的实质：</strong>简并微扰论的核心思想是在简并子空间内重新选择基矢，使微扰哈密顿量 $\\hat{H}'$ 对角化。由于简并态之间能量相同，任意线性组合仍是未受扰哈密顿量的本征态，但只有使 $\\hat{H}'$ 对角的那些组合才是“正确的零级波函数”——它们在微扰开启时不会发散。这与线性代数中将矩阵对角化的过程完全一致。若存在对称性使某些矩阵元为零（如氢原子斯塔克效应中 $\\langle 2s|z|2p_{\\pm1}\\rangle=0$），则久期行列式可分块对角化，问题简化。残余简并（久期方程有重根）通常对应某种未被微扰破坏的对称性。"))
 )},
{"id":"qm7s2-3","name":"斯塔克效应","tags":["der","app"],"brief":"氢原子在外电场中的能级分裂。",
 "fig":"stark","figCap":"斯塔克效应：电场使简并能级分裂",
 "body": wrap(
   defn("斯塔克效应",p("原子在外电场中能级发生分裂与移动的现象。氢原子 $n=2$ 能级的斯塔克效应是简并微扰论的经典应用。"))+
   der(p("<strong>氢原子 n=2 斯塔克效应：</strong>微扰 $\\hat{H}'=e\\mathcal{E}z$（电场沿 z 方向）。$2s$（$|200\\rangle$）与 $2p_0$（$|210\\rangle$）宇称相反，矩阵元 $\\langle 200|z|210\\rangle=-3a_0$ 非零；$2p_{\\pm1}$ 不参与耦合（$m=\\pm1$）。久期方程为：")+
   fml("\\begin{vmatrix}-E^{(1)} & -3e\\mathcal{E}a_0 \\\\ -3e\\mathcal{E}a_0 & -E^{(1)}\\end{vmatrix}=0 \\implies E^{(1)}=\\pm3e\\mathcal{E}a_0")+
   p("故 $n=2$ 能级分裂为三条：$E_2\\pm3e\\mathcal{E}a_0$（来自 $2s$-$2p_0$ 混合）和不变的 $E_2$（$2p_{\\pm1}$）。这是线性斯塔克效应。"))+
   note(p("氢原子的线性斯塔克效应源于 $2s$ 与 $2p$ 的偶然简并；一般原子（如碱金属）的 $s,p$ 能级不简并，只有二次斯塔克效应。"))
 )},
]},
{
"name": "7.3 变分法",
"color": "#c2410c",
"desc": "变分原理、试探波函数与基态能量",
"items": [
{"id":"qm7s3-1","name":"变分原理","tags":["thm","der"],"brief":"任意态的能量期望不低于基态能量。",
 "fig":"variational","figCap":"变分法：期望值的极小值逼近基态能量",
 "body": wrap(
   thm("变分原理",p("对任意满足边界条件的归一化波函数 $|\\psi\\rangle$，其能量期望值满足：")+
   fml("\\langle\\psi|\\hat{H}|\\psi\\rangle \\geq E_0")+
   p("其中 $E_0$ 为基态能量，等号当且仅当 $|\\psi\\rangle$ 为基态时成立。"))+
   der(p("<strong>证明：</strong>将 $|\\psi\\rangle$ 按 $\\hat{H}$ 的本征态展开 $|\\psi\\rangle=\\sum_n c_n|n\\rangle$，$\\sum_n|c_n|^2=1$。则：")+
   fml("\\langle H\\rangle = \\sum_n |c_n|^2 E_n \\geq E_0\\sum_n|c_n|^2 = E_0")+
   p("因 $E_n\\geq E_0$，等号当且仅当只有 $c_0$ 非零。变分原理是变分法的理论基础，提供了基态能量的严格上界。"))+
   note(p("变分法不限于基态：选择与基态正交的试探波函数，可得到第一激发态能量的上界，依此类推。"))+
   note(p("<strong>变分法的优势与局限：</strong>变分原理的最大优势是提供基态能量的严格上界，且不需要势场可解。通过选取含可调参数的试探波函数 $\\psi(\\lambda)$，计算 $E(\\lambda)=\\langle\\psi(\\lambda)|H|\\psi(\\lambda)\\rangle/\\langle\\psi(\\lambda)|\\psi(\\lambda)\\rangle$，对 $\\lambda$ 求极小即可逼近基态。试探波函数的选取依赖物理直觉（如基态宇称、节点数），选取越好结果越精确。变分法广泛用于分子、固体、原子核的基态计算，是量子化学与第一性原理计算的核心方法之一。"))
 )},
{"id":"qm7s3-2","name":"瑞利-里兹变分法","tags":["der"],"brief":"含参数试探波函数的极值法。",
 "body": wrap(
   defn("瑞利-里兹变分法",p("选择含可调参数的试探波函数 $|\\psi(\\alpha)\\rangle$，计算能量期望 $\\langle H\\rangle(\\alpha)$，对参数求极小值：")+
   fml("\\frac{\\partial}{\\partial\\alpha}\\langle H\\rangle(\\alpha) = 0")+
   p("极小值即为基态能量的近似上界，对应的波函数为基态近似。"))+
   der(p("<strong>多参数与线性变分：</strong>若试探波函数为基函数的线性组合 $|\\psi\\rangle=\\sum_i c_i|\\phi_i\\rangle$，则 $\\langle H\\rangle=\\sum_{ij}c_i^*H_{ij}c_j/\\sum_{ij}c_i^*S_{ij}c_j$（$H_{ij}=\\langle\\phi_i|H|\\phi_j\\rangle$，$S_{ij}=\\langle\\phi_i|\\phi_j\\rangle$）。对 $c_i$ 变分得广义本征方程：")+
   fml("\\sum_j(H_{ij}-E S_{ij})c_j = 0")+
   p("其最小本征值为基态能量上界。这是量子化学中 Hartree-Fock 与分子轨道法的基础。"))+
   app(p("<strong>应用：</strong>变分法是量子化学计算分子结构与能量的核心方法，也是密度泛函理论（DFT）的基础。"))+
   note(p("<strong>变分法与微扰论的互补：</strong>变分法与微扰论是量子力学两大近似方法，各有优劣。微扰论给出级数展开的各级修正，适用于已知可解哈密顿量加小微扰的情形，但不保证能量上界；变分法给出基态能量的严格上界，且不需势场可微扰，但若试探波函数选取不当，结果可能偏差较大。实际计算中常将二者结合：用变分法确定零级波函数，再用微扰论计算关联修正。量子化学中的组态相互作用（CI）、耦合簇（CC）方法本质上都是变分原理的系统化推广，通过扩大试探波函数的基函数空间来逼近精确解。"))
 )},
{"id":"qm7s3-3","name":"变分法实例：氦原子基态","tags":["der","exa"],"brief":"用变分法估算氦原子基态能量。",
 "body": wrap(
   exa(p("<strong>例：</strong>氦原子哈密顿量 $\\hat{H}=-\\frac{\\hbar^2}{2m}(\\nabla_1^2+\\nabla_2^2)-\\frac{2e^2}{4\\pi\\varepsilon_0 r_1}-\\frac{2e^2}{4\\pi\\varepsilon_0 r_2}+\\frac{e^2}{4\\pi\\varepsilon_0 r_{12}}$。忽略电子间相互作用时基态波函数为类氢波函数乘积。考虑屏蔽效应，取试探波函数：")+
   fml("\\psi(r_1,r_2) = \\frac{Z'^3}{\\pi a_0^3}e^{-Z'(r_1+r_2)/a_0}")+
   p("其中 $Z'$ 为有效核电荷（变分参数）。计算 $\\langle H\\rangle(Z')$ 并对 $Z'$ 求极小，得 $Z'=27/16\\approx1.688$，$E\\approx-77.5\\,\\text{eV}$，接近实验值 $-78.975\\,\\text{eV}$。"))+
   note(p("若进一步考虑电子关联（如引入 Hylleraas 波函数含 $r_{12}$），精度可大幅提高；这是量子化学中处理电子关联的基本思路。"))
 )},
]},
{
"name": "7.4 氢原子极化率与斯塔克效应",
"color": "#c2410c",
"desc": "极化率的微扰计算与二次斯塔克效应",
"items": [
{"id":"qm7s4-1","name":"氢原子基态极化率","tags":["der"],"brief":"二级微扰计算氢原子极化率。",
 "body": wrap(
   defn("电极化率",p("原子在弱电场 $\\mathcal{E}$ 中，能级移动 $\\Delta E=-\\frac12\\alpha\\mathcal{E}^2$，$\\alpha$ 为电极化率。氢原子基态极化率为 $\\alpha=\\frac92 a_0^3$。"))+
   der(p("<strong>二级微扰计算：</strong>微扰 $\\hat{H}'=e\\mathcal{E}z$，基态 $|100\\rangle$ 一级修正为零（$\\langle 100|z|100\\rangle=0$）。二级修正：")+
   fml("E^{(2)} = \\sum_{nlm}\\frac{|\\langle nlm|e\\mathcal{E}z|100\\rangle|^2}{E_1-E_n}")+
   p("利用 Thomas-Reiche-Kuhn 求和规则或变分法可精确求得 $E^{(2)}=-\\frac94 a_0^3\\mathcal{E}^2\\cdot(4\\pi\\varepsilon_0)$（SI 单位），故 $\\alpha=\\frac92 a_0^3\\cdot4\\pi\\varepsilon_0$。在高斯单位下 $\\alpha=\\frac92 a_0^3$。"))+
   note(p("极化率反映原子对外电场的响应能力，是介电常数、范德瓦尔斯力等宏观性质的微观基础。"))+
   note(p("<strong>斯塔克效应的物理图像：</strong>外电场使原子的正电荷中心（核）与负电荷中心（电子云）发生相对位移，产生感应电偶极矩 $\\mathbf{p}=\\alpha\\mathcal{E}$。对非简并态（如氢基态），一级电偶极矩为零（球对称电子云无固有偶极矩），极化是二级效应，故能级移动与 $\\mathcal{E}^2$ 成正比（二次斯塔克效应）。对简并态（如氢 $n=2$ 态），不同宇称态可混合，产生与 $\\mathcal{E}$ 成正比的线性斯塔克效应。斯塔克效应是外场调控原子能级的重要手段，在激光冷却、原子钟精密测量中有应用。"))
 )},
{"id":"qm7s4-2","name":"二次斯塔克效应","tags":["der","app"],"brief":"非简并原子的二次斯塔克移动。",
 "body": wrap(
   defn("二次斯塔克效应",p("对非简并原子能级，外电场引起的能级移动与场强平方成正比：")+
   fml("\\Delta E = -\\frac12\\alpha\\mathcal{E}^2")+
   p("这称为二次斯塔克效应，区别于氢原子 $n\\geq2$ 的线性斯塔克效应。"))+
   der(p("<strong>来源：</strong>一级修正 $\\langle n|z|n\\rangle=0$（定态具有确定宇称，$z$ 为奇宇称算符，对角元为零），故线性项消失。二级修正给出与 $\\mathcal{E}^2$ 成正比的移动：")+
   fml("\\Delta E = e^2\\mathcal{E}^2\\sum_{k\\neq n}\\frac{|\\langle k|z|n\\rangle|^2}{E_n-E_k} = -\\frac12\\alpha\\mathcal{E}^2")+
   p("极化率 $\\alpha=-2e^2\\sum_{k\\neq n}|\\langle k|z|n\\rangle|^2/(E_n-E_k)>0$（因 $E_n-E_k<0$ 对主导项）。"))+
   app(p("<strong>应用：</strong>斯塔克效应用于原子分子光谱的精细测量、外场下能级的调控、冷原子与分子的操控等。"))
 )},
{"id":"qm7s4-3","name":"变分法求极化率","tags":["der"],"brief":"用变分法上界估计极化率。",
 "body": wrap(
   der(p("<strong>变分计算极化率：</strong>对基态极化率，可构造含参数的变分波函数 $|\\psi\\rangle=|0\\rangle+\\lambda\\hat{z}|0\\rangle$（微扰形式）。能量期望：")+
   fml("\\langle H\\rangle = \\langle 0|H_0+e\\mathcal{E}z|0\\rangle + 2\\lambda\\langle 0|e\\mathcal{E}z\\cdot z|0\\rangle + \\lambda^2\\langle z0|H_0-E_0|z0\\rangle")+
   p("对 $\\lambda$ 求极小得 $\\lambda=-e\\mathcal{E}\\langle z^2\\rangle/\\langle z0|H_0-E_0|z0\\rangle$，代回得到能量的二级项，从而给出极化率的变分上界。该方法可避免对所有激发态求和。"))+
   note(p("变分法与微扰论相辅相成：微扰论给出系统性修正，变分法提供严格上界；二者结合可得到高精度结果与误差估计。"))
 )},
]},
]

ch8_sections = [
{
"name": "8.1 含时微扰论",
"color": "#d97706",
"desc": "含时微扰的相互作用绘景与一级解",
"items": [
{"id":"qm8s1-1","name":"相互作用绘景的态演化","tags":["def","der"],"brief":"含时微扰下态矢的积分方程。",
 "body": wrap(
   defn("含时微扰论",p("设 $\\hat{H}=\\hat{H}_0+\\hat{H}'(t)$，$\\hat{H}_0$ 已知且不含时，$\\hat{H}'(t)$ 为含时小微扰。在相互作用绘景中，态矢满足：")+
   fml("i\\hbar\\frac{d}{dt}|\\psi(t)\\rangle_I = \\hat{H}'_I(t)|\\psi(t)\\rangle_I")+
   p("其中 $\\hat{H}'_I(t)=e^{i\\hat{H}_0t/\\hbar}\\hat{H}'(t)e^{-i\\hat{H}_0t/\\hbar}$。"))+
   der(p("<strong>积分形式：</strong>对运动方程从 $0$ 到 $t$ 积分，得戴森级数的积分方程：")+
   fml("|\\psi(t)\\rangle_I = |\\psi(0)\\rangle - \\frac{i}{\\hbar}\\int_0^t\\hat{H}'_I(t')|\\psi(t')\\rangle_I dt'")+
   p("若 $\\hat{H}'$ 很小，可迭代求解。一级近似将右边的 $|\\psi(t')\\rangle_I$ 代换为 $|\\psi(0)\\rangle$：")+
   fml("|\\psi^{(1)}(t)\\rangle_I = |\\psi(0)\\rangle - \\frac{i}{\\hbar}\\int_0^t\\hat{H}'_I(t')|\\psi(0)\\rangle dt'")+
   p("这就是含时微扰论的一级解。"))+
   note(p("更高阶修正由戴森级数给出，在量子场论中发展为费曼图技术。"))+
   note(p("<strong>三种绘景的统一理解：</strong>量子力学中态与算符的时间演化可在不同绘景中描述，本质是幺正变换的不同选择。薛定谔绘景中态演化、算符不动；海森伯绘景中算符演化、态不动；相互作用绘景中态与算符都演化，分别由相互作用与未受扰哈密顿量支配。相互作用绘景特别适合处理含时微扰，因为它将 $\\hat{H}_0$ 的演化吸收到算符中，使态矢只受 $\\hat{H}'$ 驱动。戴森级数 $\\hat{U}_I(t)=T\\exp\\left[-\\frac{i}{\\hbar}\\int_0^t\\hat{H}'_I(t')dt'\\right]$（$T$ 为编时算符）是量子场论微扰展开的起点。"))
 )},
{"id":"qm8s1-2","name":"一级跃迁振幅","tags":["der","thm"],"brief":"初态到末态的一级跃迁振幅。",
 "body": wrap(
   thm("一级跃迁振幅",p("设初态为 $\\hat{H}_0$ 的本征态 $|i\\rangle$（$E_i$），则在一级近似下，$t$ 时刻处于末态 $|f\\rangle$（$E_f$）的振幅为：")+
   fml("c_f^{(1)}(t) = -\\frac{i}{\\hbar}\\int_0^t \\langle f|\\hat{H}'(t')|i\\rangle e^{i\\omega_{fi}t'}dt'")+
   p("其中 $\\omega_{fi}=(E_f-E_i)/\\hbar$。跃迁概率 $P_{i\\to f}(t)=|c_f^{(1)}(t)|^2$。"))+
   der(p("<strong>推导：</strong>将 $|\\psi(0)\\rangle=|i\\rangle$ 代入一级解，左乘 $\\langle f|$：")+
   fml("c_f^{(1)}(t) = -\\frac{i}{\\hbar}\\int_0^t\\langle f|\\hat{H}'_I(t')|i\\rangle dt' = -\\frac{i}{\\hbar}\\int_0^t\\langle f|\\hat{H}'(t')|i\\rangle e^{i\\omega_{fi}t'}dt'")+
   p("这里利用了 $\\langle f|e^{i\\hat{H}_0t'/\\hbar}\\hat{H}'e^{-i\\hat{H}_0t'/\\hbar}|i\\rangle=e^{i(E_f-E_i)t'/\\hbar}\\langle f|\\hat{H}'|i\\rangle$。跃迁概率即模平方。"))+
   note(p("若 $\\hat{H}'$ 不含时（突然加上恒定微扰），则 $H'_{fi}$ 为常数，积分给出 $c_f^{(1)}\\propto\\frac{1-e^{i\\omega_{fi}t}}{\\omega_{fi}}$。"))
 )},
{"id":"qm8s1-3","name":"常微扰与时间能量不确定","tags":["der"],"brief":"恒定微扰下的跃迁概率与共振。",
 "body": wrap(
   der(p("<strong>常微扰的跃迁概率：</strong>若 $\\hat{H}'$ 在 $0<t<T$ 内为常数，则：")+
   fml("c_f^{(1)}(T) = -\\frac{i}{\\hbar}H'_{fi}\\int_0^T e^{i\\omega_{fi}t}dt = -\\frac{i}{\\hbar}H'_{fi}\\frac{e^{i\\omega_{fi}T}-1}{i\\omega_{fi}}")+
   fml("P_{i\\to f}(T) = \\frac{|H'_{fi}|^2}{\\hbar^2}\\left|\\frac{e^{i\\omega_{fi}T}-1}{\\omega_{fi}}\\right|^2 = \\frac{|H'_{fi}|^2}{\\hbar^2}\\left[\\frac{\\sin(\\omega_{fi}T/2)}{\\omega_{fi}/2}\\right]^2")+
   p("该函数在 $\\omega_{fi}=0$ 处取最大值，峰宽约为 $2\\pi/T$，故仅当 $|E_f-E_i|\\lesssim h/T$ 时跃迁概率显著，体现时间-能量不确定关系。"))+
   exa(p("<strong>例：</strong>微扰作用时间越长，共振峰越窄，能量选择越精确；这是高分辨光谱的物理基础。"))
 )},
]},
{
"name": "8.2 跃迁概率与费米黄金规则",
"color": "#d97706",
"desc": "连续谱末态的跃迁速率",
"items": [
{"id":"qm8s2-1","name":"费米黄金规则","tags":["thm","der"],"brief":"连续末态的跃迁速率公式。",
 "fig":"transition","figCap":"能级间的量子跃迁与光子交换",
 "body": wrap(
   thm("费米黄金规则",p("当末态形成连续谱、态密度为 $\\rho(E_f)$ 时，单位时间跃迁概率（速率）为：")+
   fml("\\Gamma_{i\\to f} = \\frac{2\\pi}{\\hbar}|\\langle f|\\hat{H}'|i\\rangle|^2\\rho(E_f)")+
   p("该公式称为费米黄金规则。"))+
   der(p("<strong>推导：</strong>对常微扰，末态连续时总跃迁概率需对末态积分：")+
   fml("P = \\int |c_f^{(1)}(T)|^2\\rho(E_f)dE_f = \\int \\frac{|H'_{fi}|^2}{\\hbar^2}\\left[\\frac{\\sin(\\omega_{fi}T/2)}{\\omega_{fi}/2}\\right]^2\\rho(E_f)dE_f")+
   p("当 $T\\to\\infty$ 时，$\\frac{1}{T}\\left[\\frac{\\sin(\\omega T/2)}{\\omega/2}\\right]^2\\to 2\\pi\\hbar\\delta(E_f-E_i)$，故速率 $\\Gamma=P/T$：")+
   fml("\\Gamma = \\frac{2\\pi}{\\hbar}|H'_{fi}|^2\\rho(E_i)")+
   p("态密度 $\\rho(E)$ 取在初态能量处。黄金规则广泛适用，前提是末态连续且微扰足够弱。"))+
   note(p("黄金规则是光谱学、核物理、粒子物理中计算跃迁速率与寿命的基本公式。"))+
   app(p("<strong>典型应用：</strong>（1）原子自发与受激辐射速率的计算，结合态密度得到爱因斯坦 A、B 系数；（2）原子核 $\\beta$ 衰变、$\\gamma$ 跃迁的寿命；（3）半导体中电子-声子、电子-光子散射速率；（4）量子阱中光吸收系数。黄金规则揭示跃迁速率正比于矩阵元平方与末态态密度，是连接微观相互作用与宏观可观测速率的桥梁。"))
 )},
{"id":"qm8s2-2","name":"周期性微扰与共振","tags":["der"],"brief":"单色微扰下的共振跃迁。",
 "body": wrap(
   der(p("<strong>周期性微扰：</strong>设 $\\hat{H}'(t)=\\hat{F}e^{-i\\omega t}+\\hat{F}^\\dagger e^{i\\omega t}$（如光与原子的电偶极相互作用）。一级振幅：")+
   fml("c_f^{(1)}(t) = -\\frac{i}{\\hbar}\\left[F_{fi}\\frac{e^{i(\\omega_{fi}-\\omega)t}-1}{i(\\omega_{fi}-\\omega)} + F_{fi}^*\\frac{e^{i(\\omega_{fi}+\\omega)t}-1}{i(\\omega_{fi}+\\omega)}\\right]")+
   p("当 $\\omega\\approx\\omega_{fi}$（即 $\\hbar\\omega\\approx E_f-E_i$）时，第一项（吸收，$E_f>E_i$）共振增强；当 $\\omega\\approx-\\omega_{fi}$（即 $\\hbar\\omega\\approx E_i-E_f$）时，第二项（受激辐射）共振。非共振项可忽略。"))+
   der(p("<strong>共振跃迁速率：</strong>对连续末态，在 $\\omega=\\omega_{fi}$ 附近积分，得：")+
   fml("\\Gamma_{i\\to f} = \\frac{2\\pi}{\\hbar}|F_{fi}|^2\\rho(E_f)")+
   p("其中 $E_f=E_i+\\hbar\\omega$。这是吸收与受激辐射的速率，爱因斯坦 B 系数即与此相关。"))+
   note(p("共振条件 $\\hbar\\omega=E_f-E_i$ 正是玻尔频率条件，体现能量守恒。"))
 )},
{"id":"qm8s2-3","name":"自发辐射与爱因斯坦系数","tags":["der","app"],"brief":"自发辐射需量子化光场。",
 "body": wrap(
   defn("爱因斯坦系数",p("爱因斯坦引入三个系数描述辐射过程：$B_{if}$（吸收）、$B_{fi}$（受激辐射）、$A_{fi}$（自发辐射）。细致平衡给出 $B_{if}=B_{fi}$，$A_{fi}=\\frac{\\hbar\\omega^3}{\\pi^2c^3}B_{fi}$。"))+
   der(p("<strong>关系推导：</strong>热平衡时，两能级 $E_i<E_f$ 间跃迁平衡：$N_iB_{if}u(\\omega)=N_f(A_{fi}+B_{fi}u(\\omega))$。由玻尔兹曼分布 $N_i/N_f=e^{\\hbar\\omega/k_BT}$ 与普朗克公式 $u(\\omega)=\\frac{\\hbar\\omega^3}{\\pi^2c^3}\\frac{1}{e^{\\hbar\\omega/k_BT}-1}$，联立得：")+
   fml("B_{if}=B_{fi},\\qquad A_{fi}=\\frac{\\hbar\\omega^3}{\\pi^2c^3}B_{fi}")+
   p("自发辐射 $A_{fi}$ 不能由半经典含时微扰论导出（需将光场量子化），但爱因斯坦通过热力学平衡论证给出了与受激辐射的关系。"))+
   app(p("<strong>应用：</strong>爱因斯坦系数是激光理论的基础：受激辐射 $B_{fi}$ 提供光放大，自发辐射 $A_{fi}$ 决定激光上能级寿命。"))
 )},
]},
{
"name": "8.3 光的吸收与辐射",
"color": "#d97706",
"desc": "电偶极近似、跃迁矩阵元与谱线强度",
"items": [
{"id":"qm8s3-1","name":"电偶极近似","tags":["def","der"],"brief":"长波近似下光与原子的相互作用。",
 "body": wrap(
   defn("电偶极近似",p("当光波长远大于原子尺度（$\\lambda\\gg a_0$）时，光场在原子范围内近似均匀，相互作用哈密顿量取电偶极近似：")+
   fml("\\hat{H}'(t) = -\\hat{\\mathbf{d}}\\cdot\\mathbf{E}(t),\\qquad \\hat{\\mathbf{d}}=q\\hat{\\mathbf{r}}")+
   p("其中 $\\hat{\\mathbf{d}}$ 为电偶极矩算符，$\\mathbf{E}(t)$ 为电场。"))+
   der(p("<strong>推导：</strong>光的矢量势 $\\mathbf{A}(\\mathbf{r},t)=\\mathbf{A}_0e^{i(\\mathbf{k}\\cdot\\mathbf{r}-\\omega t)}$。在原子范围内 $\\mathbf{k}\\cdot\\mathbf{r}\\sim ka_0\\sim2\\pi a_0/\\lambda\\ll1$，故 $e^{i\\mathbf{k}\\cdot\\mathbf{r}}\\approx1$。相互作用 $\\hat{H}'=-q\\hat{\\mathbf{A}}\\cdot\\hat{\\mathbf{p}}/m$，经规范变换可化为电偶极形式 $-q\\hat{\\mathbf{r}}\\cdot\\mathbf{E}$。更高阶项（磁偶极、电四极）通常小 $\\alpha$（精细结构常数）量级。"))+
   note(p("电偶极近似是原子光谱的主要机制；磁偶极与电四极跃迁为禁戒跃迁，概率小但在特定条件下可观测。"))+
   note(p("<strong>多极展开的物理图像：</strong>光与原子的相互作用可按多极矩展开：电偶极（E1）、磁偶极（M1）、电四极（E2）……各阶跃迁速率之比约为 $1:\\alpha^2:\\alpha^2$。对可见光（$\\lambda\\sim500$ nm）与原子（$a_0\\sim0.05$ nm），$ka_0\\sim\\alpha/2\\pi\\ll1$，故电偶极跃迁占绝对主导。电偶极近似本质上是忽略光场在原子尺度的空间变化，将光场视为均匀振荡电场，这对原子、分子光谱几乎总是成立的。"))
 )},
{"id":"qm8s3-2","name":"跃迁矩阵元与谱线强度","tags":["der"],"brief":"电偶极跃迁概率与矩阵元平方成正比。",
 "body": wrap(
   der(p("<strong>电偶极跃迁概率：</strong>对偏振方向为 $\\mathbf{e}$ 的光，吸收速率由黄金规则：")+
   fml("\\Gamma_{i\\to f} = \\frac{2\\pi}{\\hbar}|\\langle f|q\\mathbf{e}\\cdot\\mathbf{r}|i\\rangle|^2\\rho(E_f)")+
   p("谱线强度正比于 $|\\langle f|\\hat{\\mathbf{d}}|i\\rangle|^2$。矩阵元 $\\mathbf{d}_{fi}=\\langle f|e\\mathbf{r}|i\\rangle$ 称为电偶极跃迁矩阵元。若其为零，则该跃迁为电偶极禁戒。"))+
   der(p("<strong>自发辐射速率：</strong>由爱因斯坦关系与电偶极矩阵元，自发辐射速率：")+
   fml("A_{fi} = \\frac{e^2\\omega_{fi}^3}{3\\pi\\varepsilon_0\\hbar c^3}|\\mathbf{d}_{fi}|^2")+
   p("这就是电偶极自发辐射速率公式。寿命 $\\tau=1/A_{fi}$，能级宽度 $\\Gamma=\\hbar A_{fi}$。氢原子 $2p\\to1s$ 跃迁的 $A\\approx6.27\\times10^8\\,\\text{s}^{-1}$，寿命约 $1.6\\,\\text{ns}$。"))+
   note(p("若电偶极矩阵元为零但磁偶极或电四极非零，则发生禁戒跃迁，速率小很多（如亚稳态寿命可达秒级）。"))
 )},
{"id":"qm8s3-3","name":"选择定则","tags":["der","app"],"brief":"电偶极跃迁的量子数选择定则。",
 "body": wrap(
   der(p("<strong>电偶极选择定则：</strong>矩阵元 $\\langle n'l'm'|z|nlm\\rangle$ 非零的条件。$z=r\\cos\\theta\\propto Y_1^0$，利用球谐函数积分与 CG 系数，得：")+
   fml("\\Delta l = \\pm1,\\qquad \\Delta m = 0,\\pm1,\\qquad \\Delta n \\text{ 任意}")+
   p("对 $x\\pm iy\\propto Y_1^{\\pm1}$，对应 $\\Delta m=\\pm1$；对 $z$，$\\Delta m=0$。宇称变化：$\\mathbf{r}$ 为奇宇称，故 $\\Delta l$ 必为奇数（仅 $\\pm1$ 在电偶极近似下允许）。自旋不参与电偶极作用，故 $\\Delta S=0$。"))+
   der(p("<strong>总角动量选择定则：</strong>考虑自旋-轨道耦合时，用总角动量量子数 $j$：")+
   fml("\\Delta j = 0,\\pm1\\ (j=0\\to j=0 \\text{ 禁戒}),\\qquad \\Delta m_j = 0,\\pm1")+
   p("$j=0\\to j=0$ 禁戒因角动量守恒（光子角动量为 $\\hbar$）。"))+
   app(p("<strong>应用：</strong>选择定择解释了原子光谱的谱线结构，是分析原子能级与跃迁的重要工具；禁戒跃迁在天体物理（如星云谱线）中有重要意义。"))
 )},
]},
{
"name": "8.4 选择定则",
"color": "#d97706",
"desc": "角动量守恒、宇称与禁戒跃迁",
"items": [
{"id":"qm8s4-1","name":"选择定则的物理来源","tags":["der","thm"],"brief":"由对称性与守恒律导出选择定则。",
 "body": wrap(
   thm("选择定则的本质",p("选择定则源于相互作用哈密顿量的对称性。若 $\\hat{H}'$ 在某对称变换下的变换性质已知，则只有初末态量子数满足相应条件时矩阵元才非零。"))+
   der(p("<strong>角动量选择定则：</strong>电偶极算符 $\\hat{\\mathbf{d}}$ 是秩 1 的球张量（$\\Delta J=0,\\pm1$，且 $0\\to0$ 禁戒）。这是因为光子携带角动量 $\\hbar$，角动量守恒要求初末态总角动量满足三角形法则。对轨道角动量，$\\hat{\\mathbf{r}}\\propto\\mathbf{r}Y_1^q$，故 $\\Delta l=\\pm1$（CG 系数非零条件）。"))+
   der(p("<strong>宇称选择定则：</strong>$\\hat{\\mathbf{d}}$ 为奇宇称算符（$\\mathbf{r}\\to-\\mathbf{r}$ 时变号），矩阵元 $\\langle f|\\hat{\\mathbf{d}}|i\\rangle$ 非零要求 $\\psi_f^*\\hat{\\mathbf{d}}\\psi_i$ 为偶宇称，即 $\\Pi_f\\cdot(-1)\\cdot\\Pi_i=+1$，故初末态宇称相反。对中心力场 $\\Pi=(-1)^l$，得 $\\Delta l$ 为奇数。"))+
   note(p("磁偶极算符 $\\hat{\\mathbf{L}}+2\\hat{\\mathbf{S}}$ 为偶宇称，故磁偶极跃迁宇称不变，$\\Delta l=0$；电四极算符为偶宇称张量，$\\Delta l=0,\\pm2$。"))+
   note(p("<strong>选择定则与光谱学：</strong>选择定则决定了原子光谱中哪些谱线可以观测到。电偶极选择定则 $\\Delta l=\\pm1$、$\\Delta m=0,\\pm1$ 解释了氢原子巴尔末系、碱金属主线系等光谱的结构。违反选择定则的跃迁称为禁戒跃迁，其概率虽小（通常小 $\\alpha^2\\sim10^{-5}$ 倍），但在天体物理中可观测到（如星云的禁戒线），因为低密度环境下原子有足够长的寿命发生禁戒跃迁。选择定则本质上是守恒律的体现：角动量守恒（光子带走 $\\hbar$ 角动量）、宇称守恒（电偶极算符的奇宇称）、以及角向动量投影守恒（$\\Delta m$ 定则）。"))
 )},
{"id":"qm8s4-2","name":"禁戒跃迁","tags":["der","note"],"brief":"高阶多极跃迁与寿命。",
 "body": wrap(
   defn("禁戒跃迁",p("电偶极矩阵元为零的跃迁称为电偶极禁戒。若磁偶极或电四极矩阵元非零，则可通过高阶多极过程发生，称为禁戒跃迁，其速率远小于电偶极跃迁。"))+
   der(p("<strong>速率量级：</strong>电偶极速率 $A_{E1}\\sim\\alpha(\\omega a_0/c)^2\\omega$，磁偶极 $A_{M1}\\sim A_{E1}\\cdot\\alpha^2$，电四极 $A_{E2}\\sim A_{E1}\\cdot(ka_0)^2\\sim A_{E1}\\cdot\\alpha^2$。故禁戒跃迁速率小约 $\\alpha^2\\sim5\\times10^{-5}$，对应寿命从纳秒增至毫秒甚至秒级。"))+
   app(p("<strong>应用：</strong>禁戒跃迁产生亚稳态，在激光（如 He-Ne 激光的 Ne 亚稳态）、原子频标、天体光谱（如星云的氧禁线）中有重要作用。"))
 )},
{"id":"qm8s4-3","name":"光电效应与电离","tags":["der","app"],"brief":"光子电离的连续谱跃迁。",
 "body": wrap(
   der(p("<strong>光电效应：</strong>原子吸收光子 $\\hbar\\omega$ 后电子电离到连续态（$E_f>0$）。用黄金规则，末态为自由电子态 $|\\mathbf{k}\\rangle$，态密度 $\\rho(E)=\\frac{V}{2\\pi^2}\\frac{m\\sqrt{2mE}}{\\hbar^3}$。电离截面：")+
   fml("\\sigma = \\frac{4\\pi^2}{\\hbar c}|\\langle\\mathbf{k}|e\\mathbf{e}\\cdot\\mathbf{r}|i\\rangle|^2\\rho(E_f)")+
   p("其中 $E_f=E_i+\\hbar\\omega$。当 $\\hbar\\omega$ 刚好超过电离能时截面最大，随光子能量增大而下降。"))+
   app(p("<strong>应用：</strong>光电效应是光电子能谱（PES）、光电子显微镜与光探测器的基础；多光子电离在强激光场中发生，需用非微扰方法处理。"))
 )},
]},
]

ch9_sections = [
{
"name": "9.1 散射截面与散射振幅",
"color": "#059669",
"desc": "散射截面的定义、微分散射截面与散射振幅",
"items": [
{"id":"qm9s1-1","name":"散射截面的定义","tags":["def","der"],"brief":"用入射流与散射粒子流定义截面。",
 "fig":"scattering","figCap":"粒子被靶散射到不同方向",
 "body": wrap(
   defn("散射截面",p("设入射粒子流密度为 $j_{\\text{inc}}$，单位时间散射到立体角 $d\\Omega$ 内的粒子数为 $dn$，则微分散射截面定义为：")+
   fml("\\frac{d\\sigma}{d\\Omega} = \\frac{dn}{j_{\\text{inc}}\\,d\\Omega}")+
   p("总截面 $\\sigma=\\int\\frac{d\\sigma}{d\\Omega}d\\Omega$。截面的量纲为面积，常用单位 barn（$1\\,\\text{b}=10^{-28}\\,\\text{m}^2$）。"))+
   der(p("<strong>物理意义：</strong>微分散射截面等于单个靶粒子将入射粒子散射到 $\\theta,\\varphi$ 方向单位立体角的等效面积。总截面是入射粒子被散射（任意方向）的总等效面积。对弹性散射，入射与散射粒子能量相同。"))+
   note(p("散射实验是探测微观粒子相互作用与结构的主要手段：卢瑟福散射揭示原子的核式结构，深度非弹性散射揭示夸克的存在。"))+
   note(p("<strong>散射实验的分类：</strong>按末态是否变化分为弹性散射（粒子种类与内能不变，仅动量改变）、非弹性散射（内部状态改变，如激发、电离）、反应（粒子种类改变，如核反应）。按能量分为低能（分波法适用）、中能（玻恩近似适用）、高能（部分子模型、微扰 QCD）。散射截面的测量与理论计算的比较，是检验粒子物理标准模型、研究原子核结构、分析材料性质的核心方法。现代大型粒子加速器（如 LHC）与同步辐射光源本质上都是散射实验装置。"))
 )},
{"id":"qm9s1-2","name":"散射振幅与波函数渐近形式","tags":["der"],"brief":"散射振幅的模平方给出微分截面。",
 "body": wrap(
   defn("散射振幅",p("弹性散射中，定态散射波函数在 $r\\to\\infty$ 处的渐近形式为：")+
   fml("\\psi(\\mathbf{r}) \\xrightarrow{r\\to\\infty} e^{ikz} + f(\\theta)\\frac{e^{ikr}}{r}")+
   p("第一项为入射平面波（沿 z 轴），第二项为出射球面波，$f(\\theta)$ 称为散射振幅。"))+
   der(p("<strong>微分截面与散射振幅：</strong>入射流密度 $j_{\\text{inc}}=\\hbar k/m$。散射球面波的径向流密度：")+
   fml("j_r = \\frac{\\hbar}{2mi}(\\psi_{\\text{sc}}^*\\partial_r\\psi_{\\text{sc}}-\\psi_{\\text{sc}}\\partial_r\\psi_{\\text{sc}}^*) = \\frac{\\hbar k}{m}\\frac{|f(\\theta)|^2}{r^2}")+
   p("单位时间通过半径 $r$、立体角 $d\\Omega$ 的粒子数 $dn=j_r r^2 d\\Omega=\\frac{\\hbar k}{m}|f(\\theta)|^2 d\\Omega$。故：")+
   fml("\\frac{d\\sigma}{d\\Omega} = |f(\\theta)|^2")+
   p("散射问题归结为求散射振幅 $f(\\theta)$。"))+
   note(p("以上推导假设势场为中心势（$f$ 仅与 $\\theta$ 有关）；一般势场中 $f$ 还依赖方位角 $\\varphi$。"))
 )},
{"id":"qm9s1-3","name":"散射过程的 Lippmann-Schwinger 方程","tags":["der","thm"],"brief":"用积分方程表述散射问题。",
 "body": wrap(
   thm("Lippmann-Schwinger 方程",p("散射定态波函数满足积分方程：")+
   fml("|\\psi^{(+)}\\rangle = |\\mathbf{k}\\rangle + \\frac{1}{E-\\hat{H}_0+i\\epsilon}\\hat{V}|\\psi^{(+)}\\rangle")+
   p("其中 $|\\mathbf{k}\\rangle$ 为入射平面波，$+i\\epsilon$ 规定出射波边界条件。"))+
   der(p("<strong>推导：</strong>定态薛定谔方程 $(E-\\hat{H}_0)|\\psi\\rangle=\\hat{V}|\\psi\\rangle$ 形式上解为 $|\\psi\\rangle=|\\mathbf{k}\\rangle+\\hat{G}_0(E)\\hat{V}|\\psi\\rangle$，其中格林算符 $\\hat{G}_0(E)=(E-\\hat{H}_0+i\\epsilon)^{-1}$。在坐标表象中，自由格林函数为：")+
   fml("G_0(\\mathbf{r},\\mathbf{r}') = -\\frac{m}{2\\pi\\hbar^2}\\frac{e^{ik|\\mathbf{r}-\\mathbf{r}'|}}{|\\mathbf{r}-\\mathbf{r}'|}")+
   p("代入可得玻恩级数，是微扰论处理散射的出发点。"))+
   note(p("$\\psi^{(+)}$ 的上标 + 表示出射波边界条件（散射波为出射球面波）；$\\psi^{(-)}$ 对应入射波边界条件。"))+
   note(p("<strong>Lippmann-Schwinger 方程的意义：</strong>Lippmann-Schwinger 方程将散射问题从微分方程（薛定谔方程）转化为积分方程，其核心是引入格林函数 $G_0$ 来描述自由粒子从 $\\mathbf{r}'$ 传播到 $\\mathbf{r}$ 的振幅。$+i\\epsilon$  prescription 至关重要：它确保散射波为出射球面波（推迟解），符合物理因果律。方程的迭代解即为玻恩级数：一阶玻恩近似取 $|\\psi^{(+)}\\rangle\\approx|\\mathbf{k}\\rangle$，二阶玻恩近似取 $|\\psi\\rangle\\approx|\\mathbf{k}\\rangle+G_0V|\\mathbf{k}\\rangle$，依此类推。每一项对应粒子在势场中发生多次散射的费曼图。Lippmann-Schwinger 方程是形式散射理论的基础，也是量子场论中 S 矩阵理论的出发点。"))
 )},
]},
{
"name": "9.2 分波法与相移",
"color": "#059669",
"desc": "按角动量分波展开、相移与截面",
"items": [
{"id":"qm9s2-1","name":"分波展开","tags":["der","thm"],"brief":"散射振幅按角动量分波展开。",
 "fig":"partialwave","figCap":"分波法：入射平面波分解为各角动量分波",
 "body": wrap(
   thm("分波展开",p("中心势散射中，散射振幅可按角动量 $l$ 展开：")+
   fml("f(\\theta) = \\frac{1}{k}\\sum_{l=0}^\\infty (2l+1)e^{i\\delta_l}\\sin\\delta_l\\,P_l(\\cos\\theta)")+
   p("其中 $\\delta_l$ 为第 $l$ 分波的相移。"))+
   der(p("<strong>推导：</strong>中心势中角动量守恒，入射平面波展开为 $e^{ikz}=\\sum_l i^l(2l+1)j_l(kr)P_l(\\cos\\theta)$。$r\\to\\infty$ 时 $j_l(kr)\\sim\\sin(kr-l\\pi/2)/(kr)$。散射后第 $l$ 分波的径向波函数渐近形式为 $R_l(r)\\sim\\sin(kr-l\\pi/2+\\delta_l)/(kr)$，相移 $\\delta_l$ 反映势场对该分波的影响。出射球面波振幅即给出上述分波展开式。"))+
   note(p("分波法是中心势散射的严格方法，当势场作用范围 $a$ 有限时，仅 $l\\lesssim ka$ 的分波相移显著，高 $l$ 分波可忽略，故级数可截断。"))+
   note(p("<strong>分波法的物理图像：</strong>分波法将散射过程按角动量分解。入射粒子的角动量 $L\\sim p\\cdot b$，其中 $b$ 为碰撞参数。若 $L/\\hbar=l$，则 $b\\sim l/k$。当 $b>a$（即 $l>ka$）时，粒子轨迹不进入势场作用区，相移可忽略。这解释了为何低能散射（$ka\\ll1$）只需 s 波。相移 $\\delta_l$ 的符号反映相互作用性质：$\\delta_l>0$ 为吸引势（波函数被拉入，相位超前），$\\delta_l<0$ 为排斥势。分波法是核物理低能散射（如中子-质子散射）的标准方法。"))
 )},
{"id":"qm9s2-2","name":"相移与分波截面","tags":["der","thm"],"brief":"各分波对总截面的贡献。",
 "body": wrap(
   thm("分波截面",p("第 $l$ 分波对总截面的贡献为：")+
   fml("\\sigma_l = \\frac{4\\pi}{k^2}(2l+1)\\sin^2\\delta_l")+
   p("总截面 $\\sigma=\\sum_l\\sigma_l$。"))+
   der(p("<strong>推导：</strong>微分散射截面 $|f(\\theta)|^2$ 对全立体角积分，利用勒让德多项式正交性 $\\int P_lP_{l'}d\\Omega=4\\pi\\delta_{ll'}/(2l+1)$：")+
   fml("\\sigma = \\int|f(\\theta)|^2 d\\Omega = \\frac{4\\pi}{k^2}\\sum_l(2l+1)\\sin^2\\delta_l")+
   p("每个分波的最大贡献为 $\\sigma_l^{\\max}=4\\pi(2l+1)/k^2$（当 $\\sin^2\\delta_l=1$，即 $\\delta_l=\\pi/2$ 时），称为幺正极限。"))+
   exa(p("<strong>例：</strong>低能散射（$ka\\ll1$）时仅 s 波（$l=0$）贡献，$\\sigma\\approx4\\pi a_s^2$，$a_s$ 为 s 波散射长度。"))
 )},
{"id":"qm9s2-3","name":"s 波散射与散射长度","tags":["der","exa"],"brief":"低能散射的 s 波主导。",
 "body": wrap(
   der(p("<strong>低能极限：</strong>当 $ka\\ll1$ 时，$l\\geq1$ 分波的相移 $\\delta_l\\sim k^{2l+1}$（因 $j_l(ka)\\sim(ka)^l$），可忽略，仅 s 波（$l=0$）贡献。s 波径向方程渐近解 $u_0(r)\\sim A\\sin(kr+\\delta_0)$，定义散射长度 $a_s=-\\tan\\delta_0/k$（$k\\to0$）：")+
   fml("\\delta_0 \\approx -ka_s,\\qquad \\sigma \\approx \\frac{4\\pi}{k^2}\\sin^2\\delta_0 \\approx 4\\pi a_s^2")+
   p("散射长度 $a_s$ 的符号与大小反映相互作用性质：$a_s>0$ 等效排斥势，$a_s<0$ 等效吸引势。"))+
   app(p("<strong>应用：</strong>散射长度是冷原子物理的核心参数，Feshbach 共振可调控散射长度，从而实现 BEC-BCS 渡越、分子缔合等量子现象。"))+
   note(p("<strong>散射长度的物理意义：</strong>散射长度 $a_s$ 是低能极限下描述两体相互作用的唯一参数，其物理意义为：当 $a_s>0$（等效排斥）时，径向波函数向外推，两体径向分布在短距离被压低；当 $a_s<0$（等效吸引）时，波函数向内拉，表明存在弱束缚态。Feshbach 共振利用外磁场调节束缚态与散射态的能量差，使散射长度从 $-\\infty$ 到 $+\\infty$ 连续变化，是冷原子实验中操控相互作用的关键技术。在 $|a_s|\\gg$ 其它长度标度的幺正极限（unitary limit）下，体系性质变得普适，不依赖具体相互作用细节。"))
 )},
]},
{"name": "9.3 玻恩近似",
"color": "#059669",
"desc": "一阶玻恩近似与势的傅里叶变换",
"items": [
{"id":"qm9s3-1","name":"一阶玻恩近似","tags":["der","thm"],"brief":"弱势下散射振幅为势的傅里叶变换。",
 "body": wrap(
   thm("玻恩近似",p("在一阶微扰近似下，散射振幅为：")+
   fml("f(\\theta) = -\\frac{m}{2\\pi\\hbar^2}\\int V(\\mathbf{r}')e^{i(\\mathbf{k}-\\mathbf{k}')\\cdot\\mathbf{r}'}d^3r' = -\\frac{m}{2\\pi\\hbar^2}\\tilde{V}(\\mathbf{q})")+
   p("其中 $\\mathbf{q}=\\mathbf{k}-\\mathbf{k}'$ 为动量转移，$|\\mathbf{q}|=2k\\sin(\\theta/2)$，$\\tilde{V}(\\mathbf{q})$ 为势的三维傅里叶变换。"))+
   der(p("<strong>推导：</strong>Lippmann-Schwinger 方程的一阶近似（玻恩级数首项）取 $|\\psi^{(+)}\\rangle\\approx|\\mathbf{k}\\rangle$，则散射振幅：")+
   fml("f(\\theta) = -\\frac{m}{2\\pi\\hbar^2}\\langle\\mathbf{k}'|\\hat{V}|\\mathbf{k}\\rangle = -\\frac{m}{2\\pi\\hbar^2}\\int e^{-i\\mathbf{k}'\\cdot\\mathbf{r}}V(\\mathbf{r})e^{i\\mathbf{k}\\cdot\\mathbf{r}}d^3r")+
   p("即 $f(\\theta)=-\\frac{m}{2\\pi\\hbar^2}\\int V(\\mathbf{r})e^{i\\mathbf{q}\\cdot\\mathbf{r}}d^3r$。这表明散射振幅是势的傅里叶变换，是反散射问题（由散射数据重建势）的基础。"))+
   note(p("玻恩近似适用条件：势足够弱或能量足够高，使得 $|V_0|ma/\\hbar^2\\ll1$ 或 $ka\\gg1$。卢瑟福散射（库仑势）的玻恩近似恰好给出精确结果。"))+
   note(p("<strong>玻恩近似的物理图像：</strong>一阶玻恩近似将散射视为势场对入射平面波的单次散射（微扰一阶），相当于粒子在势场中只被“踢”一次。散射振幅正比于势的傅里叶变换 $\\tilde{V}(\\mathbf{q})$，这意味着测量不同角度的微分散射截面，就相当于在动量空间中探测势的形状——小角度散射（小 $q$）对应势的长程部分，大角度散射（大 $q$）对应势的短程结构。这一原理是电子衍射、中子散射、X 射线衍射等结构探测手段的理论基础。高阶玻恩修正对应多次散射过程，在势较强或低能时需考虑。"))
 )},
{"id":"qm9s3-2","name":"卢瑟福散射","tags":["der","app"],"brief":"库仑势散射的经典结果。",
 "body": wrap(
   der(p("<strong>库仑势的玻恩近似：</strong>对库仑势 $V(r)=\\frac{Z_1Z_2e^2}{4\\pi\\varepsilon_0 r}$，其傅里叶变换为 $\\tilde{V}(\\mathbf{q})=\\frac{Z_1Z_2e^2}{\\varepsilon_0 q^2}$（$q=2k\\sin\\theta/2$）。代入玻恩公式：")+
   fml("f(\\theta) = -\\frac{m}{2\\pi\\hbar^2}\\cdot\\frac{Z_1Z_2e^2}{\\varepsilon_0 q^2} = -\\frac{Z_1Z_2e^2}{4\\pi\\varepsilon_0\\cdot4E\\sin^2(\\theta/2)}")+
   fml("\\frac{d\\sigma}{d\\Omega} = |f(\\theta)|^2 = \\left(\\frac{Z_1Z_2e^2}{16\\pi\\varepsilon_0 E\\sin^2(\\theta/2)}\\right)^2")+
   p("这正是卢瑟福散射公式，与经典力学结果完全一致。量子力学中库仑势的精确解（抛物坐标）也给出相同微分截面。"))+
   app(p("<strong>应用：</strong>卢瑟福散射是探测原子核结构的经典方法，$\\alpha$ 粒子散射实验确立了原子的核式模型；现代卢瑟福背散射（RBS）用于材料表面分析。"))+
   note(p("<strong>历史意义：</strong>1909 年盖革-马斯登的 $\\alpha$ 粒子大角度散射实验令汤姆逊的葡萄干布丁模型破产。卢瑟福据此于 1911 年提出原子核式结构：原子质量集中在半径 $\\sim10^{-15}$ m 的核内。值得注意的是，库仑势是唯一使玻恩近似与精确解、且与经典力学结果完全一致的势场，这源于库仑势的长程性与共形对称性。"))
 )},
{"id":"qm9s3-3","name":"玻恩近似的适用条件","tags":["der","note"],"brief":"弱势或高能时玻恩近似有效。",
 "body": wrap(
   der(p("<strong>有效性判据：</strong>玻恩近似要求一级修正远小于入射波，即 $|\\langle\\mathbf{k}'|V|\\mathbf{k}\\rangle|/\\hbar v\\ll1$。对短程势 $V_0$、范围 $a$，条件为：")+
   fml("\\frac{m|V_0|a^2}{\\hbar^2} \\ll 1 \\quad \\text{或} \\quad ka \\gg 1")+
   p("前者为弱散射条件，后者为高能条件。在高能极限下，粒子快速穿过势场，偏转小，玻恩近似精度高。"))+
   note(p("当玻恩近似失效时（低能强散射），需用分波法或变分法（Kohn 变分、定态变分）精确求解相移，或用耦合道方法处理非弹性散射。"))
 )},
]},
{
"name": "9.4 全同粒子散射",
"color": "#059669",
"desc": "全同玻色子与费米子散射的干涉效应",
"items": [
{"id":"qm9s4-1","name":"全同粒子散射的对称性","tags":["der","thm"],"brief":"全同性导致散射振幅的对称化。",
 "fig":"identical","figCap":"全同粒子交换的对称性：玻色子对称、费米子反对称",
 "body": wrap(
   thm("全同粒子散射振幅",p("两个全同粒子散射时，由于不可区分性，质心系中 $\\theta$ 与 $\\pi-\\theta$ 方向的散射不可区分，散射振幅需对称化：")+
   fml("\\frac{d\\sigma}{d\\Omega} = |f(\\theta) \\pm f(\\pi-\\theta)|^2")+
   p("玻色子取 +（对称），费米子取 -（反对称，且空间波函数对称性受自旋态制约）。"))+
   der(p("<strong>推导：</strong>对两个全同粒子，交换粒子等价于将散射角 $\\theta$ 换为 $\\pi-\\theta$。在质心系中，全同波函数的概率密度为 $|\\psi(\\theta)\\pm\\psi(\\pi-\\theta)|^2$，故微分截面：")+
   fml("\\frac{d\\sigma}{d\\Omega} = |f(\\theta)|^2+|f(\\pi-\\theta)|^2 \\pm 2\\text{Re}[f(\\theta)f^*(\\pi-\\theta)]")+
   p("交叉项 $2\\text{Re}[...]$ 是量子干涉的体现，经典力学中无此效应。"))+
   note(p("对自旋 1/2 的费米子（如电子-电子散射），总波函数反对称。自旋单态（反平行）时空间波函数对称，取 +；自旋三重态（平行）时空间波函数反对称，取 -。需对自旋求平均。"))+
   note(p("<strong>全同粒子散射的实验意义：</strong>全同粒子散射的干涉项是量子全同性的直接实验证据。以 $\\alpha$-$\\alpha$ 散射为例（玻色子，自旋 0），微分截面在 $\\theta=\\pi/2$ 处为 $|f(\\pi/2)+f(\\pi/2)|^2=4|f(\\pi/2)|^2$，是经典可区分粒子截面 $2|f(\\pi/2)|^2$ 的两倍。质子-质子散射（费米子，自旋 1/2）因自旋相关，截面在 $\\theta=\\pi/2$ 处呈现复杂的自旋依赖结构。这些实验结果只能用量子全同性与交换对称性解释，是量子力学统计诠释的关键验证。Mott 散射公式精确描述了电子-电子散射的全同效应。"))
 )},
{"id":"qm9s4-2","name":"玻色子与费米子散射","tags":["der","exa"],"brief":"不同统计的散射角分布。",
 "body": wrap(
   der(p("<strong>无自旋玻色子（如 $\\alpha$-$\\alpha$ 散射）：</strong>空间波函数对称，微分截面为 $|f(\\theta)+f(\\pi-\\theta)|^2$。在 $\\theta=\\pi/2$ 处，截面为 $|2f(\\pi/2)|^2=4|f(\\pi/2)|^2$，是可分辨粒子的 2 倍。"))+
   der(p("<strong>自旋 1/2 费米子（如电子-电子，莫特散射）：</strong>对非极化入射，自旋单态概率 1/4、三重态 3/4，平均微分截面：")+
   fml("\\frac{d\\sigma}{d\\Omega} = \\frac14|f(\\theta)+f(\\pi-\\theta)|^2+\\frac34|f(\\theta)-f(\\pi-\\theta)|^2")+
   p("在 $\\theta=\\pi/2$ 处得 $\\frac14|2f|^2+\\frac34|0|^2=|f|^2$。自旋相关的散射可用于测量电子极化。"))+
   app(p("<strong>应用：</strong>全同粒子散射的干涉效应是验证量子统计的重要手段；中子-中子散射、电子-电子散射实验都观察到了全同性带来的角分布特征。"))
 )},
{"id":"qm9s4-3","name":"非弹性散射与反应","tags":["def","note"],"brief":"非弹性散射与核反应概述。",
 "body": wrap(
   defn("非弹性散射",p("若散射过程中粒子内部状态改变（如激发、电离、反应），则为非弹性散射。末态粒子种类或内部能量不同于初态。"))+
   der(p("<strong>处理方法：</strong>非弹性散射需用耦合道方法，将不同内部通道的波函数耦合求解。形式上仍可推广 Lippmann-Schwinger 方程，引入跃迁算符 $\\hat{T}$，散射振幅 $f_{fi}\\propto\\langle f|\\hat{T}|i\\rangle$。对核反应等强相互作用过程，玻恩近似通常失效，需用分波法或光学模型。"))+
   note(p("散射理论是核物理、粒子物理、凝聚态物理的基础工具；现代散射实验（如 LHC、同步辐射 X 射线散射）依赖精确的散射理论分析。"))
 )},
]},
]

ch10_sections = [
{
"name": "10.1 全同性原理与波函数对称性",
"color": "#7e22ce",
"desc": "全同粒子不可区分性、玻色子与费米子",
"items": [
{"id":"qm10s1-1","name":"全同性原理","tags":["def","der"],"brief":"全同粒子不可区分导致波函数对称化。",
 "fig":"identical","figCap":"全同粒子交换的对称性",
 "body": wrap(
   defn("全同性原理",p("全同粒子（内禀属性完全相同的粒子）不可区分，交换任意两个粒子不改变体系的物理态。因此波函数在粒子交换下只能是对称或反对称的：")+
   fml("\\psi(1,2,\\dots,i,\\dots,j,\\dots) = \\pm\\psi(1,2,\\dots,j,\\dots,i,\\dots)")+
   p("对称者为玻色子，反对称者为费米子。"))+
   der(p("<strong>推导：</strong>交换算符 $\\hat{P}_{ij}$ 交换第 $i,j$ 个粒子，$\\hat{P}_{ij}^2=1$，本征值 $\\pm1$。由于全同性，$\\hat{P}_{ij}$ 与哈密顿量对易，是守恒量。实验表明：自旋为整数的粒子（玻色子）波函数对称（本征值 +1），自旋为半整数的粒子（费米子）反对称（本征值 -1）。这就是自旋统计定理。"))+
   note(p("自旋统计定理是相对论量子场论的结果：半整数自旋粒子服从费米-狄拉克统计，整数自旋粒子服从玻色-爱因斯坦统计。"))
 )},
{"id":"qm10s1-2","name":"泡利不相容原理","tags":["thm","der"],"brief":"费米子不能占据同一量子态。",
 "body": wrap(
   thm("泡利不相容原理",p("两个全同费米子不能处于同一单粒子量子态。"))+
   der(p("<strong>推导：</strong>对两个费米子，总波函数反对称 $\\psi(1,2)=-\\psi(2,1)$。若两粒子处于同一单粒子态 $\\phi$，则 $\\psi(1,2)=\\phi(1)\\phi(2)$，对称化后 $\\psi_A=[\\phi(1)\\phi(2)-\\phi(2)\\phi(1)]/\\sqrt2=0$，波函数消失，故不可能。对 $N$ 个费米子，由 Slater 行列式的性质，两行（两粒子）相同时行列式为零，故任一单粒子态最多容纳一个费米子。"))+
   app(p("<strong>应用：</strong>泡利原理是原子壳层结构、元素周期表、金属电导（费米海）、白矮星与中子星的简并压、化学键等的物理基础。"))+
   note(p("<strong>简并压与致密星：</strong>白矮星靠电子简并压抗衡引力坍缩，其质量上限为钱德拉塞卡极限（$\\sim1.4M_\\odot$）；超过此限电子被压入原子核形成中子星，靠中子简并压支撑，上限约 $2-3M_\\odot$（奥本海默极限），再重则坍缩为黑洞。简并压源于泡利不相容原理：当费米子被压缩到极小体积时，大量粒子被迫占据高能态，产生巨大的压强，与温度无关（冷简并压）。"))
 )},
{"id":"qm10s1-3","name":"两粒子波函数","tags":["der"],"brief":"两体系统的对称与反对称波函数。",
 "body": wrap(
   der(p("<strong>两粒子系统：</strong>设两个单粒子态 $\\phi_a,\\phi_b$。对玻色子，对称波函数为：")+
   fml("\\psi_S(1,2) = \\frac{1}{\\sqrt2}[\\phi_a(1)\\phi_b(2)+\\phi_a(2)\\phi_b(1)]")+
   p("对费米子，反对称波函数为：")+
   fml("\\psi_A(1,2) = \\frac{1}{\\sqrt2}[\\phi_a(1)\\phi_b(2)-\\phi_a(2)\\phi_b(1)]")+
   p("两者都满足 $\\langle\\psi|\\psi\\rangle=1$（当 $a\\neq b$ 且 $\\phi_a,\\phi_b$ 正交归一）。当 $a=b$ 时费米子波函数为零，体现泡利原理。"))+
   der(p("<strong>空间与自旋分离：</strong>对电子（自旋 1/2），总波函数为空间部分与自旋部分的乘积，总反对称要求空间与自旋对称性相反：自旋单态（反对称）配空间对称，自旋三重态（对称）配空间反对称。"))+
   note(p("这导致氦原子的两个电子态：单态（仲氦）与三重态（正氦），对应不同能级与光谱。"))+
   note(p("<strong>交换相互作用与磁性：</strong>由于波函数的对称性要求，两个电子的空间波函数与自旋波函数的对称性必须相反。当两电子自旋平行（三重态，对称）时，空间波函数反对称，两电子在空间同一点相遇的概率为零（$|\\psi_A(\\mathbf{r},\\mathbf{r})|^2=0$），即存在“交换孔”，库仑排斥能较低；自旋反平行（单态，反对称）时空间波函数对称，两电子靠近概率较大，库仑能较高。这种由全同性与库仑相互作用共同导致的自旋相关能量差称为交换相互作用，是铁磁性、反铁磁性等固体磁性的微观起源。氢分子的共价键也源于自旋单态（反对称自旋）配对称空间波函数，使两电子在两核间概率增大，形成束缚。"))
 )},
]},
{
"name": "10.2 二次量子化",
"color": "#7e22ce",
"desc": "产生湮灭算符、粒子数表象与场算符",
"items": [
{"id":"qm10s2-1","name":"玻色子的二次量子化","tags":["der","thm"],"brief":"玻色子产生湮灭算符的对易关系。",
 "fig":"secondquant","figCap":"二次量子化：粒子数表象与产生湮灭算符",
 "body": wrap(
   defn("产生湮灭算符",p("在粒子数表象中，定义产生算符 $\\hat{a}_\\alpha^\\dagger$ 与湮灭算符 $\\hat{a}_\\alpha$，作用于粒子数态 $|n_\\alpha\\rangle$：")+
   fml("\\hat{a}_\\alpha^\\dagger|n_\\alpha\\rangle = \\sqrt{n_\\alpha+1}|n_\\alpha+1\\rangle,\\qquad \\hat{a}_\\alpha|n_\\alpha\\rangle = \\sqrt{n_\\alpha}|n_\\alpha-1\\rangle")+
   p("粒子数算符 $\\hat{n}_\\alpha=\\hat{a}_\\alpha^\\dagger\\hat{a}_\\alpha$，本征值为 $n_\\alpha$。"))+
   der(p("<strong>对易关系：</strong>玻色子产生湮灭算符满足对易关系：")+
   fml("[\\hat{a}_\\alpha,\\hat{a}_\\beta^\\dagger] = \\delta_{\\alpha\\beta},\\qquad [\\hat{a}_\\alpha,\\hat{a}_\\beta]=0,\\qquad [\\hat{a}_\\alpha^\\dagger,\\hat{a}_\\beta^\\dagger]=0")+
   p("由此可证明 $\\hat{n}_\\alpha$ 的本征值为非负整数，即玻色子每个态可容纳任意多个粒子。总粒子数算符 $\\hat{N}=\\sum_\\alpha\\hat{n}_\\alpha$。"))+
   note(p("二次量子化把多体波函数的对称化/反对称化转化为算符代数，是处理全同粒子多体问题的标准语言。"))+
   note(p("<strong>二次量子化的意义：</strong>“二次量子化”并非将量子力学再量子化一次，而是将波函数本身提升为算符（场算符），使其能够描述粒子的产生与湮灭。这一步对于处理可变粒子数的系统（如辐射场、粒子物理过程）至关重要。在二次量子化框架中，全同粒子的对称性自动编码于算符的对易（玻色）或反对易（费米）关系中，无需显式构造对称化波函数。这是从量子力学到量子场论的关键桥梁：量子场论中的电磁场、电子场等都以二次量子化的场算符形式出现。"))
 )},
{"id":"qm10s2-2","name":"费米子的二次量子化","tags":["der","thm"],"brief":"费米子算符满足反对易关系。",
 "body": wrap(
   der(p("<strong>反对易关系：</strong>费米子产生湮灭算符满足反对易关系：")+
   fml("\\{\\hat{c}_\\alpha,\\hat{c}_\\beta^\\dagger\\} = \\delta_{\\alpha\\beta},\\qquad \\{\\hat{c}_\\alpha,\\hat{c}_\\beta\\}=0,\\qquad \\{\\hat{c}_\\alpha^\\dagger,\\hat{c}_\\beta^\\dagger\\}=0")+
   p("其中 $\\{A,B\\}=AB+BA$ 为反对易子。由 $\\{\\hat{c}_\\alpha,\\hat{c}_\\alpha\\}=2\\hat{c}_\\alpha^2=0$ 得 $\\hat{c}_\\alpha^2=0$，故 $\\hat{n}_\\alpha^2=\\hat{c}_\\alpha^\\dagger\\hat{c}_\\alpha\\hat{c}_\\alpha^\\dagger\\hat{c}_\\alpha=\\hat{c}_\\alpha^\\dagger(1-\\hat{c}_\\alpha^\\dagger\\hat{c}_\\alpha)\\hat{c}_\\alpha=\\hat{n}_\\alpha$，$\\hat{n}_\\alpha$ 本征值为 0 或 1，即泡利原理。"))+
   der(p("<strong>费米子态：</strong>真空态 $|0\\rangle$ 满足 $\\hat{c}_\\alpha|0\\rangle=0$。$N$ 个费米子态为 $\\hat{c}_{\\alpha_1}^\\dagger\\hat{c}_{\\alpha_2}^\\dagger\\cdots\\hat{c}_{\\alpha_N}^\\dagger|0\\rangle$，产生算符顺序决定符号（费米子符号问题）。"))+
   note(p("反对易关系自动实现了波函数的反对称性，无需显式构造 Slater 行列式。"))+
   note(p("<strong>费米子符号与 Wick 定理：</strong>费米子产生算符的反对易性导致波函数的符号依赖于产生算符的顺序，这是多体计算中著名的“费米子符号问题”。在费曼图微扰论中，每个费米子闭合圈贡献一个负号。Wick 定理将费米子场算符的时序乘积展开为正规乘积与收缩之和，其中费米子收缩（传播子）带有符号。这些符号规则保证了费米子体系的泡利不相容原理与量子统计，是费米液体理论、BCS 超导理论、哈伯德模型等多体问题计算的基础。"))
 )},
{"id":"qm10s2-3","name":"场算符与哈密顿量","tags":["der"],"brief":"二次量子化形式的多体哈密顿量。",
 "body": wrap(
   defn("场算符",p("定义场算符 $\\hat{\\psi}(\\mathbf{r})=\\sum_\\alpha\\phi_\\alpha(\\mathbf{r})\\hat{a}_\\alpha$（玻色子）或 $\\hat{\\psi}(\\mathbf{r})=\\sum_\\alpha\\phi_\\alpha(\\mathbf{r})\\hat{c}_\\alpha$（费米子），其中 $\\phi_\\alpha$ 为单粒子基。$\\hat{\\psi}(\\mathbf{r})$ 在 $\\mathbf{r}$ 处湮灭一个粒子，$\\hat{\\psi}^\\dagger(\\mathbf{r})$ 产生一个粒子。"))+
   der(p("<strong>多体哈密顿量：</strong>对有相互作用的全同粒子体系，哈密顿量的二次量子化形式为：")+
   fml("\\hat{H} = \\int d^3r\\,\\hat{\\psi}^\\dagger(\\mathbf{r})\\left[-\\frac{\\hbar^2}{2m}\\nabla^2+V(\\mathbf{r})\\right]\\hat{\\psi}(\\mathbf{r}) + \\frac12\\int d^3r d^3r'\\,\\hat{\\psi}^\\dagger(\\mathbf{r})\\hat{\\psi}^\\dagger(\\mathbf{r}')V(\\mathbf{r}-\\mathbf{r}')\\hat{\\psi}(\\mathbf{r}')\\hat{\\psi}(\\mathbf{r})")+
   p("第一项为单粒子动能与外势，第二项为两体相互作用。场算符的等时对易（玻色）或反对易（费米）关系为 $[\\hat{\\psi}(\\mathbf{r}),\\hat{\\psi}^\\dagger(\\mathbf{r}')]_\\pm=\\delta(\\mathbf{r}-\\mathbf{r}')$。"))+
   app(p("<strong>应用：</strong>二次量子化是凝聚态物理（BCS 超导、玻色-爱因斯坦凝聚）、量子场论、量子多体理论的基本框架。"))
 )},
]},
{
"name": "10.3 哈特里-福克近似",
"color": "#7e22ce",
"desc": "平均场近似、Slater 行列式与自洽场",
"items": [
{"id":"qm10s3-1","name":"哈特里-福克近似","tags":["def","der"],"brief":"用单个 Slater 行列式近似多体基态。",
 "fig":"hartreefock","figCap":"Slater 行列式：费米子的反对称波函数",
 "body": wrap(
   defn("哈特里-福克近似",p("对 $N$ 个费米子体系，取基态试探波函数为单个 Slater 行列式：")+
   fml("\\Psi(1,2,\\dots,N) = \\frac{1}{\\sqrt{N!}}\\det[\\phi_i(\\mathbf{r}_j\\sigma_j)]")+
   p("其中 $\\phi_i$ 为单粒子自旋轨道。变分求能量极小得到哈特里-福克方程。"))+
   der(p("<strong>变分推导：</strong>能量期望 $\\langle\\Psi|\\hat{H}|\\Psi\\rangle$ 包含单粒子项 $\\sum_i\\langle i|h|i\\rangle$ 与两体相互作用项。对 $\\phi_i$ 变分（约束正交归一），得到哈特里-福克方程：")+
   fml("\\left[h(\\mathbf{r})+\\sum_j\\int d^3r'\\frac{|\\phi_j(\\mathbf{r}')|^2}{|\\mathbf{r}-\\mathbf{r}'|} - \\sum_j\\frac{\\phi_j(\\mathbf{r})}{\\phi_i(\\mathbf{r})}\\int d^3r'\\frac{\\phi_j^*(\\mathbf{r}')\\phi_i(\\mathbf{r}')}{|\\mathbf{r}-\\mathbf{r}'|}\\right]\\phi_i(\\mathbf{r}) = \\varepsilon_i\\phi_i(\\mathbf{r})")+
   p("第二项为直接库仑势（哈特里项），第三项为交换势（费米子特有，源于反对称性）。"))+
   note(p("哈特里-福克方程是非线性的，需自洽迭代求解（自洽场方法 SCF）。它忽略了电子关联（动态关联），是量子化学的基础近似。"))+
   note(p("<strong>哈特里-福克的历史与地位：</strong>哈特里于 1928 年提出平均场思想（哈特里方法，未考虑反对称性），福克与斯莱特于 1930 年引入 Slater 行列式修正，得到哈特里-福克方法。它是量子化学从头算（ab initio）的基石：所有更高级的电子相关方法（如 MP2、CI、CCSD(T)）都以哈特里-福克解为零级近似。哈特里-福克精确处理了交换能，但忽略了电子间的动态关联（即电子运动的瞬时相关），因此对键能、反应能的计算误差通常在 1 eV 量级，需通过后哈特里-福克方法或 DFT 进一步改进。"))
 )},
{"id":"qm10s3-2","name":"交换能与关联能","tags":["der","note"],"brief":"交换效应降低费米子能量。",
 "body": wrap(
   der(p("<strong>交换能：</strong>哈特里-福克能量中，两体相互作用分为直接项（库仑积分 $J_{ij}$）与交换项（$K_{ij}$）：")+
   fml("E = \\sum_i\\langle i|h|i\\rangle + \\frac12\\sum_{ij}(J_{ij}-K_{ij})")+
   p("交换项 $K_{ij}$ 仅对同自旋电子非零，源于波函数反对称性使同自旋电子保持距离（费米穴），从而降低库仑排斥能。交换能是铁磁性、化学键方向性等的来源。"))+
   note(p("哈特里-福克忽略的剩余电子-电子关联贡献称为关联能 $E_c=E_{\\text{exact}}-E_{HF}$。精确处理关联能需用组态相互作用（CI）、耦合簇（CC）、密度泛函理论（DFT）等方法。"))
 )},
{"id":"qm10s3-3","name":"密度泛函理论简介","tags":["app","note"],"brief":"以电子密度为基本变量的多体理论。",
 "body": wrap(
   defn("密度泛函理论（DFT）",p("Hohenberg-Kohn 定理证明：体系的基态能量是电子密度 $n(\\mathbf{r})$ 的唯一泛函 $E[n]$；Kohn-Sham 方法将相互作用多体问题映射为无相互作用粒子在有效势场中的问题。"))+
   der(p("<strong>Kohn-Sham 方程：</strong>有效势 $v_{\\text{eff}}(\\mathbf{r})=v_{\\text{ext}}(\\mathbf{r})+\\int\\frac{n(\\mathbf{r}')}{|\\mathbf{r}-\\mathbf{r}'|}d^3r'+v_{\\text{xc}}(\\mathbf{r})$，其中 $v_{\\text{xc}}$ 为交换关联势（包含所有多体效应）。Kohn-Sham 方程：")+
   fml("\\left[-\\frac{\\hbar^2}{2m}\\nabla^2+v_{\\text{eff}}(\\mathbf{r})\\right]\\phi_i(\\mathbf{r})=\\varepsilon_i\\phi_i(\\mathbf{r}),\\qquad n(\\mathbf{r})=\\sum_i|\\phi_i(\\mathbf{r})|^2")+
   p("自洽求解得到电子密度与能量。DFT 的核心近似是交换关联泛函（如 LDA、GGA）。"))+
   app(p("<strong>应用：</strong>DFT 是目前计算材料、分子、固体电子结构的最广泛使用的方法，在化学、物理、材料科学中具有核心地位。"))
 )},
]},
{
"name": "10.4 玻色子与费米子多体态",
"color": "#7e22ce",
"desc": "玻色-爱因斯坦凝聚、费米海与统计分布",
"items": [
{"id":"qm10s4-1","name":"玻色-爱因斯坦凝聚","tags":["der","app"],"brief":"低温下玻色子宏观占据基态。",
 "body": wrap(
   defn("玻色-爱因斯坦凝聚（BEC）",p("玻色子不受泡利原理限制，低温下大量粒子可宏观占据同一单粒子态（基态），形成玻色-爱因斯坦凝聚。"))+
   der(p("<strong>临界温度：</strong>对三维无相互作用玻色气体，当温度低于临界温度 $T_c$ 时，激发态容纳的粒子数饱和，剩余粒子凝聚到基态。临界温度由粒子数密度 $n$ 决定：")+
   fml("k_B T_c = \\frac{2\\pi\\hbar^2}{m}\\left(\\frac{n}{2.612}\\right)^{2/3}")+
   p("当 $T<T_c$ 时，凝聚体分数 $n_0/n=1-(T/T_c)^{3/2}$。凝聚体具有相干性，表现为超流（如液氦-4）或原子 BEC。"))+
   app(p("<strong>应用：</strong>1995 年实验实现的原子 BEC 开启了超冷原子物理领域；BEC 是量子模拟、精密测量、原子激光器的基础。"))+
   note(p("<strong>BEC 与超流、超导的联系：</strong>液氦-4 在 2.17 K 发生超流转变（λ 相变），本质是玻色子凝聚导致的宏观量子相干态，表现为零黏滞与量子化涡旋。对于费米子系统，通过 BCS 理论，电子配对（库珀对）形成复合玻色子，在低温下发生凝聚，导致超导现象。BEC-BCS 渡越描述了从弱耦合 BCS 极限到强耦合 BEC 极限的连续演化，是当前冷原子物理的前沿课题。"))
 )},
{"id":"qm10s4-2","name":"费米海与费米面","tags":["der","app"],"brief":"费米子填充到费米能级形成费米海。",
 "body": wrap(
   der(p("<strong>费米分布：</strong>热平衡下费米子在能级 $\\varepsilon$ 上的平均占据数为费米-狄拉克分布：")+
   fml("n(\\varepsilon) = \\frac{1}{e^{(\\varepsilon-\\mu)/k_BT}+1}")+
   p("其中 $\\mu$ 为化学势。$T=0$ 时，$n(\\varepsilon)=1$（$\\varepsilon<\\mu$）、$0$（$\\varepsilon>\\mu$），$\\mu(0)=\\varepsilon_F$ 为费米能量。所有 $\\varepsilon<\\varepsilon_F$ 的态被填满，形成费米海，其边界为费米面。"))+
   der(p("<strong>自由电子气：</strong>三维自由电子气的态密度 $g(\\varepsilon)=\\frac{V}{2\\pi^2}(\\frac{2m}{\\hbar^2})^{3/2}\\sqrt{\\varepsilon}$。$T=0$ 时总粒子数 $N=\\int_0^{\\varepsilon_F}g(\\varepsilon)d\\varepsilon$，得费米波矢 $k_F=(3\\pi^2n)^{1/3}$，费米能量 $\\varepsilon_F=\\hbar^2k_F^2/(2m)$。"))+
   app(p("<strong>应用：</strong>费米海模型解释了金属的电子比热（线性于 $T$）、泡利顺磁性、电导率等；费米面的形状决定了金属与半导体的输运性质。"))+
   note(p("<strong>费米海的深刻意义：</strong>费米海是朗道费米液体理论的基础：即使电子间存在库仑相互作用，低能激发仍可描述为有效费米子（准粒子）的费米海，准粒子具有重整化的有效质量与寿命。费米面附近的准粒子决定了金属的低温性质：电子比热 $C_V=\\gamma T$（线性于温度，因为只有费米面附近 $k_BT$ 范围内的电子可被激发）、泡利顺磁性 $\\chi_P=\\mu_0g(\\varepsilon_F)\\mu_B^2$（与温度无关）、电导率等。费米面的拓扑性质（如费米面是否闭合）还与拓扑绝缘体、外尔半金属等新型量子物态密切相关。"))
 )},
{"id":"qm10s4-3","name":"玻色与费米统计","tags":["der","note"],"brief":"两种量子统计分布及其经典极限。",
 "body": wrap(
   der(p("<strong>两种统计：</strong>玻色子服从玻色-爱因斯坦分布 $n_{BE}(\\varepsilon)=1/(e^{(\\varepsilon-\\mu)/k_BT}-1)$，每个态粒子数无上限；费米子服从费米-狄拉克分布 $n_{FD}(\\varepsilon)=1/(e^{(\\varepsilon-\\mu)/k_BT}+1)$，每个态最多一个粒子。"))+
   der(p("<strong>经典极限：</strong>当 $e^{(\\varepsilon-\\mu)/k_BT}\\gg1$（即 $n\\lambda_T^3\\ll1$，热德布罗意波长远小于粒子间距）时，两种分布都退化为玻尔兹曼分布：")+
   fml("n(\\varepsilon) \\approx e^{(\\mu-\\varepsilon)/k_BT}")+
   p("此时量子统计效应可忽略，体系可用经典统计力学描述。常温常压下的气体通常处于经典极限。"))+
   note(p("量子统计是理解黑体辐射（普朗克，玻色子）、电子比热（费米子）、白矮星质量上限（钱德拉塞卡极限，费米简并压）、BEC 等现象的基础。"))
 )},
]},
]

CHAPTERS = [
    {"id":"qm-ch1","num":"第一章","title":"波函数与薛定谔方程","en":"WAVE FUNCTION & SCHRÖDINGER EQUATION",
     "desc":"波函数与概率诠释、薛定谔方程、概率守恒、定态与能级、态叠加原理、波包演化、对称性与守恒律。",
     "sections": ch1_sections},
    {"id":"qm-ch2","num":"第二章","title":"一维定态问题","en":"ONE-DIMENSIONAL STATIONARY STATES",
     "desc":"无限深方势阱、有限深势阱、谐振子、势垒穿透与隧穿效应、周期势场与能带结构。",
     "sections": ch2_sections},
    {"id":"qm-ch3","num":"第三章","title":"力学量与算符","en":"OBSERVABLES & OPERATORS",
     "desc":"算符的基本性质、厄米算符、对易关系、不确定原理、力学量期望值与守恒量、共同本征态与 CSCO。",
     "sections": ch3_sections},
    {"id":"qm-ch4","num":"第四章","title":"表象理论","en":"REPRESENTATION THEORY",
     "desc":"坐标与动量表象、矩阵表示、幺正变换、狄拉克符号、薛定谔绘景与海森伯绘景、相互作用绘景。",
     "sections": ch4_sections},
    {"id":"qm-ch5","num":"第五章","title":"中心力场","en":"CENTRAL FORCE FIELD",
     "desc":"角动量本征值与球谐函数、氢原子能级与波函数、径向方程、球方势阱、三维谐振子。",
     "sections": ch5_sections},
    {"id":"qm-ch6","num":"第六章","title":"自旋与角动量耦合","en":"SPIN & ANGULAR MOMENTUM COUPLING",
     "desc":"电子自旋与泡利矩阵、角动量耦合与 CG 系数、自旋-轨道耦合、精细结构、塞曼效应、磁共振。",
     "sections": ch6_sections},
    {"id":"qm-ch7","num":"第七章","title":"近似方法","en":"APPROXIMATION METHODS",
     "desc":"非简并与简并定态微扰论、氢原子极化率与斯塔克效应、变分原理与瑞利-里兹法、氦原子基态。",
     "sections": ch7_sections},
    {"id":"qm-ch8","num":"第八章","title":"含时微扰论与量子跃迁","en":"TIME-DEPENDENT PERTURBATION & TRANSITIONS",
     "desc":"含时微扰论一阶跃迁振幅、费米黄金规则、光与物质相互作用、电偶极辐射与选择定则、禁戒跃迁与光电效应。",
     "sections": ch8_sections},
    {"id":"qm-ch9","num":"第九章","title":"散射理论","en":"SCATTERING THEORY",
     "desc":"散射截面与散射振幅、分波法与相移、玻恩近似与卢瑟福散射、全同粒子散射与干涉效应。",
     "sections": ch9_sections},
    {"id":"qm-ch10","num":"第十章","title":"多体问题简介","en":"MANY-BODY PROBLEM",
     "desc":"全同性原理与玻色子/费米子、泡利不相容原理、二次量子化、哈特里-福克近似与 DFT、玻色-爱因斯坦凝聚与费米海。",
     "sections": ch10_sections},
]

total_items = sum(sum(len(s["items"]) for s in ch["sections"]) for ch in CHAPTERS)
print(f"Total items: {total_items}")

def gen_html():
    data_lines = []
    for ch in CHAPTERS:
        sec_strs = []
        for sec in ch["sections"]:
            item_strs = []
            for it in sec["items"]:
                tags_js = json.dumps(it["tags"], ensure_ascii=False)
                body_esc = js_escape(fix_lt_math(it["body"]))
                fig_field = f",fig:{json.dumps(it.get('fig',''),ensure_ascii=False)}" if it.get("fig") else ""
                figcap_field = f",figCap:{json.dumps(it.get('figCap',''),ensure_ascii=False)}" if it.get("figCap") else ""
                item_strs.append(
                    f"{{id:'{it['id']}',name:{json.dumps(it['name'],ensure_ascii=False)},"
                    f"tags:{tags_js},brief:{json.dumps(it['brief'],ensure_ascii=False)},"
                    f"body:`{body_esc}`{fig_field}{figcap_field}}}"
                )
            sec_strs.append(
                f"{{name:{json.dumps(sec['name'],ensure_ascii=False)},"
                f"color:'{sec['color']}',desc:{json.dumps(sec['desc'],ensure_ascii=False)},"
                f"items:[{','.join(item_strs)}]}}"
            )
        data_lines.append(
            f"{{id:'{ch['id']}',num:{json.dumps(ch['num'],ensure_ascii=False)},"
            f"title:{json.dumps(ch['title'],ensure_ascii=False)},en:'{ch['en']}',"
            f"desc:{json.dumps(ch['desc'],ensure_ascii=False)},"
            f"sections:[{','.join(sec_strs)}]}}"
        )
    la_data = "[" + ",".join(data_lines) + "]"

    fig_entries = []
    for k, v in FIG.items():
        fig_entries.append(f"{json.dumps(k)}:`{js_escape(v)}`")
    fig_js = "{" + ",".join(fig_entries) + "}"
    tag_label_js = json.dumps(TAG_LABEL, ensure_ascii=False)

    nav_tabs = "".join(
        f'<a class="la-nav-tab c{i+1}" href="#{ch["id"]}">{ch["num"]} · {ch["title"]}</a>'
        for i, ch in enumerate(CHAPTERS)
    )

    css = '''  :root{--la-bg:#f4f7fb;--la-card:#ffffff;--la-ink:#152033;--la-muted:#607089;--la-shadow:0 12px 32px rgba(20,36,60,.09);}
  *{box-sizing:border-box}
  html{scroll-behavior:smooth}
  body{margin:0;font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Hiragino Sans GB","Microsoft YaHei",sans-serif;color:var(--la-ink);background:radial-gradient(circle at 10% 10%,rgba(124,58,237,.08),transparent 28%),radial-gradient(circle at 90% 10%,rgba(37,99,235,.08),transparent 28%),var(--la-bg);line-height:1.7}
  a{color:inherit}
  .la-wrap{width:min(1400px,94vw);margin:auto}
  .la-header{padding:52px 0 20px;text-align:center}
  .la-eyebrow{font-size:13px;letter-spacing:.22em;color:var(--la-muted);font-weight:700;text-transform:uppercase}
  h1{margin:10px 0 8px;font-size:clamp(30px,5vw,54px);line-height:1.08;letter-spacing:-.03em}
  .la-subtitle{margin:0 auto;color:var(--la-muted);font-size:16px;max-width:820px;line-height:1.8}
  .back-bar{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin:22px 0 6px}
  .back-btn{display:inline-flex;align-items:center;gap:8px;padding:10px 22px;border-radius:999px;text-decoration:none;font-size:14px;font-weight:800;background:#fff;color:#1e3a8a;border:1px solid #c7d7ee;box-shadow:0 8px 20px rgba(20,36,60,.08);transition:.25s;cursor:pointer}
  .back-btn:hover{transform:translateY(-2px);box-shadow:0 14px 30px rgba(20,36,60,.14);color:#4c1d95;border-color:#ddd6fe}
  .la-nav-tabs{display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin:22px 0 8px}
  .la-nav-tab{padding:8px 16px;border-radius:999px;text-decoration:none;font-weight:700;font-size:13px;border:1px solid #d5deea;background:#fff;transition:.25s;color:#334155}
  .la-nav-tab:hover{transform:translateY(-2px);box-shadow:0 8px 20px rgba(20,36,60,.1)}
  .la-nav-tab.c1{color:#7c3aed;border-color:#ddd6fe}
  .la-nav-tab.c2{color:#2563eb;border-color:#bfdbfe}
  .la-nav-tab.c3{color:#0d9488;border-color:#99f6e4}
  .la-nav-tab.c4{color:#4f46e5;border-color:#c7d2fe}
  .la-nav-tab.c5{color:#0891b2;border-color:#a5f3fc}
  .la-nav-tab.c6{color:#be185d;border-color:#fbcfe8}
  .la-nav-tab.c7{color:#c2410c;border-color:#fed7aa}
  .la-nav-tab.c8{color:#d97706;border-color:#fde68a}
  .la-nav-tab.c9{color:#059669;border-color:#a7f3d0}
  .la-nav-tab.c10{color:#7e22ce;border-color:#e9d5ff}
  .la-engagement-bar{display:flex;gap:12px;justify-content:center;flex-wrap:wrap;margin:26px 0 10px}
  .la-stat-item{display:inline-flex;align-items:center;gap:8px;padding:8px 16px;border-radius:999px;background:#fff;border:1px solid #e2e8f0;font-size:13px;color:#334155;font-weight:600}
  .la-stat-value{color:#6366f1;font-weight:800;font-size:15px}
  .la-stat-link{cursor:pointer;text-decoration:none;transition:.2s}
  .la-stat-link:hover{background:#eef2ff;border-color:#c7d2fe}
  .la-legend{display:flex;gap:8px;flex-wrap:wrap;justify-content:center;margin:0 0 24px;font-size:12px;color:#64748b}
  .la-legend-title{font-weight:700;margin-right:4px}
  .la-arc-badge{font-size:11px;padding:3px 10px;border-radius:999px;font-weight:700;letter-spacing:.04em}
  .la-arc-def{background:#dbeafe;color:#1e40af}
  .la-arc-thm{background:#ede9fe;color:#6d28d9}
  .la-arc-der{background:#e0f2fe;color:#0369a1}
  .la-arc-exa{background:#dcfce7;color:#15803d}
  .la-arc-app{background:#fef3c7;color:#b45309}
  .la-arc-note{background:#fee2e2;color:#b91c1c}
  .la-roadmap{padding:30px 0}
  .la-phase-title{font-size:24px;color:#1e293b;margin:40px 0 6px 18px;display:flex;align-items:center;gap:12px}
  .la-phase-title::before{content:"";width:6px;height:26px;border-radius:4px}
  .la-phase-title.qm-ch1::before{background:#7c3aed}
  .la-phase-title.qm-ch2::before{background:#2563eb}
  .la-phase-title.qm-ch3::before{background:#0d9488}
  .la-phase-title.qm-ch4::before{background:#4f46e5}
  .la-phase-title.qm-ch5::before{background:#0891b2}
  .la-phase-title.qm-ch6::before{background:#be185d}
  .la-phase-title.qm-ch7::before{background:#c2410c}
  .la-phase-title.qm-ch8::before{background:#d97706}
  .la-phase-title.qm-ch9::before{background:#059669}
  .la-phase-title.qm-ch10::before{background:#7e22ce}
  .la-phase-en{font-size:11px;letter-spacing:.36em;color:#94a3b8;font-weight:700;text-transform:uppercase;margin:0 0 12px 18px;font-style:italic}
  .la-phase-desc{color:var(--la-muted);font-size:14px;margin:0 0 24px 18px;line-height:1.8;max-width:960px}
  .la-domain{margin-bottom:26px;padding:16px 18px 18px 22px;position:relative;background:rgba(255,255,255,.6);border-radius:18px;border:1px solid #e5ebf2}
  .la-domain::before{content:"";position:absolute;left:6px;top:16px;bottom:16px;width:5px;border-radius:5px;background:var(--domain-color,#2563eb);box-shadow:0 0 12px rgba(37,99,235,.25)}
  .la-domain-header{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:12px}
  .la-domain-header h3{margin:0;font-size:17px;color:#1e293b}
  .la-domain-count{font-size:11px;padding:2px 10px;border-radius:999px;background:#eef2ff;color:#4f46e5;font-weight:700}
  .la-domain-desc{font-size:12px;color:#94a3b8}
  .la-domain-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px}
  .la-course-card{background:#fff;border:1px solid #e5ebf2;border-radius:14px;padding:14px 16px;cursor:pointer;transition:.22s;box-shadow:var(--la-shadow)}
  .la-course-card:hover{transform:translateY(-3px);border-color:#c7d2fe;box-shadow:0 16px 40px rgba(37,99,235,.12)}
  .la-course-card h4{margin:6px 0;font-size:15px;color:#1e293b}
  .la-course-card p{margin:4px 0 0;font-size:12.5px;color:#64748b;line-height:1.6}
  .la-arc-badges{display:flex;gap:5px;flex-wrap:wrap;margin-bottom:2px}
  .la-overlay{position:fixed;inset:0;background:rgba(15,23,42,.5);display:none;align-items:center;justify-content:center;padding:18px;z-index:60;backdrop-filter:blur(2px)}
  .la-overlay.show{display:flex}
  .la-modal{width:min(820px,96vw);background:white;border-radius:24px;padding:30px;box-shadow:0 24px 80px rgba(0,0,0,.28);animation:laPopIn .3s;max-height:90vh;overflow-y:auto}
  @keyframes laPopIn{from{transform:scale(.94);opacity:0}to{transform:scale(1);opacity:1}}
  .la-modal h2{margin:0 0 10px;font-size:23px;color:#1e293b;line-height:1.35}
  .la-modal .la-crumbs{font-size:12px;color:#94a3b8;margin:0 0 14px;font-weight:600;letter-spacing:.02em}
  .la-modal .la-arc-badges{margin:0 0 16px}
  .la-modal-body{color:#334155;font-size:15px;line-height:1.9}
  .la-modal-body p{margin:0 0 12px}
  .la-modal-body strong{color:#0f172a}
  .la-modal-body ul{margin:0 0 12px;padding-left:22px}
  .la-modal-body li{margin-bottom:6px}
  .la-fml{margin:16px 0;padding:14px 18px;background:linear-gradient(135deg,#f8fafc,#eef4fb);border-left:4px solid #93b4e8;border-radius:10px;overflow-x:auto;font-size:16px;color:#0f172a}
  .la-fml .note{display:block;font-size:12.5px;color:#8496ad;margin-top:8px;line-height:1.6;font-family:system-ui,-apple-system,"PingFang SC","Microsoft YaHei",sans-serif}
  .la-fml mjx-container[display="true"]{margin:0 !important}
  mjx-container, mjx-container *{color:#0f172a !important;opacity:1 !important}
  mjx-mi{font-style:italic !important}
  mjx-mo{color:#0f172a !important}
  .la-modal-body mjx-container, .la-modal-body mjx-container *{color:#0f172a !important;opacity:1 !important}
  .la-fig{margin:18px auto;padding:14px 16px 10px;background:#fafcff;border:1px solid #e2ebf7;border-radius:14px;display:flex;flex-direction:column;align-items:center;max-width:600px}
  .la-fig svg{display:block;width:100%;height:auto;max-width:560px}
  .la-fig .la-fig-cap{font-size:12px;color:#8496ad;margin-top:8px;text-align:center;letter-spacing:.02em}
  .la-callout{margin:14px 0;padding:12px 16px;background:#fffbeb;border-left:3px solid #fbbf24;border-radius:8px;font-size:13.5px;color:#78350f;line-height:1.8}
  .la-kp-sec{margin:0 0 18px;padding:14px 16px;border-radius:12px;background:#f8fafc;border:1px solid #eef2f7}
  .la-kp-sec h5{margin:0 0 10px;font-size:14px;color:#1e293b;letter-spacing:.04em;display:flex;align-items:center;gap:8px}
  .la-kp-sec h5::before{content:"";width:4px;height:14px;border-radius:2px;background:var(--la-accent,#3b82f6)}
  .la-kp-def{border-left:3px solid #3b82f6}
  .la-kp-thm{border-left:3px solid #8b5cf6;background:#faf7ff}
  .la-kp-der{border-left:3px solid #0ea5e9;background:#f0f9ff}
  .la-kp-exa{border-left:3px solid #10b981;background:#f0fdf4}
  .la-kp-app{border-left:3px solid #f59e0b;background:#fffbeb}
  .la-kp-note{border-left:3px solid #ef4444;background:#fef2f2}
  .la-kp-his{border-left:3px solid #64748b;background:#f8fafc}
  .la-kp-sec p:last-child{margin-bottom:0}
  .la-modal-close{margin-top:22px;background:#0f172a;color:white;border-color:#0f172a;padding:10px 20px;font-weight:bold}
  .la-footer{padding:34px 0 50px;color:var(--la-muted);text-align:center;font-size:13px;line-height:1.9}
  .la-core-fmls{margin:40px 0 20px;padding:28px 24px;background:linear-gradient(135deg,#f0f4ff,#faf7ff);border:1px solid #e0e7ff;border-radius:18px}
  .la-core-fmls h3{font-size:18px;color:#1e293b;margin:0 0 20px;text-align:center;letter-spacing:.04em}
  .la-core-fmls h3 .la-core-count{display:inline-block;background:#6366f1;color:#fff;font-size:13px;padding:2px 10px;border-radius:20px;margin-left:8px;vertical-align:middle}
  .la-core-item{display:flex;gap:12px;margin:0 0 14px;padding:12px 16px;background:#fff;border-radius:12px;border-left:3px solid #6366f1;align-items:flex-start}
  .la-core-num{flex-shrink:0;width:26px;height:26px;border-radius:50%;background:#6366f1;color:#fff;font-size:13px;display:flex;align-items:center;justify-content:center;font-weight:bold}
  .la-core-body{flex:1;min-width:0}
  .la-core-body .la-core-name{font-size:14px;font-weight:600;color:#1e293b;margin-bottom:4px}
  .la-core-body .la-fml{margin:6px 0 0;padding:8px 14px;font-size:15px}
  .la-back-top{display:inline-block;margin-top:20px;padding:10px 28px;background:#1e293b;color:#fff;border:none;border-radius:25px;font-size:14px;cursor:pointer;letter-spacing:.04em;transition:background .2s}
  .la-back-top:hover{background:#334155}
  @media(max-width:900px){.la-wrap{width:min(94vw,720px)}.la-roadmap{padding:20px}.la-phase-title{font-size:19px}.la-phase-en{font-size:10px;letter-spacing:.26em}.la-domain-desc{display:none}.la-domain-grid{grid-template-columns:repeat(auto-fill,minmax(160px,1fr))}.la-modal{padding:22px}}'''

    js = f'''const LA_DATA = {la_data};
const LA_TAG_LABEL = {tag_label_js};
const LA_FIG = {fig_js};
const LA_KP = {{}};
function laBuildCard(item){{
  const tags = item.tags.map(t => `<span class="la-arc-badge la-arc-${{t}}">${{LA_TAG_LABEL[t]}}</span>`).join('');
  return `<div class="la-course-card" onclick="showLaItem('${{item.id}}')"><div class="la-arc-badges">${{tags}}</div><h4>${{item.name}}</h4><p>${{item.brief}}</p></div>`;
}}
function renderLa(){{
  const root = document.getElementById('laRoadmap');
  let html = '';
  LA_DATA.forEach(ch => {{
    html += `<h2 class="la-phase-title ${{ch.id}}" id="${{ch.id}}">${{ch.num}} · ${{ch.title}}</h2>`;
    html += `<div class="la-phase-en">${{ch.en}}</div>`;
    html += `<p class="la-phase-desc">${{ch.desc}}</p>`;
    ch.sections.forEach(sec => {{
      html += `<div class="la-domain" style="--domain-color:${{sec.color}};"><div class="la-domain-header"><h3>${{sec.name}}</h3><span class="la-domain-count">${{sec.items.length}} 个知识点</span><span class="la-domain-desc">${{sec.desc}}</span></div><div class="la-domain-grid">`;
      sec.items.forEach(it => {{ html += laBuildCard(it); LA_KP[it.id] = {{item: it, section: sec.name, chapter: `${{ch.num}} · ${{ch.title}}`}}; }});
      html += `</div></div>`;
    }});
  }});
  root.innerHTML = html;
  const kCount = Object.keys(LA_KP).length;
  document.getElementById('laKCount').textContent = kCount;
}}
function showLaItem(id){{
  const rec = LA_KP[id];
  if(!rec) return;
  const it = rec.item;
  document.getElementById('laCrumbs').textContent = rec.chapter + ' ／ ' + rec.section;
  document.getElementById('laTitle').textContent = it.name;
  document.getElementById('laTags').innerHTML = it.tags.map(t => `<span class="la-arc-badge la-arc-${{t}}">${{LA_TAG_LABEL[t]}}</span>`).join('');
  let bodyHtml = it.body;
  if (it.fig && LA_FIG[it.fig]) {{
    const figHtml = `<div class="la-fig">${{LA_FIG[it.fig]}}<div class="la-fig-cap">${{it.figCap || ''}}</div></div>`;
    bodyHtml = figHtml + bodyHtml;
  }}
  document.getElementById('laBody').innerHTML = bodyHtml;
  document.getElementById('laOverlay').classList.add('show');
  document.querySelector('.la-modal').scrollTop = 0;
  if (window.MathJax && window.MathJax.typesetPromise) {{ window.MathJax.typesetPromise([document.getElementById('laBody')]).catch(()=>{{}}); }}
}}
function hideLaInfo(){{ document.getElementById('laOverlay').classList.remove('show'); }}
function closeLaInfo(e){{ if(e.target.id === 'laOverlay') hideLaInfo(); }}
document.addEventListener('keydown', e => {{ if(e.key === 'Escape') hideLaInfo(); }});
document.addEventListener('DOMContentLoaded', () => {{
  renderLa();
  if (window.MathJax && window.MathJax.typesetPromise) {{ window.MathJax.typesetPromise([document.getElementById('laRoadmap')]).catch(()=>{{}}); }}
}});'''

    html = f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="量子力学知识体系：波函数与薛定谔方程、一维定态、算符、表象、中心力场、自旋、近似方法、跃迁、散射、多体">
<title>量子力学 · 知识体系</title>
<script>
window.MathJax = {{
  tex: {{
    inlineMath: [['$','$'], ['\\\\(','\\\\)']],
    displayMath: [['$$','$$'], ['\\\\[','\\\\]']],
    processEscapes: true,
    packages: {{'[+]': ['ams','boldsymbol']}}
  }},
  options: {{
    skipHtmlTags: ['script','noscript','style','textarea','pre','code'],
    ignoreHtmlClass: 'tex2jax_ignore'
  }},
  svg: {{ fontCache: 'global' }}
}};
</script>
<script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js" id="MathJax-script" async></script>
<style>
{css}
</style>
</head>
<body>
<div class="la-wrap">
  <header class="la-header">
    <div class="la-eyebrow">QUANTUM MECHANICS · KNOWLEDGE MAP</div>
    <h1>量子力学 · 知识体系</h1>
    <p class="la-subtitle">波函数与薛定谔方程 · 一维定态 · 算符与表象 · 中心力场 · 自旋与角动量 · 近似方法 · 量子跃迁 · 散射理论 · 多体问题</p>
    <div class="back-bar"><a class="back-btn" href="index.html">← 返回总览</a></div>
    <div class="la-nav-tabs">{nav_tabs}</div>
    <div class="la-engagement-bar">
      <div class="la-stat-item"><span>📘</span><span class="la-stat-value" id="laKCount">--</span><span>个知识点</span></div>
      <a class="la-stat-item la-stat-link" href="#laCoreFmls" onclick="event.preventDefault();document.getElementById('laCoreFmls').scrollIntoView({{behavior:'smooth',block:'start'}})"><span>🧮</span><span class="la-stat-value">{len(CORE_FORMULAS)}</span><span>条核心公式 · 点击速查</span></a>
    </div>
  </header>
  <div class="la-legend">
    <span class="la-legend-title">知识记号</span>
    <span class="la-arc-badge la-arc-def">定 义</span>
    <span class="la-arc-badge la-arc-thm">定 理</span>
    <span class="la-arc-badge la-arc-der">推 导</span>
    <span class="la-arc-badge la-arc-exa">例 子</span>
    <span class="la-arc-badge la-arc-app">应 用</span>
    <span class="la-arc-badge la-arc-note">备 注</span>
  </div>
  <main class="la-roadmap" id="laRoadmap"></main>
  <section class="la-core-fmls" id="laCoreFmls">
    <h3>核心公式速查 <span class="la-core-count">{len(CORE_FORMULAS)} 条</span></h3>
{chr(10).join(f'    <div class="la-core-item"><div class="la-core-num">{i+1}</div><div class="la-core-body"><div class="la-core-name">{name}</div><div class="la-fml">$${latex}$$</div><div class="note" style="font-size:12px;color:#8496ad;margin-top:4px">{desc}</div></div></div>' for i,(name,latex,desc) in enumerate(CORE_FORMULAS))}
  </section>
  <footer class="la-footer">
    <div>量子力学 · 知识体系可视化 · MathJax + SVG</div>
    <div style="margin-top:8px">基于 曾谨言《量子力学教程》《量子力学》卷 I/II 核心知识体系整理</div>
    <button class="la-back-top" onclick="window.scrollTo({{top:0,behavior:'smooth'}})">↑ 回到顶部</button>
  </footer>
</div>
<div class="la-overlay" id="laOverlay" onclick="closeLaInfo(event)">
  <div class="la-modal" onclick="event.stopPropagation()">
    <p class="la-crumbs" id="laCrumbs"></p>
    <h2 id="laTitle">知识点</h2>
    <div class="la-arc-badges" id="laTags"></div>
    <div class="la-modal-body" id="laBody"></div>
    <button class="la-modal-close" onclick="hideLaInfo()">关 闭</button>
  </div>
</div>
<script>
{js}
</script>
</body>
</html>'''
    return html

if __name__ == "__main__":
    html = gen_html()
    with open("/workspace/quantum-mechanics.html", "w", encoding="utf-8") as f:
        f.write(html)
    print(f"Generated quantum-mechanics.html ({len(html)} chars)")




