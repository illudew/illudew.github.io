import re

src = open('index.html', encoding='utf-8').read()

# ============ 1. DIFFICULTY MAPPING ============
DIFF = {
  '初等数学':       ['PST 1','PRS 4','FTR 7'],
  '微积分':         ['PST 3','PRS 5','FTR 8','ETR 9'],
  '线性代数':       ['PST 2','PRS 4','FTR 7'],
  '力学':           ['PST 1','PRS 3','FTR 7'],
  '电磁学':         ['PST 3','PRS 6','FTR 7'],
  '热学':           ['PST 3','PRS 5','FTR 8'],
  '光学':           ['PST 7','PRS 9','FTR 11'],
  '原子物理学':     ['PST 4','PRS 6','FTR 8'],
  '理论力学':       ['PST 4','PRS 7','FTR 9','BYD 10'],
  '电动力学':       ['PST 5','PRS 7','FTR 9+','BYD 10+'],
  '数学物理方法':   ['PST 6','PRS 8','FTR 10','ETR 10+'],
  '特殊函数':       ['PST 5','PRS 7','FTR 9+','ETR 10+'],
  '计算物理':       ['PST 3','PRS 7','FTR 10','ETR 10'],
  '电路':           ['PST 2','PRS 6','FTR 9'],
  '热力学与统计物理':['PST 7','PRS 9','FTR 10+','BYD 11'],
  '工程光学':       ['PST 5','PRS 8','FTR 10'],
  '固体物理':       ['PST 7','PRS 9','FTR 10+','BYD 11'],
  '材料物理':       ['PST 5','PRS 8','FTR 10'],
  '量子力学':       ['PST 7','PRS 9','FTR 10+','BYD 11+'],
}

ARC_DEF = {
  'PST':'刚刚明白这门课讲了个啥',
  'PRS':'考试能够及格',
  'FTR':'考试能够取得4.0或90+',
  'ETR':'能够灵活运用该工具学科',
  'BYD':'能够深入理解该学科',
  'INS':'the god is in here, and in you!',
}

def arc_badges_html(arc_list):
    spans = []
    for a in arc_list:
        code = a.split()[0]
        val = a.split()[1]
        cls = code.lower()
        title = ARC_DEF.get(code, '')
        spans.append(f'<span class="arc-badge arc-{cls}" title="{title}">{code} {val}</span>')
    return '<div class="arc-badges">' + ''.join(spans) + '</div>'

# ============ 2. UPDATE INLINE CARD BADGES ============
for name, arc in DIFF.items():
    if name == '量子力学':
        continue  # handled separately (trial card)
    new_badges = arc_badges_html(arc)
    pat = re.compile(
        r'(<h4(?:[^>]*)>' + re.escape(name) + r'</h4>\s*)<div class="arc-badges">.*?</div>',
        re.DOTALL
    )
    src, n = pat.subn(lambda m: m.group(1) + new_badges, src)
    if n == 0:
        print(f'WARN card badge not found: {name}')

# ============ 3. UPDATE COURSES DATA arc ARRAYS ============
for name, arc in DIFF.items():
    new_arr = '[' + ','.join(f"'{a}'" for a in arc) + ']'
    pat = re.compile(
        r"('" + re.escape(name) + r"':\{.*?arc:)\[[^\]]*\]",
        re.DOTALL
    )
    src, n = pat.subn(lambda m: m.group(1) + new_arr, src)
    if n == 0:
        print(f'WARN data arc not found: {name}')

# ============ 4. CONVERT 量子力学 CARD TO TRIAL CARD ============
qm_old = """        <div class="course-card legendary-card" onclick="showCourse('量子力学')"><div class="tag">第5章pro max</div><h4 style="color:#92400e;">量子力学</h4>
          <div class="arc-badges"><span class="arc-badge arc-pst">PST 6</span><span class="arc-badge arc-prs">PRS 8</span><span class="arc-badge arc-ftr">FTR 10</span><span class="arc-badge arc-byd">BYD 11</span></div>
          <p style="color:#78350f;">微观世界的全新理论。遇事不决，量子力学。</p></div>"""

qm_new = """        <div class="course-card qm-trial-card" onclick="openTrial()"><div class="tag">第5章pro max</div><h4 style="color:#92400e;">量子力学</h4>
          <div class="arc-badges"><span class="arc-badge arc-pst" title="刚刚明白这门课讲了个啥">PST 7</span><span class="arc-badge arc-prs" title="考试能够及格">PRS 9</span><span class="arc-badge arc-ftr" title="考试能够取得4.0或90+">FTR 10+</span><span class="arc-badge arc-byd" title="能够深入理解该学科">BYD 11+</span></div>
          <p style="color:#78350f;">微观世界的全新理论。遇事不决，量子力学。</p>
          <div class="qm-trial-overlay"><div class="lock-icon">🔒</div><div class="lock-text">解锁魔王的试炼</div><div class="lock-sub">十题通关 · 方可闯入量子世界</div></div></div>"""

if qm_old in src:
    src = src.replace(qm_old, qm_new)
    print('QM card replaced OK')
else:
    print('ERROR: QM old card not found!')
    # fallback: try regex
    pat = re.compile(
        r'<div class="course-card legendary-card" onclick="showCourse\(\'量子力学\'\)">.*?遇事不决，量子力学。</p></div>',
        re.DOTALL
    )
    src, n = pat.subn(qm_new, src)
    print(f'QM card regex replaced: {n}')

# ============ 5. INJECT TRIAL CSS ============
TRIAL_CSS = r"""
  /* ===== 量子力学解锁魔王的试炼 ===== */
  .qm-trial-card{position:relative;filter:grayscale(0.65) brightness(0.72);cursor:pointer;border:2px solid #7c3aed;background:linear-gradient(135deg,#fffbeb,#fef3c7);box-shadow:0 0 22px rgba(124,58,237,.35);transition:.25s}
  .qm-trial-card:hover{filter:grayscale(0.25) brightness(0.92);transform:translateY(-5px) scale(1.02);box-shadow:0 0 36px rgba(124,58,237,.6)}
  .qm-trial-card:active{transform:translateY(-2px) scale(0.99)}
  .qm-trial-overlay{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;background:radial-gradient(circle at center,rgba(76,29,149,.55),rgba(30,41,59,.78));backdrop-filter:blur(2.5px);z-index:10;border-radius:18px;pointer-events:none;text-align:center;padding:10px}
  .qm-trial-overlay .lock-icon{font-size:50px;margin-bottom:10px;animation:qmPulse 2s ease-in-out infinite}
  @keyframes qmPulse{0%,100%{transform:scale(1);opacity:.95}50%{transform:scale(1.12);opacity:1}}
  .qm-trial-overlay .lock-text{color:#fff;font-size:19px;font-weight:900;letter-spacing:.06em;text-shadow:0 2px 10px rgba(0,0,0,.7);background:linear-gradient(90deg,#fbbf24,#f472b6);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent}
  .qm-trial-overlay .lock-sub{color:#ddd6fe;font-size:12.5px;margin-top:8px;font-weight:600;letter-spacing:.03em}

  .trial-overlay{position:fixed;inset:0;background:rgba(15,23,42,.88);backdrop-filter:blur(7px);z-index:10000;display:none;align-items:center;justify-content:center;padding:20px;animation:trialFade .25s ease}
  .trial-overlay.show{display:flex}
  @keyframes trialFade{from{opacity:0}to{opacity:1}}
  .trial-modal{background:#fff;border-radius:22px;padding:30px;max-width:660px;width:100%;box-shadow:0 30px 90px rgba(0,0,0,.5);animation:trialPop .4s cubic-bezier(.34,1.56,.64,1);max-height:90vh;overflow-y:auto}
  @keyframes trialPop{from{transform:scale(.8) translateY(20px);opacity:0}to{transform:scale(1) translateY(0);opacity:1}}
  .trial-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;border-bottom:2px solid #ede9fe;padding-bottom:16px}
  .trial-header h2{margin:0;color:#7c3aed;font-size:22px;display:flex;align-items:center;gap:8px}
  .trial-progress{background:linear-gradient(135deg,#ede9fe,#ddd6fe);color:#6d28d9;padding:7px 15px;border-radius:20px;font-weight:800;font-size:14px;white-space:nowrap}
  .trial-q{font-size:17px;font-weight:600;color:#1e293b;margin-bottom:18px;line-height:1.7}
  .trial-q .q-topic{display:inline-block;font-size:12px;font-weight:700;color:#7c3aed;background:#ede9fe;padding:3px 11px;border-radius:10px;margin-right:10px;margin-bottom:6px;letter-spacing:.02em}
  .trial-options{display:flex;flex-direction:column;gap:10px}
  .trial-opt{display:flex;align-items:flex-start;gap:12px;padding:14px 16px;border:2px solid #e2e8f0;border-radius:13px;cursor:pointer;transition:.15s;font-size:15px;line-height:1.55;background:#fff}
  .trial-opt:hover{border-color:#a78bfa;background:#f5f3ff}
  .trial-opt.correct{border-color:#10b981;background:#ecfdf5}
  .trial-opt.wrong{border-color:#ef4444;background:#fef2f2;animation:trialShake .4s}
  @keyframes trialShake{0%,100%{transform:translateX(0)}25%{transform:translateX(-6px)}75%{transform:translateX(6px)}}
  .trial-opt .opt-letter{flex-shrink:0;width:30px;height:30px;border-radius:50%;background:#f1f5f9;display:flex;align-items:center;justify-content:center;font-weight:800;color:#64748b;font-size:14px}
  .trial-opt:hover .opt-letter{background:#a78bfa;color:#fff}
  .trial-opt.correct .opt-letter{background:#10b981;color:#fff}
  .trial-opt.wrong .opt-letter{background:#ef4444;color:#fff}
  .trial-feedback{margin-top:16px;padding:13px 16px;border-radius:11px;font-size:14px;font-weight:700;display:none;line-height:1.5}
  .trial-feedback.show{display:block}
  .trial-feedback.success{background:#ecfdf5;color:#047857}
  .trial-feedback.fail{background:#fef2f2;color:#b91c1c}
  .trial-result{text-align:center;padding:10px 0}
  .trial-result .big-emoji{font-size:68px;line-height:1;margin-bottom:8px}
  .trial-result h3{color:#7c3aed;font-size:22px;margin:10px 0}
  .trial-result p.sub{color:#64748b;margin:8px 0 18px;font-size:14px}
  .trial-subject-select{width:100%;padding:13px 14px;border:2px solid #c4b5fd;border-radius:11px;font-size:15px;background:#fff;color:#1e293b;margin-bottom:16px;cursor:pointer;outline:none;transition:.15s}
  .trial-subject-select:focus{border-color:#7c3aed;box-shadow:0 0 0 3px rgba(124,58,237,.15)}
  .trial-btn{padding:13px 22px;border:none;border-radius:12px;font-size:15px;font-weight:700;cursor:pointer;transition:.15s;font-family:inherit}
  .trial-btn-primary{background:linear-gradient(135deg,#7c3aed,#4f46e5);color:#fff;width:100%;margin-top:6px}
  .trial-btn-primary:hover{transform:translateY(-2px);box-shadow:0 8px 22px rgba(124,58,237,.35)}
  .trial-btn-primary:active{transform:translateY(0)}
  .trial-btn-ghost{background:#f1f5f9;color:#64748b;margin-top:10px}
  .trial-btn-ghost:hover{background:#e2e8f0}
"""

assert '</style>' in src
src = src.replace('</style>', TRIAL_CSS + '\n</style>', 1)
print('CSS injected')

# ============ 6. INJECT TRIAL HTML ============
TRIAL_HTML = r"""
  <!-- 量子力学解锁魔王的试炼 -->
  <div id="trialOverlay" class="trial-overlay" onclick="closeTrialOnBg(event)">
    <div class="trial-modal" onclick="event.stopPropagation()">
      <div class="trial-header">
        <h2>🔒 解锁魔王的试炼</h2>
        <div class="trial-progress"><span id="trialProg">0 / 10</span></div>
      </div>
      <div id="trialBody" class="trial-body"></div>
    </div>
  </div>
"""

assert '</body>' in src
src = src.replace('</body>', TRIAL_HTML + '\n</body>', 1)
print('HTML injected')

# ============ 7. INJECT TRIAL JS ============
TRIAL_JS = r"""
/* ===== 量子力学解锁魔王的试炼 ===== */
var TRIAL_QUESTIONS=[
 {topic:'理论力学 · 哈密顿力学', q:'哈密顿正则方程的形式为？', options:[
   '$\\dot{q}_i = \\frac{\\partial H}{\\partial p_i},\\quad \\dot{p}_i = -\\frac{\\partial H}{\\partial q_i}$',
   '$\\dot{q}_i = \\frac{\\partial H}{\\partial q_i},\\quad \\dot{p}_i = -\\frac{\\partial H}{\\partial p_i}$',
   '$\\dot{q}_i = -\\frac{\\partial H}{\\partial p_i},\\quad \\dot{p}_i = \\frac{\\partial H}{\\partial q_i}$',
   '$\\dot{q}_i = \\frac{\\partial L}{\\partial q_i},\\quad \\dot{p}_i = \\frac{\\partial L}{\\partial \\dot{q}_i}$'
 ], answer:0},
 {topic:'电动力学 · 电磁波波导', q:'矩形波导（宽 a，高 b，a>b）中 TE₁₀ 模的截止波长 λ_c 为？', options:[
   '$a$',
   '$2a$',
   '$a/2$',
   '$\\sqrt{a^2+b^2}$'
 ], answer:1},
 {topic:'数学物理方法 · 分离变量法', q:'两端固定弦（区间 0≤x≤l）自由振动的本征函数为？', options:[
   '$\\cos\\dfrac{n\\pi x}{l}$',
   '$\\sin\\dfrac{n\\pi x}{l}$',
   '$e^{in\\pi x/l}$',
   '$x^n(l-x)$'
 ], answer:1},
 {topic:'数学物理方法 · 数理方程求解', q:'一维热传导方程 $u_t = a^2 u_{xx}$ 的基本解（格林函数）为？', options:[
   '$\\dfrac{1}{\\sqrt{4\\pi a^2 t}}\\exp\\!\\left(-\\dfrac{x^2}{4a^2 t}\\right)$',
   '$\\dfrac{1}{2a}\\,\\theta(at-|x|)$',
   '$\\dfrac{1}{2\\pi}\\ln\\dfrac{1}{r}$',
   '$\\dfrac{e^{ikr}}{4\\pi r}$'
 ], answer:0},
 {topic:'热力学与统计物理 · 系综', q:'正则系综的配分函数 $Z = \\sum_i e^{-\\beta E_i}$ 中，$\\beta$ 等于？', options:[
   '$k_B T$',
   '$1/(k_B T)$',
   '$-k_B T$',
   '$k_B/T$'
 ], answer:1},
 {topic:'热力学与统计物理 · 涨落', q:'正则系综中系统能量的涨落 $\\overline{(\\Delta E)^2}$ 等于（C_V 为定容热容）？', options:[
   '$k_B T^2 C_V$',
   '$k_B T C_V$',
   '$C_V / T$',
   '$k_B^2 T^2$'
 ], answer:0},
 {topic:'特殊函数 · 厄米多项式', q:'厄米多项式 $H_n(x)$ 满足的递推关系为？', options:[
   '$H_{n+1}(x) = 2x\\,H_n(x) - 2n\\,H_{n-1}(x)$',
   '$H_{n+1}(x) = x\\,H_n(x) - n\\,H_{n-1}(x)$',
   '$H_{n+1}(x) = 2n\\,H_n(x) - x\\,H_{n-1}(x)$',
   '$H_{n+1}(x) = x\\,H_n(x) + n\\,H_{n-1}(x)$'
 ], answer:0},
 {topic:'原子物理 · 电子自旋', q:'电子自旋角动量的大小（自旋量子数 s=1/2）为？', options:[
   '$\\hbar$',
   '$\\dfrac{1}{2}\\hbar$',
   '$\\dfrac{\\sqrt{3}}{2}\\hbar$',
   '$\\sqrt{2}\\,\\hbar$'
 ], answer:2},
 {topic:'光学 · 波动光学', q:'杨氏双缝干涉中，相邻明纹间距为（d 为缝间距，D 为缝到屏的距离，λ 为波长）？', options:[
   '$\\Delta x = \\dfrac{\\lambda D}{d}$',
   '$\\Delta x = \\dfrac{\\lambda d}{D}$',
   '$\\Delta x = \\dfrac{2\\lambda D}{d}$',
   '$\\Delta x = \\dfrac{D}{\\lambda d}$'
 ], answer:0},
 {topic:'光学 · 波动光学', q:'单缝夫琅禾费衍射中，暗纹条件为（a 为缝宽，θ 为衍射角）？', options:[
   '$a\\sin\\theta = k\\lambda\\quad(k=\\pm1,\\pm2,\\dots)$',
   '$a\\sin\\theta = (2k+1)\\lambda/2$',
   '$a\\cos\\theta = k\\lambda$',
   '$a\\sin\\theta = \\lambda/2$'
 ], answer:0}
];

var ALL_SUBJECTS=['初等数学','微积分','线性代数','概率论与数理统计','群论','数学物理方法','特殊函数','矢量分析','计算物理','力学','理论力学','流体力学','固体力学','计算流体力学','电磁学','电动力学','电路','模拟电子技术','数字电子技术','集成电路','热学','热力学与统计物理','光学','工程光学','光学系统设计','激光原理','非线性光学','发光物理','声学','原子物理学','量子力学','量子信息','量子计算','原子核物理','基础物理实验','近代物理实验','固体物理','材料物理','超导物理','纳米物理','拓扑物态','二维材料','低温物理','材料制备技术','材料测试技术','半导体物理','半导体材料','半导体器件','半导体工艺','相对论','宇宙学','黑洞物理','粒子物理','规范场论','量子场论','弦理论','量子引力','共形场论','拓扑量子场论','天体物理学','等离子体物理','生物物理','辐射过程','核聚变物理'];

var trialIdx=0;
function openTrial(){
  trialIdx=0;
  document.getElementById('trialOverlay').classList.add('show');
  renderTrial();
}
function closeTrial(){
  document.getElementById('trialOverlay').classList.remove('show');
}
function closeTrialOnBg(e){
  if(e.target.id==='trialOverlay') closeTrial();
}
function renderTrial(){
  var body=document.getElementById('trialBody');
  var prog=document.getElementById('trialProg');
  if(trialIdx<TRIAL_QUESTIONS.length){
    var q=TRIAL_QUESTIONS[trialIdx];
    prog.textContent=(trialIdx+1)+' / '+TRIAL_QUESTIONS.length;
    var opts=q.options.map(function(o,i){
      var letter=String.fromCharCode(65+i);
      return '<div class="trial-opt" onclick="trialPick('+i+')"><span class="opt-letter">'+letter+'</span><span>'+o+'</span></div>';
    }).join('');
    body.innerHTML='<div class="trial-q"><span class="q-topic">'+q.topic+'</span>'+q.q+'</div>'
      +'<div class="trial-options">'+opts+'</div>'
      +'<div class="trial-feedback" id="trialFb"></div>';
  }else{
    prog.textContent='最终题';
    var opts2=ALL_SUBJECTS.map(function(s){return '<option value="'+s+'">'+s+'</option>';}).join('');
    body.innerHTML='<div class="trial-result">'
      +'<div class="big-emoji">🎉</div>'
      +'<h3>十题全通！魔王认可了你的实力</h3>'
      +'<p class="sub">最后一题：你最喜欢什么学科？<br>（只有一个答案能让魔王放行）</p>'
      +'<select class="trial-subject-select" id="subjectSelect"><option value="">请选择你最钟情的学科…</option>'+opts2+'</select>'
      +'<button class="trial-btn trial-btn-primary" onclick="trialFinal()">确认选择</button>'
      +'<div class="trial-feedback" id="trialFb" style="margin-top:14px"></div>'
      +'</div>';
  }
  if(window.MathJax&&window.MathJax.typeset){
    try{MathJax.typeset([body])}catch(e){}
  }
}
function trialPick(i){
  var q=TRIAL_QUESTIONS[trialIdx];
  var opts=document.querySelectorAll('.trial-opt');
  opts.forEach(function(o){o.onclick=null;o.style.cursor='default';});
  var fb=document.getElementById('trialFb');
  if(i===q.answer){
    opts[i].classList.add('correct');
    fb.className='trial-feedback show success';
    fb.textContent='✓ 回答正确！魔王微微点头……';
    setTimeout(function(){ trialIdx++; renderTrial(); }, 850);
  }else{
    opts[i].classList.add('wrong');
    opts[q.answer].classList.add('correct');
    fb.className='trial-feedback show fail';
    fb.textContent='✗ 回答错误！试炼失败，回到主界面，下次再来挑战吧。';
    setTimeout(function(){ closeTrial(); }, 1800);
  }
}
function trialFinal(){
  var sel=document.getElementById('subjectSelect');
  var v=sel.value;
  var fb=document.getElementById('trialFb');
  if(!v){
    fb.className='trial-feedback show fail';
    fb.textContent='请先选择一个学科。';
    return;
  }
  if(v==='量子力学'){
    fb.className='trial-feedback show success';
    fb.textContent='✓ 唯有量子力学配得上你的野心……进入量子世界！';
    setTimeout(function(){ window.location.href='quantum-mechanics.html'; }, 1100);
  }else{
    fb.className='trial-feedback show fail';
    fb.textContent='✗ 魔王冷笑：「这个答案，不配打开量子之门。」试炼失败。';
    setTimeout(function(){ closeTrial(); }, 2000);
  }
}
document.addEventListener('keydown',function(e){
  if(e.key==='Escape'&&document.getElementById('trialOverlay').classList.contains('show')) closeTrial();
});

/* 给所有 arc-badge 加上难度定义 tooltip */
(function(){
  var DEF={'PST':'刚刚明白这门课讲了个啥','PRS':'考试能够及格','FTR':'考试能够取得4.0或90+','ETR':'能够灵活运用该工具学科','BYD':'能够深入理解该学科','INS':'the god is in here, and in you!'};
  document.querySelectorAll('.arc-badge').forEach(function(el){
    var t=(el.textContent||'').trim().split(' ')[0];
    if(DEF[t]&&!el.getAttribute('title')) el.setAttribute('title',DEF[t]);
  });
})();
"""

# inject before the LAST </script> (the main script block before </body>)
last_script = src.rfind('</script>')
assert last_script != -1
src = src[:last_script] + TRIAL_JS + '\n' + src[last_script:]
print('JS injected')

# ============ 8. WRITE ============
open('index.html', 'w', encoding='utf-8').write(src)
print('DONE')
