import re

UNLOCKED = {
    '初等数学', '微积分', '线性代数', '计算物理', '数学物理方法', '特殊函数',
    '力学', '理论力学', '电磁学', '电动力学', '热学', '热力学与统计物理',
    '光学', '工程光学', '原子物理学', '电路', '量子力学',
}

LOCK_HTML = '<div class="lock-overlay"><div class="lock-icon">🔒</div><div class="lock-text">知识不够，前面的区域以后再来探索吧</div></div>'

with open('/workspace/index.html', 'r', encoding='utf-8') as f:
    html = f.read()

# Find all course-card opening tags with their showCourse name
# Pattern: <div class="course-card..." onclick="showCourse('NAME')" ...>
card_pat = re.compile(
    r'<div\s+class="course-card([^"]*)"\s+onclick="showCourse\(\'([^\']+)\'\)"'
    r'(\s+style="[^"]*")?\s*>'
)

locked_names = []
unlocked_names = []
# We process from end to start to preserve offsets
matches = list(card_pat.finditer(html))
print(f"Found {len(matches)} course cards")

# Build list of (name, locked, start, end_of_open_tag)
card_infos = []
for m in matches:
    name = m.group(2)
    is_locked = name not in UNLOCKED
    card_infos.append((name, is_locked, m.start(), m.end()))
    if is_locked:
        locked_names.append(name)
    else:
        unlocked_names.append(name)

print(f"Unlocked ({len(unlocked_names)}): {unlocked_names}")
print(f"Locked ({len(locked_names)}): {locked_names}")

# Function to find matching closing </div> for a div starting at open_tag_end
def find_matching_close(s, open_end):
    depth = 1
    i = open_end
    while i < len(s) and depth > 0:
        open_m = re.search(r'<div\b', s[i:])
        close_m = re.search(r'</div>', s[i:])
        if close_m is None:
            return -1
        close_pos = i + close_m.start()
        if open_m and (i + open_m.start()) < close_pos:
            depth += 1
            i = i + open_m.end()
        else:
            depth -= 1
            if depth == 0:
                return close_pos
            i = close_pos + len('</div>')
    return -1

# Process from end to start
new_html = html
for name, is_locked, start, open_end in reversed(card_infos):
    if not is_locked:
        continue
    # Add locked-card class
    # The class attribute is class="course-card..." - insert before the closing quote
    # We can do: replace 'class="course-card' with 'class="course-card locked-card'
    # But safer to do it on the matched portion
    close_pos = find_matching_close(new_html, open_end)
    if close_pos == -1:
        print(f"WARNING: could not find closing div for {name}")
        continue
    # Insert overlay before </div>
    new_html = new_html[:close_pos] + LOCK_HTML + new_html[close_pos:]
    # Add locked-card class: find the class="course-card..." within [start, open_end)
    seg = new_html[start:open_end]
    seg = seg.replace('class="course-card', 'class="course-card locked-card', 1)
    # Remove onclick so locked cards can never trigger the modal
    seg = re.sub(r'\s+onclick="showCourse\([^)]*\)"', '', seg)
    new_html = new_html[:start] + seg + new_html[open_end:]

# Patch CSS: make .locked-card share .locked-chapter styling
new_html = new_html.replace(
    '.locked-chapter{position:relative;',
    '.locked-chapter,.locked-card{position:relative;',
    1
)
new_html = new_html.replace(
    '.locked-chapter .lock-overlay{',
    '.locked-chapter .lock-overlay,.locked-card .lock-overlay{',
    1
)
new_html = new_html.replace(
    '.locked-chapter .lock-icon{',
    '.locked-chapter .lock-icon,.locked-card .lock-icon{',
    1
)
new_html = new_html.replace(
    '.locked-chapter .lock-text{',
    '.locked-chapter .lock-text,.locked-card .lock-text{',
    1
)
new_html = new_html.replace(
    '.locked-chapter .lock-sub{',
    '.locked-chapter .lock-sub,.locked-card .lock-sub{',
    1
)
# Locked-card overlay must not capture clicks (pass through the card which has pointer-events:none)
new_html = new_html.replace(
    '.locked-chapter .lock-sub,.locked-card .lock-sub{color:#cbd5e1;font-size:13px;margin-top:8px;text-align:center}',
    '.locked-chapter .lock-sub,.locked-card .lock-sub{color:#cbd5e1;font-size:13px;margin-top:8px;text-align:center}\n  .locked-card .lock-overlay{pointer-events:none!important}',
    1
)

with open('/workspace/index.html', 'w', encoding='utf-8') as f:
    f.write(new_html)

print("Done. Wrote index.html")
